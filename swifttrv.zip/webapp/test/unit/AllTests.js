sap.ui.define([
	"com/bosch/hr/swift_trv/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
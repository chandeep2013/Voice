sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	"com/bosch/hr/swift_trv/model/formatter"
], function (JSONModel, Controller, Filter, FilterOperator, Sorter, MessageBox, formatter) {
	"use strict";

	return Controller.extend("com.bosch.hr.swift_trv.controller.Master", {
		formatter: formatter,
		onInit: function () {
			this.oView = this.getView();
			this._bDescendingSort = false;
			this.oProductsTable = this.oView.byId("requestsTable");
			this.oRouter = this.getOwnerComponent().getRouter();
			var Device = sap.ui.Device.system.desktop;
			if (Device === true) {
				this.getView().byId("idSearch").setWidth("27.5rem");
			}

		},

		onSearch: function (oEvent) {
			//var sQuery = oEvent.getParameter("query");
			var sQuery = this.getView().byId("idSearch").getValue();
			var RequestNo = new sap.ui.model.Filter("RequestNo", sap.ui.model.FilterOperator.Contains, sQuery);
			var pendingWith = new sap.ui.model.Filter("pendingWith", sap.ui.model.FilterOperator.Contains, sQuery);
			var Status = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.Contains, sQuery);

			var filters = new sap.ui.model.Filter([RequestNo, pendingWith, Status]);
			var listassign = this.getView().byId("requestsTable");
			listassign.getBinding("items").filter(filters, "Appliation");
		},

		onAdd: function (oEvent) {
			//MessageBox.information("This functionality is not ready yet.", {title: "Aw, Snap!"});
			this.createFragment = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Common.CreateRequest", this.getView().getController());
			this.createFragment.open();
		},
		onCancelCreate: function () {
			this.createFragment.close();
			this.createFragment.destroy();

		},
		handleConfirm: function (oEvent) {
			var oView = this.getView();
			var oTable = oView.byId("requestsTable");
			var mParams = oEvent.getParameters();
			var oBinding = oTable.getBinding("items");
			// apply grouping 
			var aSorters = [];
			if (mParams.groupItem) {
				var sPath = mParams.groupItem.getKey();
				var bDescending = mParams.groupDescending;
				var vGroup = function (oContext) {
					var name = oContext.getProperty("Status");
					return {
						key: name,
						text: name
					};
				};
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
			}

			// apply sorter 
			// var sPath = mParams.sortItem.getKey();
			if (mParams.groupItem == undefined) {
				var sPath = "RequestNo";
			} else {
				var sPath = mParams.groupItem.getKey();
			}
			var bDescending = mParams.sortDescending;
			aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
			oBinding.sort(aSorters);
		},
		/*onSort: function (oEvent) {
			this._bDescendingSort = !this._bDescendingSort;
			var oBinding = this.oProductsTable.getBinding("items"),
				oSorter = new Sorter("RequestNo", this._bDescendingSort);

			oBinding.sort(oSorter);
		},*/
		onSort: function (oEvent) {
			//this._bDescendingSort = !this._bDescendingSort;
			var selectedButton = oEvent.getSource().getText();
			var value = "";
			if (selectedButton === "RequestNo") {
				value = "RequestNo";
			} else if (selectedButton === "PendingWith") {
				value = "pendingWith";
			} else if (selectedButton === "Status") {
				value = "Status";
			}
			var oBinding = this.oProductsTable.getBinding("items"),
				oSorter = new Sorter(value, false);

			oBinding.sort(oSorter);
		},
		onView: function (oEvent) {
			if (!this._oDialogView) {
				this._oDialogView = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Common.ViewSettings", this);
				this.getView().addDependent(this._oDialogView);
			}
			this._oDialogView.open();
		},

		onListItemPress: function (oEvent) {
			var that =this;
			if (oEvent == undefined) {
				var product = this.getView().getModel("products").getData().ProductCollection.length - 1;
				var oNextUIState;
			} else {
				var productPath = oEvent.getSource().getBindingContext("products").getPath(),
					product = productPath.split("/").slice(-1).pop(),
					oNextUIState;
			}
			this.getOwnerComponent().getHelper().then(function (oHelper) {
				oNextUIState = oHelper.getNextUIState(1);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
				oRouter.navTo("detail", {
					layout: oNextUIState.layout,
					product: product
				});
			}.bind(this));
		},
		onPressProceed: function (oEvent) {
			var that = this;
			sap.ui.core.BusyIndicator.show(1);
			var Products = this.getView().getModel("products").getData().ProductCollection;
			this.getView().getModel("products").getData().ProductCollection.push({
				"RequestNo": "--",
				"pendingWith": "Chandeep Mudigolam",
				"Status": "New",
				"From": sap.ui.getCore().byId("idFromDateC").getValue(),
				"To": sap.ui.getCore().byId("idToDateC").getValue(),
				"FromCountry": sap.ui.getCore().byId("idFromCountryC").getValue(),
				"ToCountry": sap.ui.getCore().byId("idToCountryC").getValue(),
				"FromLocation": sap.ui.getCore().byId("idFromLocationC").getValue(),
				"ToLocation": sap.ui.getCore().byId("idToLocationC").getValue(),
				"Duration": "",
				"Visa": "",
				"Purpose": "",
				"Mobile": "",
				"Insurance": "",
				"Meal": "",
				"Seat": "",
				"VisaAvailablity": "",
				"Sim": ""
			});
			this.getView().getModel("products").refresh();
			setTimeout(function () {
				sap.ui.core.BusyIndicator.hide(0);
				that.onCancelCreate();
				that.onListItemPress();
				sap.ui.getCore().getModel("products").getData().butonVisible = false;
				sap.ui.getCore().getModel("products").getData().busy = true;
				sap.ui.getCore().getModel('products').refresh();
			}, 100);

		},
	});
});
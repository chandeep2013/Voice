sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/bosch/hr/swift_trv/model/formatter",
	"sap/m/MessageBox"
], function ( Controller,formatter,MessageBox) {
	"use strict";

	return Controller.extend("com.bosch.hr.swift_trv.controller.Ticketing", {
		formatter: formatter,
		onInit: function () {
			this.oOwnerComponent = this.getOwnerComponent();

			this.oRouter = this.oOwnerComponent.getRouter();
			this.oModel = this.oOwnerComponent.getModel();

			this.oRouter.getRoute("master").attachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").attachPatternMatched(this._onProductMatched, this);
			this.nonedit_Elements();
		},
		_onProductMatched: function (oEvent) {
			this._product = oEvent.getParameter("arguments").product || this._product || "0";
			this.getView().bindElement({
				path: "/ProductCollection/" + this._product,
				model: "products"
			});
		},
		destroy:function(){
			this.getView().byId("idOption1Panel").destroyContent();
			this.getView().byId("idOption2Panel").destroyContent();
			this.getView().byId("idOption3Panel").destroyContent();
		},
		nonedit_Elements:function(){
			var objPage = this.getView().byId("idTicketPage");
			objPage.removeAllBlocks();
			//objPage.addBlock(sap.ui.xmlfragment("TravelPlan.FragmentForViews.ChangeTicket", this));
			objPage.addBlock(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Ticketing.DisplayTicketForm", this));
			this.destroy();
			this.getView().byId("idOption1Panel").addContent(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Ticketing.DisplayTicketDetailsOptionsForm", this));
			this.getView().byId("idOption2Panel").addContent(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Ticketing.DisplayTicketDetailsOptionsForm", this));
			this.getView().byId("idOption3Panel").addContent(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Ticketing.DisplayTicketDetailsOptionsForm", this));
			setTimeout(function(){ $(".sapMListTblSubCntRow").css("cssText", "display: -webkit-box !important;");
			$(".sapMListTbl .sapMLabel").css("cssText", "width: 7.8rem !important;");
			$(".sapMListTblSubCntSpr").css("cssText", "display: .5rem !important;"); }, 100);
		},
		edit_Elements: function () {

			var objPage = this.byId("idTicketPage");
			objPage.removeAllBlocks();
			objPage.addBlock(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Ticketing.ChangeTicket", this));
			this.destroy();
			this.getView().byId("idOption1Panel").addContent(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Ticketing.ChangeTicketDetailsOptionsForm", this));
			this.getView().byId("idOption2Panel").addContent(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Ticketing.ChangeTicketDetailsOptionsForm", this));
			this.getView().byId("idOption3Panel").addContent(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Ticketing.ChangeTicketDetailsOptionsForm", this));
			
			setTimeout(function(){ $(".sapMListTblSubCntRow").css("cssText", "display: block !important;");
			$(".sapMListTbl .sapMLabel").css("cssText", "width: auto !important;");
			$(".sapMListTblSubCntSpr").css("cssText", "display: None !important;"); }, 100);

		},
		handleFullScreen: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.oRouter.navTo("detail", {layout: sNextLayout, product: this._product});
		},

		handleExitFullScreen: function () {
			if(this._product == undefined){
				this._product = 0;
			}
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
			this.oRouter.navTo("detail", {layout: sNextLayout, product: this._product});
		},

		handleClose: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
			this.oRouter.navTo("master", {layout: sNextLayout});
		},

		onExit: function () {
			this.oRouter.getRoute("master").detachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").detachPatternMatched(this._onProductMatched, this);
		},
		onComnetButtonPress:function(){
			var oCommentDialog = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Common.Comments", this);
			this.getView().addDependent(oCommentDialog);
			oCommentDialog.open();
		},
		pressDecline: function (oEvent) {
			oEvent.getSource().getParent().getParent().close();
			oEvent.getSource().getParent().getParent().destroy();
		},
		onEditToggleButtonPress:function(){
		var oObjectPage = this.getView().byId("ObjectPageTicketLayout"),
		bCurrentShowFooterState = oObjectPage.getShowFooter();
		oObjectPage.setShowFooter(!bCurrentShowFooterState);

		if (!bCurrentShowFooterState == true) {
			this.getView().getModel("products").getData().editable = true;
			this.getView().getModel("products").getData().busy = true;
			this.getView().getModel("products").refresh();
			sap.ui.getCore().getModel("products").getData().butonVisible = false;
			sap.ui.getCore().getModel("products").getData().busy = true;
			sap.ui.getCore().getModel('products').refresh();
			this.edit_Elements();
		} else {
			this.getView().getModel("products").getData().editable = false;
			this.getView().getModel("products").getData().busy = false;
			this.getView().getModel("products").refresh();
			sap.ui.getCore().getModel("products").getData().butonVisible = true;
			sap.ui.getCore().getModel("products").getData().busy = false;
			sap.ui.getCore().getModel('products').refresh();
			this.nonedit_Elements();

		}
	},
	onPressSave:function(){

		this.getView().getModel("products").getData().editable = false;
		this.getView().getModel("products").refresh();

		var oObjectPage = this.getView().byId("ObjectPageTicketLayout");
		oObjectPage.setShowFooter(false);
		sap.ui.getCore().getModel("products").getData().butonVisible = true;
		sap.ui.getCore().getModel("products").getData().busy = false;
		sap.ui.getCore().getModel('products').refresh();
		sap.m.MessageBox.confirm("Saved Successfully..!!!", {
			icon: MessageBox.Icon.INFORMATION,
			title: "Success",
			actions: [MessageBox.Action.OK],
			onClose: function (oAction) {}
		});
		this.nonedit_Elements();
	},
	onPressCancel:function(){
		this.getView().getModel("products").getData().editable = false;
		this.getView().getModel("products").refresh();

		var oObjectPage = this.getView().byId("ObjectPageTicketLayout");
		oObjectPage.setShowFooter(false);
		sap.ui.getCore().getModel("products").getData().butonVisible = true;
		sap.ui.getCore().getModel("products").getData().busy = false;
		sap.ui.getCore().getModel('products').refresh();
		
		this.nonedit_Elements();
	}
	});

});
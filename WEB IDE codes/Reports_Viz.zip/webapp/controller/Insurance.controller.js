sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/bosch/hr/swift_trv/model/formatter",
	"sap/ui/model/json/JSONModel",
	'sap/m/ColumnListItem',
	'sap/m/Input',
	'sap/m/DatePicker',
	"sap/m/MessageBox"
], function (Controller, formatter, JSONModel, ColumnListItem, Input, DatePicker, MessageBox) {
	"use strict";

	return Controller.extend("com.bosch.hr.swift_trv.controller.Insurance", {
		formatter: formatter,
		onInit: function () {
			var that = this;
			this.oOwnerComponent = this.getOwnerComponent();

			this.oRouter = this.oOwnerComponent.getRouter();
			this.oModel = this.oOwnerComponent.getModel();

			this.oRouter.getRoute("master").attachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").attachPatternMatched(this._onProductMatched, this);

			var detailModel = new JSONModel();
			var get = $.ajax({
				cache: false,
				url: "model/data.json",
				type: "GET",
				async: false
			});
			get.done(function (result) {
				detailModel.setData(result);
				that.getView().setModel(detailModel, "detail");
			});
			get.fail(function (err) {
			});

			/************************* Travel Details Table********************************/

			this.TravellingTable = this.byId("idTravellingTable");
			this.oReadOnlyTemplate_T = this.byId("idTravellingTable").removeItem(0);
			this.rebindTable_T(this.oReadOnlyTemplate_T, "Navigation");
			this.oEditableTemplate_T = new ColumnListItem({
				cells: [
					new Text({
						text: ""
					}),
					new Input({
						value: "{detail>Name}"
					}), new sap.m.Input({
						value: "{detail>Relation}"
					}),
					
					new sap.m.Select ({
						value: "{detail>Visa}",
						width: "100%",
						items: {
							path: "detail>/Visa",
							templateShareable: false,
							template: new sap.ui.core.Item({
								key: "{detail>key}",
								text: "{detail>title}"
							})

						}
					}),
					
					new sap.m.Select ({
						placeholder: "Mode",
						value: "{detail>Payment}",
						width: "100%",
						items: {
							path: "detail>/Payment",
							templateShareable: false,
							template: new sap.ui.core.Item({
								key: "{detail>key}",
								text: "{detail>title}"
							})

						}
					}),
					new Input({
						value: "{detail>Ins}"
					}),
					new sap.m.DatePicker({
						value: "{detail>DOB}"
					}),
					new Input({
						value: "{detail>Passport}"
					})
				]
			});

			/**********************************************************/

			/************************* Dependent Details Table********************************/

			this.DependentTable = this.byId("idDependentTable");
			this.oReadOnlyTemplate_D = this.byId("idDependentTable").removeItem(0);
			this.rebindTable_D(this.oReadOnlyTemplate_D, "Navigation");
			this.oEditableTemplate_D = new ColumnListItem({
				cells: [
					new Text({
						text: ""
					}),
					new Input({
						value: "{detail>Name}"
					}), new sap.m.Input({
						value: "{detail>Relation}"
					}),
					new sap.m.Select ({
						placeholder: "Mode",
						value: "{detail>Visa}",
						width: "100%",
						items: {
							path: "detail>/Visa",
							templateShareable: false,
							template: new sap.ui.core.Item({
								key: "{detail>key}",
								text: "{detail>title}"
							})

						}
					}),
					new sap.m.Select ({
						placeholder: "Mode",
						value: "{detail>Payment}",
						width: "100%",
						items: {
							path: "detail>/Payment",
							templateShareable: false,
							template: new sap.ui.core.Item({
								key: "{detail>key}",
								text: "{detail>title}"
							})

						}
					}),
					new Input({
						value: "{detail>Ins}"
					}),
					new sap.m.DatePicker({
						value: "{detail>DOB}"
					}),
					new Input({
						value: "{detail>Passport}"
					}),
					new sap.m.DatePicker({
						value: "{detail>StartDate}"
					}),
					new sap.m.DatePicker({
						value: "{detail>EndDate}"
					}),
				]
			});

			/**********************************************************/
			
			

		},
		rebindTable_T: function (oTemplate, sKeyboardMode) {
			this.TravellingTable.bindItems({
				path: "detail>/TravelMembers",
				template: oTemplate,
				templateShareable: true,
				key: "Visa"
			}).setKeyboardMode(sKeyboardMode);
		},
		rebindTable_D: function (oTemplate, sKeyboardMode) {
			this.DependentTable.bindItems({
				path: "detail>/TravelMembers1",
				template: oTemplate,
				templateShareable: true,
				key: "Visa"
			}).setKeyboardMode(sKeyboardMode);
		},
		
		onAfterRendering: function () {

			var Device = sap.ui.Device.system.desktop;

			if (Device === true || sap.ui.Device.system.tablet) {
				this.getView().byId("idTravellingTable").getInfoToolbar().setVisible(true);
				this.getView().byId("idDependentTable").getInfoToolbar().setVisible(true);
				
				this.getView().byId("idTravellingColumn").setVisible(false);
				this.getView().byId("idDependentColumn").setVisible(false);
			} else {
				this.getView().byId("idTravellingTable").getInfoToolbar().setVisible(false);
				this.getView().byId("idDependentTable").getInfoToolbar().setVisible(false);
				
				this.getView().byId("idTravellingColumn").setVisible(true);
				this.getView().byId("idDependentColumn").setVisible(true);
			}

		},
		
		onEditToggleButtonPress: function () {
			var oObjectPage = this.getView().byId("ObjectPageLayout"),
				bCurrentShowFooterState = oObjectPage.getShowFooter();
			oObjectPage.setShowFooter(!bCurrentShowFooterState);

			if (!bCurrentShowFooterState == true) {
				this.getView().getModel("products").getData().editable = true;
				this.getView().getModel("products").refresh();
				this.rebindTable_T(this.oEditableTemplate_T, "Edit");
				this.rebindTable_D(this.oEditableTemplate_D, "Edit");
				
				setTimeout(function(){ $(".sapMListTblSubCntRow").css("cssText", "display: block !important;");
				$(".sapMListTbl .sapMLabel").css("cssText", "width: auto !important;");
				$(".sapMListTblSubCntSpr").css("cssText", "display: None !important;"); }, 100);
				
			} else {
				this.getView().getModel("products").getData().editable = false;
				this.getView().getModel("products").refresh();
				this.rebindTable_T(this.oReadOnlyTemplate_T, "Navigation");
				this.rebindTable_D(this.oReadOnlyTemplate_D, "Navigation");
				
				setTimeout(function(){ $(".sapMListTblSubCntRow").css("cssText", "display: -webkit-box !important;");
				$(".sapMListTbl .sapMLabel").css("cssText", "width: 7.8rem !important;");
				$(".sapMListTblSubCntSpr").css("cssText", "display: .5rem !important;"); }, 100);
			}
		},
		onSave: function () {
			this.getView().getModel("products").getData().editable = false;
			this.getView().getModel("products").refresh();
			setTimeout(function(){ $(".sapMListTblSubCntRow").css("cssText", "display: -webkit-box !important;");
			$(".sapMListTbl .sapMLabel").css("cssText", "width: 7.5rem !important;");
			$(".sapMListTblSubCntSpr").css("cssText", "display: .5rem !important;"); }, 100);
			var oObjectPage = this.getView().byId("ObjectPageLayout"),
				bCurrentShowFooterState = oObjectPage.getShowFooter();
			oObjectPage.setShowFooter(false);
			sap.m.MessageBox.confirm("Request saved Successfully..!!!", {
				icon: MessageBox.Icon.INFORMATION,
				title: "Success",
				actions: [MessageBox.Action.OK],
				onClose: function (oAction) {}
			});
			this.rebindTable_T(this.oReadOnlyTemplate_T, "Navigation");
			this.rebindTable_D(this.oReadOnlyTemplate_D, "Navigation");

		},
		onCancel: function () {
			var oObjectPage = this.getView().byId("ObjectPageLayout"),
				bCurrentShowFooterState = oObjectPage.getShowFooter();
			oObjectPage.setShowFooter(false);
			this.rebindTable_T(this.oReadOnlyTemplate_T, "Navigation");
			this.rebindTable_D(this.oReadOnlyTemplate_D, "Navigation");
		},
		_onProductMatched: function (oEvent) {
			this._product = oEvent.getParameter("arguments").product || this._product || "0";
			this.getView().bindElement({
				path: "/ProductCollection/" + this._product,
				model: "products"
			});
		},
		handleFullScreen: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.oRouter.navTo("detail", {
				layout: sNextLayout,
				product: this._product
			});
		},

		handleExitFullScreen: function () {
			if (this._product == undefined) {
				this._product = 0;
			}
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
			this.oRouter.navTo("detail", {
				layout: sNextLayout,
				product: this._product
			});
		},

		handleClose: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
			this.oRouter.navTo("master", {
				layout: sNextLayout
			});
			this.rebindTable_T(this.oReadOnlyTemplate_T, "Navigation");
			this.rebindTable_D(this.oReadOnlyTemplate_D, "Navigation");
		},

		onExit: function () {
			this.oRouter.getRoute("master").detachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").detachPatternMatched(this._onProductMatched, this);
		},
		onComnetButtonPress: function () {
			var oCommentDialog = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.Common.Comments", this);
			this.getView().addDependent(oCommentDialog);
			oCommentDialog.open();
		},
		pressDecline: function (oEvent) {
			oEvent.getSource().getParent().getParent().close();
			oEvent.getSource().getParent().getParent().destroy();
		},

	});

});
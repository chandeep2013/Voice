sap.ui.define([
	"sap/ui/core/BusyIndicator",
	"sap/m/MessageBox",
	"sap/m/MessageStrip",
	"sap/ui/core/mvc/Controller",
	"sap/suite/ui/commons/ChartContainer",
	"sap/suite/ui/commons/ChartContainerContent",
	"sap/viz/ui5/controls/Popover",
	'sap/ui/core/Fragment'

], function (BusyIndicator, MessageBox, MessageStrip, Controller, ChartContainer, ChartContainerContent, Popover, Fragment) {
	"use strict";
	var oControllerThis, appView, rightPanelForImg;
	var Plant, PlantDesc, Category, WC, WCDesc, PackageName, PackageId, thingId, thingType, ThingName, ThingDesc, oTree,
		aSelectedItems, woHistoryModel, EquipmentRecordsArray,
		treeModelData, oSelectTimeDialogChartKey, EnergyArray, thingTypeName,
		reqBody, oChartModel, sFromDateValue, sToDateValue, DateFlag = 0;
	var flagChartDialog = 0;
	var OpenWorkModel, PMDueModel, MaintananceModel;
	var gaugeRecord, children, thingsArray = [],
		FromDateTime, ToDateTime;

	return Controller.extend("ui_app.SustainableManufacturingAsset_MonitoringDashboard.controller.View1", {

		onInit: function (oEvent) {
			if (!window.location.href.includes("notificationView")) {
				oControllerThis = this;
				appView = this.getView();
				BusyIndicator.show(0);
				appView.byId("ui_page").setVisible(true);
				//Added by maviya for panel in the left
				/*var ms = 86400000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
				var dt = new Date();
				dt.setTime(dt.getTime() - (330 * 60 * 1000));
				var toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				var subtract1hr = dt;
				subtract1hr.setTime(dt.getTime() - ms);
				var fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				console.log(fromDateTime + "-------" + toDateTime);
				appView.byId("FromDt").setValue(fromDateTime.replace('Z', ''));
				appView.byId("ToDt").setValue(toDateTime.replace('Z', ''));*/

				Plant = jQuery.sap.getUriParameters().get("Plant");
				FromDateTime = jQuery.sap.getUriParameters().get("FromDateTime");
				ToDateTime = jQuery.sap.getUriParameters().get("ToDateTime");
			}

		},

		onAfterRendering: function () {
			////#################### 002JH6-Chamdeep Changes ################////
			if (FromDateTime && ToDateTime) {
				this.getView().byId("FromDt").setValue(FromDateTime);
				this.getView().byId("ToDt").setValue(ToDateTime);
			} else {
				var ms = 86400000; // 1 hr =3600000// 86400000 = 1 day
				var dt = new Date();
				dt.setTime(dt.getTime() - (8 * 3600000));
				var fromDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', '');
				this.getView().byId("FromDt").setValue(fromDateTime);
				var dt = new Date();
				dt.setTime(dt.getTime());
				var toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', '');
				//var toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', '');
				this.getView().byId("ToDt").setValue(toDateTime);
			}
			if (!window.location.href.includes("notificationView")) {
				//call the service to get the digital twin model
				$.ajax({
					method: "POST",
					contentType: "application/json",
					url: "/node/GetIoTAEMultiLevelHierarchyToMonitor",
					async: true,
					success: function (result) {
						treeModelData = new sap.ui.model.json.JSONModel(result);
						appView.byId("DigitalTwinTree").setModel(treeModelData);
						BusyIndicator.hide();
						appView.byId("DigitalTwinTree").expandToLevel(result.Level);
						rightPanelForImg = appView.byId("rightPanelForImg");
						//
						/*	$.getScript("https://" + result.Host + "/socket.io/socket.io.js", function () {
								console.log('script is loaded');
								socket = io.connect('https://' + result.Host + '/PTM_Socket');
								socket.on('RefreshNotification', function (data) {
									console.log("socket > RefreshNotification : " + JSON.parse(data).ThingName);
									if (ThingName == JSON.parse(data).ThingName) {
										oControllerThis.getNotificationList(ThingName);
									}
								});
								socket.on('NotificationCount', function (data) {
									console.log("socket > NotificationCount : " + JSON.parse(data).ThingId + ":" + JSON.parse(data).PropertySet);
									var jsonData = JSON.parse(data);
									oControllerThis.showMsgStrip(jsonData.Msg, "Error");
									if (rightPanelForImg.getVisible() == true && thingId != "" && thingId !== undefined) {
										reqBody = {
											"PackageName": PackageId,
											"ThingId": thingId,
											"ThingType": thingType
										}
										oControllerThis.getEquipmentTags(reqBody, 1);
										oControllerThis.PaneData();
									}
									if (jsonData.ThingId == thingId ) {
										oControllerThis.getNotificationList(ThingName);
										console.log("eqp/thing matched");
									}
								});
								socket.on('disconnect', function (data) {
									console.log("Disconnected");
								});
							});*/
						/*setInterval(function () {
							console.log("RefreshImg : DateFlag " + DateFlag);
							if (thingId !== "" && thingId !== undefined) {
								reqBody = {
									"PackageName": PackageId,
									"ThingId": thingId,
									"ThingType": thingType
								};
								//	oControllerThis.getEquipmentTags(reqBody, 1);
								if (!Category.toUpperCase().includes(("WorkCenter").toUpperCase())) {
									if (DateFlag === 0) {
										oControllerThis.GetPropertyValues(thingId, PackageId, thingType, "SDAMTrigger");
										oControllerThis.GetPropertyValues(thingId, PackageId, thingType, "RootCause");
										oControllerThis.GetPropertyValues(thingId, PackageId, thingType, "Accuracy");
										oControllerThis.getNotificationList(ThingName);
										oControllerThis.GetWOHistory(ThingName);
										oControllerThis.GetWorkOrdersCount(ThingName);
										oControllerThis.GetPMWorkOrdersDueCount(ThingName);
										oControllerThis.onRefreshPress();
									} else {
										appView.byId("PredRootCauseValue").setContentText("");
										appView.byId("SDAMStatus").setContentText("");
										//appView.byId("AccuracyID").setValue(0);
										appView.byId("PredRootCauseValue").setSubheader("Confidence:0%");
										appView.byId("SDAMStatusTile").addStyleClass("blackTile");
										appView.byId("SDAMStatusTile").removeStyleClass("redTile");
										appView.byId("SDAMStatusTile").removeStyleClass("greenTile");
										oControllerThis.getNotificationListData(ThingName, sFromDateValue, sToDateValue);
										oControllerThis.getOpenWorkOrdersListData(ThingName, sFromDateValue, sToDateValue);
										oControllerThis.getPMWorkOrdersDueListData(ThingName, sFromDateValue, sToDateValue);
										oControllerThis.getWOHistoryListData(ThingName, sFromDateValue, sToDateValue);
									}
								} else {
									//appView.byId("notifNumericContent").setVisible(false);
								}
							}
						}, 40000);*/

						setTimeout(function () {
							///////####################002JH6- Chamdeep Changes ############################//////////////
							if (Plant) {
								oTree = appView.byId("DigitalTwinTree");
								var Items = oTree.getItems();
								for (var i = 0; i < Items.length; i++) {
									if (Items[i].getTitle().indexOf(Plant) > -1 && Items[i].getParentNodeContext().level === -1) {
										oTree.setSelectedItem(Items[i]);
										oTree.fireSelectionChange();
										break;
									}
								}
							}
							///////////////############### Chamdeep changes end#######################//////////////////////////////
						}, 500);

					},
					error: function (errorThrown) {
						console.log("GetIoTAEMultiLevelHierarchyToMonitor error " + JSON.stringify(errorThrown));
						BusyIndicator.hide();
					}
				});
			}

			var visibilityFalse = ["idOpenWR", "idPMDue", "idCorrectiveWR", "SDAMStatusTile", "idRootCause"];
			for (var i = 0; i < visibilityFalse.length; i++) {
				this.getView().byId(visibilityFalse[i]).setVisible(false);
			}
			//// For Plant Level
			var visibilityTrue = ["idEHSComplianceTile", "idEmissionIncidents", "idTotalSafetyIncidents", "idUtilityAvgTile",
				"idUtilityTotalTile"
			];
			for (var i = 0; i < visibilityTrue.length; i++) {
				this.getView().byId(visibilityTrue[i]).setVisible(true);
			}
			this.getView().byId("idNotifTable").setVisible(false);
			this.getView().byId("ProcessVisibilityBtnID").setVisible(false);
		},
		GetPropertyValues: function (ThingId, Package, ThingType, propertySet) {
			var RequestBody = {
				"ThingId": ThingId,
				"PackageName": Package,
				"ThingType": ThingType,
				"propertySet": propertySet
			};
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/getThingData",
				data: JSON.stringify(RequestBody),
				async: false,
				success: function (result) {
					if (result.value !== undefined)
						if (result.value.length === 0) {
							appView.byId("PredRootCauseValue").setContentText("");
							appView.byId("SDAMStatus").setContentText("");
							//appView.byId("AccuracyID").setValue(0);
							appView.byId("PredRootCauseValue").setSubheader("Confidence:0%");
						} else {
							//console.log(result.value);
							var resultArray = result.value[0];
							var Key;
							for (var key in resultArray) {
								if (resultArray.hasOwnProperty(key)) {
									//console.log("Key " + key + "::::" + resultArray[key]);
									Key = key;
								}
							}
							if (Key === "PredictedRootCause") {
								appView.byId("PredRootCauseValue").setContentText(resultArray[key]);
							} else if (Key === "SDAMValue") {
								//appView.byId("SDAMStatus").setContentText(resultArray[key]);
								if (resultArray[key] === "ON") {
									appView.byId("SDAMStatus").setContentText(resultArray[key]);
									appView.byId("SDAMStatusTile").addStyleClass("redTile");
									appView.byId("SDAMStatusTile").removeStyleClass("greenTile");
									appView.byId("SDAMStatusTile").removeStyleClass("blackTile");
								} else if (resultArray[key] === "") {
									appView.byId("SDAMStatus").setContentText("");
									appView.byId("SDAMStatusTile").addStyleClass("greenTile");
									appView.byId("SDAMStatusTile").removeStyleClass("redTile");
									appView.byId("SDAMStatusTile").removeStyleClass("blackTile");
								} else if (resultArray[key] === "OFF") {
									appView.byId("SDAMStatus").setContentText("");
									appView.byId("SDAMStatusTile").addStyleClass("greenTile");
									appView.byId("SDAMStatusTile").removeStyleClass("redTile");
									appView.byId("SDAMStatusTile").removeStyleClass("blackTile");
								}
							} else if (Key === "AccuracyValue") {
								//appView.byId("AccuracyID").setValue(resultArray[key] + "%");
								appView.byId("PredRootCauseValue").setSubheader("Confidence:" + resultArray[key] + "%");
							}
						}
				},
				error: function (errorThrown) {
					console.log("getThingData error " + JSON.stringify(errorThrown));
				}
			});
		},

		getThingOfTypeEquipment: function (obj) {
			var that = this;
			if (obj.Category == "Equipment") {
				thingsArray.push(obj.Name);
				//console.log(idArray);
			}
			if (!obj.children) {
				return
			}

			obj.children.forEach(child => that.getThingOfTypeEquipment(child))
		},

		onSelect: function () {
			oTree = appView.byId("DigitalTwinTree");
			aSelectedItems = oTree.getSelectedItem();
			////################ 002JH6-Chamdeep Changes########################///////////////
			this.getView().byId("rightPanelForPanelAnalytical").setVisible(false);
			sFromDateValue = this.getView().byId("FromDt").getValue();
			sToDateValue = this.getView().byId("ToDt").getValue();
			if (aSelectedItems !== null) {
				PackageName = aSelectedItems.getBindingContext().getProperty("ThingPkg");
				PackageId = aSelectedItems.getBindingContext().getProperty("ThingPkgName");
				thingId = aSelectedItems.getBindingContext().getProperty("ThingId");
				thingTypeName = aSelectedItems.getBindingContext().getProperty("ThingTypeName");
				thingType = aSelectedItems.getBindingContext().getProperty("ThingType");
				ThingName = aSelectedItems.getBindingContext().getProperty("Name");
				ThingDesc = aSelectedItems.getBindingContext().getProperty("ThingDesc");
				Category = aSelectedItems.getBindingContext().getProperty("Category");
				children = aSelectedItems.getBindingContext().getProperty("children");
				console.log("ThingName---" + ThingName + "thingId---" + thingId + "PackageId-----" + PackageId);

				if (Category === "FunctionLocation") {
					this.FunctionalLocationSelected = true;
					this.getView().byId("rightPanelForPanelAnalytical").setVisible(true);
					this.getView().byId("idVizFrame2").setVisible(false);
					this.getView().byId("idVizFrame5").setVisible(false);
					var things = {
						children: children
					};
					thingsArray = [];
					this.getThingOfTypeEquipment(things);
					this.getNotificationCountForFL(thingsArray);
					Plant = aSelectedItems.getBindingContext().getProperty("ThingTypeName").split(":")[0].split(".")[2];
					this.getEHSComplianceData("PLANT_ID eq '" + Plant + "' and FUNCT_LOC_ID eq '" + ThingName + "'");
					this.getTotalIncidents("(PLANT_ID eq '" + Plant + "') and (FUNCT_LOC_ID eq '" + ThingName + "')", sFromDateValue, sToDateValue);
				} else {
					this.FunctionalLocationSelected = false;
					this.getView().byId("idVizFrame2").setVisible(true);
					this.getView().byId("idVizFrame5").setVisible(true);
				}
				if (Category === "Equipment") {
					this.getView().byId("idEquipmentImage").setVisible(true);
				} else {
					this.getView().byId("idEquipmentImage").setVisible(false);
				}
				var visibilityFalse = ["idOpenWR", "idPMDue", "idCorrectiveWR", "SDAMStatusTile", "idRootCause"];
				for (var i = 0; i < visibilityFalse.length; i++) {
					if (thingId == undefined || Category === "FunctionLocation") {
						this.getView().byId(visibilityFalse[i]).setVisible(false);
					} else {
						this.getView().byId(visibilityFalse[i]).setVisible(true);
					}
				}
				//// For Plant Level
				var visibilityTrue = ["idEHSComplianceTile", "idEmissionIncidents", "idTotalSafetyIncidents", "idUtilityAvgTile",
					"idUtilityTotalTile"
				];
				for (var i = 0; i < visibilityTrue.length; i++) {
					if (thingId == undefined || Category === "FunctionLocation") {
						this.getView().byId(visibilityTrue[i]).setVisible(true);
					} else {
						this.getView().byId(visibilityTrue[i]).setVisible(false);
					}
				}

				if (thingId !== undefined) {
					this.getView().byId("ProcessVisibilityBtnID").setVisible(true);
					var reqBody = {
						"PackageName": PackageId,
						"ThingId": aSelectedItems.getBindingContext().getProperty("ThingId"),
						"ThingType": thingType
					}
					Plant = aSelectedItems.getBindingContext().getProperty("ThingTypeName").split(":")[0].split(".")[2];
					PlantDesc = aSelectedItems.getBindingContext().getProperty("ThingPkgDesc");
					WC = aSelectedItems.getBindingContext().getProperty("WorkCenter");
					WCDesc = aSelectedItems.getBindingContext().getProperty("WorkCenterDesc");
					appView.byId("subHeaderTH").setVisible(true);
					appView.byId("plant").setText(PlantDesc + "(" + Plant + ")");
					appView.byId("thingLbl").setText(Category + " : ");
					appView.byId("equipment").setText(ThingDesc + "(" + ThingName + ")");
					this.RootNodeSelected = false;
					if (Category === "FunctionLocation") {
						var ThingPkgName = aSelectedItems.getBindingContext().getProperty("children")[0].ThingPkgName;
						var SelectedPlant = aSelectedItems.getBindingContext().getProperty("children")[0].Name;

						this._onvizCharts(ThingPkgName, SelectedPlant, ThingName, thingId, thingTypeName);
						/*var filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + ThingPkgName +
							":" + thingType + "'";*/
						var filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + thingTypeName + "'";
						oControllerThis.loadPropertyChartPlantOrThing(ThingPkgName, sFromDateValue, sToDateValue, filter);
					}
					//for work center notification will not be there

					if (!Category.toUpperCase().includes(("WorkCenter").toUpperCase())) {
						//oControllerThis.GetPropertyValues(thingId, PackageId, thingType, "SDAMTrigger");
						//oControllerThis.GetPropertyValues(thingId, PackageId, thingType, "RootCause");
						appView.byId("PredRootCauseValue").setContentText("");
						appView.byId("SDAMStatus").setContentText("");
						//appView.byId("AccuracyID").setValue(0);
						appView.byId("PredRootCauseValue").setSubheader("Confidence:0%");
						appView.byId("SDAMStatusTile").addStyleClass("blackTile");
						appView.byId("SDAMStatusTile").removeStyleClass("redTile");
						appView.byId("SDAMStatusTile").removeStyleClass("greenTile");
						if (Category !== "FunctionLocation") {
							oControllerThis.getNotificationList(ThingName);
						}
						oControllerThis.GetWOHistory(ThingName);
						oControllerThis.GetWorkOrdersCount(ThingName);
						oControllerThis.GetPMWorkOrdersDueCount(ThingName);
						appView.byId("wcLbl").setVisible(true);
						appView.byId("wc").setVisible(true);
						appView.byId("wc").setText(WCDesc + "(" + WC + ")");
					} else {
						//appView.byId("notifNumericContent").setVisible(false);
						appView.byId("wcLbl").setVisible(false);
						appView.byId("wc").setVisible(false);
					}
					oControllerThis.getEquipmentTags(reqBody, 0);
					oControllerThis.PaneData();
				} else {
					rightPanelForImg.destroyContent();
					PackageName = "";
					PackageId = "";
					thingId = "";
					thingType = "";
					ThingName = "";
					ThingDesc = "";
					Category = "";
					WC = "";
					WCDesc = "";
					//appView.byId("notifNumericContent").setVisible(false);
					/////############################################# 002JH6- Chamdeep changes start ##########################//////////
					this.RootNodeSelected = true;
					this.FunctionalLocationSelected = false;
					this.getView().byId("rightPanelForPanelAnalytical").setVisible(true);
					var ThingPkgName = aSelectedItems.getBindingContext().getProperty("children")[0].ThingPkgName;
					this.getView().byId("ProcessVisibilityBtnID").setVisible(false);
					//var SelectedPlant = aSelectedItems.getBindingContext().getProperty("children")[0].Name;
					var SelectedPlant = aSelectedItems.getBindingContext().getProperty("Name");
					this._onvizCharts(ThingPkgName, SelectedPlant);
					this.getNotificationListData(ThingName, sFromDateValue, sToDateValue, SelectedPlant);
					this.getEHSComplianceData("PLANT_ID eq '" + SelectedPlant + "'");
					this.getTotalIncidents("(PLANT_ID eq '" + SelectedPlant + "') ", sFromDateValue, sToDateValue);
					var filter = "?$filter=startswith(_thingType,'" + ThingPkgName + ":FunctionLocation')";
					oControllerThis.loadPropertyChartPlantOrThing(ThingPkgName, sFromDateValue, sToDateValue, filter);
				}

				/*var ms = 86400000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
				var dt = new Date();
				dt.setTime(dt.getTime() - (330 * 60 * 1000));
				var toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				var subtract1hr = dt;
				subtract1hr.setTime(dt.getTime() - ms);
				var fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				console.log(fromDateTime + "-------" + toDateTime);
				sFromDateValue = fromDateTime;
				sToDateValue = toDateTime;
				appView.byId("FromDt").setValue(sFromDateValue.replace('Z', ''));
				appView.byId("ToDt").setValue(sToDateValue.replace('Z', ''));*/
				//appView.byId("btnDtSubmit").setEnabled(true);
				//appView.byId("btnDtReset").setEnabled(true);
			} else {
				PackageName = "";
				PackageId = "";
				thingId = "";
				thingType = "";
				ThingName = "";
				ThingDesc = "";
				Category = "";
				WC = "";
				WCDesc = "";
				//	appView.byId("notifNumericContent").setVisible(false);
			}
			var ms = 86400000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
			var dt = new Date();
			dt.setTime(dt.getTime() - (330 * 60 * 1000));
			var toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
			var subtract1hr = dt;
			subtract1hr.setTime(dt.getTime() - ms);
			var fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
			//console.log(fromDateTime + "-------" + toDateTime);

			oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
		},
		///////##################################### 002JH6-Chamdeep changes start #######################################/////
		_onvizCharts: function (ThingPkgName, SelectedPlant, ThingName, thingId, thingTypeName) {
			var that = this;
			var vizModel = new sap.ui.model.json.JSONModel();
			var FLWiseModel = new sap.ui.model.json.JSONModel();
			var TotalDataForPlantModel = new sap.ui.model.json.JSONModel();
			sFromDateValue = this.getView().byId("FromDt").getValue();
			sToDateValue = this.getView().byId("ToDt").getValue();
			var GetAvgDataForPlantOrThing = jQuery.Deferred();
			var GetAvgDataForPlantOrThing_Energy = jQuery.Deferred();
			var GetDataForPlantFLWise = jQuery.Deferred();
			//	var GetDataForPlantFLWise_Energy = jQuery.Deferred();
			var GetStockPlantwise = jQuery.Deferred();
			var GetTotalDataForPlantOrThing = jQuery.Deferred();
			var GetTotalDataForPlantOrThing_Energy = jQuery.Deferred();
			var loadPropertyChartPlantOrThing = jQuery.Deferred();
			BusyIndicator.show(-1);
			//For Emission
			var data = {
				"PackageName": ThingPkgName,
				"fromDateTime": sFromDateValue + "Z",
				"toDateTime": sToDateValue + "Z",
				"PropertySet": "TOXIC" //ENERGY
			};
			if (this.FunctionalLocationSelected === false) {
				data.filter = "?$filter=startswith(_thingType,'" + ThingPkgName + ":FunctionLocation')";
			} else {
				//data.filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + ThingPkgName +":" + thingType + "'";
				data.filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + thingTypeName + "'";
			}
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetAvgDataForPlantOrThing",
				data: JSON.stringify(data),
				async: true,
				success: function (result) {
					GetAvgDataForPlantOrThing.resolve();
					//	console.log(result);
					vizModel.setData(result);
					//	sap.ui.getCore().setModel(vizModel, "vizEmission");
					//	that.getView().setModel(vizModel, "vizEmission");
					that.getView().byId("idVizFrame1").setModel(vizModel);
					//BusyIndicator.hide();
				},
				error: function (errorThrown) {
					GetAvgDataForPlantOrThing.resolve();
					console.log("GetAvgDataForPlantOrThing error " + JSON.stringify(errorThrown));
					//	BusyIndicator.hide();
				}
			});

			//For Avg Utility
			var AvgDataUtility = {
				"PackageName": ThingPkgName,
				"fromDateTime": sFromDateValue + "Z",
				"toDateTime": sToDateValue + "Z",
				"PropertySet": "ENERGY"
			};
			if (this.FunctionalLocationSelected === false) {
				AvgDataUtility.filter = "?$filter=startswith(_thingType,'" + ThingPkgName + ":FunctionLocation')";
			} else {
				AvgDataUtility.filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + thingTypeName + "'";
			}

			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetAvgDataForPlantOrThing",
				data: JSON.stringify(AvgDataUtility),
				async: true,
				success: function (result) {
					GetAvgDataForPlantOrThing_Energy.resolve();
					//	console.log(result);
					if (result.length == 1) {
						that.getView().byId("idUtilityNotify").setValue(result[0].average);
						that.getView().byId("idUtilityNotify").setScale(result[0].uom);
					} else {
						that.getView().byId("idUtilityNotify").setValue("0");
						that.getView().byId("idUtilityNotify").setScale("");
					}
					//BusyIndicator.hide();
				},
				error: function (errorThrown) {
					GetAvgDataForPlantOrThing_Energy.resolve();
					console.log("GetAvgDataForPlantOrThing error " + JSON.stringify(errorThrown));
					//	BusyIndicator.hide();
				}
			});

			//For Total Utility
			var TotalDataUtility = {
				"PackageName": ThingPkgName,
				"fromDateTime": sFromDateValue + "Z",
				"toDateTime": sToDateValue + "Z",
				"PropertySet": "ENERGY"
			};

			if (this.FunctionalLocationSelected === false) {
				TotalDataUtility.filter = "?$filter=startswith(_thingType,'" + ThingPkgName + ":FunctionLocation')";
			} else {
				TotalDataUtility.filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + thingTypeName + "'";
			}
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetTotalDataForPlantOrThing",
				data: JSON.stringify(TotalDataUtility),
				async: true,
				success: function (result) {
					GetTotalDataForPlantOrThing_Energy.resolve();
					//	console.log(result);
					if (result.length == 1) {
						that.getView().byId("idUtilityTotalNotify").setValue(result[0].total);
						that.getView().byId("idUtilityTotalNotify").setScale(result[0].uom);

						that.getView().byId("idEnergyProgressIndicator").setDisplayValue(result[0].total + " " + result[0].uom);
						that.getView().byId("idEnergyProgressIndicator").setPercentValue("50");
					} else {
						that.getView().byId("idUtilityTotalNotify").setValue("0");
						that.getView().byId("idUtilityTotalNotify").setScale("");
						that.getView().byId("idEnergyProgressIndicator").setDisplayValue("0");
						that.getView().byId("idEnergyProgressIndicator").setPercentValue("0");
					}
					//BusyIndicator.hide();
				},
				error: function (errorThrown) {
					GetTotalDataForPlantOrThing_Energy.resolve();
					console.log("GetAvgDataForPlantOrThing error " + JSON.stringify(errorThrown));
					//	BusyIndicator.hide();
				}
			});

			var FLWise = {
				"PackageName": ThingPkgName,
				"fromDateTime": sFromDateValue + "Z",
				"toDateTime": sToDateValue + "Z",
				"PropertySet": "TOXIC"
			};
			if (this.FunctionalLocationSelected === false) {
				FLWise.filter = "?$filter=startswith(_thingType,'" + ThingPkgName + ":FunctionLocation')";
			} else {
				/*FLWise.filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + ThingPkgName +
					":" + thingType + "'";*/
				FLWise.filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + thingTypeName + "'";
			}

			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetDataForPlantFLWiseOrThing",
				data: JSON.stringify(FLWise),
				async: true,
				success: function (result) {
					GetDataForPlantFLWise.resolve();
					//	console.log(result, "GetDataForPlantFLWise Data");
					FLWiseModel.setData(result);
					that.getView().byId("idVizFrame2").setModel(FLWiseModel);
					that.getView().setModel(FLWiseModel, "FLWiseModel");
					sap.ui.getCore().setModel(FLWiseModel, "FLWiseModel");
					if (result.PlantWise) {
						that.getView().byId("idEmissionProgressIndicator").setPercentValue("40");
						that.getView().byId("idEmissionProgressIndicator").setDisplayValue(result.PlantWise.total + " " + result.PlantWise.uom);
					} else {
						that.getView().byId("idEmissionProgressIndicator").setPercentValue("0");
						that.getView().byId("idEmissionProgressIndicator").setDisplayValue("0KWH");
					}

					//	BusyIndicator.hide();
				},
				error: function (errorThrown) {
					GetDataForPlantFLWise.resolve();
					console.log("GetDataForPlantFLWise error " + JSON.stringify(errorThrown));
					//	BusyIndicator.hide();
				}
			});
			/*var FLWise_Energy = {
				"PackageName": ThingPkgName,
				"fromDateTime": sFromDateValue + "Z",
				"toDateTime": sToDateValue + "Z",
				"PropertySet": "ENERGY"
			};
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetDataForPlantFLWise",
				data: JSON.stringify(FLWise_Energy),
				async: true,
				success: function (result) {
					GetDataForPlantFLWise_Energy.resolve();
					if (result.PropertyWise && result.PropertyWise[0] && result.PropertyWise[0].TotalEmission[0]) {
						EnergyArray = result.PropertyWise[0].TotalEmission[0];
					}
					if (result.PlantWise) {
						that.getView().byId("idEnergyProgressIndicator").setDisplayValue(result.PlantWise.total + " " + result.PlantWise.uom);
						that.getView().byId("idEnergyProgressIndicator").setPercentValue("50");
					} else {
						that.getView().byId("idEnergyProgressIndicator").setPercentValue("0");
						that.getView().byId("idEnergyProgressIndicator").setDisplayValue("0TO");
					}
				},
				error: function (errorThrown) {
					GetDataForPlantFLWise_Energy.resolve();
					console.log("GetDataForPlantFLWise error " + JSON.stringify(errorThrown));
					//	BusyIndicator.hide();
				}
			});*/

			var Production = {
				"plant": SelectedPlant,
				"startDateTime": sFromDateValue + "Z",
				"endDateTime": sToDateValue + "Z",
				"user": "supmalak@in.ibm.com"
			};
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetStockPlantwise",
				data: JSON.stringify(Production),
				async: true,
				success: function (result) {
					GetStockPlantwise.resolve();
					if (result.totalProduction) {
						that.getView().byId("idProductionProgressIndicator").setPercentValue("40");
						that.getView().byId("idProductionProgressIndicator").setDisplayValue(result.totalProduction + " " + result.uom);
					} else {
						that.getView().byId("idProductionProgressIndicator").setPercentValue("0");
						that.getView().byId("idProductionProgressIndicator").setDisplayValue("0 EA");
					}
				},
				error: function (errorThrown) {
					GetStockPlantwise.resolve();
					console.log("GetDataForPlantFLWise error " + JSON.stringify(errorThrown));
					//	BusyIndicator.hide();
				}
			});

			var TotalEmission = {
				"PackageName": ThingPkgName,
				"fromDateTime": sFromDateValue + "Z",
				"toDateTime": sToDateValue + "Z",
				"PropertySet": "TOXIC"
			};
			if (this.FunctionalLocationSelected === false) {
				TotalEmission.filter = "?$filter=startswith(_thingType,'" + ThingPkgName + ":FunctionLocation')";
			} else {
				TotalEmission.filter = "?$filter=_id eq '" + thingId + "' and _thingType eq '" + thingTypeName + "'";
			}
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetTotalDataForPlantOrThing",
				data: JSON.stringify(TotalEmission),
				async: true,
				success: function (result) {
					GetTotalDataForPlantOrThing.resolve();
					TotalDataForPlantModel.setData(result);
					that.getView().byId("idVizFrame5").setModel(TotalDataForPlantModel);
				},
				error: function (errorThrown) {
					GetTotalDataForPlantOrThing.resolve();

					console.log("GetDataForPlantFLWise error " + JSON.stringify(errorThrown));
					//	BusyIndicator.hide();
				}
			});

			$.when(GetAvgDataForPlantOrThing, GetAvgDataForPlantOrThing_Energy, GetDataForPlantFLWise,
				GetStockPlantwise,
				GetTotalDataForPlantOrThing_Energy).done(
				function () {
					BusyIndicator.hide();
					var oView = that.getView();
					that.expandmyChart(oView, "idVizFrame1");
					that.expandmyChart(oView, "idVizFrame2");
					that.expandmyChart(oView, "idVizFrame5");
					that.expandmyChart(oView, "idVizFrame4");
				});

			//	this.expandmyChart(oView, "idVizFrame3", "Cell3");

			//	this.twoSeriesChart(oView, "idVizFrame3", "valueAxisFeed3");
		},
		expandmyChart: function (oView, sChart, name) {
			var vizFrame = oView.byId(sChart);
			if (sChart === "idVizFrame3") {
				vizFrame.setVizProperties({
					plotArea: {
						dataLabel: {
							visible: true,
							type: "value"
						},
						colorPalette: ["#13A4B4", "#BF399E", '#6C8893', '#ED4A7B'],
					}
				});
			} else {
				vizFrame.setVizProperties({
					plotArea: {
						dataLabel: {
							visible: true,
							type: "value",
							//renderer: function(oEvent) { oEvent.text = "test";
							//	}
						}
					}
				});
			}

			var VizFrame5 = this.getView().byId("idVizFrame5");
			VizFrame5.setVizProperties({
				title: {
					text: 'Actual Emissions' + " in TO"
				}
			});

			var VizFrame2 = this.getView().byId("idVizFrame2");
			VizFrame2.setVizProperties({
				title: {
					text: 'Total Emission by Sections' + " in TO"
				}
			});

			var VizFrame1 = this.getView().byId("idVizFrame1");
			VizFrame1.setVizProperties({
				title: {
					text: 'Average Emissions' + " in TO"
				}
			});
			var oVizFrame = this.getView().byId("idVizFrame4");
			/*	var Data = this.getView().getModel("FLWiseModel").getData();
				if(Data.PrpFLWise[0]){
					var uomVal = Data.PrpFLWise[0].uom;
				}*/
			oVizFrame.setVizProperties({
				title: {
					text: 'Actual Emissions By Each Sections in TO'
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "value"
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					},
					label: {
						/*angle: 45,*/
						rotation: 'fixed'
					}
				}
			});
		},
		onSelectFunctionLocation: function (sel) {
			var that = this;
			var PropertyWiseData = this.getView().getModel("FLWiseModel").getData().PropertyWise;
			var uom = PropertyWiseData[0].uom;
			if (sel && sel[0] && sel[0].data && sel[0].data.name) {
				for (var j = 0; j < PropertyWiseData.length; j++) {
					if (PropertyWiseData[j].ThingName === sel[0].data.name) {
						this.getView().getModel("FLWiseModel").getData().PropertyWiseData = PropertyWiseData[j].TotalEmission;
					}
				}
			}
			this.getView().getModel("FLWiseModel").refresh();
			sap.ui.getCore().getModel("FLWiseModel").refresh();

			that.getView().byId("idVizFrame4").setVizProperties({
				title: {
					text: sel[0].data.name + " " + PropertyWiseData[0].TotalEmission[0].uom

				}
			});

			/*	if (!that._oDialogFunctionLocation) {
					that._oDialogFunctionLocation = sap.ui.xmlfragment(
						"ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ContributionsByPlanSections", that);
					that.getView().addDependent(that._oDialogFunctionLocation);
					setTimeout(function () {}, 1000);
				} else {
					that.getView().byId("idVizFrame4").setVizProperties({
						title: {
							text: sel[0].data.name + " in TO"
						}
					});
				}

				if (sel && sel[0] && sel[0].data && sel[0].data.name) {
					sap.ui.getCore().byId("idDialogChart").setTitle("Emission By Sections");
				}
				that._oDialogFunctionLocation.open();*/
		},
		_oDialogFunctionLocationClose: function () {
			this._oDialogFunctionLocation.close();
		},
		onSelectVizChart: function (evt) {
			var that = this;
			if (evt !== "onPressUtility") {
				var sChart = evt.getSource().getVizUid();
				this.pop = evt.getSource().getVizUid().split("")[evt.getSource().getVizUid().split("").length - 1];
				if (evt.getSource().getVizUid() === "idVizFrame4") {
					this.oVizFrame = that.getView().byId(sChart);
					var sel = that.getView().byId(sChart).vizSelection();
				} else {
					this.oVizFrame = this.getView().byId(sChart);
					sel = this.getView().byId(sChart).vizSelection();
				}
				var selectedChart = sChart.split("--")[sChart.split("--").length - 1];
			}

			/*if (selectedChart && selectedChart === "idVizFrame2") {
				this.onSelectFunctionLocation(sel);
			} else*/
			if (selectedChart === "idVizFrame1" || evt === "onPressUtility" || selectedChart === "idVizFrame4" || selectedChart ===
				"idVizFrame5" || selectedChart === "idVizFrame2") {
				if (!that._oDialogPopoverDisplay) {
					that._oDialogPopoverDisplay = sap.ui.xmlfragment(
						"ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.PopoverDisplay", that);
					that.getView().addDependent(that._oDialogPopoverDisplay);
				}
				that._oDialogPopoverDisplay.open();

				if (selectedChart === "idVizFrame1") {
					var uom = this.getView().byId(sChart).getModel().getData()[0].uom;
					sap.ui.getCore().byId("idDialogPopOverDisplay").setTitle("Average Emissions");
					sap.ui.getCore().byId("idStandardListItem").setTitle(sel[0].data.name);
					sap.ui.getCore().byId("idStandardListItem").setDescription(sel[0].data.average + " " + uom);
				} else if (selectedChart === "idVizFrame4") {
					var uom = this.getView().getModel("FLWiseModel").getData().PrpFLWise[0].uom;
					var vizTitle = that.getView().byId("idVizFrame4").getVizProperties().title.text;
					sap.ui.getCore().byId("idDialogPopOverDisplay").setTitle(vizTitle);
					sap.ui.getCore().byId("idStandardListItem").setTitle(sel[0].data.name);
					sap.ui.getCore().byId("idStandardListItem").setDescription(sel[0].data.property + "- " + sel[0].data.total + " " + uom);
				} else if (selectedChart === "idVizFrame5") {
					var uom = this.getView().byId(sChart).getModel().getData()[0].uom;
					sap.ui.getCore().byId("idDialogPopOverDisplay").setTitle("Actual Emissions");
					sap.ui.getCore().byId("idStandardListItem").setTitle(sel[0].data.name);
					sap.ui.getCore().byId("idStandardListItem").setDescription(sel[0].data.total + " " + uom);
				} else if (selectedChart === "idVizFrame2") {
					var uom = this.getView().byId(sChart).getModel().getData().FLWise[0].uom;
					sap.ui.getCore().byId("idDialogPopOverDisplay").setTitle("Total Emission By Sections");
					sap.ui.getCore().byId("idStandardListItem").setTitle(sel[0].data.name);
					sap.ui.getCore().byId("idStandardListItem").setDescription(sel[0].data.total + " " + uom);
				} else if (evt === "onPressUtility") {
					sap.ui.getCore().byId("idDialogPopOverDisplay").setTitle("Hourly Avg Energy Consumed");
					sap.ui.getCore().byId("idStandardListItem").setTitle(EnergyArray.ThingName);
					sap.ui.getCore().byId("idStandardListItem").setDescription(EnergyArray.name + " - " + EnergyArray.total + " " + EnergyArray.uom);
				}

			}

		},
		onPressUtilityTile: function () {
			var that = this;
			var press = "onPressUtility";
			that.onSelectVizChart(press);
		},
		_oDialogPopOverDisplayClose: function () {
			try {
				this._oDialogPopoverDisplay.close();
			} catch (err) {
				this._oDialogEnergyPopoverDisplay.close();
			}

		},
		/////////////////////############################ 002JH6-Chamdeep Changes end #######################/////////////////////
		getEquipmentTags: function (reqBody, isPrpSet) {
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/getEquipmentPrpAndChildTags",
				data: JSON.stringify(reqBody),
				async: false, //true,
				success: function (result) {
					//console.log(result);
					gaugeRecord = result.prpSetRecords.records;
					//console.log(gaugeRecord.length);
					var EquipmentRecords = result.EquipmentRecords;
					//console.log(EquipmentRecords);
					if (EquipmentRecords.length !== 0) {
						appView.byId("FLAlertTile").setVisible(false);
						EquipmentRecordsArray = [];
						EquipmentRecords.forEach(function (Equipment) {
							var equipName = Equipment.ThingName;
							EquipmentRecordsArray.push(equipName);
						});
						//console.log(EquipmentRecordsArray);
						//console.log(EquipmentRecordsArray);
						if (EquipmentRecordsArray.length !== 0) {
							oControllerThis.getNotificationListForFL(EquipmentRecordsArray);
							oControllerThis.getOpenWorkOrdersCountForFL(EquipmentRecordsArray);
							oControllerThis.getPMWorkOrdersDueCountForFL(EquipmentRecordsArray);
							oControllerThis.GetWOHistoryForFL(EquipmentRecordsArray);
						}
					} else {
						if (result.imgDiv === "") {
							appView.byId("FLAlertTile").setVisible(false);
						} else {
							//appView.byId("FLAlertTile").setVisible(true);
							appView.byId("FLAlertTile").setVisible(false);
						}
					}

					oControllerThis.getThingTagDetails(result.imgDiv, result.span, result.gaugeRecord.records, isPrpSet, result.prpSetRecords);
					/*if (result.gaugeRecord.records.length === 0) {
						console.log("hide the pane");
						appView.byId("ImageSplitPane").setSize("auto");
						appView.byId("TrendChartSplitPane").setSize("0px");
						appView.byId("bottomPanelForChart").setVisible(false);
					} else {
						console.log("show the pane");
						appView.byId("ImageSplitPane").setSize("500px");
						appView.byId("TrendChartSplitPane").setSize("auto");
						appView.byId("bottomPanelForChart").setVisible(true);
					}*/
				},
				error: function (errorThrown) {
					console.log("getEquipmentPrpAndChildTags error " + JSON.stringify(errorThrown));
				}
			});
		},
		PaneData: function () {
			if (gaugeRecord && gaugeRecord.length === 0) {
				//console.log("hide the pane");
				appView.byId("ImageSplitPane").setSize("auto");
				appView.byId("TrendChartSplitPane").setSize("0px");
				appView.byId("bottomPanelForChart").setVisible(false);
			} else {
				//console.log("show the pane");
				appView.byId("ImageSplitPane").setSize("500px");
				appView.byId("TrendChartSplitPane").setSize("auto");
				appView.byId("bottomPanelForChart").setVisible(true);
			}
		},

		getThingTagDetails: function (imgDiv, spanData, gaugeData, isPrpSet, prpSetRecords) {
			rightPanelForImg = appView.byId("rightPanelForImg");
			rightPanelForImg.destroyContent();
			var htmlElm = new sap.ui.core.HTML();
			var content;
			if (imgDiv === "" || imgDiv === undefined) {
				content = "<div class='centerDiv'>No data found</div>";
			} else {
				content = imgDiv + spanData;
			}
			htmlElm.setContent(content);
			rightPanelForImg.addContent(htmlElm);
			this.getView().byId("rightPanelForImgVBox").addItem(rightPanelForImg);
			setTimeout(function () {
				$(".clickableChildDiv").on("click", function (e) {
					e.preventDefault();
					var selectedThingName = e.currentTarget.attributes.id.nodeValue;
					//console.log("selectedThingName " + selectedThingName);
					oTree.expand(oTree.indexOfItem(aSelectedItems));
					var oNode = aSelectedItems.getBindingContext().getObject();
					if (oNode.children) {
						for (var i in oNode.children) {
							if (oNode.children[i].Name === selectedThingName) {
								oNode.children[i].selected = true;
								treeModelData.refresh();
								oTree.fireSelectionChange();
								break;
							}
						}
					}
				});
				$(".clickableDiv").on("click", function (e) {
					e.preventDefault();
					oControllerThis.onClickLoadPropertyDialog().open();
					var selectedPrpSet = e.currentTarget.attributes.id.nodeValue;
					oControllerThis.setPropertyDialog(selectedPrpSet);
				});
			}, 1000);
		},

		onClickLoadPropertyDialog: function () {
			if (!oControllerThis._oDialog) {
				oControllerThis._oDialog = sap.ui.xmlfragment("ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.PropertySetDialog",
					appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._oDialog);
			}
			return oControllerThis._oDialog;
		},

		onClickLoadPropertyDialogClose: function (event) {
			flagChartDialog = 0;
			oControllerThis._oDialog.close();
		},

		setPropertyDialog: function (selectedPrpSet) {
			sap.ui.getCore().byId("PropertySetFragment").setTitle("Property Set " + selectedPrpSet);
			var toDateTime, fromDateTime; /*toDateTimeDisply, fromDateTimeDisply*/
			if (flagChartDialog === 0) {
				var ms = 86400000; // 1 hr =3600000// 86400000 = 1 day
				var dt = new Date();
				dt.setTime(dt.getTime() - (330 * 60 * 1000));
				toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				//toDateTimeDisply = toDateTime.replace('Z', '');
				var subtract1hr = dt;
				subtract1hr.setTime(dt.getTime() - ms);
				fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				//fromDateTimeDisply = fromDateTime.replace('Z', '');
				//	console.log(toDateTime + " --- " + fromDateTime);
			} else {
				/*fromDateTime = sap.ui.getCore().byId("IdFromdt").getValue();
				toDateTime = sap.ui.getCore().byId("IdTodt").getValue();
				if (!fromDateTime.match("Z") && !toDateTime.match("Z")) {
					toDateTimeDisply = toDateTime;
					fromDateTimeDisply = fromDateTime;
					fromDateTime = fromDateTime + "Z";
					toDateTime = toDateTime + "Z";
				} else if (!fromDateTime.match("Z") && toDateTime.match("Z")) {
					toDateTimeDisply = toDateTime.replace('Z', '');
					fromDateTimeDisply = fromDateTime;
					fromDateTime = fromDateTime + "Z";
					toDateTime = toDateTime;
				} else if (fromDateTime.match("Z") && !toDateTime.match("Z")) {
					toDateTimeDisply = toDateTime;
					fromDateTimeDisply = fromDateTime.replace('Z', '');
					fromDateTime = fromDateTime;
					toDateTime = toDateTime + "Z";
				} else {
					toDateTimeDisply = toDateTime.replace('Z', '');
					fromDateTimeDisply = fromDateTime.replace('Z', '');
					fromDateTime = fromDateTime;
					toDateTime = toDateTime;
				}*/

				if (oSelectTimeDialogChartKey === "1H") {
					ms = 3600000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
					var dt = new Date();
					dt.setTime(dt.getTime() - (330 * 60 * 1000));
					toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
					var subtract1hr = dt;
					subtract1hr.setTime(dt.getTime() - ms);
					fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
					console.log(fromDateTime + "-------" + toDateTime);
					//oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
				} else if (oSelectTimeDialogChartKey === "4H") {
					ms = 3600000 * 4; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
					var dt1 = new Date();
					dt1.setTime(dt1.getTime() - (330 * 60 * 1000));
					toDateTime = new Date(dt1.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
					var subtract4hr = dt1;
					subtract4hr.setTime(dt1.getTime() - ms);
					fromDateTime = new Date(new Date(subtract4hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
					console.log(fromDateTime + "-------" + toDateTime);
					//oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
				} else if (oSelectTimeDialogChartKey === "8H") {
					ms = 3600000 * 8; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
					var dt2 = new Date();
					dt2.setTime(dt2.getTime() - (330 * 60 * 1000));
					toDateTime = new Date(dt2.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
					var subtract8hr = dt2;
					subtract8hr.setTime(dt2.getTime() - ms);
					fromDateTime = new Date(new Date(subtract8hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
					console.log(fromDateTime + "-------" + toDateTime);
					//oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
				} else if (oSelectTimeDialogChartKey === "24H") {
					ms = 86400000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
					var dt3 = new Date();
					dt3.setTime(dt3.getTime() - (330 * 60 * 1000));
					toDateTime = new Date(dt3.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
					var subtract24hr = dt3;
					subtract24hr.setTime(dt3.getTime() - ms);
					fromDateTime = new Date(new Date(subtract24hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
					console.log(fromDateTime + "-------" + toDateTime);
					//oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
				}
			}
			//var dpFromDate = sap.ui.getCore().byId("IdFromdt").setValue(fromDateTimeDisply);
			//var dpIdTodt = sap.ui.getCore().byId("IdTodt").setValue(toDateTimeDisply);
			var req = {
				fromDateTime: fromDateTime,
				toDateTime: toDateTime,
				PackageName: PackageId,
				thingid: thingId,
				propertySet: selectedPrpSet,
				ThingType: thingType
			};
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetThingDataGvnRange",
				data: JSON.stringify(req),
				async: true,
				success: function (result) {
					var oVizFrame = sap.ui.getCore().byId("trendVizFrame");
					oVizFrame.setVizProperties({
						plotArea: {
							dataLabel: {
								visible: true
							},
							legend: {
								visible: false
							}
						},
						valueAxis: {
							title: {
								visible: false
							}
						},
						categoryAxis: {
							title: {
								visible: false
							}
						},
						title: {
							visible: false,
							text: ''
						},
						legendGroup: {
							layout: {
								position: "bottom"
							}
						}
					});
					//---- destroy existing Dataset and create new Dataset----//
					if (oVizFrame.getDataset() !== null) {
						oVizFrame.destroyDataset();
					}
					var mesaureArr = [];
					var feedValArr = [];
					for (var k = 0; k < result.property.length; k++) {
						var mesaureJson = {
							name: result.property[k].Property,
							value: "{" + result.property[k].Property + "}"
						}
						mesaureArr.push(mesaureJson);
						feedValArr.push(result.property[k].Property);
						if (result.property[k].PropertySet === "SEP_FlowRate") {
							//console.log("in if");
							oVizFrame.setVizScales([{
								feed: "valueAxis",
								min: 40,
								max: 120
							}]);
						} else if (result.property[k].PropertySet === "CMP_MassFlowRate") {
							//console.log("in else if");
							oVizFrame.setVizScales([{
								feed: "valueAxis",
								min: 35,
								max: 50
							}]);
						} else {
							//console.log("in else ");
							oVizFrame.setVizScales([{
								feed: "valueAxis",
								min: 0,
								max: null
							}]);
						}
					}
					var oVizFramegraph_dataset = new sap.viz.ui5.data.FlattenedDataset({
						dimensions: [{
							name: "Time",
							value: "{_time}"
						}],
						measures: mesaureArr,
						data: {
							path: "/value"
						}
					});
					//----set new Dataset to vizframe----//
					oVizFrame.setDataset(oVizFramegraph_dataset);
					if (oVizFrame.getFeeds() !== null || oVizFrame.getFeeds() != "") {
						oVizFrame.destroyFeeds();
					}
					var feedPrimaryValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
						uid: "valueAxis",
						type: "Measure",
						values: feedValArr
					});
					var feedAxisLabels = new sap.viz.ui5.controls.common.feeds.FeedItem({
						uid: "categoryAxis",
						type: "Dimension",
						values: ["Time"]
					});
					//----add new Feeds to vizframe----//
					oVizFrame.addFeed(feedPrimaryValues);
					oVizFrame.addFeed(feedAxisLabels);
					var oModel = new sap.ui.model.json.JSONModel(result);
					oVizFrame.setModel(oModel);
					var trendPopOver = sap.ui.getCore().byId("trendPopOver");
					trendPopOver.connect(oVizFrame.getVizUid());
				},
				error: function (errorThrown) {
					console.log("GetThingDataGvnRange error " + JSON.stringify(errorThrown));
				}
			});
		},

		onDialogSubmitDate: function () {
			var dpFromDate = sap.ui.getCore().byId("IdFromdt").getValue();
			var dpIdTodt = sap.ui.getCore().byId("IdTodt").getValue();
			if (dpFromDate == "" || dpFromDate === null) {
				this.showDialogMsgStrip("Please select a valid From Date", "Error");
			} else if (dpIdTodt == "" || dpIdTodt === null) {
				this.showDialogMsgStrip("Please select a valid To Date", "Error");
			} else if (dpFromDate > dpIdTodt) {
				this.showDialogMsgStrip("To Date should be greater then From Date", "Error");
			} else {
				flagChartDialog = 1;
				var title = sap.ui.getCore().byId("PropertySetFragment").getTitle();
				var prpSetSelected = title.replace("Property Set ", "");
				oControllerThis.setPropertyDialog(prpSetSelected);
			}
		},

		getNotificationList: function (eqp) {
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetNotificationList",
				data: JSON.stringify({
					"equipment": eqp
				}),
				async: false,
				success: function (result) {
					//console.log(result);
					//Start for Changes to view Notification count on Button
					//appView.byId("notifNumericContent").setVisible(true);

					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("TotalNotifCount").setValue(result.results.length);
						var oTableModel = new sap.ui.model.json.JSONModel(result);
						//console.log(oTableModel.getData());
						appView.byId("idNotifTable").setModel(oTableModel);
						/*PriorityArray = [];
						var response = result.results;
						response.forEach(function (entry) {
							var priority = entry.MaintPriority;
							if (priority === "2") {
								PriorityArray.push(entry);
							}
						});
						//console.log(PriorityArray);
						appView.byId("CriticalAlertCount").setValue(PriorityArray.length);*/
						appView.byId("AlertMsgStrip").setVisible(true);
						appView.byId("AlertMsgStrip").setText("PM Notification " + result.results[result.results.length - 1].MaintenanceNotification +
							" created for Equipment " + eqp);
						/*appView.byId("notifNumericContent").setText("PM Notification : " + result.results.length);
						appView.byId("notifNumericContent").setType("Reject");
						appView.byId("notifNumericContent").removeStyleClass("notifNumericContent");
						appView.byId("notifNumericContent").addStyleClass("notifNumericContentYellow");*/
					} else {
						appView.byId("TotalNotifCount").setValue(result.results.length);
						//appView.byId("CriticalAlertCount").setValue(0);
						var oEmptyModel = new sap.ui.model.json.JSONModel();
						appView.byId("idNotifTable").setModel(oEmptyModel);
						appView.byId("AlertMsgStrip").setVisible(false);

						/*appView.byId("CriticalAlertCount").setValue("0");
						appView.byId("notifNumericContent").setText("PM Notification : " + result.results.length);
						appView.byId("notifNumericContent").setType("Emphasized");
						appView.byId("notifNumericContent").removeStyleClass("notifNumericContentYellow");
						appView.byId("notifNumericContent").addStyleClass("notifNumericContent");*/
					}
					//End for Changes to view Notification count on Button
				},
				error: function (errorThrown) {
					console.log("GetNotificationList error " + JSON.stringify(errorThrown));
				}
			});
		},

		onPressNotification: function () {
			if (this.RootNodeSelected === false) {
				var pDesc = appView.byId("plant").getText();
				//	var wDesc = appView.byId("wc").getText();
				var eqpDesc = appView.byId("equipment").getText();
				//Start of code if WC is blank
				if (WC === "" || WC === null) {
					var WCDummy = "DUMMY";
					var WCDescDummy = "DUMMY(DUMMY)";
					console.log("choosen data Plant " + Plant + ",PlantDesc = " + pDesc + ",WCDesc=" + WCDescDummy +
						", WC = " + WCDummy + "," + eqpDesc + ", ThingId = " + thingId + ", ThingName " + ThingName + ",thingType= " + thingType +
						"," +
						PackageId + "," + Category);
					window.open(window.location.href + "#/notificationView/" + Plant + "," + pDesc + "," + WCDummy + "," +
						WCDescDummy + "," + eqpDesc + "," + thingId + "," + ThingName + "," + thingType + "," + PackageId + "," + Category, "_blank");
				} else {
					console.log("choosen data Plant " + Plant + ",PlantDesc = " + pDesc + ",WCDesc=" + WCDesc +
						", WC = " + WC + "," + eqpDesc + ", ThingId = " + thingId + ", ThingName " + ThingName + ",thingType= " + thingType + "," +
						PackageId + "," + Category);
					window.open(window.location.href + "#/notificationView/" + Plant + "," + pDesc + "," + WC + "," +
						WCDesc + "," + eqpDesc + "," + thingId + "," + ThingName + "," + thingType + "," + PackageId + "," + Category, "_blank");
				}
				//End of code if WC is blank
			}

		},

		showDialogMsgStrip: function (msgText, type) {
			var oMs = sap.ui.getCore().byId("dmsgStrip");
			if (oMs) {
				oMs.destroy();
			}
			this._generateDialogMsgStrip(msgText, type);
		},

		_generateDialogMsgStrip: function (msgText, type) {
			var oVC = sap.ui.getCore().byId("oDMsgLayout");
			oVC.setVisible(true);
			var oMsgStrip = new MessageStrip("dmsgStrip", {
				text: msgText,
				type: type,
				showIcon: true,
				showCloseButton: true
			});
			oVC.addContent(oMsgStrip);
			setTimeout(function () {
				oMsgStrip.close();
				oVC.setVisible(false);
			}, 8000);
		},

		showMsgStrip: function (msgText, type) {
			var oMs = sap.ui.getCore().byId("msgStrip");
			if (oMs) {
				oMs.destroy();
			}
			this._generateMsgStrip(msgText, type);
		},

		_generateMsgStrip: function (msgText, type) {
			var oVC = appView.byId("oMsgLayout");
			oVC.setVisible(true);
			var oMsgStrip = new MessageStrip("msgStrip", {
				text: msgText,
				type: type,
				showIcon: true,
				showCloseButton: true
			});
			oVC.addContent(oMsgStrip);
			setTimeout(function () {
				oMsgStrip.close();
				oVC.setVisible(false);
			}, 10000);
		},
		loadPropertyChartPlantOrThing: function (ThingPkgName, fromDateTime, toDateTime, filter) {

			var req = {
				"PackageName": ThingPkgName,
				"fromDateTime": fromDateTime + "Z",
				"toDateTime": toDateTime + "Z",
				"PropertySet": "TOXIC",
				"Filter": filter
			};
			//console.log(req);
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetAllEmissionDataForPlantOrFlorThing",
				data: JSON.stringify(req),
				async: true,
				success: function (result) {
					var propertyChart = oControllerThis.getView().byId("idVizFrame6");
					if (result.property && result.property.length > 0) {
						propertyChart.setVizProperties({
							title: {
								visible: true,
								text: "Emission Trend Analysis"
							},
							valueAxis: {
								title: {
									visible: false
								}
							},
							categoryAxis: {
								title: {
									visible: false
								}
							},
							plotArea: {
								dataLabel: {
									visible: true,
									hideWhenOverlap: false
								},
								animation: {
									dataLoading: true
								},
								dataPoint: {
									invalidity: "ignore"
								}
							},
							legendGroup: {
								layout: {
									position: "bottom"
								}
							}
						});
						if (propertyChart.getDataset() !== null) {
							propertyChart.destroyDataset();
						}
						var mesaureArr = [];
						var feedValArr = [];
						for (var k = 0; k < result.property.length; k++) {
							var mesaureJson = {
								name: result.property[k],
								value: "{" + result.property[k] + "}"
							}
							mesaureArr.push(mesaureJson);
							feedValArr.push(result.property[k]);
						}
						var oVizFramegraph_dataset = new sap.viz.ui5.data.FlattenedDataset({
							dimensions: [{
								name: "Time",
								value: "{_time}"
							}],
							measures: mesaureArr,
							data: {
								path: "/value"
							}
						});
						//----set new Dataset to vizframe----//
						propertyChart.setDataset(oVizFramegraph_dataset);
						if (propertyChart.getFeeds() !== null || propertyChart.getFeeds() !== "") {
							propertyChart.destroyFeeds();
						}
						var feedPrimaryValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
							uid: "valueAxis",
							type: "Measure",
							values: feedValArr
						});
						var feedAxisLabels = new sap.viz.ui5.controls.common.feeds.FeedItem({
							uid: "categoryAxis",
							type: "Dimension",
							values: ["Time"]
						});
						//----add new Feeds to vizframe----//
						propertyChart.addFeed(feedPrimaryValues);
						propertyChart.addFeed(feedAxisLabels);
						var oviz6Model = new sap.ui.model.json.JSONModel(result);
						propertyChart.setModel(oviz6Model);
						var trendPopOver = oControllerThis.getView().byId("trendPopOverVizFrame6");
						trendPopOver.connect(propertyChart.getVizUid());
					}
				},
				error: function (errorThrown) {
					console.error("loadPropertyChartPlantOrThing error ");
				}
			});

		},
		loadPropertyChart: function (fromDateTime, toDateTime) {
			var req = {
				PackageName: PackageId,
				thingid: thingId,
				thingType: thingType,
				fromDateTime: fromDateTime,
				toDateTime: toDateTime
			};
			//console.log(req);
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetThingPropertyData",
				data: JSON.stringify(req),
				async: true,
				success: function (result) {
					var trendChartContainer = oControllerThis.getView().byId("trendChartContainer");
					var propertyChart = oControllerThis.getView().byId("propertyChart");
					if (result.property && result.property.length > 0) {
						trendChartContainer.setVisible(true);
						propertyChart.setVizProperties({
							title: {
								visible: false
							},
							valueAxis: {
								title: {
									visible: true
								}
							},
							categoryAxis: {
								title: {
									visible: true
								}
							},
							plotArea: {
								dataLabel: {
									visible: true,
									hideWhenOverlap: false
								},
								animation: {
									dataLoading: true
								}
							},
							legendGroup: {
								layout: {
									position: "bottom"
								}
							}
						});
						if (propertyChart.getDataset() !== null) {
							propertyChart.destroyDataset();
						}
						var mesaureArr = [];
						var feedValArr = [];
						for (var k = 0; k < result.property.length; k++) {
							var mesaureJson = {
								name: result.property[k].Property,
								value: "{" + result.property[k].Property + "}"
							}
							mesaureArr.push(mesaureJson);
							feedValArr.push(result.property[k].Property);
						}
						var oVizFramegraph_dataset = new sap.viz.ui5.data.FlattenedDataset({
							dimensions: [{
								name: "Time",
								value: "{_time}"
							}],
							measures: mesaureArr,
							data: {
								path: "/value"
							}
						});
						//----set new Dataset to vizframe----//
						propertyChart.setDataset(oVizFramegraph_dataset);
						if (propertyChart.getFeeds() !== null || propertyChart.getFeeds() !== "") {
							propertyChart.destroyFeeds();
						}
						var feedPrimaryValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
							uid: "valueAxis",
							type: "Measure",
							values: feedValArr
						});
						var feedAxisLabels = new sap.viz.ui5.controls.common.feeds.FeedItem({
							uid: "categoryAxis",
							type: "Dimension",
							values: ["Time"]
						});
						//----add new Feeds to vizframe----//
						propertyChart.addFeed(feedPrimaryValues);
						propertyChart.addFeed(feedAxisLabels);
						oChartModel = new sap.ui.model.json.JSONModel(result);
						propertyChart.setModel(oChartModel);
						var trendPopOver = oControllerThis.getView().byId("trendPopOver");
						trendPopOver.connect(propertyChart.getVizUid());
					} else {
						trendChartContainer.setVisible(false);
					}
				},
				error: function (errorThrown) {
					console.error("GetThingDataGvnRange error ");
				}
			});
		},
		onRefreshPress: function () {
			console.log("Refreshed chart");
			var ms = 86400000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
			var dt = new Date();
			dt.setTime(dt.getTime() - (330 * 60 * 1000));
			var toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
			var subtract1hr = dt;
			subtract1hr.setTime(dt.getTime() - ms);
			var fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
			console.log(fromDateTime + "-------" + toDateTime);
			oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
			appView.byId("idTimeSelector").setSelectedKey("24H");
		},
		/*onReset: function () {
			var ms = 86400000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
			var dt = new Date();
			dt.setTime(dt.getTime() - (330 * 60 * 1000));
			var toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
			var subtract1hr = dt;
			subtract1hr.setTime(dt.getTime() - ms);
			var fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
			console.log(fromDateTime + "-------" + toDateTime);
			appView.byId("FromDt").setValue(fromDateTime.replace('Z', ''));
			appView.byId("ToDt").setValue(toDateTime.replace('Z', ''));
		},
		onSubmitLoadData: function () {
			var FromDate = appView.byId("FromDt").getValue();
			var ToDate = appView.byId("ToDt").getValue();
			console.log(FromDate + "-------" + ToDate);
			if (FromDate === "" || FromDate === null) {
				oControllerThis.showMsgStrip("Please select a valid From Date", "Error");
			} else if (ToDate === "" || ToDate === null) {
				oControllerThis.showMsgStrip("Please select a valid To Date", "Error");
			} else if (FromDate > ToDate) {
				oControllerThis.showMsgStrip("To Date should be greater then From Date", "Error");
			} else {
				oControllerThis.getNotificationListData(ThingName, FromDate, ToDate);

			}
		},*/
		handleFromDateChange: function (oEvent) {
			sFromDateValue = oEvent.getParameter("value");
			console.log("Fromdate:::::::" + sFromDateValue);
		},
		handleToDateChange: function (oEvent) {
			sToDateValue = oEvent.getParameter("value");
			console.log("Todate:::::::" + sToDateValue);
			DateFlag = 1;
			if (sFromDateValue > sToDateValue) {
				oControllerThis.showMsgStrip("To Date should be greater then From Date", "Error");
			} else if (sFromDateValue === "" || sFromDateValue === null) {
				oControllerThis.showMsgStrip("Please select a valid From Date", "Error");
			} else if (sToDateValue === "" || sToDateValue === null) {
				oControllerThis.showMsgStrip("Please select a valid To Date", "Error");
			} else {
				oControllerThis.getNotificationListData(ThingName, sFromDateValue, sToDateValue);
				oControllerThis.getOpenWorkOrdersListData(ThingName, sFromDateValue, sToDateValue);
				oControllerThis.getPMWorkOrdersDueListData(ThingName, sFromDateValue, sToDateValue);
				oControllerThis.getWOHistoryListData(ThingName, sFromDateValue, sToDateValue);
			}
		},
		getEHSComplianceData: function (filter) {
			var that = this;
			var ServiceUrl = "/node/GetComplianceFromSAPEHS";
			var payload = JSON.stringify({
				//"Filter": "PLANT_ID eq '" + SelectedPlant + "'"
				"Filter": filter
			});
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: ServiceUrl,
				data: payload,
				async: false,
				success: function (result) {
					//Start for Changes to view Notification count on Button
					//console.log(result);
					try {
						var myJSON = JSON.parse(result.results);
						if (myJSON[0]) {
							if (myJSON[0].FAULT_IND && myJSON[0].FAULT_IND.trim() === "Yes") {
								that.getView().byId("idEHSCompliance").setTitle("Compliant"); //result.results[0].FAULT_IND Complaint 
								that.getView().byId("idEHSCompliance").setIcon("sap-icon://sys-enter-2");
								that.getView().byId("idEHSCompliance").addStyleClass("SuccessClass");
								that.getView().byId("idEHSCompliance").setState("Success");
							} else {
								that.getView().byId("idEHSCompliance").setTitle("NA");
								that.getView().byId("idEHSCompliance").setIcon("sap-icon://error");
								that.getView().byId("idEHSCompliance").addStyleClass("ErrorClass");
							}

						} else {
							that.getView().byId("idEHSCompliance").setIcon("sap-icon://error");
							that.getView().byId("idEHSCompliance").setTitle("NA");
							that.getView().byId("idEHSCompliance").setState("Error");
							that.getView().byId("idEHSCompliance").addStyleClass("ErrorClass");
						}
					} catch (err) {}

				},
				error: function (errorThrown) {
					console.log("GetComplianceFromSAPEHS error " + JSON.stringify(errorThrown));
				}
			});

		},
		getTotalIncidents: function (filter, sFromDateValue, sToDateValue) {
			var that = this;
			var ServiceUrl = "/node/GetTotalIncidents";
			var payload = JSON.stringify({
				"Filter": filter,
				"INC_GROUP": "EHHSS_IGR_DEVIATION",
				"StartDate": sFromDateValue,
				"EndDate": sToDateValue
			});
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: ServiceUrl,
				data: payload,
				async: false,
				success: function (result) {
					//Start for Changes to view Notification count on Button
					if (result.Count) {
						that.getView().byId("idTotalIncidents").setValue(result.Count);
					} else {
						that.getView().byId("idTotalIncidents").setValue(0);
					}
				},
				error: function (errorThrown) {
					console.log("GetTotalIncidents error " + JSON.stringify(errorThrown));
				}
			});

			var SafetyServiceUrl = "/node/GetTotalIncidents";
			var SafetyPayload = JSON.stringify({
				"Filter": filter,
				"INC_GROUP": "EHHSS_IGR_OCC_INC",
				"StartDate": sFromDateValue,
				"EndDate": sToDateValue
			});
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: SafetyServiceUrl,
				data: SafetyPayload,
				async: false,
				success: function (result) {
					//Start for Changes to view Notification count on Button
					if (result.Count) {
						that.getView().byId("idTotalSafetyIncidentsCount").setValue(result.Count);
					} else {
						that.getView().byId("idTotalSafetyIncidentsCount").setValue(0);
					}
				},
				error: function (errorThrown) {
					console.log("GetTotalIncidents error " + JSON.stringify(errorThrown));
				}
			});

		},
		getNotificationListData: function (eqp, fromdate, todate, SelectedPlant) {
			var that = this;
			if (SelectedPlant !== undefined) {
				var ServiceUrl = "/node/GetNotificationListForPlant";
				var payload = JSON.stringify({
					"Plant": SelectedPlant
				});
				that.SelectedPlant = true;
			} else {
				ServiceUrl = "/node/GetNotificationListData";
				payload = JSON.stringify({
					"equipment": eqp,
					"FromDate": fromdate,
					"ToDate": todate
				});
				that.SelectedPlant = false;
			}
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: ServiceUrl,
				data: payload,
				async: false,
				success: function (result) {
					//Start for Changes to view Notification count on Button
					//console.log(result);
					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("TotalNotifCount").setValue(result.results.length);
						if (that.SelectedPlant === false) {
							that.getView().byId("idNotifTable").setVisible(true);
							var oTableModel = new sap.ui.model.json.JSONModel(result);
							//console.log(oTableModel.getData());
							appView.byId("idNotifTable").setModel(oTableModel);
						} else {
							that.getView().byId("idNotifTable").setVisible(false);
						}

						/*PriorityArray = [];
						var response = result.results;
						response.forEach(function (entry) {
							var priority = entry.MaintPriority;
							if (priority === "2") {
								PriorityArray.push(entry);
							}
						});
						//console.log(PriorityArray);
						appView.byId("CriticalAlertCount").setValue(PriorityArray.length);*/
					} else {
						//	appView.byId("TotalNotifCount").setValue(result.results.length);
						if (that.SelectedPlant === false) {
							that.getView().byId("idNotifTable").setVisible(true);
							var oEmptyModel = new sap.ui.model.json.JSONModel();
							appView.byId("idNotifTable").setModel(oEmptyModel);
						} else {
							that.getView().byId("idNotifTable").setVisible(false);
						}

						//appView.byId("CriticalAlertCount").setValue(0);
					}
					//End for Changes to view Notification count on Button
				},
				error: function (errorThrown) {
					console.log("GetNotificationListData error " + JSON.stringify(errorThrown));
				}
			});
		},
		getWOHistoryListData: function (eqp, fromdate, todate) {
			var MaintenanceOrderType = "YBA1";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetWOHistoryListData",
				data: JSON.stringify({
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqp,
					"FromDate": fromdate,
					"ToDate": todate
				}),
				async: false,
				success: function (result) {
					//Start for Changes to view Notification count on Button
					//console.log(result);
					MaintananceModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("MaintenanceCount").setValue(result.results.length);
					} else {
						appView.byId("MaintenanceCount").setValue(result.results.length);
					}
					//End for Changes to view Notification count on Button
				},
				error: function (errorThrown) {
					console.log("GetWOHistoryListData error " + JSON.stringify(errorThrown));
				}
			});
		},
		getOpenWorkOrdersListData: function (eqp, fromdate, todate) {
			var MaintenanceOrderType = "YBA2";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetOpenWorkOrdersListData",
				data: JSON.stringify({
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqp,
					"FromDate": fromdate,
					"ToDate": todate
				}),
				async: false,
				success: function (result) {
					//Start for Changes to view Notification count on Button
					//console.log(result);
					OpenWorkModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("OpenWOCount").setValue(result.results.length);
					} else {
						appView.byId("OpenWOCount").setValue(result.results.length);
					}
					//End for Changes to view Notification count on Button
				},
				error: function (errorThrown) {
					console.log("GetOpenWorkOrdersListData error " + JSON.stringify(errorThrown));
				}
			});
		},
		getPMWorkOrdersDueListData: function (eqp, fromdate, todate) {
			var MaintenanceOrderType = "YBA2";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetPMWorkOrdersDueListData",
				data: JSON.stringify({
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqp,
					"FromDate": fromdate,
					"ToDate": todate
				}),
				async: false,
				success: function (result) {
					//Start for Changes to view Notification count on Button
					//console.log(result);
					PMDueModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						var WOstartDate = new Date(result.results[0].MaintOrdSchedBasicStartDate);
						WOstartDate = WOstartDate.getFullYear() + '-' + (WOstartDate.getMonth() + 1) + '-' + WOstartDate.getDate();
						//appView.byId("PMDueCount").setValue(result.results.length);
						appView.byId("PMDueCount").setContentText(WOstartDate);
					} else {
						appView.byId("PMDueCount").setContentText("");
						//appView.byId("PMDueCount").setValue(result.results.length);
					}
					//End for Changes to view Notification count on Button
				},
				error: function (errorThrown) {
					console.log("GetPMWorkOrdersDueListData error " + JSON.stringify(errorThrown));
				}
			});
		},
		getCurrentDateTime: function () {
			var currentDT = new Date(new Date().toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0];
			return currentDT;
		},
		GetWOHistory: function (eqpNo) {
			var MaintenanceOrderType = "YBA1";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetMaintenanceHistory",
				data: JSON.stringify({
					"currentDate": oControllerThis.getCurrentDateTime(),
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					//console.log(result);
					MaintananceModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("MaintenanceCount").setValue(result.results.length);
					} else {
						appView.byId("MaintenanceCount").setValue(result.results.length);
					}
				},
				error: function (errorThrown) {
					console.error("GetMaintenanceHistory error " + JSON.stringify(errorThrown));
				}
			});
		},
		formatRowHighlight: function (oValue) {
			// Your logic for rowHighlight goes here
			//console.log("oValue-----" + oValue);
			if (oValue === "1") {
				return "Error";
			} else if (oValue === "2") {
				return "Warning";
			} else if (oValue === "3") {
				return "Information";
			}
			return "Success";
		},
		formatStatus: function (oValue) {
			console.log("oValue----" + oValue);
			var StatusValue;
			if (oValue !== null) {
				StatusValue = oValue.split(" ")[0];
				console.log(StatusValue);
			}
			return StatusValue;
		},
		getNotificationCountForFL: function (eqp) {
			sFromDateValue = this.getView().byId("FromDt").getValue();
			sToDateValue = this.getView().byId("ToDt").getValue();
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetNotificationListForFL",
				data: JSON.stringify({
					"equipment": eqp,
					"FromDate": sFromDateValue,
					"ToDate": sToDateValue
				}),
				async: false,
				success: function (result) {
					if (result.results !== undefined) {
						appView.byId("TotalNotifCount").setValue(result.results.length);
					} else {
						appView.byId("TotalNotifCount").setValue(0);
					}
				},
				error: function (errorThrown) {
					console.log("getNotificationCountForFL error " + JSON.stringify(errorThrown));
				}
			});
		},
		getNotificationListForFL: function (eqp) {
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetNotificationListForFunctionalLocation",
				data: JSON.stringify({
					"equipment": eqp
				}),
				async: false,
				success: function (result) {
					//Start for Changes to view Notification count on Button
					//console.log(result);
					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("TotalNotifCount").setValue(result.results.length);
						var oTableModel = new sap.ui.model.json.JSONModel(result);
						//console.log(oTableModel.getData());
						appView.byId("idNotifTable").setModel(oTableModel);
						/*console.log(PriorityArray);
						PriorityArray = [];
						var response = result.results;
						response.forEach(function (entry) {
							var priority = entry.MaintPriority;
							if (priority === "2") {
								PriorityArray.push(entry);
							}
						});
						//console.log(PriorityArray);
						appView.byId("CriticalAlertCount").setValue(PriorityArray.length);*/
					} else {
						appView.byId("TotalNotifCount").setValue(result.results.length);
						var oEmptyModel = new sap.ui.model.json.JSONModel(result);
						appView.byId("idNotifTable").setModel(oEmptyModel);
						//appView.byId("CriticalAlertCount").setValue(0);
					}
					//End for Changes to view Notification count on Button
				},
				error: function (errorThrown) {
					console.log("GetNotificationListForFunctionalLocation error " + JSON.stringify(errorThrown));
				}
			});
		},

		GetWOHistoryForFL: function (eqpNo) {
			var MaintenanceOrderType = "YBA1";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetMaintenanceHistoryForFunctLoc",
				data: JSON.stringify({
					"currentDate": oControllerThis.getCurrentDateTime(),
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					//console.log(result);
					MaintananceModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("MaintenanceCount").setValue(result.results.length);
					} else {
						appView.byId("MaintenanceCount").setValue(result.results.length);
					}
				},
				error: function (errorThrown) {
					console.error("GetMaintenanceHistoryForFunctLoc error " + JSON.stringify(errorThrown));
				}
			});
		},
		getOpenWorkOrdersCountForFL: function (eqpNo) {
			var MaintenanceOrderType = "YBA2";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetOpenWorkOrdersCountForFL",
				data: JSON.stringify({
					"currentDate": oControllerThis.getCurrentDateTime(),
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					//console.log(result);
					OpenWorkModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("OpenWOCount").setValue(result.results.length);
					} else {
						appView.byId("OpenWOCount").setValue(result.results.length);
					}
				},
				error: function (errorThrown) {
					console.error("GetOpenWorkOrdersCountForFL error " + JSON.stringify(errorThrown));
				}
			});
		},
		getPMWorkOrdersDueCountForFL: function (eqpNo) {
			var MaintenanceOrderType = "YBA2";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetPMWorkOrdersDueCountForFL",
				data: JSON.stringify({
					"currentDate": oControllerThis.getCurrentDateTime(),
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					//console.log(result);
					PMDueModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						var WOstartDate = new Date(result.results[0].MaintOrdSchedBasicStartDate);
						WOstartDate = WOstartDate.getFullYear() + '-' + (WOstartDate.getMonth() + 1) + '-' + WOstartDate.getDate();
						//appView.byId("PMDueCount").setValue(result.results.length);
						appView.byId("PMDueCount").setContentText(WOstartDate);
					} else {
						appView.byId("PMDueCount").setContentText("");
						//appView.byId("PMDueCount").setValue(result.results.length);
					}
				},
				error: function (errorThrown) {
					console.error("getPMWorkOrdersDueCountForFL error " + JSON.stringify(errorThrown));
				}
			});
		},
		onTimeSelectLoadChart: function () {
			var oSelect = appView.byId("idTimeSelector");
			var oSelectKey = oSelect.getSelectedKey();
			console.log("oSelectKey------" + oSelectKey);
			var ms, toDateTime, fromDateTime;
			if (oSelectKey === "1H") {
				ms = 3600000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
				var dt = new Date();
				dt.setTime(dt.getTime() - (330 * 60 * 1000));
				toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				var subtract1hr = dt;
				subtract1hr.setTime(dt.getTime() - ms);
				fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				console.log(fromDateTime + "-------" + toDateTime);
				oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
			} else if (oSelectKey === "4H") {
				ms = 3600000 * 4; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
				var dt1 = new Date();
				dt1.setTime(dt1.getTime() - (330 * 60 * 1000));
				toDateTime = new Date(dt1.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				var subtract4hr = dt1;
				subtract4hr.setTime(dt1.getTime() - ms);
				fromDateTime = new Date(new Date(subtract4hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				console.log(fromDateTime + "-------" + toDateTime);
				oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
			} else if (oSelectKey === "8H") {
				ms = 3600000 * 8; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
				var dt2 = new Date();
				dt2.setTime(dt2.getTime() - (330 * 60 * 1000));
				toDateTime = new Date(dt2.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				var subtract8hr = dt2;
				subtract8hr.setTime(dt2.getTime() - ms);
				fromDateTime = new Date(new Date(subtract8hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				console.log(fromDateTime + "-------" + toDateTime);
				oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
			} else if (oSelectKey === "24H") {
				ms = 86400000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
				var dt3 = new Date();
				dt3.setTime(dt3.getTime() - (330 * 60 * 1000));
				toDateTime = new Date(dt3.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				var subtract24hr = dt3;
				subtract24hr.setTime(dt3.getTime() - ms);
				fromDateTime = new Date(new Date(subtract24hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
				console.log(fromDateTime + "-------" + toDateTime);
				oControllerThis.loadPropertyChart(fromDateTime, toDateTime);
			}
		},
		onTimeSelectLoadChartDialog: function () {
			var oSelectTimeDialogChart = sap.ui.getCore().byId("idTimeSelectorDialog");
			oSelectTimeDialogChartKey = oSelectTimeDialogChart.getSelectedKey();
			console.log("oSelectTimeDialogChartKey------" + oSelectTimeDialogChartKey);
			flagChartDialog = 1;
			var title = sap.ui.getCore().byId("PropertySetFragment").getTitle();
			var prpSetSelected = title.replace("Property Set ", "");
			oControllerThis.setPropertyDialog(prpSetSelected);

		},
		GetWorkOrdersCount: function (eqpNo) {
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetOpenWorkOrdersCount",
				data: JSON.stringify({
					"currentDate": oControllerThis.getCurrentDateTime(),
					"Equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					//console.log(result);
					OpenWorkModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						appView.byId("OpenWOCount").setValue(result.results.length);
					} else {
						appView.byId("OpenWOCount").setValue(result.results.length);
					}
				},
				error: function (errorThrown) {
					console.error("GetWorkOrdersCount error " + JSON.stringify(errorThrown));
				}
			});
		},
		GetPMWorkOrdersDueCount: function (eqpNo) {
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetPMWorkOrdersDueCount",
				data: JSON.stringify({
					"currentDate": oControllerThis.getCurrentDateTime(),
					"Equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					//console.log(result);

					PMDueModel = new sap.ui.model.json.JSONModel(result);
					if (result.results !== undefined && result.results.length > 0) {
						var WOstartDate = new Date(result.results[0].MaintOrdSchedBasicStartDate);
						WOstartDate = WOstartDate.getFullYear() + '-' + (WOstartDate.getMonth() + 1) + '-' + WOstartDate.getDate();
						//appView.byId("PMDueCount").setValue(result.results.length);
						appView.byId("PMDueCount").setContentText(WOstartDate);
					} else {
						appView.byId("PMDueCount").setContentText("");
						//appView.byId("PMDueCount").setValue(result.results.length);
					}
				},
				error: function (errorThrown) {
					console.error("GetPMWorkOrdersDueCount error " + JSON.stringify(errorThrown));
				}
			});
		},
		onPressProcessVisibility: function () {
			window.open(
				"https://admi-subaccount.cockpit.workflowmanagement.cfapps.eu10.hana.ondemand.com/cp.portal/site#pv-showScenarioOverview?scenarioId=workordervisibility.workorder&sap-app-origin-hint="
			);
		},
		onPressCloseOpenWO: function () {
			oControllerThis._getOpenWODialog().close();
		},
		onPressClosePMDue: function () {
			oControllerThis._getOpenPMDue().close();
		},
		onPressCloseMaintanance: function () {
			oControllerThis._getOpenMaintananceDialog().close();
		},

		onPressOpenWO: function () {
			oControllerThis._getOpenWODialog().open();
			sap.ui.getCore().byId("OpenWorkTb").setModel(OpenWorkModel);
		},
		onPressPMDue: function () {
			oControllerThis._getOpenPMDue().open();
			sap.ui.getCore().byId("PmDueTable").setModel(PMDueModel);
		},
		onPressMaintanance: function () {
			oControllerThis._getOpenMaintananceDialog().open();
			sap.ui.getCore().byId("MaintananceTb").setModel(MaintananceModel);
		},
		_getOpenWODialog: function () {
			if (!oControllerThis._OpenWODialog) {
				oControllerThis._OpenWODialog = sap.ui.xmlfragment("ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ShowOpenWO",
					appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._OpenWODialog);
			}
			return oControllerThis._OpenWODialog;
		},
		_getOpenPMDue: function () {
			if (!oControllerThis._OpenPMDueDialog) {
				oControllerThis._OpenPMDueDialog = sap.ui.xmlfragment("ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ShowPmDue",
					appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._OpenPMDueDialog);
			}
			return oControllerThis._OpenPMDueDialog;
		},
		_getOpenMaintananceDialog: function () {
				if (!oControllerThis._OpenMaintananceDialog) {
					oControllerThis._OpenMaintananceDialog = sap.ui.xmlfragment(
						"ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ShowMaintanance",
						appView.getController());
					oControllerThis.getView().addDependent(oControllerThis._OpenMaintananceDialog);
				}
				return oControllerThis._OpenMaintananceDialog;
			}
			/*onPredRootCauseTileClick: function () {
				var PredRootCauseEquip = appView.byId("PredRootCauseValue").getContentText();
				if (PredRootCauseEquip !== "" || PredRootCauseEquip !== undefined || PredRootCauseEquip !== null) {
					var selectedThingName = PredRootCauseEquip;
					console.log("selectedThingName " + selectedThingName);
					oTree.expand(oTree.indexOfItem(aSelectedItems));
					// var TreeModel = appView.byId("DigitalTwinTree").getModel().getData();
					// console.log(TreeModel);
					var oNode = aSelectedItems.getBindingContext().getObject();
					console.log(oNode);
					if (oNode.children) {
						for (var i in oNode.children) {
							if (oNode.children[i].Name == selectedThingName) {
								oNode.children[i].selected = true;
								treeModelData.refresh();
								oTree.fireSelectionChange();
								break;
							}
						}
					}
				}
			}*/
	});
});
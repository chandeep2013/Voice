sap.ui.define([
	"sap/ui/core/BusyIndicator",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/MessageStrip",
	"sap/m/MessageBox",
	"sap/ui/core/mvc/Controller",
	'sap/viz/ui5/format/ChartFormatter',
	'sap/viz/ui5/api/env/Format'
], function (BusyIndicator, Filter, FilterOperator, Fragment, MessageStrip, MessageBox, Controller, ChartFormatter, Format) {
	"use strict";
	var Plant, PlantDesc, WC, ERP_WC, WCDesc, PackageName, Category, ThingDesc, ThingId, ThingName, ThingType, SelectedPrpSet;
	var appView, oControllerThis, oPMWorkOrderModel, woHistoryModel, oNotifModel, oChartModel, eqpNo, notificationId = "",
		oSpareTableModel, sparePartsRes, notificationText = "";

	return Controller.extend("ui_app.SustainableManufacturingAsset_MonitoringDashboard.controller.notificationView", {

		onInit: function () {
			BusyIndicator.show(0);
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("notificationView").attachMatched(this._onRouteMatched, this);
		},

		_onRouteMatched: function (oEvent) {
			var parameters = oEvent.getParameter("arguments");
			Plant = parameters.Plant;
			PlantDesc = parameters.PlantDesc;
			WC = parameters.WC;
			ERP_WC = parameters.WC;
			WCDesc = parameters.WCDesc;
			PackageName = parameters.PackageName;
			Category = parameters.Category;
			ThingId = parameters.ThingId;
			ThingName = parameters.ThingName;
			ThingType = parameters.ThingType;
			ThingDesc = parameters.ThingDesc;
			eqpNo = ThingName;
			console.log(Plant + "," + PlantDesc + "," + WC + "," + WCDesc + "," + PackageName + "," + ThingDesc + "," + ThingId + "," +
				ThingName + "," + ThingType + "," + Category);
			appView = this.getView();
			oControllerThis = this;
			appView.byId("plant").setText(PlantDesc);
			appView.byId("wc").setText(WCDesc);
			appView.byId("thingLbl").setText(Category + " : ");
			appView.byId("equipment").setText(ThingDesc);
			BusyIndicator.hide();

			oControllerThis.loadNotifList();
			oControllerThis.loadProdOrder();
			var ms = 86400000; //3600000; //1 hr // 86400000=1 day // 2592000000=1 month
			var dt = new Date();
			dt.setTime(dt.getTime() - (330 * 60 * 1000));
			var toDateTime = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
			var subtract1hr = dt;
			subtract1hr.setTime(dt.getTime() - ms);
			var fromDateTime = new Date(new Date(subtract1hr).toString().split('GMT')[0] + ' UTC').toISOString().replace('.000Z', 'Z');
			appView.byId("FromDt").setValue(fromDateTime.replace('Z', ''));
			appView.byId("ToDt").setValue(toDateTime.replace('Z', ''));
			oControllerThis.loadPropertyChart(eqpNo, fromDateTime, toDateTime);
			oControllerThis.GetPMWorkOrder(eqpNo);
			oControllerThis.GetWOHistory(eqpNo);
			oControllerThis.loadPropertyGauge();
			setTimeout(function () {
				BusyIndicator.hide(0);
			}, 4000);
			setInterval(function () {
				console.log("refresh data");
				oControllerThis.loadNotifList();
				oControllerThis.loadProdOrder();
				var FromDate = appView.byId("FromDt").getValue();
				var ToDate = appView.byId("ToDt").getValue();
				oControllerThis.loadPropertyChart(eqpNo, FromDate + "Z", ToDate + "Z");
				oControllerThis.GetPMWorkOrder(eqpNo);
				oControllerThis.GetWOHistory(eqpNo);
				oControllerThis.loadPropertyGauge();
			}, 60000);
		},

		loadNotifList: function () {
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetNotificationList",
				data: JSON.stringify({
					"equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					oNotifModel = new sap.ui.model.json.JSONModel(result);
					appView.byId("notificationList").setModel(oNotifModel);
					if (result.results.length > 0) {
						//appView.byId("notificationList").setSelectedItem(0);
						appView.byId("notificationList").getItems()[0].setSelected(true);
						var oCtx = appView.byId("notificationList").getSelectedItem().getBindingContext();
						notificationId = oCtx.getProperty("MaintenanceNotification");
						notificationText = oCtx.getProperty("NotificationText");
						console.log(notificationId + ":" + notificationText);
						//set failure tile
						var dataArr = notificationText.split(":");
						if (dataArr[1].includes('Separator') === true) {
							appView.byId("failureTile").setHeader(dataArr[1]);
							if (dataArr[2].includes(">")) {
								appView.byId("failureNC").setValue(dataArr[2].split(">")[0]);
								appView.byId("failureNC").setScale(dataArr[2].split(">")[0].replace(/[^a-z]/gi, ''));
							} else if (dataArr[2].includes("<")) {
								appView.byId("failureNC").setValue(dataArr[2].split("<")[0]);
								appView.byId("failureNC").setScale(dataArr[2].split("<")[0].replace(/[^a-z]/gi, ''));
							}
						} else {
							appView.byId("failureTile").setHeader(dataArr[1] + " failure");
							if (dataArr[2].includes(">")) {
								appView.byId("failureNC").setValue(dataArr[2].split(">")[0]);
								appView.byId("failureNC").setScale(dataArr[2].split(">")[0].replace(/[^a-z]/gi, ''));
							} else if (dataArr[2].includes("<")) {
								appView.byId("failureNC").setValue(dataArr[2].split("<")[0]);
								appView.byId("failureNC").setScale(dataArr[2].split("<")[0].replace(/[^a-z]/gi, ''));
							}
						}
						oControllerThis.loadSpareParts();
					} else {
						appView.byId("failureTile").setHeader("No failure");
						appView.byId("failureNC").setValue("NA");
					}
				},
				error: function (errorThrown) {
					console.error("GetNotificationList error " + JSON.stringify(errorThrown));
				}
			});
		},

		loadProdOrder: function () {
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetProdOrder",
				data: JSON.stringify({
					"WorkCenter": ERP_WC
				}),
				async: true,
				success: function (result) {
					var oTableModel = new sap.ui.model.json.JSONModel(result);
					appView.byId("ProdPlan").setModel(oTableModel);
				},
				error: function (errorThrown) {
					console.error("GetProdOrder error " + JSON.stringify(errorThrown));
				}
			});
		},

		loadSpareParts: function () {
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetSparePartsWithStockCost",
				data: JSON.stringify({
					"shortdesc": notificationText.split(":")[0], //"MP-62",
					"Plant": Plant
						//,"MaterialGroup": "YBSVM1"
				}),
				async: true,
				success: function (result) {
					sparePartsRes = result;
					oSpareTableModel = new sap.ui.model.json.JSONModel(result);
					appView.byId("SpareParts").setModel(oSpareTableModel);
				},
				error: function (errorThrown) {
					console.error("GetSpareParts error " + JSON.stringify(errorThrown));
				}
			});
		},

		getCurrentDateTime: function () {
			var currentDT = new Date(new Date().toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0];
			return currentDT;
		},

		onNotificationClick: function (oEvent) {
			var oItem = oEvent.getParameter("listItem");
			var oCtx = oItem.getBindingContext();
			notificationId = oCtx.getProperty("MaintenanceNotification");
			notificationText = oCtx.getProperty("NotificationText");
			console.log(notificationId + ":" + notificationText);
			//set failure tile
			var dataArr = notificationText.split(":");
			appView.byId("failureTile").setHeader(dataArr[1] + " failure");
			appView.byId("failureNC").setValue(dataArr[2].split(">")[0]);
		},
		onNotifPress: function (oEvent) {
			var oItem = oEvent.getParameter("listItem");
			var oCtx = oItem.getBindingContext();
			var data = {
				result: [{
					"MaintenanceNotification": oCtx.getProperty("MaintenanceNotification"),
					"NotificationCreationDate": oCtx.getProperty("NotificationCreationDate"),
					"NotificationText": oCtx.getProperty("NotificationText"),
					"MaintPriorityDesc": oCtx.getProperty("MaintPriorityDesc")
				}]
			};
			console.log("data " + JSON.stringify(data));
			var oModel = new sap.ui.model.json.JSONModel(data);
			oControllerThis._getNotifDetailDialog().open();
			sap.ui.getCore().byId("notifDtlTbl").setModel(oModel);
		},

		_getNotifDetailDialog: function () {
			if (!oControllerThis._oNotifDialog) {
				oControllerThis._oNotifDialog = sap.ui.xmlfragment("ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ShowNotifDetail", appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._oNotifDialog);
			}
			return oControllerThis._oNotifDialog;
		},

		onCloseNotifDialog: function () {
			oControllerThis._getNotifDetailDialog().close();
		},

		onSearch: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("MaintenanceNotification", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			// update list binding
			var oList = this.byId("notificationList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		GetWOHistory: function () {
			var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
			var records, recordsPMO;
			var MaintenanceOrderType = "YBA1";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetMaintenanceHistory",
				data: JSON.stringify({
					"currentDate": oControllerThis.getCurrentDateTime(),
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					woHistoryModel = new sap.ui.model.json.JSONModel(result);
					var woHistorycount = woHistoryModel.oData.results.length;
					appView.byId("PmWoHistory").setValue(woHistorycount);
					var MaintenanceHistoryData = [];
					records = [];
					var tempJson = woHistoryModel.getData();
					for (var j = 1; j <= 12; j++) {
						var count = 0;
						var MaintenanceHistoryDataCount = 0;
						for (var i = 0; i < woHistorycount; i++) {
							var date = tempJson.results[i].MaintOrdBasicStartDate;
							date = Number(date.substring(5, 7));
							if (j == date) {
								var cost = tempJson.results[i].MaintOrdTotalCost;
								cost = Number(cost.substring(cost.indexOf("/") + 1, cost.lastIndexOf("/")));
								count = count + cost;
								MaintenanceHistoryDataCount = MaintenanceHistoryDataCount + 1;
							}
						}
						var d = {
							"MaintOrdBasicStartDate": months[j - 1],
							"MaintOrdTotalCost": count
						};
						var a = {
							"MaintOrdBasicStartDate": months[j - 1],
							"MaintenanceHistoryDataCount": MaintenanceHistoryDataCount
						};
						records.push(d);
						MaintenanceHistoryData.push(a);
					}
					console.log(records);
					console.log(MaintenanceHistoryData);

					var MaintenanceHistoryModel = new sap.ui.model.json.JSONModel({
						MaintenanceHistoryData
					});

					var MaintenanceHistorylineChart = sap.ui.getCore().byId("idlLineVizFrame2");
					MaintenanceHistorylineChart.setModel(MaintenanceHistoryModel);
					Format.numericFormatter(ChartFormatter.getInstance());
					var formatPattern2 = ChartFormatter.DefaultPattern;
					MaintenanceHistorylineChart.setVizProperties({
						plotArea: {
							dataLabel: {
								formatString: formatPattern2.SHORTFLOAT_MFD2,
								visible: true
							}
						},
						valueAxis: {
							label: {
								formatString: formatPattern2.SHORTFLOAT
							},
							title: {
								visible: false
							}
						},
						categoryAxis: {
							title: {
								visible: false
							}
						}
					});

					var oPopOver2 = sap.ui.getCore().byId("idPopOver2");
					oPopOver2.connect(MaintenanceHistorylineChart.getVizUid());
					oPopOver2.setFormatString(formatPattern2.STANDARDFLOAT);

					var MaintenanceOrderType2 = "YBA2";
					$.ajax({
						method: "POST",
						contentType: "application/json",
						url: "/node/GetPreventiveMaintenanceOrder",
						data: JSON.stringify({
							"currentDate": oControllerThis.getCurrentDateTime(),
							"MaintenanceOrderType": MaintenanceOrderType2,
							"Equipment": eqpNo
						}),
						async: true,
						success: function (result) {
							oPMWorkOrderModel = new sap.ui.model.json.JSONModel(result);
							var WOCount = oPMWorkOrderModel.oData.results.length;
							recordsPMO = [];
							var tempJsonPMO = oPMWorkOrderModel.getData();
							console.log(tempJsonPMO);
							for (var j = 1; j <= 12; j++) {
								var count = 0;
								for (var i = 0; i < WOCount; i++) {
									var date = tempJsonPMO.results[i].MaintOrdBasicStartDate;
									date = Number(date.substring(5, 7));
									if (j == date) {
										var cost = tempJsonPMO.results[i].MaintOrdTotalCost;
										cost = Number(cost.substring(cost.indexOf("/") + 1, cost.lastIndexOf("/")));
										count = count + cost;
									}
								}
								var dataPMO = {
									"MaintOrdBasicStartDate": months[j - 1],
									"MaintOrdTotalCost": count
								};
								recordsPMO.push(dataPMO);
							}
							console.log(recordsPMO);
							var mesaureArr = [];
							console.log(recordsPMO[0].MaintOrdBasicStartDate);
							for (var j = 0; j < 12; j++) {
								var mesaureJson = {
									"MaintOrdBasicStartDate": records[j].MaintOrdBasicStartDate,
									"value1": records[j].MaintOrdTotalCost,
									"value2": recordsPMO[j].MaintOrdTotalCost
								};
								mesaureArr.push(mesaureJson);
							}
							console.log(mesaureArr);
							var CostTrendModel = new sap.ui.model.json.JSONModel({
								mesaureArr
							});

							var lineChart = sap.ui.getCore().byId("idlLineVizFrame");
							lineChart.setModel(CostTrendModel);
							Format.numericFormatter(ChartFormatter.getInstance());
							var formatPattern = ChartFormatter.DefaultPattern;
							lineChart.setVizProperties({
								plotArea: {
									dataLabel: {
										formatString: formatPattern.SHORTFLOAT_MFD2,
										visible: true
									}
								},
								valueAxis: {
									label: {
										formatString: formatPattern.SHORTFLOAT
									},
									title: {
										visible: false
									}
								},
								categoryAxis: {
									title: {
										visible: false
									}
								}
							});

							var oPopOver = sap.ui.getCore().byId("idPopOver");
							oPopOver.connect(lineChart.getVizUid());
							oPopOver.setFormatString(formatPattern.STANDARDFLOAT);
						},

						error: function (errorThrown) {
							console.error("GetPreventiveMaintenanceOrder error " + JSON.stringify(errorThrown));
						}
					});
				},
				error: function (errorThrown) {
					console.error("GetMaintenanceHistory error " + JSON.stringify(errorThrown));
				}
			});

		},

		onPressWOHistory: function () {
			oControllerThis._getWOHistoryDialog().open();
			sap.ui.getCore().byId("woHistoryTbl").setModel(woHistoryModel);
		},

		_getWOHistoryDialog: function () {
			if (!oControllerThis._oWODialog) {
				oControllerThis._oWODialog = sap.ui.xmlfragment("ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ShowWOHistory", appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._oWODialog);
				oControllerThis.GetWOHistory();
			}
			return oControllerThis._oWODialog;
		},

		onPressCloseWOHistory: function () {
			oControllerThis._getWOHistoryDialog().close();
		},

		GetPMWorkOrder: function (eqpNo) {
			var MaintenanceOrderType = "YBA2";
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetPreventiveMaintenanceOrder",
				data: JSON.stringify({
					"currentDate": oControllerThis.getCurrentDateTime(),
					"MaintenanceOrderType": MaintenanceOrderType,
					"Equipment": eqpNo
				}),
				async: true,
				success: function (result) {
					oPMWorkOrderModel = new sap.ui.model.json.JSONModel(result);
					var WOCount = oPMWorkOrderModel.oData.results.length;
					appView.byId("PreventiveMntncNC").setValue(WOCount);
				},
				error: function (errorThrown) {
					console.error("GetPreventiveMaintenanceOrder error " + JSON.stringify(errorThrown));
				}
			});
		},

		_getPMDialog: function () {
			if (!oControllerThis._oPMDialog) {
				oControllerThis._oPMDialog = sap.ui.xmlfragment("ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ShowPMPlan", appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._oPMDialog);
			}
			return oControllerThis._oPMDialog;
		},

		onPressClosePM: function () {
			oControllerThis._getPMDialog().close();
		},

		onPressPM: function () {
			oControllerThis._getPMDialog().open();
			sap.ui.getCore().byId("pmTbl").setModel(oPMWorkOrderModel);
		},

		onSubmitLoadChart: function () {
			var FromDate = appView.byId("FromDt").getValue();
			var ToDate = appView.byId("ToDt").getValue();
			if (FromDate == "" || FromDate == null) {
				oControllerThis.showMsgStrip("Please select a valid From Date", "Error");
			} else if (ToDate == "" || ToDate == null) {
				oControllerThis.showMsgStrip("Please select a valid To Date", "Error");
			} else if (FromDate > ToDate) {
				oControllerThis.showMsgStrip("To Date should be greater then From Date", "Error");
			} else {
				oControllerThis.loadPropertyChart(eqpNo, FromDate + "Z", ToDate + "Z");
			}
		},

		loadPropertyChart: function (eqpNo, fromDateTime, toDateTime) {
			var req = {
				PackageName: PackageName,
				thingid: ThingId,
				thingType: ThingType,
				fromDateTime: fromDateTime,
				toDateTime: toDateTime
			};
			console.log(req);
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetThingPropertyData",
				data: JSON.stringify(req),
				async: true,
				success: function (result) {
					var trendChartContainer = oControllerThis.getView().byId("trendChartContainer");
					var propertyChart = oControllerThis.getView().byId("propertyChart");
					if (result.property.length > 0) {
						trendChartContainer.setVisible(true);
						propertyChart.setVizProperties({
							title: {
								visible: false
							},
							valueAxis: {
								title: {
									visible: true
								}
							},
							categoryAxis: {
								title: {
									visible: true
								}
							},
							plotArea: {
								dataLabel: {
									visible: true,
									hideWhenOverlap: false
								},
								animation: {
									dataLoading: true
								}
							},
							legendGroup: {
								layout: {
									position: "bottom"
								}
							}
						});
						if (propertyChart.getDataset() != null) {
							propertyChart.destroyDataset();
						}
						var mesaureArr = [];
						var feedValArr = [];
						for (var k = 0; k < result.property.length; k++) {
							var mesaureJson = {
								name: result.property[k].Property,
								value: "{" + result.property[k].Property + "}"
							}
							mesaureArr.push(mesaureJson);
							feedValArr.push(result.property[k].Property);
						}

						var oVizFramegraph_dataset = new sap.viz.ui5.data.FlattenedDataset({
							dimensions: [{
								name: "Time",
								value: "{_time}"
							}],
							measures: mesaureArr,
							data: {
								path: "/value"
							}
						});
						//----set new Dataset to vizframe----//
						propertyChart.setDataset(oVizFramegraph_dataset);
						if (propertyChart.getFeeds() != null || propertyChart.getFeeds() != "") {
							propertyChart.destroyFeeds();
						}
						var feedPrimaryValues = new sap.viz.ui5.controls.common.feeds.FeedItem({
							uid: "valueAxis",
							type: "Measure",
							values: feedValArr
						});
						var feedAxisLabels = new sap.viz.ui5.controls.common.feeds.FeedItem({
							uid: "categoryAxis",
							type: "Dimension",
							values: ["Time"]
						});
						//----add new Feeds to vizframe----//
						propertyChart.addFeed(feedPrimaryValues);
						propertyChart.addFeed(feedAxisLabels);
						oChartModel = new sap.ui.model.json.JSONModel(result);
						propertyChart.setModel(oChartModel);
						var trendPopOver = oControllerThis.getView().byId("trendPopOver");
						trendPopOver.connect(propertyChart.getVizUid());
					} else {
						trendChartContainer.setVisible(false);
					}
				},
				error: function (errorThrown) {
					console.error("GetThingDataGvnRange error ");
				}
			});
		},

		loadPropertyGauge: function () {
			var req = {
				PackageName: PackageName,
				ThingId: ThingId
			};
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetPropertyGauge",
				data: JSON.stringify(req),
				async: true,
				success: function (result) {
					appView.byId("PropertyGauge").setContent(result.gaugeRecord);
				},
				error: function (errorThrown) {
					console.error("GetPropertyGauge error " + JSON.stringify(errorThrown));
				}
			});
		},

		_getSkipNotifDialog: function () {
			if (!oControllerThis._oSkipNotifDialog) {
				oControllerThis._oSkipNotifDialog = sap.ui.xmlfragment(
					"ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ShowSkipNotification",
					appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._oSkipNotifDialog);
			}
			return oControllerThis._oSkipNotifDialog;
		},

		onPressCancelSkipNotif: function () {
			oControllerThis._getSkipNotifDialog().close();
		},

		onPressSkipNotif: function () {
			oControllerThis._getSkipNotifDialog().close();
			var dateTime = oControllerThis.getCurrentDateTime();
			var time = dateTime.split("T")[1];
			var refTime = "PT" + time.substring(0, 2) + "H" + time.substring(3, 5) + "M" + time.substring(6, 8) + "S";
			var reqBody = {
				"NotificationNo": "0000" + notificationId,
				"RefDate": dateTime.split("T")[0] + "T00:00:00",
				"RefTime": refTime,
				"Equipment": eqpNo
			};
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/skipNotification",
				data: JSON.stringify(reqBody),
				async: false,
				success: function (result) {
					console.log("skipNotification result " + JSON.stringify(result));
					oControllerThis.showMsgStrip(result.Msg, result.Status);
					notificationId = "", notificationText = "";
					oControllerThis.loadNotifList();
				},
				error: function (errorThrown) {
					console.error("skipNotification error " + JSON.stringify(errorThrown));
					oControllerThis.showMsgStrip("Failed to Skip Notification " + notificationId + ".", "Error");
					notificationId = "", notificationText = "";
					oControllerThis.loadNotifList();
				}
			});
		},

		onClickSkip: function () {
			if (notificationId != "" && notificationId != undefined) {
				oControllerThis._getSkipNotifDialog().open();
				sap.ui.getCore().byId("confirmMsg").setText("Do you want to Skip Notification " + notificationId + "?");
			} else {
				oControllerThis.showMsgStrip("Notification not available/selected to Skip", "Information");
			}
		},

		_getCreatePMDialog: function () {
			if (!oControllerThis._oCreatPMDialog) {
				oControllerThis._oCreatPMDialog = sap.ui.xmlfragment("ui_app.SustainableManufacturingAsset_MonitoringDashboard.view.ShowCreatePMWO",
					appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._oCreatPMDialog);
			}
			return oControllerThis._oCreatPMDialog;
		},

		onPressCloseCreatePM: function () {
			oControllerThis._getCreatePMDialog().close();
		},

		onPressCreatePMWO: function () {
			oControllerThis._getCreatePMDialog().open();
			sap.ui.getCore().byId("createPMWODate").setMinDate(new Date());
			sap.ui.getCore().byId("createPMWODate").setDateValue(new Date());
			sap.ui.getCore().byId("pnWoShortText").setValue(notificationText);
			sap.ui.getCore().byId("selectedNotif").setText("Selected Notification No. " + notificationId);
			if (notificationId == "" || notificationId == undefined) {
				sap.ui.getCore().byId("submitBtn").setEnabled(false);
			} else {
				sap.ui.getCore().byId("submitBtn").setEnabled(true);
			}

		},
		handleLiveChange: function (oEvent) {
			var oTextArea = oEvent.getSource(),
				iValueLength = oTextArea.getValue().length,
				iMaxLength = oTextArea.getMaxLength(),
				sState = iValueLength > iMaxLength ? "Warning" : "None";
			oTextArea.setValueState(sState);
		},

		onPressSubmitCreatePM: function () {
			var selectedDatetime = sap.ui.getCore().byId("createPMWODate").getValue();
			var datetime = selectedDatetime.split("T")[0] + "T00:00:00";
			var time = selectedDatetime.split("T")[1];
			var Basicstart = "PT" + time.substring(0, 2) + "H" + time.substring(3, 5) + "M" + time.substring(6, 8) + "S";
			var components = [];
			var oTable = appView.byId("SpareParts");
			var pattern = /^\d+$/;
			for (var i in sparePartsRes.records) {
				var component = sparePartsRes.records[i].Component;
				var qty = sparePartsRes.records[i].CompQty;
				if (pattern.test(component)) {
					component = component.toString().padStart(18, "0");
				}
				var jsondata = {
					"Material": component,
					"Plant": Plant,
					"ItemCat": "L",
					"ItemNumber": ((Number(i) + 1) * 10).toString().padStart(4, "0"),
					"RequirementQuantity": qty.trim(),
					"RelationshipType": "FS"
				};
				components.push(jsondata);
			}
			var reqBody = {
				"Header": [{
					"Orderid": "%00000000001",
					"OrderType": "YBA1",
					"Planplant": Plant,
					"Plant": Plant,
					"Equipment": "0000000000" + ThingName,
					"StartDate": selectedDatetime,
					"Basicstart": Basicstart, //"PT18H20M00S",
					"ShortText": sap.ui.getCore().byId("pnWoShortText").getValue(),
					"NotifNo": "0000" + notificationId
				}],
				"Operation": [{
					"Activity": "0010",
					"ControlKey": "YBM1",
					"WorkCntr": ERP_WC,
					"Plant": Plant,
					"StandardTextKey": "",
					"Description": sap.ui.getCore().byId("pnWoShortText").getValue()
				}],
				"Component": components,
				"WorkFlow": {
					"Plant": Plant,
					"Equipment": ThingName,
					"UserEmail": "dipankar.saha@in.ibm.com",
					"MailID": "dipankar.saha@in.ibm.com"
				}
			};
			oControllerThis._getCreatePMDialog().close();
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/CreateWorkOrder",
				data: JSON.stringify(reqBody),
				async: true,
				success: function (result) {
					console.log("CreateWorkOrder success " + JSON.stringify(result));
					var MaintenanceOrder = "",
						MaintenanceNotif = "";
					for (var k in result) {
						if (result[k].Number == "126") {
							MaintenanceOrder = result[k].MessageV2;
							MaintenanceNotif = result[k].MessageV3;
							break;
						}
					}
					console.log(MaintenanceOrder + " : " + MaintenanceNotif);
					if (MaintenanceOrder != "" && MaintenanceNotif == notificationId) {
						var msg = "Work Order " + MaintenanceOrder + " successfully created against Notification " + MaintenanceNotif;
						oControllerThis.showMsgStrip(msg, "Success");
					} else {
						oControllerThis.showMsgStrip("Error in Work Order creation", "Error");
					}
					notificationId = "", notificationText = "";
					oControllerThis.loadNotifList();
				},
				error: function (errorThrown) {
					console.error("CreateWorkOrder error " + JSON.stringify(errorThrown));
					notificationId = "", notificationText = "";
					oControllerThis.showMsgStrip("Error in Work Order creation", "Error");
					oControllerThis.loadNotifList();
				}
			});
		},

		showMsgStrip: function (msgText, type) {
			var oMs = sap.ui.getCore().byId("msgStrip");
			if (oMs) {
				oMs.destroy();
			}
			this._generateMsgStrip(msgText, type);
		},

		_generateMsgStrip: function (msgText, type) {
			var oVC = appView.byId("oMsgLayout");
			oVC.setVisible(true);
			var oMsgStrip = new MessageStrip("msgStrip", {
				text: msgText,
				type: type,
				showIcon: true,
				showCloseButton: true
			});
			oVC.addContent(oMsgStrip);
			setTimeout(function () {
				oMsgStrip.close();
				oVC.setVisible(false);
			}, 8000);
		},
	});
});
sap.ui.define([
	"ui_app/SustainableManufacturingAsset_MonitoringDashboard/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
/*eslint no-console: 0*/
//hostname hardcoded
"use strict";
var nodemailer = require('nodemailer');
var xsjs = require("@sap/xsjs");
var xsenv = require("@sap/xsenv");
var hdbext = require("@sap/hdbext");
var express = require("express");
var async = require("async");
var deasync = require("deasync");
var app = express();
var http = require("http");
var https = require("https");
var request = require("request");
var bodyParser = require('body-parser');
const fs = require("fs");
var qs = require("querystring");
//var xml2json = require('fast-xml-parser').parse;
var xml2js = require('xml2js');
var stripNS = require('xml2js').processors.stripPrefix;
var appPort = 1998;
var soketPort = process.env.PORT || 3000;
var socketIO = require('socket.io');
var server = http.createServer(app);
var io = socketIO(server);
var socketObj;
var cron = require("cron");
var cors = require("cors");
app.use(cors());
var util = require('util');
var LTT = require('list-to-tree-lite');
var traverse = require('traverse');
const SapCfAxios = require('sap-cf-axios').default;
const axiosCSRF = SapCfAxios('S4HANA_Destination', null, {
	method: 'get',
	url: '/sap/opu/odata/sap/CB_EQUIPMENT_SRV/MaintenanceNotifications'
});
const axios = SapCfAxios('S4HANA_Destination');
const WF_axios = SapCfAxios('Workflow_Service');
const WF_Users_axios = SapCfAxios('Authorization');
const axiosWF = SapCfAxios('WorkFlowDestination');
const WF_Destinations = SapCfAxios("Destinations");
var hanaOptions = xsenv.getServices({
	hana: {
		tag: "hana"
	}
});
var hanaConfig = {
	host: hanaOptions.hana.host,
	port: hanaOptions.hana.port,
	user: hanaOptions.hana.user,
	encrypt: true,
	currentSchema: hanaOptions.hana.schema,
	sslValidateCertificate: false,
	password: hanaOptions.hana.password
};
app.use(bodyParser.json({
	limit: '10mb'
}));
app.use(bodyParser.urlencoded({
	extended: false,
	limit: '10mb'
}));

app.listen(appPort, function () {
	console.info("Listening on port: " + appPort);
});
app.post('/GetSiteWC', function (req, res) {
	var Token = getToken();
	var options = {
		hostname: "config-package-sap.cfapps.eu10.hana.ondemand.com",
		path: "/Package/v1/Packages",
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var requst = https.request(options, function (resp) {
		var body = '';
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on('end', function () {
			var data = {};
			var result = {
				records: [],
				Host: req.headers.host
			};
			/*var jsonBody = xml2json(body, {
				ignoreNameSpace: true
			});
			var entries = jsonBody.feed.entry;*/
			xml2js.parseString(body, {
				explicitArray: false,
				ignoreAttrs: true,
				trim: true,
				tagNameProcessors: [stripNS]
			}, function (err, result) {
				//console.log("result",result);
				var entries = result.feed.entry;
				if (entries != undefined) {
					entries.forEach(function (entry) {
						var str = entry.content.properties.Name.substring(entry.content.properties.Name.lastIndexOf(".") + 1);
						var plantDesc = entry.content.properties.Description.substring(0, entry.content.properties.Description.lastIndexOf("-") - 1);
						var wcDesc = entry.content.properties.Description.substring(entry.content.properties.Description.lastIndexOf("-") + 1,
							entry.content
							.properties
							.Description.length);
						var plant = str.substring(0, 4);
						var wc = str.substring(4, str.length);
						var erp_wc = wcDesc.substring(wcDesc.lastIndexOf("(") + 1, wcDesc.lastIndexOf(")"));
						if (wc != "") {
							data = {
								"Plant": plant,
								"PlantDesc": plantDesc,
								"WC": wc,
								"WCDesc": wcDesc,
								"ERP_WC": erp_wc
							};
							result.records.push(data);
						}
					});
					result.records.sort(function (a, b) {
						return a.Plant.localeCompare(b.Plant);
					});
				}
				res.type("application/json").status(200).send(result);
			});
		});
	});
	requst.end();
});

var getToken = deasync(function (callback) {
	var options = {
		"method": "POST",
		"hostname": "admi-subaccount.authentication.eu10.hana.ondemand.com",
		//"hostname": "ibm-sapain.authentication.eu10.hana.ondemand.com",
		"port": null,
		"path": "/oauth/token",
		"headers": {
			"content-type": "application/x-www-form-urlencoded"
		}
	};
	var req = https.request(options, function (res) {
		var chunks = [];
		res.on("data", function (chunk) {
			chunks.push(chunk);
		});
		res.on("end", function () {
			var body = Buffer.concat(chunks);
			var tokenJson = JSON.parse(body);
			callback(null, tokenJson.access_token);
		});
	});
	req.write(qs.stringify({
		client_id: 'sb-e51ad56f-80cd-4e34-a37d-b45f4408e4f5!b11739|iotae_service!b5',
		client_secret: 'y69nnCZYzuVnh2ONxcMFgJQpXT8=',
		/*client_id: 'sb-35e9f559-8d48-43e6-8be6-c56b5bf082c0!b28702|iotae_service!b5',
		client_secret: 'vIa9UUtOeCsQks2UPHEdY106pAc=',*/
		grant_type: 'client_credentials',
		response_type: 'token'
	}));
	req.end();
});

var getThingData = deasync(function (Token, Path, callback) {
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: Path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error(error);
		});
		res.on('end', function () {
			var dat = JSON.parse(body);
			callback(null, dat);
		});
	});
	req.end();
});

app.post('/getEquipmentRecords', function (req, res) {
	var PackageName = req.body.PackageName;
	var sql =
		'select distinct "TI"."ThingId","TI"."ThingName","TI"."ThingDesc","IT"."ThingType" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" "TI" join  "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag" "IT" on "IT"."ThingId" = "TI"."ThingId" where "TI"."PackageName"= ?';
	//'select "ThingId","ThingName","ThingDesc" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" where "PackageName"=? ';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("getEquipmentRecords: error=" + JSON.stringify(error));
			return res.type("application/json").status(500).send(JSON.stringify(error));
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("getEquipmentRecords: err=" + JSON.stringify(err));
				return res.type("application/json").status(500).send(JSON.stringify(err));
			}
			statement.exec([PackageName], function (er, results) {
				if (er) {
					console.error("getEquipmentRecords error " + JSON.stringify(er));
					return res.type("application/json").status(500).send(JSON.stringify(er));
				} else {
					var result = JSON.stringify({
						records: results
					});
					return res.type("application/json").status(202).send(result);
				}
			});
		});
	});
});

app.post('/getEquipmentTags', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var ThingId = req.body.ThingId;
	var prpSetSelected = req.body.PropertySet;
	var Color = req.body.Color;
	var sql =
		'select "IT"."ThingId", "IT"."ThingType","IT"."PropertySet", "IT"."Coordinates","IT"."Shape","TI"."Image" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag"  "IT" JOIN "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" "TI" ON "IT"."PackageName" = "TI"."PackageName" and "IT"."ThingId" = "TI"."ThingId" where "IT"."PackageName"=? AND "IT"."ThingId"=?';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("getEquipmentTags: error=" + JSON.stringify(error));
			return res.type("application/json").status(500).send(JSON.stringify(error));
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("getEquipmentTags: err=" + JSON.stringify(err));
				return res.type("application/json").status(500).send(JSON.stringify(err));
			}
			statement.exec([PackageName, ThingId], function (er, results) {
				if (er) {
					console.error("getEquipmentTags error " + JSON.stringify(er));
					return res.type("application/json").status(500).send(JSON.stringify(er));
				} else {
					var spanData = "";
					var min = 0,
						max = 100;
					var firstrange = 40;
					var secondrange = 70;
					var thirdrange = 100;
					var maxcol = "FA0E0E";
					var locol = "0F9A30";
					var valcol = "FAD30E";
					var prpSetResults = {
						records: []
					};
					var gauge = {
						records: []
					};
					var data = {},
						imgSrc, imgDiv;
					if (results.length > 0) {
						imgSrc = "data:image/jpg;base64," + results[0].Image;
						imgDiv = "<div style='position:relative'><img src='" + imgSrc + "'/>";
					}
					async.each(results, function (eachRecord, callback) {
						var currentitem = results.indexOf(eachRecord);
						var thingid = results[currentitem].ThingId;
						var thingType = results[currentitem].ThingType;
						var propertySet = results[currentitem].PropertySet;
						var coords = results[currentitem].Coordinates;
						data = {
							PopertySet: propertySet
						};
						prpSetResults.records.push(data);
						var path = "/Things('" + thingid + "')/admi.subaccount." + PackageName + ":" + thingType + "/" + propertySet +
							"?orderby=_time&timerange=1M&$top=1";
						//call api to get thing data 
						var thingData = getThingData(Token, path);
						var properties = getProperties(thingid, thingType, propertySet);
						var propertyElm = "";
						var propertyLabelTd = "",
							gaugeData = "";
						var rPath = "/Things('" + thingid + "')/ReferenceProperties/admi.subaccount." + PackageName + ":" + thingType + "/" +
							propertySet + "?orderby=_time&$top=1";
						var thingReferenceData = getThingData(Token, rPath);
						for (var i in properties) {
							var uom;
							if (properties[i].UOM != "") {
								uom = "(" + properties[i].UOM + ")";
							} else {
								uom = properties[i].UOM;
							}
							if (i == 0) {
								propertyLabelTd = "<td style='color:black;' align='center'>" + properties[i].Property + uom + "</td>";
							} else {
								propertyLabelTd = propertyLabelTd + "<td style='color:black;'  align='center'>" + properties[i].Property + uom + "</td>";
							}
							var upperThreshHold = 0;
							if (thingData.value != undefined) {
								if (thingData.value.length > 0) {
									if (thingReferenceData.value != undefined) {
										if (thingReferenceData.value.length > 0) {
											Object.keys(thingReferenceData.value[0]).forEach(function (key) {
												if (key.includes(properties[i].Property + "L")) {
													min = thingReferenceData.value[0][key];
												} else if (key.includes(properties[i].Property + "U")) {
													upperThreshHold = thingReferenceData.value[0][key];
													if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
														Color = "red";
														max = Number(thingData.value[0][properties[i].Property]) + 100;
													} else {
														Color = "green";
														max = Number(upperThreshHold) + 100;
													}
													firstrange = Number(upperThreshHold) - 1;
													secondrange = Number(upperThreshHold) - 1;
													thirdrange = max;
												}
											});
										} else {
											min = 0;
											upperThreshHold = 28;
											if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
												Color = "red";
												max = Number(thingData.value[0][properties[i].Property]) + 100;
											} else {
												Color = "green";
												max = Number(upperThreshHold) + 100;
											}
											firstrange = Number(upperThreshHold) - 1;
											secondrange = Number(upperThreshHold) - 1;
											thirdrange = max;
										}
									} else {
										min = 0;
										upperThreshHold = 28;
										if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
											Color = "red";
											max = Number(thingData.value[0][properties[i].Property]) + 100;
										} else {
											Color = "green";
											max = Number(upperThreshHold) + 100;
										}
										firstrange = Number(upperThreshHold) - 1;
										secondrange = Number(upperThreshHold) - 1;
										thirdrange = max;
									}
									if (i == 0) {
										propertyElm = properties[i].Property + " : " + thingData.value[0][properties[i].Property] + " " + properties[i].UOM;
										gaugeData = "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
											min +
											"%26max=" + max +
											"%26val=" +
											thingData.value[0][properties[i].Property] +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 6rem;width: 10rem;border: 0px;'></iframe></td>";
									} else {
										propertyElm = propertyElm + "<br>" + properties[i].Property + " : " + thingData.value[0][properties[i].Property] + " " +
											properties[i].UOM;
										gaugeData = gaugeData +
											"<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
											min + "%26max=" +
											max +
											"%26val=" + thingData.value[0][properties[i].Property] +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 6rem;width: 10rem;border: 0px;'></iframe></td>";
									}
								} else {
									if (thingReferenceData.value != undefined) {
										if (thingReferenceData.value.length > 0) {
											Object.keys(thingReferenceData.value[0]).forEach(function (key) {
												if (key.includes(properties[i].Property + "L")) {
													min = thingReferenceData.value[0][key];
												} else if (key.includes(properties[i].Property + "U")) {
													upperThreshHold = thingReferenceData.value[0][key];
													max = Number(upperThreshHold) + 100;
													firstrange = Number(upperThreshHold) - 1;
													secondrange = Number(upperThreshHold) - 1;
													thirdrange = max;
												}
											});
										} else {
											min = 0;
											upperThreshHold = 710;
											max = upperThreshHold;
											Color = "green";
											firstrange = Number(upperThreshHold) - 1;
											secondrange = Number(upperThreshHold) - 1;
											thirdrange = max;
										}
									} else {
										min = 0;
										upperThreshHold = 710;
										max = upperThreshHold;
										Color = "green";
										firstrange = Number(upperThreshHold) - 1;
										secondrange = Number(upperThreshHold) - 1;
										thirdrange = max;
									}
									if (i == 0) {
										propertyElm = properties[i].Property + " : NA";
										gaugeData = "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
											min +
											"%26max=" + max +
											"%26val=0" +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 6rem;width: 10rem;border: 0px;'></iframe></td>";
									} else {
										propertyElm = propertyElm + "<br>" + properties[i].Property + " : NA";
										gaugeData = gaugeData +
											"<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
											min + "%26max=" +
											max +
											"%26val=0" +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 6rem;width: 10rem;border: 0px;'></iframe></td>";
									}
								}
							}
						}
						var tempData = {};
						tempData[propertySet] = "<table><tr>" + propertyLabelTd + "</tr><tr>" + gaugeData + "</tr></table>";
						gauge.records.push(tempData);
						spanData = spanData + getSpanStr(Color, coords, "Property Set : " + propertySet + "<br>" + propertyElm, propertySet,
							"<table><tr>" + gaugeData + "</tr></table>");
						callback(null);
					}, function (err) {
						if (err) {
							console.error('getEquipmentTags something went wrong err===>>>' + JSON.stringify(err));
						} else {
							var result = JSON.stringify({
								prpSetRecords: prpSetResults,
								span: spanData + "</div>",
								imgDiv: imgDiv,
								gaugeRecord: gauge
							});
							return res.type("application/json").status(202).send(result);
						}
					});
				}
			});
		});
	});
});

var getProperties = deasync(function (ThingId, ThingType, PropertySet, cb) {
	var sql =
		'select * from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty"  where "ThingId"=? and "ThingType"=? and "PropertySet"=?';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("getProperties: error=" + JSON.stringify(error));
			return;
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("getProperties: err=" + JSON.stringify(err));
				return;
			}
			statement.exec([ThingId, ThingType, PropertySet], function (er, results) {
				if (er) {
					console.error("getProperties error " + JSON.stringify(er));
				} else {
					cb(null, results);
				}
			});
		});
	});

});

var getSpanStr = deasync(function (Color, Coordinates, data, propertySet, gaugeDataTbl, callback) {
	var coorArr = Coordinates.split(',');
	var top = coorArr[0];
	var left = coorArr[1];
	var bottom = coorArr[2];
	var right = coorArr[3];
	var height = bottom - top;
	var width = right - left;
	var borderColor, boxShadow, cssClass;
	if (Color == "green") {
		borderColor = "transparent";
		//boxShadow = "20px 20px 20px #505050";
		cssClass = "clickableDiv dataDiv";
	} else if (Color == "red") {
		borderColor = Color;
		//boxShadow = "20px 20px 20px #db5b1d";
		cssClass = "clickableDiv customBlink dataDiv";
	} else {
		Color = "green";
		borderColor = "transparent";
		//boxShadow = "20px 20px 20px #505050";
		cssClass = "clickableDiv dataDiv";
	}
	var selectedArea = "<div id='" + propertySet + "Area' class='mappedDiv' style='top:" + top + "px ;  left:" + left + "px; height:" +
		height + "px; width:" + width +
		"px;'></div>";
	top = Number(top) + Number(height) + 15;
	/*var dataDiv = "<div id='" + propertySet + "' class='" + cssClass + "' style='opacity:.1; top:" + top + "px; left:" + left +
		"px; border-color:" + borderColor + ";  box-shadow: " + boxShadow + ";  color: " + Color + "'>" + data + "<br>" + gaugeDataTbl +
		"</div>";*/
	var dataDiv = "<div id='" + propertySet + "' class='" + cssClass + "' style='opacity:.1; top:" + top + "px; left:" + left +
		"px; border-color:" + borderColor + ";  box-shadow: " + boxShadow + ";  color: white'>" + data + "<br>" + gaugeDataTbl +
		"</div>";
	callback(null, selectedArea + dataDiv);
});

app.post('/GetNotificationList', async function (req, res) {
	var equipment = req.body.equipment;
	//console.log(equipment);
	//fetching data for last 1 week
	var dt = new Date();
	var formatted_dt = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var toDate = formatted_dt + "T00:00:00";
	dt.setDate(dt.getDate() - 7);
	var formatted_dt2 = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var fromDate = formatted_dt2 + "T00:00:00";
	//console.log(fromDate);
	var url = '/sap/opu/odata/sap/CB_EQUIPMENT_SRV/MaintenanceNotifications?$filter=(Equipment eq \'' + equipment +
		'\' and NotifProcessingPhase eq \'1\' and NotificationCreationDate  gt datetime\'' + fromDate + '\')';
	console.log(url);
	const config = {
		method: 'GET',
		url: url,
		headers: {
			"content-type": "application/json"
		},
	}
	try {
		let resp = await axios(config);
		var ms, time, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].NotificationCreationDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().split('.')[0].split("T")[0];
			time = data[i].MZEIT; // time in PT12H56M04S format 
			data[i].NotificationCreationDate = tempDate + " " + time.substring(2, 4) + ":" + time.substring(5, 7) + ":" + time.substring(8, 10);
		}
		data.sort(function (a, b) {
			return a.MaintenanceNotification.localeCompare(b.MaintenanceNotification);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
	} catch (error) {
		console.error('GetNotificationList error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

/*app.post('/postNotificationCount', async function (req, res) {
	var PredictedRootCauseEquip = "10002258";
	var description = req.body.content;
	var ThingId = req.body.ThingId;
	var ThingName = req.body.ThingName;
	var Priority = req.body.Priority;
	var PropertySet = req.body.PropertySet;
	var ThrustBearingValue = req.body.ThrustBearingValue;
	var VibrationValue = req.body.VibrationValue;
	var Property = req.body.Property;
	if (PredictedRootCauseEquip !== ThingName) {
		ThingName = PredictedRootCauseEquip;
	} else if (PredictedRootCauseEquip === "" || PredictedRootCauseEquip === undefined) {
		ThingName = req.body.ThingName;
	} else {
		ThingName = req.body.ThingName;
	}
	if (Priority.toUpperCase() === ("Very high").toUpperCase()) {
		Priority = "1";
	} else if (Priority.toUpperCase() === ("high").toUpperCase()) {
		Priority = "2";
	} else if (Priority.toUpperCase() === ("Medium").toUpperCase()) {
		Priority = "3";
	} else if (Priority.toUpperCase() === ("low").toUpperCase()) {
		Priority = "4";
	}
	var dt = new Date();
	var dateTime = dt.getTime();
	var currentDT = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0];
	var time = currentDT.split("T")[1];
	var NotificationTime = "PT" + time.substring(0, 2) + "H" + time.substring(3, 5) + "M" + time.substring(6, 8) + "S";

	const config = {
		method: 'POST',
		url: '/sap/opu/odata/sap/eam_ntf_create/NotificationHeaderSet',
		headers: {
			"content-type": "application/json"
		},
		data: {
			"AttachmentId": "",
			"UserCanBeNotified": false,
			"NotificationPhase": "1",
			"PlantSection": "",
			"Completed": false,
			"Room": "",
			"NotificationNumber": "",
			"ShortText": description,
			"NotificationTimezone": "EET",
			"NotificationDate": "\/Date(" + dateTime + ")\/",
			"NotificationTime": NotificationTime, //"PT15H23M16S", /////////////////////// check/////////////////////////////
			"TecObjNoLeadingZeros": "",
			"TechnicalObjectTypeDesc": "",
			"ReporterDisplay": "",
			"LastChangedTimestamp": "\/Date(" + dateTime + ")\/",
			"TechnicalObjectType": "EAMS_EQUI",
			"Deleted": false,
			"Effect": "",
			"EffectText": "",
			"DateMonitor": "Y",
			"NotificationTimestamp": "\/Date(" + dateTime + ")\/",
			"ReporterUserId": "",
			"TechnicalObjectNumber": ThingName,
			"TechnicalObjectDescription": "",
			"NotificationType": "M1",
			"Priority": Priority,
			"PriorityType": "PM",
			"PriorityText": "",
			"Location": "",
			"Reporter": "",
			"Subscribed": false
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let hanaResp = await axiosCSRF(config);
		var EquipmentName = hanaResp.data.d.TechnicalObjectDescription;
		var result = JSON.stringify({
			ThingId: ThingId,
			PropertySet: PropertySet,
			Msg: "Notification " + hanaResp.data.d.NotificationNumber + " is created."
		});
		if (socketObj != undefined) {
			socketObj.emit('NotificationCount', result);
		}
		//console.log(result);
		var transporter = nodemailer.createTransport({
			service: 'gmail',
			auth: {
				user: 'maviya.farnaz1@gmail.com',
				pass: 'P@ssWord#$'
			}
		});
		var mailOptions = {
			from: 'maviya.farnaz1@gmail.com',
			to: 'mfarnaz1@in.ibm.com, , deb.chakraborty@uk.ibm.com, dipankar.saha@in.ibm.com, sudipta.mukherjee@in.ibm.com, avijdhar@in.ibm.com',
			subject: 'Equipment ' + ThingName + '(' + EquipmentName + ') Failure Notification Creation',
			html: '<h1 style="color:#27408b; text-align:center;">' + ThrustBearingValue +
				'(Deg C) and ' + VibrationValue +
				'(MMS) exceeded Reliable Thresholds.Inspection recommended.</h1><h1 style="color:#27408b; text-align:center;">Potential root cause from S-DAM: ' +
				ThingName + '(' + EquipmentName +
				')</h1><div style="display: flex; justify-content: center;"><a href="https://gbs-admi-global-cf-org-dev-connectedassetpai-monitoring253e1ab6.cfapps.eu10.hana.ondemand.com/ConnectedAssetPAI_MonitoringDashboard/index.html" target="_blank"><button style="width: 230px;  text-align: center; color: black; padding: 5px 15px; font-size: 16px; margin: auto;cursor: pointer; margin-right: 20px; transition-duration: 0.4s;">Monitoring Dashboard</button></a></div><div style="display: flex;"><h3 style="text-align:left;">This is an automated email. please do not respond to this email id.</h3></div>'
		};

		transporter.sendMail(mailOptions, function (Error, info) {
			if (Error) {
				console.log(Error);
			} else {
				console.log('Email sent');
			}
		});
		console.log("----------------------------------------------- mail sent");
		return res.type("application/json").status(200).send(result);
	} catch (error) {
		console.error('postNotificationCount error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});*/
app.post('/postNotificationCount', async function (req, res) {
	var dt = new Date();
	var dateTime = dt.getTime();
	var currentDT = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0];
	var time = currentDT.split("T")[1];
	var NotificationTime = "PT" + time.substring(0, 2) + "H" + time.substring(3, 5) + "M" + time.substring(6, 8) + "S";
	var NotifArray = [];
	var InputReq = req.body.InputRequest;
	for (var i = 0; i < InputReq.length; i++) {
		var description = InputReq[i].content;
		var ThingId = InputReq[i].ThingId;
		var ThingName = InputReq[i].ThingName;
		var Priority = InputReq[i].Priority;
		var PropertySet = InputReq[i].PropertySet;
		var ThrustBearingValue = InputReq[i].ThrustBearingValue;
		var VibrationValue = InputReq[i].VibrationValue;
		var Property = InputReq[i].Property;
		var MailFlag = InputReq[i].MailFlag;
		console.log(ThingName + "------" + MailFlag);
		if (Priority.toUpperCase() === ("Very high").toUpperCase()) {
			Priority = "1";
		} else if (Priority.toUpperCase() === ("high").toUpperCase()) {
			Priority = "2";
		} else if (Priority.toUpperCase() === ("Medium").toUpperCase()) {
			Priority = "3";
		} else if (Priority.toUpperCase() === ("low").toUpperCase()) {
			Priority = "4";
		}
		const config = {
			method: 'POST',
			url: '/sap/opu/odata/sap/eam_ntf_create/NotificationHeaderSet',
			headers: {
				"content-type": "application/json"
			},
			data: {
				"AttachmentId": "",
				"UserCanBeNotified": false,
				"NotificationPhase": "1",
				"PlantSection": "",
				"Completed": false,
				"Room": "",
				"NotificationNumber": "",
				"ShortText": description,
				"NotificationTimezone": "EET",
				"NotificationDate": "\/Date(" + dateTime + ")\/",
				"NotificationTime": NotificationTime, //"PT15H23M16S", /////////////////////// check/////////////////////////////
				"TecObjNoLeadingZeros": "",
				"TechnicalObjectTypeDesc": "",
				"ReporterDisplay": "",
				"LastChangedTimestamp": "\/Date(" + dateTime + ")\/",
				"TechnicalObjectType": "EAMS_EQUI",
				"Deleted": false,
				"Effect": "",
				"EffectText": "",
				"DateMonitor": "Y",
				"NotificationTimestamp": "\/Date(" + dateTime + ")\/",
				"ReporterUserId": "",
				"TechnicalObjectNumber": ThingName,
				"TechnicalObjectDescription": "",
				"NotificationType": "M1",
				"Priority": Priority,
				"PriorityType": "PM",
				"PriorityText": "",
				"Location": "",
				"Reporter": "",
				"Subscribed": false
			},
			xsrfHeaderName: "x-csrf-token"
		};
		try {
			let hanaResp = await axiosCSRF(config);
			var EquipmentName = hanaResp.data.d.TechnicalObjectDescription;

			var Notification = hanaResp.data.d.NotificationNumber;
			NotifArray.push(Notification);

			if (MailFlag === "1") {
				var transporter = nodemailer.createTransport({
					service: 'gmail',
					auth: {
						user: 'maviya.farnaz1@gmail.com',
						pass: 'P@ssWord#$'
					}
				});
				var mailOptions = {
					from: 'maviya.farnaz1@gmail.com',
					to: 'mfarnaz1@in.ibm.com, , deb.chakraborty@uk.ibm.com, dipankar.saha@in.ibm.com, sudipta.mukherjee@in.ibm.com, avijdhar@in.ibm.com',
					subject: 'Equipment ' + ThingName + '(' + EquipmentName + ') Failure Notification Creation',
					html: '<h1 style="color:#27408b; text-align:center;">' + ThrustBearingValue +
						'(Deg C) and ' + VibrationValue +
						'(MMS) exceeded Reliability Thresholds. Inspection recommended.</h1><h1 style="color:#27408b; text-align:center;">Potential root cause from S-DAM: ' +
						ThingName + '(' + EquipmentName +
						')</h1><div style="display: flex; justify-content: center;"><a href="https://xww7bpwfqv44kb5ynitoringdashboard.cfapps.eu10.hana.ondemand.com/ConnectedAssetPAI_MonitoringDashboard/index.html" target="_blank"><button style="width: 230px;  text-align: center; color: black; padding: 5px 15px; font-size: 16px; margin: auto;cursor: pointer; margin-right: 20px; transition-duration: 0.4s;">Monitoring Dashboard</button></a></div><div style="display: flex;"><h3 style="text-align:left;">This is an automated email. please do not respond to this email id.</h3></div>'
				};

				transporter.sendMail(mailOptions, function (Error, info) {
					if (Error) {
						console.log(Error);
					} else {
						console.log('Email sent');
					}
				});
				console.log("----------------------------------------------- mail sent");
			}
		} catch (error) {
			console.error('postNotificationCount error===>>>' + JSON.stringify(error));
			//return res.type("application/json").status(500).send(JSON.stringify(error));
		}
	}
	var result = JSON.stringify({
		Msg: "Notification " + NotifArray.toString() + " are created."
	});
	return res.type("application/json").status(200).send(result);
});

app.post('/GetIoTAEHierarchy', function (req, res) {
	var Token = getToken();
	var Hostname = "appiot-mds.cfapps.eu10.hana.ondemand.com";
	var options = {
		hostname: Hostname,
		path: "/Things",
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var requst = https.request(options, function (resp) {
		var body = '';
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on('end', function () {
			var data = {};
			var eqpData = {};
			var thingTypeId = "",
				thingType = "",
				thingPkg = "",
				path = "",
				thingConfigData;
			var eqpGrp = [];
			JSON.parse(body).value.forEach(function (eachRecord) {
				thingTypeId = eachRecord._thingType.toString();
				thingPkg = thingTypeId.substring(thingTypeId.lastIndexOf(".") + 1, thingTypeId.lastIndexOf(":"));
				thingType = thingTypeId.substring(thingTypeId.lastIndexOf(":") + 1, thingTypeId.length);
				path = "/Things('" + eachRecord._id.toString() + "')/Configuration"
				thingConfigData = getThingConfigData(Token, Hostname, path);
				eqpData = {
					ThingId: eachRecord._id.toString(),
					Name: eachRecord._name.toString(),
					ThingDesc: eachRecord._description.en.toString(),
					ThingPkg: thingPkg,
					ThingType: thingType,
					Category: "Equipment",
					Group: thingConfigData.Group
				}
				eqpGrp.push(eqpData);
			});
			var groupBy = function (xs, key) {
				return xs.reduce(function (rv, x) {
					(rv[x[key]] = rv[x[key]] || []).push(x);
					return rv;
				}, {});
			};
			var groubedByPkg = groupBy(eqpGrp, 'ThingPkg');
			var pckg, tempArr = [];
			var value = JSON.parse(body).value;
			for (var i in value) {
				tempArr.push(value[i]._thingType.toString().substring(value[i]._thingType.toString().lastIndexOf(".") + 1, value[i]._thingType.toString()
					.indexOf(":")));
			}
			let uniquePck = [...new Set(tempArr)];
			var result = {
				Group: [],
				Host: req.headers.host
			};
			for (var i in uniquePck) {
				var y = {
					Name: uniquePck[i],
					Category: "Package",
					Group: groubedByPkg[uniquePck[i]]
				};
				result.Group.push(y);
			}
			res.type("application/json").status(200).send(JSON.stringify(result));
		});
	});
	requst.end();
});

var getThingConfigData = deasync(function (Token, Hostname, Path, callback) {
	var options = {
		hostname: Hostname,
		path: Path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error("getThingConfigData error >> " + JSON.stringify(error));
		});
		res.on('end', function () {
			var dat = JSON.parse(body);
			var prpSet = {},
				property = {},
				prpSetId;
			var result = {
				Group: []
			};
			dat.propertySetTypes.forEach(function (eachPrpSet) {
				var propertyGrp = [];
				if (eachPrpSet.dataCategory == "TimeSeriesData") {
					prpSetId = eachPrpSet.name.toString().substring(eachPrpSet.name.toString().lastIndexOf(":") + 1, eachPrpSet.name.toString().length);
					eachPrpSet.propertyTypes.forEach(function (eachPrp) {
						property = {
							Name: eachPrp.value.id,
							Category: "Property",
							UOM: eachPrp.value.unitOfMeasure
						};
						propertyGrp.push(property);
					});
					prpSet = {
						Name: prpSetId,
						Category: "PropertySet",
						Group: propertyGrp
					};
					result.Group.push(prpSet);
				}
			});
			dat.thingTypes.forEach(function (eachThingTypes) {
				result.ThingType = eachThingTypes.name;
				result.ThingTypeDescription = eachThingTypes.description.en;
			});
			callback(null, result);
		});
	});
	req.end();
});

app.post('/getUsedCoords', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var ThingId = req.body.ThingId;
	var prpSetSelected = req.body.PropertySet;
	var Color = req.body.Color;
	var sql =
		'select "IT"."ThingId", "IT"."ThingType","IT"."PropertySet", "IT"."Coordinates","IT"."DataPosition","IT"."Shape","TI"."Image" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag"  "IT" JOIN "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" "TI" ON "IT"."PackageName" = "TI"."PackageName" and "IT"."ThingId" = "TI"."ThingId" where "IT"."PackageName"=? AND "IT"."ThingId"=?';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("getUsedCoords: error=" + JSON.stringify(error));
			return res.type("application/json").status(500).send(JSON.stringify(error));
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("getUsedCoords: err=" + JSON.stringify(err));
				return res.type("application/json").status(500).send(JSON.stringify(err));
			}
			statement.exec([PackageName, ThingId], function (er, results) {
				if (er) {
					console.error("getUsedCoords error " + JSON.stringify(er));
					return res.type("application/json").status(500).send(JSON.stringify(er));
				} else {
					var spanData = "";
					var data = {},
						imgSrc, imgDiv;
					var prpResults = {
						records: []
					};
					if (results.length > 0) {
						imgSrc = "data:image/jpg;base64," + results[0].Image;
						imgDiv = "<div style='position:relative'><img src='" + imgSrc + "'/>";
					}
					async.each(results, function (eachRecord, callback) {
						var currentitem = results.indexOf(eachRecord);
						var thingid = results[currentitem].ThingId;
						var thingType = results[currentitem].ThingType;
						var propertySet = results[currentitem].PropertySet;
						var coords = results[currentitem].Coordinates;
						var DataPosition = results[currentitem].DataPosition;
						var properties = getProperties(thingid, thingType, propertySet);
						data = {
							PropertySet: propertySet,
							coords: coords,
							Property: properties
						}
						prpResults.records.push(data);
						var propertyElm = "",
							uom;
						for (var i in properties) {
							if (properties[i].UOM != "" && properties[i].UOM != undefined) {
								uom = "(" + properties[i].UOM + ")";
							} else {
								uom = "";
							}
							if (i == 0) {
								propertyElm = properties[i].Property + uom;
							} else {
								propertyElm = propertyElm + "<br>" + properties[i].Property + uom;
							}
						}
						spanData = spanData + getUsedCoordsStr(coords, "Property Set : " + propertySet + "<br>" + propertyElm, DataPosition);
						callback(null);
					}, function (err) {
						if (err) {
							console.error('getUsedCoords something went wrong err===>>>' + JSON.stringify(err));
						} else {
							var result = JSON.stringify({
								prpRecords: prpResults,
								span: spanData + "</div>",
								imgDiv: imgDiv
							});
							return res.type("application/json").status(202).send(result);
						}
					});
				}
			});
		});
	});
});

var getUsedCoordsStr = deasync(function (Coordinates, data, DataPosition, callback) {
	var coorArr = Coordinates.split(',');
	var top = coorArr[0];
	var left = coorArr[1];
	var bottom = coorArr[2];
	var right = coorArr[3];

	var height = bottom - top;
	var width = right - left;

	var selectedArea = "<div style='top:" + top + "px ; left:" + left + "px; height:" + height +
		"px; width:" + width + "px; position:absolute ;font-weight: bold; border:solid 5px; border-radius: 10px; color:white;'></div>";
	/*if (DataPosition == "Left") {
		top = top;
		left = left - 200;
	} else if (DataPosition == "Right") {
		top = top;
		left = left + 100;
	} else if (DataPosition == "Top") {
		top = top - 100;
		left = left;
	} else if (DataPosition == "Bottom") {
		top = left + 100;
		left = left;
	} else {
		top = top;
		left = left;
	}
	var dataArea = "<div style='top:" + top + "px ; left:" + left +
		"px; position:absolute ; border:solid 5px;border-radius: 10px; color: #595550'>" + data +
		"</div>";*/
	//callback(null, selectedArea);
	top = Number(top) + Number(height) + 15;
	/*	var dataDiv = "<div style='top:" + top + "px; left:" + left +
			"px; position:absolute ; border:solid 5px; border-radius: 10px; background:white ; color:black; border-color: #800000; opacity: 0.8; box-shadow: 20px 20px 20px #505050; font-weight: bold;'>" +
			data + "</div>";*/
	var dataDiv = "<div style='top:" + top + "px; left:" + left +
		"px; position:absolute ; border:solid 5px; border-radius: 10px; background:#29313a ; color:white; border-color: #800000; opacity: 0.8; font-weight: bold;'>" +
		data + "</div>";
	callback(null, selectedArea + dataDiv);
});

app.post('/insertThingDetails', function (req, res) {
	var PackageName = req.body.InputRequest.PackageName;
	var ThingId = req.body.InputRequest.ThingId;
	var ThingDesc = req.body.InputRequest.ThingDesc;
	var ThingType = req.body.InputRequest.ThingType;
	var ThingName = req.body.InputRequest.ThingName;
	var basecode = req.body.InputRequest.basecode;
	var coords = req.body.InputRequest.coords;
	var DateTime = req.body.InputRequest.DateTime;
	var ifUpdt = req.body.InputRequest.ifUpdt;
	var DataPosition = req.body.InputRequest.DataPosition;
	var PropertySets = req.body.InputRequest.PropertySets;
	var ChildEqp = req.body.InputRequest.ChildEqp;
	var ParentThingId = req.body.InputRequest.ParentThingID;
	var ifChangeImg = req.body.InputRequest.ifChangeImg;
	var HierarchyID = req.body.InputRequest.HierarchyID;
	var RootThingID = req.body.InputRequest.RootThingID;
	//Getting Property Type Flag from input request
	var Flag = req.body.InputRequest.Flag;
	if (ifChangeImg == 1) {
		var dltResult = deleteThingData(ThingId);
		deleteQuery2Param(ThingId, "%",
			'DELETE FROM "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ChildThing" WHERE "ParentThingId" =? and "ThingId" like ?'
		);
	} else {
		if (ifUpdt == 1) {
			if (PropertySets.length > 0) {
				var dltResult = deleteThingData(ThingId);
			} else if (ChildEqp.ThingId != "" && ChildEqp.ThingId != undefined) {
				//dlt selected child of given ThingId
				deleteQuery2Param(ThingId, ChildEqp.ThingId,
					'DELETE FROM "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ChildThing" WHERE "ParentThingId" =? and "ThingId"=?'
				);
			}
		} else if (ifUpdt < 0) {
			//dlt img tag,thing prp of the given thing id & prp set
			var dltResult = deleteThingDataOfGvnPrp(ThingId, PropertySets[0].PropertySet);
		}
	}
	var dltFromThingImage = deleteQuery(ThingId,
		'DELETE FROM "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" WHERE "ThingId" =?');
	var sql =
		'insert into "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" ("PackageName","ThingId","ThingName","ThingDesc","ThingType","Image","DateTime","Flag","HierarchyID","RootThingID") values(?,?,?,?,?,?,?,?,?,?)';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("insertThingDetail: error=" + JSON.stringify(error));
			return;
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("insertThingDetail: err=" + JSON.stringify(err));
				return;
			}
			statement.exec([PackageName, ThingId, ThingName, ThingDesc, ThingType, basecode, DateTime, Flag, HierarchyID, RootThingID],
				function (er,
					results) {
					if (er) {
						console.error("insertThingDetail er " + JSON.stringify(er));
					} else {
						if (PropertySets != "" && PropertySets != undefined) {
							async.each(PropertySets, function (eachPropertySet, callback) {
								var currentitem = PropertySets.indexOf(eachPropertySet);
								var PropertySet = PropertySets[currentitem].PropertySet;
								var insertImgTags = insertImageTag(PackageName, ThingId, ThingType, PropertySet, coords, "rect", DateTime, DataPosition,
									Flag);
								var properties = PropertySets[currentitem].Property;
								async.each(properties, function (eachProperty, cb) {
									var indx = properties.indexOf(eachProperty);
									var Property = properties[indx].Property;
									var UOM = properties[indx].UOM;
									var insertThingPrp = insertThingProperty(ThingId, ThingType, PropertySet, Property, UOM, DateTime, Flag);
									cb(null);
								}, function (err) {
									if (err) {
										console.error('something went wrong err===>>>' + err);
									}
								});
								callback(null);
							}, function (err) {
								if (err) {
									console.error('something went wrong err===>>>' + err);
								} else {
									var rst = JSON.stringify({
										status: "success"
									});
									return res.type("application/json").status(202).send(rst);
								}
							});
						} else if (ChildEqp != "" && ChildEqp != undefined) {
							var sql =
								'insert into "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ChildThing" ("PackageName","ThingId","ThingName","ThingDesc","ThingType","ParentThingId","Coordinates","Shape","DateTime","Flag") values(?,?,?,?,?,?,?,?,?,?)';
							hdbext.createConnection(hanaConfig, function (error, client) {
								if (error) {
									console.error("insertChildEquipment: error=" + JSON.stringify(error));
									return;
								}
								client.prepare(sql, function (err, statement) {
									if (err) {
										console.error("insertChildEquipment: err=" + JSON.stringify(err));
										return;
									}
									statement.exec([PackageName, ChildEqp.ThingId, ChildEqp.ThingName, ChildEqp.ThingDesc,
											ChildEqp.ThingType, ThingId, coords, "rect", DateTime, Flag
										],
										function (er,
											results) {
											if (er) {
												console.error("insertChildEquipment error " + JSON.stringify(er));
												var rst = JSON.stringify({
													status: "failed"
												});
												return res.type("application/json").status(500).send(rst);
											} else {
												var rst = JSON.stringify({
													status: "success"
												});
												return res.type("application/json").status(202).send(rst);
											}
										});
								});
							});
						}
					}
				});
		});
	});
});

var insertImageTag = deasync(function (PackageName, ThingId, ThingType, PropertySet, Coordinates, Shape, DateTime, DataPosition, Flag,
	callback) {
	var sql =
		'insert into "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag" ("PackageName","ThingId","ThingType","PropertySet","Coordinates","Shape","DateTime","DataPosition","Flag") values(?,?,?,?,?,?,?,?,?)';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("insertImageTag: error=" + JSON.stringify(error));
			return;
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("insertImageTag: err=" + JSON.stringify(err));
				return;
			}
			statement.exec([PackageName, ThingId, ThingType, PropertySet, Coordinates, Shape, DateTime, DataPosition, Flag], function (er,
				results) {
				if (er) {
					console.error("insertImageTag error " + JSON.stringify(er));
					callback(null, 0);
				} else {
					callback(null, results);
				}
			});
		});
	});
});

var insertThingProperty = deasync(function (ThingId, ThingType, PropertySet, Property, UOM, DateTime, Flag, callback) {
	var sql =
		'insert into "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty" ("ThingId","ThingType","PropertySet","Property","UOM","DateTime","Flag") values(?,?,?,?,?,?,?)';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("insertThingProperty: error=" + JSON.stringify(error));
			return;
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("insertThingProperty: err=" + JSON.stringify(err));
				return;
			}
			statement.exec([ThingId, ThingType, PropertySet, Property, UOM, DateTime, Flag], function (er, results) {
				if (er) {
					console.error("insertThingProperty error " + JSON.stringify(er));
					callback(null, 0);
				} else {
					callback(null, results);
				}
			});
		});
	});
});

var deleteThingData = deasync(function (thingId, callback) {
	var dltFromThingImage = deleteQuery(thingId,
		'DELETE FROM "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" WHERE "ThingId" =?');
	var dltFromImageTag = deleteQuery(thingId,
		'DELETE FROM "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag" WHERE "ThingId" =?');
	var dltFromThingProperty = deleteQuery(thingId,
		'DELETE FROM "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty" WHERE "ThingId" =?');
	var status;
	if (dltFromThingImage == dltFromImageTag == dltFromThingProperty == 1) {
		status = "success";
	} else {
		status = "failed";
	}
	var rst = JSON.stringify({
		status: status
	});
	callback(null, rst);
});

var deleteThingDataOfGvnPrp = deasync(function (thingId, PropertySet, callback) {
	var dltFromImageTag = deleteQuery2Param(thingId, PropertySet,
		'DELETE FROM "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag" WHERE "ThingId" =? and "PropertySet"=?'
	);
	var dltFromThingProperty = deleteQuery2Param(thingId, PropertySet,
		'DELETE FROM "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty" WHERE "ThingId" =?  and "PropertySet"=?'
	);
	var status;
	if (dltFromImageTag == dltFromThingProperty == 1) {
		status = "success";
	} else {
		status = "failed";
	}
	var rst = JSON.stringify({
		status: status
	});
	callback(null, rst);
});

var deleteQuery = deasync(function (thingId, sql, callback) {
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("deleteQuery: error=" + JSON.stringify(error));
			return;
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("deleteQuery: err=" + JSON.stringify(err));
				return;
			}
			statement.exec([thingId], function (er, results) {
				if (er) {
					console.error("deleteQuery error " + JSON.stringify(er));
					callback(null, 0);
				} else {
					callback(null, results);
				}
			});
		});
	});
});

var deleteQuery2Param = deasync(function (param1, param2, sql, callback) {
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("deleteQuery2Param: error=" + JSON.stringify(error));
			return;
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("deleteQuery2Param: err=" + JSON.stringify(err));
				return;
			}
			statement.exec([param1, param2], function (er, results) {
				if (er) {
					console.error("deleteQuery2Param error " + JSON.stringify(er));
					callback(null, 0);
				} else {
					callback(null, results);
				}
			});
		});
	});
});

app.post('/GetThingDataGvnRange', async function (req, res) {
	var Token = getToken();
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PackageName = req.body.PackageName;
	var thingid = req.body.thingid;
	var propertySet = req.body.propertySet;
	var thingType = req.body.ThingType
	var properties = getProperties(thingid, thingType, propertySet);
	var path = "/Things('" + thingid + "')/" + PackageName + ":" + thingType + "/" + propertySet +
		"?timerange=" + fromDateTime + "-" + toDateTime;
	var thingData = getThingData(Token, path);
	if (thingData.value != undefined) {
		if (thingData.value.length > 0) {
			thingData.value.sort(function (a, b) {
				return a._time.localeCompare(b._time);
			});
		}
	}
	thingData.property = properties;
	return res.type("application/json").status(202).send(thingData);
});

/*##################### Chamdeep-002JH6 Changes Start####################################*/

app.post('/GetTotalDataForPlant_FL', async function (req, res) {
	var Token = getToken();
	var fromDateTime = req.body.FromDateTime;
	var toDateTime = req.body.ToDateTime;
	var PackageName = req.body.PackageName;
	var thingid = req.body.ThingId;
	var propertySet = req.body.PropertySet;
	var thingType = req.body.ThingType
	var properties = getProperties(thingid, thingType, propertySet);
	var mergedArraybyThing = [];
	var result = {
		PlantWise_FL: []
	};
	var path = "/Things('" + thingid + "')/" + PackageName + ":" + thingType + "/" + propertySet +
		"?timerange=" + fromDateTime + "-" + toDateTime;

	var thingData = getThingData(Token, path);
	thingData.property = properties;

	if (thingData.value.length > 0) {
		mergedArraybyThing = [...mergedArraybyThing, ...thingData.value];
	}
	console.log("mergedArraybyThing", mergedArraybyThing);
	//sum all the values of the given thing

	var avg = Array.from(mergedArraybyThing.reduce(
			(acc, obj) => Object.keys(obj).reduce(
				(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
				acc),
			new Map()),
		([name, values]) =>
		({
			name,
			average: Math.round((values.reduce((a, b) => a + b) / values.length) * 100) / 100,
		})
	);
	/*res.type("application/json").status(202).send(JSON.stringify(result));*/
	return res.type("application/json").status(202).send(JSON.stringify(avg));
});

/*##################### Chamdeep-002JH6 Changes End####################################*/
app.post('/GetTimeData', async function (req, res) {
	var Token = getToken();
	var thingid = req.body.thingid;
	var PackageName = req.body.PackageName;
	var thingType = req.body.thingType;
	var propertySet = req.body.propertySet;
	var path = "/Things('" + thingid + "')/admi.subaccount." + PackageName + ":" + thingType + "/" + propertySet +
		"?orderby=_time&timerange=1M&$top=1";
	//call api to get thing data 
	var thingData = getThingData(Token, path);
	thingData.value[0]["lower"] = "0";
	thingData.value[0]["upper"] = "710";
	return res.type("application/json").status(200).send(thingData);
});

var GetProdOrderListByStatusTime = (async function (req, res, callback) {
	var dt = new Date();
	var formatted_dt = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var currdatetime = formatted_dt + "T00:00:00";
	dt.setDate(dt.getDate() + 8);
	var formatted_dt2 = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var toDate = formatted_dt2 + "T00:00:00";
	var Status = "Released";
	var filterstring =
		'?$filter=(SystemStatusText eq \'' + Status + '\' and MfgOrderPlannedStartDate gt datetime\'' + currdatetime +
		'\' and MfgOrderPlannedStartDate lt datetime\'' + toDate + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/MPE_PRODORDER_OBJPG_SRV/C_MfgOrderObjPg' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		return callback(resp.data);
	} catch (error) {
		console.error('GetProdOrderList error===>>>' + error);
		return callback(error);
	}
});

var GetProdOrderListByWCTime = (async function (req, res, callback) {
	var WC = req.body.WorkCenter;
	var dt = new Date();
	var formatted_dt = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var currdatetime = formatted_dt + "T00:00:00";
	dt.setDate(dt.getDate() + 8);
	var formatted_dt2 = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var toDate = formatted_dt2 + "T00:00:00";
	var filterstring =
		'?$filter=(WorkCenter eq \'' + WC + '\' and OpErlstSchedldExecStrtDte gt datetime\'' + currdatetime +
		'\' and OpErlstSchedldExecStrtDte lt datetime\'' + toDate + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/MPE_PRODORDER_OBJPG_SRV/C_MfgOrderObjPgOpr' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		return callback(resp.data);
	} catch (error) {
		console.error('GetProdOrderList error===>>>' + error);
		return callback(error);
	}
});

app.post('/GetProdOrder', async function (req, res) {
	var wc = req.body.WorkCenter;
	var response1;
	var response2;
	GetProdOrderListByStatusTime(req, res, function (resp1) {
		response1 = resp1.d.results;
		GetProdOrderListByWCTime(req, res, function (resp2) {
			response2 = resp2.d.results;
			var jsondata = {
				records: []
			};
			var length1 = response1.length;
			var length2 = response2.length;
			var ms, startDate, endDate;
			var k = 0;
			for (var i = 0; i < length1; i++) {
				for (var j = 0; j < length2; j++) {
					// find values 
					var valueObj1 = response1[i].ProductionOrder;
					var valueObj2 = response2[j].ManufacturingOrder;
					if (valueObj1 == valueObj2) {
						jsondata.records.push(response1[i]);
						jsondata.records[k].WC = response2[j].WorkCenter;
						ms = response1[i].MfgOrderPlannedStartDate.split("(")[1].split(")")[0];
						var start_dt = (new Date(Number(ms)).toISOString()).split("T")[0];
						var timestamp = response1[i].MfgOrderScheduledStartTime;
						timestamp = timestamp.substr(2, timestamp.length - 2);
						var hr1 = timestamp.split("H")[0];
						var min1 = (timestamp.split("H")[1]).split("M")[0];
						var sec1 = ((timestamp.split("H")[1]).split("M")[1]).split("S")[0];
						startDate = start_dt + " " + hr1 + ":" + min1 + ":" + sec1;
						//startDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
						jsondata.records[k].PlannedStart = startDate;
						ms = response1[i].MfgOrderPlannedEndDate.split("(")[1].split(")")[0];
						var end_dt = (new Date(Number(ms)).toISOString()).split("T")[0];
						var timestamp = response1[i].MfgOrderScheduledEndTime;
						timestamp = timestamp.substr(2, timestamp.length - 2);
						var hr2 = timestamp.split("H")[0];
						var min2 = (timestamp.split("H")[1]).split("M")[0];
						var sec2 = ((timestamp.split("H")[1]).split("M")[1]).split("S")[0];
						endDate = end_dt + " " + hr2 + ":" + min2 + ":" + sec2;
						//endDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
						jsondata.records[k].PlannedEnd = endDate;
						var durdays = new Date(end_dt).getTime() - new Date(start_dt).getTime();
						hr2 = parseInt(hr2);
						hr1 = parseInt(hr1);
						min2 = parseInt(min2);
						min1 = parseInt(min1);
						sec2 = parseInt(sec2);
						sec1 = parseInt(sec1);
						if (hr2 - hr1 < 0) {
							var durhrs = 23 + hr2 - hr1;
							var durmins = 59 - min1 + min2;
							if (durmins >= 60) {
								durmins = durmins - 60;
								durhrs = durhrs + 1;
							}
							var dursecs = 60 + sec2 - sec1;
							if (dursecs >= 60) {
								dursecs = dursecs - 60;
								durmins = durmins + 1;
							}

						} else {
							if (min2 > min1) {
								var durhrs = hr2 - hr1;
								var durmins = 60 - min2 + min1;
							} else if (min2 == min1) {
								var durhrs = hr2 - hr1;
								var durmins = 0;
							} else {
								var durhrs = hr2 - hr1 - 1;
								var durmins = 60 - min1 + min2;
							}
							if (sec1 > sec2) {
								var dursecs = 60 + sec2 - sec1;
							} else {
								var dursecs = sec2 - sec1;
							}
						}
						//var durdays = endDate - startDate;
						jsondata.records[k].Duration = durdays + " days " + durhrs + " hrs " + durmins + " mins " + dursecs + " secs";
						k = k + 1;
						break;
					}
				}
			}
			return res.type("application/json").status(200).send(jsondata);
		});
	});
});

app.post('/GetMaintenanceHistory', async function (req, res) {
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var Equipment = req.body.Equipment;
	var currentdate = req.body.currentDate;
	var date = new Date(currentdate); //converts the string into date object
	var yesterdayDate = new Date(date.setDate(date.getDate() - 1));
	var previousMonthDate = new Date(date.setMonth(date.getMonth() - 1));
	previousMonthDate = previousMonthDate.toISOString().slice(0, 19);
	yesterdayDate = yesterdayDate.toISOString().slice(0, 19);
	//console.log(previousMonthDate + "-----" + yesterdayDate);
	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and Equipment eq \'' + Equipment +
		'\' and MaintOrdBasicEndDate gt datetime\'' + previousMonthDate + '\' and MaintOrdBasicEndDate lt datetime\'' + yesterdayDate + '\' )';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;
		}
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetNotificationListMonthly error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/GetMaintenanceHistoryByUser', async function (req, res) {
	var personresp = "00000001";
	var person = "USER PTP";
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var Equipment = req.body.Equipment;
	var currentdate = req.body.currentDate;
	/*	var date = new Date(currentdate); //converts the string into date object
		var yesterdayDate = new Date(date.setDate(date.getDate() - 1));
		var previousMonthDate = new Date(date.setMonth(date.getMonth() - 1));
		previousMonthDate = previousMonthDate.toISOString().slice(0, 19);
		yesterdayDate = yesterdayDate.toISOString().slice(0, 19);*/
	var status = "Released";
	var filterstring = '?$filter=(MaintenanceProcessingPhaseDesc eq \'' + status + '\' and MaintOrdPersonResponsible eq \'' + personresp +
		'\' )';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;
		}
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetNotificationListMonthly error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/GetSpareParts', async function (req, res) {
	var url3 = '/sap/opu/odata/sap/CB_MATERIAL_SRV/Materials?$filter=(MaterialGroup eq \'' + req.body.MaterialGroup + '\')';
	const config3 = {
		method: 'GET',
		url: url3,
		headers: {
			"content-type": "application/json"
		},
	}
	let resp3 = await axios(config3);
	var totcompcount = resp3.data.d.results.length;
	var shortdesc = req.body.shortdesc;
	//shortdesc = shortdesc.split('-')[0];
	var len = shortdesc.length;
	var measuringDev = shortdesc.substr(3, len - 3);
	var filterstring = '?$filter=(MeasuringDevice eq \'' + measuringDev + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/CB_MEASURING_POINT_SRV/MeasuringPoints' + filterstring,
		headers: {
			"content-type": "application/json"
		},
	}
	let resp = await axios(config);
	var comp = parseInt(resp.data.d.results[0].MsrgDvceLocationAssembly);
	var url2 = '/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialBomSet?$expand=Bomitems,Bomheaders&$filter=Material eq \'' + comp +
		'\' and Plant eq \'' + req.body.Plant + '\' and Usage eq \'4\'';
	const config2 = {
		method: 'GET',
		url: url2,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp2 = await axiosCSRF(config2);
		var count = resp2.data.d.results[0].Bomitems.results.length;
		var jsondata = {
			records: []
		};
		var k = 0;
		var compdesc;
		var qty;
		for (var i = 0; i < count; i++) {
			var mat1 = resp2.data.d.results[0].Bomitems.results[i].Component;
			for (var j = 0; j < totcompcount; j++) {
				var mat2 = resp3.data.d.results[j].Material;
				if (comp == mat2) {
					compdesc = resp3.data.d.results[j].MAKTX;
				}
				if (mat1 == mat2) {
					qty = resp2.data.d.results[0].Bomitems.results[i].CompQty;
				}
			}
		}
		var maincomp = {
			"Component": comp,
			"MatDesc": compdesc,
			"CompQty": qty
		};
		jsondata.records.push(maincomp);
		k = k + 1;
		for (var i = 0; i < count; i++) {
			var mat1 = resp2.data.d.results[0].Bomitems.results[i].Component;
			for (var j = 0; j < totcompcount; j++) {
				var mat2 = resp3.data.d.results[j].Material;
				if (mat1 == mat2) {
					jsondata.records.push(resp2.data.d.results[0].Bomitems.results[i]);
					jsondata.records[k].MatDesc = resp3.data.d.results[j].MAKTX;
					k++;
					break;
				}
			}
		}
		return res.type("application/json").status(200).send(jsondata);
		//	return res.type("application/json").status(200).send(resp3.data.d.results);
	} catch (error) {
		console.error(' error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/GetSparePartsWithCost', async function (req, res) {
	var shortdesc = req.body.shortdesc;
	//shortdesc = shortdesc.split('-')[0];
	var len = shortdesc.length;
	var measuringDev = shortdesc.substr(3, len - 3);
	var filterstring = '?$filter=(MeasuringDevice eq \'' + measuringDev + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/CB_MEASURING_POINT_SRV/MeasuringPoints' + filterstring,
		headers: {
			"content-type": "application/json"
		},
	}
	let resp = await axios(config);
	var comp = parseInt(resp.data.d.results[0].MsrgDvceLocationAssembly);
	var url2 = '/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialBomSet?$expand=Bomitems,Bomheaders&$filter=Material eq \'' + comp +
		'\' and Plant eq \'' + req.body.Plant + '\' and Usage eq \'4\'';
	const config2 = {
		method: 'GET',
		url: url2,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp2 = await axiosCSRF(config2);
		var count = resp2.data.d.results[0].Bomitems.results.length;
		let complist = comp;
		for (let i = 0; i < count; i++) {
			complist = complist + "," + resp2.data.d.results[0].Bomitems.results[i].Component;
		}
		var url4 =
			'/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialPriceStockSet?$expand=MatGenData,MatValData,MatStock&$filter=MaterialNum eq \'' +
			complist + '\'';
		const config4 = {
			method: 'GET',
			url: url4,
			headers: {
				"content-type": "application/json"
			},
			xsrfHeaderName: "x-csrf-token"
		}
		try {
			let resp4 = await axiosCSRF(config4);
			var countofmat = resp4.data.d.results.length;
			var jsondata = {
				"records": []
			};
			for (var i = 0; i < countofmat; i++) {
				jsondata.records.push({});
				var a = jsondata.records[i];
				a["Component"] = parseInt(resp4.data.d.results[i].MaterialNum);
				a["MatDesc"] = resp4.data.d.results[i].MatGenData.results[0].MatlDesc;
				a["UOMKey"] = resp4.data.d.results[i].MatGenData.results[0].BaseUom;
				a["CompQty"] = resp4.data.d.results[i].MatStock.results[0].Labst;
				a["MovingPrice"] = resp4.data.d.results[i].MatValData.results[0].MovingPr;
				a["StandardPrice"] = resp4.data.d.results[i].MatValData.results[0].StdPrice;
			}
			return res.type("application/json").status(200).send(jsondata);
		} catch (error) {
			console.error(' error===>>>' + JSON.stringify(error));
		}
		//return res.type("application/json").status(200).send(jsondata);
	} catch (error) {
		console.error(' error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/GetSparePartsWithStockCost', async function (req, res) {
	var shortdesc = req.body.shortdesc;
	//shortdesc = shortdesc.split('-')[0];
	var len = shortdesc.length;
	var measuringDev = shortdesc.substr(3, len - 3);
	var filterstring = '?$filter=(MeasuringDevice eq \'' + measuringDev + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/CB_MEASURING_POINT_SRV/MeasuringPoints' + filterstring,
		headers: {
			"content-type": "application/json"
		},
	}
	let resp = await axios(config);
	var comp = parseInt(resp.data.d.results[0].MsrgDvceLocationAssembly);
	//console.log("comp-------" + comp);
	var url2 = '/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialBomSet?$expand=Bomitems,Bomheaders&$filter=Material eq \'' + comp +
		'\' and Plant eq \'' + req.body.Plant + '\' and Usage eq \'4\'';
	const config2 = {
		method: 'GET',
		url: url2,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp2 = await axiosCSRF(config2);
		//console.log(JSON.stringify(resp2.data.d.results[0].Bomitems.results));
		var count = resp2.data.d.results[0].Bomitems.results.length;
		let complist = comp;
		var comparr = [];
		for (let i = 0; i < count; i++) {
			complist = complist + "," + resp2.data.d.results[0].Bomitems.results[i].Component;
			comparr.push(resp2.data.d.results[0].Bomitems.results[i].Component);
		}
		//console.log("complist-------" + complist);
		//console.log("comparr-------" + comparr);
		//var url4 =
		//	'/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialPriceStockSet?$expand=MatGenData,MatValData,MatStock&$filter=MaterialNum eq \'' +
		//	complist + '\'';
		var url4 =
			'/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialPriceStockSet?$expand=MatGenData,MatValData,MatStock&$filter=MaterialNum eq \'' +
			comparr + '\'';
		//console.log(url4);
		const config4 = {
			method: 'GET',
			url: url4,
			headers: {
				"content-type": "application/json"
			},
			xsrfHeaderName: "x-csrf-token"
		}
		try {
			let resp4 = await axiosCSRF(config4);
			var countofmat = resp4.data.d.results.length;
			//console.log(JSON.stringify(resp4.data.d.results));
			var jsondata = {
				"records": []
			};
			//jsondata.records.push({});
			//for 101 
			if (count === 0) {
				//console.log("entered in if");
				var compheadrpad = comp.toString().padStart(18, "0");
				for (var j = 0; j < countofmat; j++) {
					if (compheadrpad == resp4.data.d.results[j].MaterialNum && resp4.data.d.results[j].MatValData.results[0].PriceCtrl == "S") {
						var compqty = resp2.data.d.results[0].Bomitems.results[0].CompQty;
						var a = {
							"Component": parseInt(resp4.data.d.results[j].MaterialNum),
							"StandardPrice": resp4.data.d.results[j].MatValData.results[0].StdPrice,
							"CompQty": compqty,
							"MatDesc": resp4.data.d.results[j].MatGenData.results[0].MatlDesc,
							"UOMKey": resp4.data.d.results[j].MatGenData.results[0].BaseUom,
							"StockQty": resp4.data.d.results[j].MatStock.results[0].Labst,
							"Currency": resp4.data.d.results[j].MatValData.results[0].Currency
						};
						jsondata.records.push(a);
						//break;
					}
				}
			} else {
				//console.log("entered in else");
				//for rest of components
				for (var i = 0; i < count; i++) {
					var comppad = comparr[i].toString().padStart(18, "0");
					for (var j = 0; j < countofmat; j++) {
						if (comppad == resp4.data.d.results[j].MaterialNum && resp4.data.d.results[j].MatValData.results[0].PriceCtrl == "S") {
							for (var k = 0; k < count; k++) {
								if (resp2.data.d.results[0].Bomitems.results[k].Component == comparr[i]) {
									var compqty = resp2.data.d.results[0].Bomitems.results[k].CompQty;
									break;
								}
							}
							var a = {
								"Component": parseInt(resp4.data.d.results[j].MaterialNum),
								"StandardPrice": resp4.data.d.results[j].MatValData.results[0].StdPrice,
								"CompQty": compqty,
								"MatDesc": resp4.data.d.results[j].MatGenData.results[0].MatlDesc,
								"UOMKey": resp4.data.d.results[j].MatGenData.results[0].BaseUom,
								"StockQty": resp4.data.d.results[j].MatStock.results[0].Labst,
								"Currency": resp4.data.d.results[j].MatValData.results[0].Currency
							};
							jsondata.records.push(a);
							//break;
						}
					}
				}
			}
			return res.type("application/json").status(200).send(jsondata);
		} catch (error) {
			console.error(' error===>>>' + JSON.stringify(error));
		}
		//return res.type("application/json").status(200).send(jsondata);
	} catch (error) {
		console.error(' error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
/*app.post('/GetSparePartsWithStockCost', async function (req, res) {
	var shortdesc = req.body.shortdesc;
	//shortdesc = shortdesc.split('-')[0];
	var len = shortdesc.length;
	var measuringDev = shortdesc.substr(3, len - 3);
	var filterstring = '?$filter=(MeasuringDevice eq \'' + measuringDev + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/CB_MEASURING_POINT_SRV/MeasuringPoints' + filterstring,
		headers: {
			"content-type": "application/json"
		},
	}
	let resp = await axios(config);
	var comp = parseInt(resp.data.d.results[0].MsrgDvceLocationAssembly);
	console.log("comp***************" + comp);
	var url2 = '/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialBomSet?$expand=Bomitems,Bomheaders&$filter=Material eq \'' + comp +
		'\' and Plant eq \'' + req.body.Plant + '\' and Usage eq \'4\'';
	const config2 = {
		method: 'GET',
		url: url2,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp2 = await axiosCSRF(config2);
		var count = resp2.data.d.results[0].Bomitems.results.length;
		//console.log("count::::::::::::" + count);
		let complist = comp;
		var comparr = [];
		for (let i = 0; i < count; i++) {
			complist = complist + "," + resp2.data.d.results[0].Bomitems.results[i].Component;
			comparr.push(resp2.data.d.results[0].Bomitems.results[i].Component);
		}
		var url4 =
			'/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialPriceStockSet?$expand=MatGenData,MatValData,MatStock&$filter=MaterialNum eq \'' +
			complist + '\'';
		const config4 = {
			method: 'GET',
			url: url4,
			headers: {
				"content-type": "application/json"
			},
			xsrfHeaderName: "x-csrf-token"
		}
		try {
			let resp4 = await axiosCSRF(config4);
			var countofmat = resp4.data.d.results.length;
			var jsondata = {
				"records": []
			};
			jsondata.records.push({});
			//for 101 
			var compheadrpad = comp.toString().padStart(18, "0");
			for (var j = 0; j < countofmat; j++) {
				if (compheadrpad == resp4.data.d.results[j].MaterialNum && resp4.data.d.results[j].MatValData.results[0].PriceCtrl == "S") {
					var compqty = resp2.data.d.results[0].Bomitems.results[0].CompQty;
					var a = jsondata.records[0];
					a["Component"] = parseInt(resp4.data.d.results[j].MaterialNum);
					a["StandardPrice"] = resp4.data.d.results[j].MatValData.results[0].StdPrice;
					a["CompQty"] = compqty;
					a["MatDesc"] = resp4.data.d.results[j].MatGenData.results[0].MatlDesc;
					a["UOMKey"] = resp4.data.d.results[j].MatGenData.results[0].BaseUom;
					a["StockQty"] = resp4.data.d.results[j].MatStock.results[0].Labst;
					a["Currency"] = resp4.data.d.results[j].MatValData.results[0].Currency;
					break;
				}
			}

			//for rest of components
			for (var i = 0; i < count; i++) {
				var comppad = comparr[i].toString().padStart(18, "0");
				for (var j = 0; j < countofmat; j++) {
					if (comppad == resp4.data.d.results[j].MaterialNum && resp4.data.d.results[j].MatValData.results[0].PriceCtrl == "S") {
						for (var k = 0; k < count; k++) {
							if (resp2.data.d.results[0].Bomitems.results[k].Component == comparr[i]) {

								var compqty = resp2.data.d.results[0].Bomitems.results[k].CompQty;
								break;
							}
						}
						jsondata.records.push({});
						var a = jsondata.records[(Number(i) + 1)];
						a["Component"] = parseInt(resp4.data.d.results[j].MaterialNum);
						a["StandardPrice"] = resp4.data.d.results[j].MatValData.results[0].StdPrice;
						a["CompQty"] = compqty;
						a["MatDesc"] = resp4.data.d.results[j].MatGenData.results[0].MatlDesc;
						a["UOMKey"] = resp4.data.d.results[j].MatGenData.results[0].BaseUom;
						a["StockQty"] = resp4.data.d.results[j].MatStock.results[0].Labst;
						a["Currency"] = resp4.data.d.results[j].MatValData.results[0].Currency;
						break;
					}

				}
			}
			return res.type("application/json").status(200).send(jsondata);
		} catch (error) {
			console.error(' error===>>>' + JSON.stringify(error));
		}
		//return res.type("application/json").status(200).send(jsondata);
	} catch (error) {
		console.error(' error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});*/

app.post('/GetPreventiveMaintenanceOrder', async function (req, res) {
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var Equipment = req.body.Equipment;
	var currentdate = req.body.currentDate;
	var date = new Date(currentdate); //converts the string into date object
	var previousMonthDate = new Date(date.setMonth(date.getMonth() - 1));
	previousMonthDate = previousMonthDate.toISOString().slice(0, 19);
	/*var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and Equipment eq \'' + Equipment +
		'\' and CreationDate gt datetime\'' + previousMonthDate + '\')'; */
	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and Equipment eq \'' + Equipment +
		'\' and MaintOrdSchedBasicStartDate gt datetime\'' + currentdate + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;
		}
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetNotificationListMonthly error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/GetPropertyGauge', async function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var ThingId = req.body.ThingId;
	var sql =
		'select "ThingId","ThingType","PropertySet" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag"  where "PackageName"=? AND "ThingId"=?';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("GetPropertyGauge: error=" + JSON.stringify(error));
			return res.type("application/json").status(500).send(JSON.stringify(error));
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("GetPropertyGauge: err=" + JSON.stringify(err));
				return res.type("application/json").status(500).send(JSON.stringify(err));
			}
			statement.exec([PackageName, ThingId], function (er, results) {
				if (er) {
					console.error("GetPropertyGauge error " + JSON.stringify(er));
					return res.type("application/json").status(500).send(JSON.stringify(er));
				} else {
					var min = 0,
						max = 100;
					var firstrange = 40;
					var secondrange = 70;
					var thirdrange = 100;
					var maxcol = "FA0E0E";
					var locol = "0F9A30";
					var valcol = "FAD30E";
					var propertyLabelTd = "",
						gaugeData = "";
					async.each(results, function (eachRecord, callback) {
						var currentitem = results.indexOf(eachRecord);
						var thingid = results[currentitem].ThingId;
						var thingType = results[currentitem].ThingType;
						var propertySet = results[currentitem].PropertySet;
						var path = "/Things('" + thingid + "')/" + PackageName + ":" + thingType + "/" + propertySet +
							"?orderby=_time&timerange=1M&$top=1";
						var thingData = getThingData(Token, path);
						var properties = getProperties(thingid, thingType, propertySet);
						var rPath = encodeURI("/Things('" + thingid + "')/ReferenceProperties/" + PackageName + ":" + thingType + "/" +
							propertySet + "?$filter=_time gt 2020-01-06T09:00:00.000Z");
						var thingReferenceData = getThingData(Token, rPath);
						var Prop_Path = "/Things('" + ThingId + "')/Configuration";
						var PropertyData = getPropertyData(Token, Prop_Path);
						for (var i in properties) {
							var Propertydesc;
							for (var q = 0; q < PropertyData.propertySetTypes.length; q++) {
								var Property_Array = PropertyData.propertySetTypes[q].propertyTypes.map(function (result) {
									if (result.value.id == properties[i].Property) {
										if (result.value.description.en == "" || result.value.description.en == null) {
											Propertydesc = properties[i].Property;
										} else {
											Propertydesc = result.value.description.en;
										}
									}
								});
							}
							var uom;
							if (properties[i].UOM != "") {
								uom = "(" + properties[i].UOM + ")";
							} else {
								uom = properties[i].UOM;
							}
							if (propertyLabelTd == "") {
								//propertyLabelTd = "<td align='center'>" + properties[i].Property + uom + "</td>";
								propertyLabelTd = "<td align='center'>" + Propertydesc + uom + "</td>";

							} else {
								//propertyLabelTd = propertyLabelTd + "<td align='center'>" + properties[i].Property + uom + "</td>";
								propertyLabelTd = propertyLabelTd + "<td align='center'>" + Propertydesc + uom + "</td>";
							}
							if (thingData.value != undefined) {
								if (thingData.value.length > 0) {
									if (thingReferenceData.value != undefined) {
										if (thingReferenceData.value.length > 0) {
											var upperThreshHold = 0;
											Object.keys(thingReferenceData.value[0]).forEach(function (key) {
												if (key.includes(properties[i].Property + "L")) {
													min = thingReferenceData.value[0][key];
												} else if (key.includes(properties[i].Property + "U")) {
													upperThreshHold = thingReferenceData.value[0][key];
													if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
														max = Number(thingData.value[0][properties[i].Property]) + 10;
													} else {
														max = Number(upperThreshHold) + 10;
													}
													firstrange = Number(upperThreshHold) - 1;
													secondrange = Number(upperThreshHold) - 1;
													thirdrange = max;
												}
											});
										} else {
											min = 0;
											upperThreshHold = 100;
											if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
												max = Number(thingData.value[0][properties[i].Property]) + 20;
											} else {
												max = Number(upperThreshHold) + 20;
											}
											firstrange = Number(upperThreshHold) - 1;
											secondrange = Number(upperThreshHold) - 1;
											thirdrange = max;
										}
									} else {
										min = 0;
										upperThreshHold = 100;
										if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
											max = Number(thingData.value[0][properties[i].Property]) + 20;
										} else {
											max = Number(upperThreshHold) + 20;
										}
										firstrange = Number(upperThreshHold) - 1;
										secondrange = Number(upperThreshHold) - 1;
										thirdrange = max;
									}
									if (gaugeData == "") {
										gaugeData = "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
											min +
											"%26max=" + max +
											"%26val=" +
											thingData.value[0][properties[i].Property] +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 6rem;width: 10rem;border: 0px;'></iframe></td>";
									} else {
										gaugeData = gaugeData +
											"<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
											min + "%26max=" +
											max +
											"%26val=" + thingData.value[0][properties[i].Property] +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 6rem;width: 10rem;border: 0px;'></iframe></td>";
									}
								} else {
									if (thingReferenceData.value != undefined) {
										if (thingReferenceData.value.length > 0) {
											var upperThreshHold = 0;
											Object.keys(thingReferenceData.value[0]).forEach(function (key) {
												if (key.includes(properties[i].Property + "L")) {
													min = thingReferenceData.value[0][key];
												} else if (key.includes(properties[i].Property + "U")) {
													upperThreshHold = thingReferenceData.value[0][key];
													max = Number(upperThreshHold) + 100;
													firstrange = Number(upperThreshHold) - 1;
													secondrange = Number(upperThreshHold) - 1;
													thirdrange = max;
												}
											});
										} else {
											/*min = 0;
											max = 100;*/
											min = 0;
											upperThreshHold = 28;
											max = upperThreshHold;
											firstrange = Number(upperThreshHold) - 1;
											secondrange = Number(upperThreshHold) - 1;
											thirdrange = max;
										}
									} else {
										/*min = 0;
										max = 100;*/
										min = 0;
										upperThreshHold = 28;
										max = upperThreshHold;
										firstrange = Number(upperThreshHold) - 1;
										secondrange = Number(upperThreshHold) - 1;
										thirdrange = max;
									}
									if (gaugeData == "") {
										gaugeData = "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
											min +
											"%26max=" + max +
											"%26val=0" +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 6rem;width: 10rem;border: 0px;'></iframe></td>";
									} else {
										gaugeData = gaugeData +
											"<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
											min + "%26max=" +
											max +
											"%26val=0" +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 6rem;width: 10rem;border: 0px;'></iframe></td>";
									}
								}
							}
						}
						callback(null);
					}, function (err) {
						if (err) {
							console.error('GetPropertyGauge something went wrong err===>>>' + JSON.stringify(err));
						} else {
							var result = JSON.stringify({
								gaugeRecord: "<table><tr>" + propertyLabelTd + "</tr><tr>" + gaugeData + "</tr></table>"
							});
							return res.type("application/json").status(202).send(result);
						}
					});
				}
			});
		});
	});
});

app.post('/GetThingPropertyData', async function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var thingid = req.body.thingid;
	var thingType = req.body.thingType;
	var toDateTime = req.body.toDateTime;
	var fromDateTime = req.body.fromDateTime;
	var properties = getAllProperties(thingid);
	var path, tempData, thingData,
		finalData = {};
	var prpSet = "",
		count = 0;
	var unionArray;
	var mergedArray = [];
	for (var i in properties) {
		if (prpSet != properties[i].PropertySet) {
			path = "/Things('" + thingid + "')/" + PackageName + ":" + thingType + "/" + properties[i].PropertySet +
				"?timerange=" + fromDateTime + "-" + toDateTime;
			thingData = getThingData(Token, path);
			mergedArray = [...mergedArray, ...thingData.value];
			prpSet = properties[i].PropertySet;
			count = count + 1;
		}
	}
	let set = new Set();
	unionArray = mergedArray.filter(item => {
		if (!set.has(item._time)) {
			set.add(item._time);
			return true;
		}
		return false;
	}, set);
	if (unionArray.length > 0) {
		unionArray.sort(function (a, b) {
			return a._time.localeCompare(b._time);
		});
	}
	var value;
	for (var k in unionArray) {
		if (Object.keys(unionArray[k]).length != (properties.length) + 1) {
			for (var p in properties) {
				if (k > 0) {
					if (unionArray[k][properties[p].Property] == undefined && unionArray[k - 1][properties[p].Property] != undefined) {
						unionArray[k][properties[p].Property] = unionArray[k - 1][properties[p].Property];
					}
				}
			}
		}
	}
	finalData.value = unionArray;
	finalData.property = properties;
	return res.type("application/json").status(202).send(finalData);
});

var getAllProperties = deasync(function (ThingId, cb) {
	var sql =
		'select "PropertySet", "Property" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty"  where "ThingId"=? order by "PropertySet"';
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("getAllProperties: error=" + JSON.stringify(error));
			return;
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("getAllProperties: err=" + JSON.stringify(err));
				return;
			}
			statement.exec([ThingId], function (er, results) {
				if (er) {
					console.error("getAllProperties error " + JSON.stringify(er));
				} else {
					cb(null, results);
				}
			});
		});
	});
});

app.post('/CreateWorkOrder', async function (req, res) {
	var compCount = req.body.Component.length;
	var oprCount = req.body.Operation.length;
	var hdr = {
		"Refnumber": "000001",
		"Objecttype": "HEADER",
		"Method": "CREATETONOTIF",
		"Objectkey": "%00000000001" + req.body.Header[0].NotifNo
	};
	var sv = {
		"Refnumber": "000001",
		"Objecttype": "",
		"Method": "SAVE",
		"Objectkey": "%00000000001"
	};
	var methodbody = [];
	methodbody.push(hdr);
	methodbody.push(sv);
	for (var i = 1; i <= oprCount; i++) {
		var activity = req.body.Operation[i - 1].Activity;
		var oprbody = {
			"Refnumber": "00000" + i,
			"Objecttype": "OPERATION",
			"Method": "CREATE",
			"Objectkey": "%00000000001" + activity
		};
		methodbody.push(oprbody);
	}
	for (var i = 1; i <= compCount; i++) {
		var itemnumber = req.body.Component[i - 1].ItemNumber;
		var compbody = {
			"Refnumber": i.toString().padStart(6, "0"),
			"Objecttype": "COMPONENT",
			"Method": "CREATE",
			"Objectkey": "%00000000001" + itemnumber
		};
		methodbody.push(compbody);
	}
	var jsondata = {};
	jsondata = "{\"IvMmsrvExternalMaintence\": \"\",";
	/*	jsondata = jsondata + "\"Methods\":" + JSON.stringify(methodbody) + "," + "\"Header\":" + JSON.stringify(req.body.Header) + "," +
			"\"Operation\":" + JSON.stringify(req.body.Operation) + ",";*/
	jsondata = jsondata + "\"Methods\":" + JSON.stringify(methodbody) + "," + "\"Header\":" + JSON.stringify(req.body.Header) + "," +
		"\"Operation\":" + JSON.stringify(req.body.Operation) + "," + "\"Component\":" + JSON.stringify(req.body.Component) + ",";

	jsondata = jsondata + "\"Returns\": []}";
	const config = {
		method: 'POST',
		url: '/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaintenaceOrderSet',
		headers: {
			"content-type": "application/json"
		},
		data: jsondata,
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var resultResp = resp.data.d.Returns.results;
		var MaintenanceOrder = "",
			MaintenanceNotif = "";
		for (var k in resultResp) {
			if (resultResp[k].Number == "126") {
				MaintenanceOrder = resultResp[k].MessageV2;
				MaintenanceNotif = resultResp[k].MessageV3;
				break;
			}
		}
		if (MaintenanceOrder != "" && MaintenanceNotif != "") {
			var configWF = {
				method: 'POST',
				url: '/rest/v1/workflow-instances',
				headers: {
					"content-type": "application/json"
				},
				data: {
					"definitionId": "pm_wo_approval",
					"context": {
						"MaintenanceOrder": MaintenanceOrder,
						"User": req.body.WorkFlow.UserEmail,
						"MailID": req.body.WorkFlow.MailID,
						"Rework": false,
						"Plant": req.body.WorkFlow.Plant,
						"Equipment": req.body.WorkFlow.Equipment
					}
				}
			};
			try {
				let wfresp = await axiosWF(configWF);
				if (wfresp.status == 201) {
					var socketData = JSON.stringify({
						ThingName: req.body.WorkFlow.Equipment
					});
					if (socketObj != undefined) {
						socketObj.emit('RefreshNotification', socketData);
					}
					return res.type("application/json").status(200).send(resp.data.d.Returns.results, false, null);
				} else {
					console.error("TriggerWrokFlow failed");
					return res.type("application/json").status(202).send({
						status: "failed"
					});
				}
			} catch (error) {
				console.error('error===>>>' + JSON.stringify(error));
				return res.type("application/json").status(500).send(JSON.stringify(error));
			}
		} else {
			return res.type("application/json").status(200).send(resp.data.d.Returns.results, false, null);
		}
	} catch (error) {
		console.error(' error===>>>' + error);
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/skipNotification', async function (req, res) {
	var notificationNo = req.body.NotificationNo;
	var refDate = req.body.RefDate;
	var refTime = req.body.RefTime;
	const config = {
		method: 'POST',
		url: '/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/NotifCloseSet',
		headers: {
			"content-type": "application/json"
		},
		data: {
			"Number": notificationNo,
			"Testrun": "",
			"Systemstate": {
				"Langu": "EN",
				"Languiso": "",
				"Refdate": refDate,
				"Reftime": refTime
			},
			"Return": []
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let hanaResp = await axiosCSRF(config);
		var result = {};
		if (hanaResp.data.d.Return.results.length == 0) {
			result = {
				"Status": "Success",
				"Msg": "Notification " + notificationNo + " is successfully Skiped.",
				"Response": hanaResp.data.d
			};
			var socketData = JSON.stringify({
				ThingName: req.body.Equipment
			});
			if (socketObj != undefined) {
				socketObj.emit('RefreshNotification', socketData);
			}
		} else {
			result = {
				"Status": "Error",
				"Msg": "Failed to Skip Notification " + notificationNo + ".",
				"Response": hanaResp.data.d
			};
		}
		return res.type("application/json").status(200).send(JSON.stringify(result));
	} catch (error) {
		console.error('skipNotification error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

// for testing 
app.post('/testWrokFlowTrigger', async function (req, res) {
	var MaintenanceOrder = req.body.MaintenanceOrder; //newly created Mntc order id
	var config = {
		method: 'POST',
		url: '/rest/v1/workflow-instances',
		headers: {
			"content-type": "application/json"
		},
		data: {
			"definitionId": "ptm_workflow",
			"context": {
				"MaintenanceOrder": "4000200",
				"User": "mfarnaz1@in.ibm.com",
				"MailID": "maviya.farnaz1@gmail.com",
				"Rework": false
			}
		}
	};
	try {
		let resp = await axiosWF(config);
		if (resp.status == 201) {
			return res.type("application/json").status(202).send({
				status: "success"
			});
		} else {
			return res.type("application/json").status(202).send({
				status: "failed"
			});
		}
	} catch (error) {
		console.error('error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/GetSpareParts2', async function (req, res) {
	var shortdesc = req.body.shortdesc;
	var measuringDev = shortdesc.substr(3, shortdesc.length - 3);
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/CB_MEASURING_POINT_SRV/MeasuringPoints?$filter=(MeasuringDevice eq \'' + measuringDev + '\')',
		headers: {
			"content-type": "application/json"
		},
	}
	let resp = await axios(config);
	var comp = parseInt(resp.data.d.results[0].MsrgDvceLocationAssembly);
	const mBomSetConfig = {
		method: 'GET',
		url: '/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaterialBomSet?$expand=Bomitems,Bomheaders&$filter=Material eq \'' + comp +
			'\' and Plant eq \'' + req.body.Plant + '\' and Usage eq \'4\'',
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let mBomSetResp = await axiosCSRF(mBomSetConfig);
		var bomItems = mBomSetResp.data.d.results[0].Bomitems;
		var bomHeader = mBomSetResp.data.d.results[0].Bomheaders;
		var count = bomItems.results.length;
		var jsondata = {
			records: []
		};
		for (var i = 0; i < count; i++) {
			const configData = {
				method: 'GET',
				url: '/sap/opu/odata/sap/CB_MATERIAL_SRV/Materials?$filter=(Material eq \'' + bomItems.results[i].Component + '\')',
				headers: {
					"content-type": "application/json"
				},
			};
			let matDetailResp = await axios(configData);
			var temp = {
				"Component": bomItems.results[i].Component,
				"MatDesc": matDetailResp.data.d.results[0].MAKTX,
				"CompQty": bomItems.results[i].CompQty.trim(),
				"CompUnit": bomItems.results[i].CompUnit.trim()
			};
			jsondata.records.push(temp);
		}
		const matDetailMainCompConfig = {
			method: 'GET',
			url: '/sap/opu/odata/sap/CB_MATERIAL_SRV/Materials?$filter=(Material eq \'' + comp + '\')',
			headers: {
				"content-type": "application/json"
			},
		}
		let matDetailMainCompResp = await axios(matDetailMainCompConfig);
		var maincomp = {
			"Component": comp,
			"MatDesc": matDetailMainCompResp.data.d.results[0].MAKTX,
			"CompQty": bomHeader.results[0].BaseQuan.trim(),
			"CompUnit": bomHeader.results[0].BaseUnit.trim()
		};
		jsondata.records.push(maincomp);

		jsondata.records.sort(function (a, b) {
			return a.Component.localeCompare(b.Component);
		});
		return res.type("application/json").status(200).send(jsondata);
	} catch (error) {
		console.error(' error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

var getThingConfiguration = deasync(function (Token, Hostname, Path, callback) {
	var options = {
		hostname: Hostname,
		path: Path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error("getThingConfiguration error >> " + JSON.stringify(error));
		});
		res.on('end', function () {
			var dat = JSON.parse(body);
			var prpSet = {},
				property = {},
				prpSetId;
			var result = {
				PropertySet: []
			};
			dat.propertySetTypes.forEach(function (eachPrpSet) {
				var propertyGrp = [];
				if (eachPrpSet.dataCategory == "TimeSeriesData") {
					prpSetId = eachPrpSet.name.toString().substring(eachPrpSet.name.toString().lastIndexOf(":") + 1, eachPrpSet.name.toString().length);
					eachPrpSet.propertyTypes.forEach(function (eachPrp) {
						property = {
							Name: eachPrp.value.id,
							Category: "Property",
							UOM: eachPrp.value.unitOfMeasure,
							Visible: false
						};
						propertyGrp.push(property);
					});
					prpSet = {
						Name: prpSetId,
						Category: "PropertySet",
						Property: propertyGrp,
						Visible: false
					};
					result.PropertySet.push(prpSet);
				}
			});
			dat.thingTypes.forEach(function (eachThingTypes) {
				result.ThingType = eachThingTypes.name;
				result.ThingTypeDescription = eachThingTypes.description.en;
			});
			callback(null, result);
		});
	});
	req.end();
});

var getThingHierarchy = deasync(function (Token, Path, Filter, callback) {
	var options = {
		hostname: "appiot-thing-hierarchy.cfapps.eu10.hana.ondemand.com",
		path: Path + Filter,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error("getThingHierarchy error " + error);
		});
		res.on('end', function () {
			/*var jsonBody = xml2json(body, {
				ignoreNameSpace: true
			});
			callback(null, jsonBody);*/
			xml2js.parseString(body, {
				explicitArray: false,
				ignoreAttrs: true,
				trim: true,
				tagNameProcessors: [stripNS]
			}, function (err, result) {
				//console.log("result",result);
				callback(null, result);
			});
		});
	});
	req.end();
});

var getPackages = deasync(function (Hostname, Token, Path, callback) {
	var options = {
		hostname: Hostname,
		path: Path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error(error);
		});
		res.on('end', function () {
			/*var jsonBody = xml2json(body, {
				ignoreNameSpace: true
			});
			var entries = jsonBody.feed.entry;
			callback(null, entries);*/

			xml2js.parseString(body, {
				explicitArray: false,
				ignoreAttrs: true,
				trim: true,
				tagNameProcessors: [stripNS]
			}, function (err, result) {
				callback(null, result.feed.entry);
			});
		});
	});
	req.end();
});

app.post("/GetIoTAEMultiLevelHierarchyToMonitor", function (req, res) {
	var Token = getToken();
	var Hostname = "appiot-mds.cfapps.eu10.hana.ondemand.com";
	var hrcGrp = [],
		thingTypeId = "",
		thingType = "",
		thingPkg = "",
		thingPkgName = "",
		thingPkgDesc = "",
		hierarchyID = "",
		rootThingID = "",
		path = "",
		category = "",
		data = [],
		hierarchyElements, found, erp_wc = "",
		erp_wcDesc = "",
		icon = "",
		thingConfigData, str1, str2, thingNameData;
	var ParentThingID = "",
		ThingID = "",
		ThingType = "";
	const packageMap = new Map();
	var result = {
		children: [],
		Host: req.headers.host,
		Level: 0
	};
	var groupBy = function (xs, key) {
		return xs.reduce(function (rv, x) {
			(rv[x[key]] = rv[x[key]] || []).push(x);
			return rv;
		}, {});
	};
	var hierarchies = getThingHierarchy(Token, "/ThingHierarchy/v1/ThingHierarchies", "").feed.entry;
	var packages = getPackages("config-package-sap.cfapps.eu10.hana.ondemand.com", Token, "/Package/v1/Packages");
	var uniquePck = [];
	packages.forEach(function (pkg) {
		packageMap.set(pkg.content.properties.Name, pkg.content.properties.Description);
		uniquePck.push(pkg.content.properties.Name.substring(pkg.content.properties.Name.lastIndexOf(".") + 1));
	});
	var mappedThings = getDbDataWith2WhereClause("%", "%",
		'Select "ThingId","ThingType","HierarchyID","RootThingID" from  "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" where "PackageName" like ? and "ThingId" like ? '
	);
	var uniqueRootThing = [];
	mappedThings.forEach(function (thing) {
		uniqueRootThing.push(thing.RootThingID);
	});
	uniqueRootThing = [...new Set(uniqueRootThing)];
	//console.log("uniqueRootThing " + JSON.stringify(uniqueRootThing));
	var temp = "",
		t1, t2;
	var catArr = ['Plant', 'FunctionalLocation', 'FunctionLocation', 'Equipment', 'WorkCenter'];
	for (var i in hierarchies) {
		if (Array.isArray(hierarchies) == false) {
			//that means only one hierarchy is there
			hierarchyID = hierarchies.content.properties.HierarchyID;
			rootThingID = hierarchies.content.properties.RootThingID;
		} else {
			hierarchyID = hierarchies[i].content.properties.HierarchyID;
			rootThingID = hierarchies[i].content.properties.RootThingID;
		}
		if (uniqueRootThing.includes(rootThingID)) {
			//for each hierarchyID : read the elements 
			path = "/ThingHierarchy/v1/ThingHierarchies('" + hierarchyID + "')?$expand=";
			hierarchyElements = getThingHierarchy(Token, path, "ThingHierarchyDescriptions,ThingHierarchyElements");
			//console.log("hierarchyID : " + hierarchyID + " , hierarchyElements " + JSON.stringify(hierarchyElements));
			data = [];
			//iterate on hierarchyElements links
			hierarchyElements.entry.link.forEach(function (link) {
				//proceed if the link title is ThingHierarchyElements else ignore
				if (link.inline != undefined && link.inline.feed.title == "ThingHierarchyElements") {
					//iterate on each entry of thing
					link.inline.feed.entry.forEach(function (entry) {
						ThingID = entry.content.properties.ThingID;
						thingConfigData = getThingConfiguration(Token, Hostname, "/Things('" + ThingID + "')/Configuration");
						thingTypeId = thingConfigData.ThingType;
						thingPkg = thingTypeId.substring(thingTypeId.lastIndexOf(".") + 1, thingTypeId.lastIndexOf(":"));
						thingPkgName = thingTypeId.substring(0, thingTypeId.lastIndexOf(":"));
						thingPkgDesc = packageMap.get(thingPkgName);
						temp = thingTypeId.split(":")[1];
						//category = temp.split("_")[1];
						category = "", t1 = "", t2 = "";
						t1 = temp.split("_")[0];
						t2 = temp.split("_")[1];
						if (catArr.includes(t1))
							category = t1;
						else
							category = t2;
						if (category.toUpperCase().includes(("WorkCenter").toUpperCase())) {
							erp_wc = entry.content.properties.ThingName;
							erp_wcDesc = entry.content.properties.ThingDescription;
						} else {
							erp_wc = "";
							erp_wcDesc = "";
						}
						//if thing is mapped then add icon
						icon = "";
						if (mappedThings.length > 0) {
							found = JSON.parse(JSON.stringify(mappedThings), function (key, value) {
								if (value.ThingId === ThingID) icon = "sap-icon://sys-enter-2";
								return value;
							});
						}
						if (rootThingID == ThingID) {

							data.push({
								RootThingID: rootThingID,
								HierarchyID: hierarchyID,
								ThingId: ThingID,
								Name: entry.content.properties.ThingName.toString(),
								ThingDesc: entry.content.properties.ThingDescription,
								ThingPkg: thingPkg,
								ThingPkgName: thingPkgName,
								ThingTypeName: thingConfigData.ThingType,
								ThingPkgDesc: thingPkgDesc,
								ThingType: thingConfigData.ThingType.split(":")[1],
								ParentThingID: "0",
								Category: category,
								PropertySet: thingConfigData.PropertySet,
								Icon: icon,
								WorkCenter: erp_wc,
								WorkCenterDesc: erp_wcDesc,
								Visible: true
							});
						} else {
							data.push({
								RootThingID: rootThingID,
								HierarchyID: hierarchyID,
								ThingId: ThingID,
								Name: entry.content.properties.ThingName.toString(),
								ThingDesc: entry.content.properties.ThingDescription,
								ThingPkg: thingPkg,
								ThingPkgName: thingPkgName,
								ThingTypeName: thingConfigData.ThingType,
								ThingPkgDesc: thingPkgDesc,
								ThingType: thingConfigData.ThingType.split(":")[1],
								ParentThingID: entry.content.properties.ParentThingID,
								Category: category,
								PropertySet: thingConfigData.PropertySet,
								Icon: icon,
								WorkCenter: erp_wc,
								WorkCenterDesc: erp_wcDesc,
								Visible: true
							});
						}

					});
				}
			});
			//create the tree structure from the flat data which is in data JSON, based on parent id
			var ltt = LTT(data, {
				idKey: 'ThingId',
				parentKey: 'ParentThingID'
			});
			//add each tree in hrcGrp
			hrcGrp.push(ltt[0]);
		}
	}
	var hrcGroupedByPkg = groupBy(hrcGrp, 'ThingPkg');
	//console.log("hrcGroupedByPkg " + JSON.stringify(hrcGroupedByPkg));
	//set the package detail for each grouped data
	for (var i in uniquePck) {
		if (hrcGroupedByPkg[uniquePck[i]] != undefined) {
			result.children.push({
				Name: uniquePck[i],
				Category: "IBM_Plant",
				children: hrcGroupedByPkg[uniquePck[i]]
			});
		}
	}
	var findDepth = function (node) {
		var maxDepth = 0;
		if (node.children !== undefined) {
			var depth = 0;
			node.children.forEach(function (child) {
				depth = findDepth(child) + 1;
				maxDepth = depth > maxDepth ? depth : maxDepth;
			})
		}
		return maxDepth;
	};
	result.children.forEach(function (obj) {
		result.Level = findDepth(obj);
	});
	result = JSON.parse(JSON.stringify(result));
	traverse(result).forEach(function (x) {
		if (x.children != undefined && x.Category == undefined && x.ThingType != undefined) {
			category = x.ThingType.split("_")[1];
			x.Category = category;
		}
	});
	//console.log(" result " + result);
	res.type("application/json").status(200).send(JSON.stringify(result));
});

app.post("/GetIoTAEMultiLevelHierarchyToMap", function (req, res) {
	var Token = getToken();
	var Hostname = "appiot-mds.cfapps.eu10.hana.ondemand.com";
	var eqpData = {},
		eqpGrp = [],
		hrcGrp = [],
		thingArray = [],
		thingTypeId = "",
		thingType = "",
		thingPkg = "",
		thingPkgName = "",
		thingPkgDesc = "",
		hierarchyID = "",
		rootThingID = "",
		isSingleHierarchy = "",
		path = "",
		category = "",
		data = [],
		hierarchyElements, found, erp_wc = "",
		erp_wcDesc = "",
		icon = "",
		thingConfigData, str1, str2, thingNameData;
	var ParentThingID = "",
		ThingID = "",
		ThingType = "";
	const packageMap = new Map();
	var result = {
		children: [],
		Host: req.headers.host
	};
	var groupBy = function (xs, key) {
		return xs.reduce(function (rv, x) {
			(rv[x[key]] = rv[x[key]] || []).push(x);
			return rv;
		}, {});
	};
	var hierarchies = getThingHierarchy(Token, "/ThingHierarchy/v1/ThingHierarchies", "").feed.entry;
	var packages = getPackages("config-package-sap.cfapps.eu10.hana.ondemand.com", Token, "/Package/v1/Packages");
	var uniquePck = [];
	packages.forEach(function (pkg) {
		packageMap.set(pkg.content.properties.Name, pkg.content.properties.Description);
		uniquePck.push(pkg.content.properties.Name.substring(pkg.content.properties.Name.lastIndexOf(".") + 1));
	});
	var mappedThings = getDbDataWith2WhereClause("%", "%",
		'Select "ThingId","ThingType","HierarchyID","RootThingID" from  "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" where "PackageName" like ? and "ThingId" like ? '
	);
	var temp = "",
		t1, t2;
	var catArr = ['Plant', 'FunctionalLocation', 'FunctionLocation', 'Equipment', 'WorkCenter'];

	for (var i in hierarchies) {
		if (Array.isArray(hierarchies) == false) {
			//that means only one hierarchy is there
			hierarchyID = hierarchies.content.properties.HierarchyID;
			rootThingID = hierarchies.content.properties.RootThingID;
		} else {
			hierarchyID = hierarchies[i].content.properties.HierarchyID;
			rootThingID = hierarchies[i].content.properties.RootThingID;
		}
		//for each hierarchyID : read the elements 
		path = "/ThingHierarchy/v1/ThingHierarchies('" + hierarchyID + "')?$expand=";
		hierarchyElements = getThingHierarchy(Token, path, "ThingHierarchyDescriptions,ThingHierarchyElements");
		//console.log("hierarchyID : " + hierarchyID + " , hierarchyElements " + JSON.stringify(hierarchyElements));
		//for each rootThingID : read the configuration
		if (Array.isArray(hierarchyElements) === false) {
			isSingleHierarchy = true;
		} else {
			isSingleHierarchy = false;
		}
		data = [];
		//iterate on hierarchyElements links
		hierarchyElements.entry.link.forEach(function (link) {
			//proceed if the link title is ThingHierarchyElements else ignore
			//console.log("link", JSON.stringify(link));
			if (link.inline != undefined && link.inline.feed.title == "ThingHierarchyElements") {
				//iterate on each entry of thing
				link.inline.feed.entry.forEach(function (entry) {
					ThingID = entry.content.properties.ThingID;
					//add thing which are there in any hierarchy in thingArray
					//thingArray.push(rootThingID);
					thingConfigData = getThingConfiguration(Token, Hostname, "/Things('" + ThingID + "')/Configuration");
					thingTypeId = thingConfigData.ThingType;
					thingPkg = thingTypeId.substring(thingTypeId.lastIndexOf(".") + 1, thingTypeId.lastIndexOf(":"));
					thingPkgName = thingTypeId.substring(0, thingTypeId.lastIndexOf(":"));
					thingPkgDesc = packageMap.get(thingPkgName);
					str1 = "", str2 = "", category = "", t1 = "", t2 = "";
					temp = thingTypeId.split(":")[1];
					//category = temp.split("_")[1];
					t1 = temp.split("_")[0];
					t2 = temp.split("_")[1];
					if (catArr.includes(t1))
						category = t1;
					else
						category = t2;

					//if root element
					if (rootThingID == ThingID) {
						ParentThingID = "0";
						//ThingType = thingConfigData.ThingType;
						ThingType = thingConfigData.ThingType.split(":")[1];
					} else {
						ParentThingID = entry.content.properties.ParentThingID;
						ThingType = thingConfigData.ThingType.split(":")[1];
					}
					if (category.toUpperCase().includes(("WorkCenter").toUpperCase())) {
						erp_wc = entry.content.properties.ThingName;
						erp_wcDesc = entry.content.properties.ThingDescription;
					} else {
						erp_wc = "";
						erp_wcDesc = "";
					}
					//if thing is mapped then add icon
					icon = "";
					if (mappedThings.length > 0) {
						found = JSON.parse(JSON.stringify(mappedThings), function (key, value) {
							if (value.ThingId === ThingID) icon = "sap-icon://sys-enter-2";
							return value;
						});
					}
					if (rootThingID == ThingID) {
						data.push({
							RootThingID: rootThingID,
							HierarchyID: hierarchyID,
							ThingId: ThingID,
							Name: entry.content.properties.ThingName.toString(),
							ThingDesc: entry.content.properties.ThingDescription,
							ThingPkg: thingPkg,
							ThingPkgName: thingPkgName,
							ThingTypeName: thingConfigData.ThingType,
							ThingPkgDesc: thingPkgDesc,
							ThingType: ThingType,
							ParentThingID: ParentThingID,
							Category: category,
							PropertySet: thingConfigData.PropertySet,
							Icon: icon,
							WorkCenter: erp_wc,
							WorkCenterDesc: erp_wcDesc,
							Visible: true
						});
					} else {
						data.push({
							RootThingID: rootThingID,
							HierarchyID: hierarchyID,
							ThingId: ThingID,
							Name: entry.content.properties.ThingName.toString(),
							ThingDesc: entry.content.properties.ThingDescription,
							ThingPkgName: thingPkgName,
							ThingTypeName: thingConfigData.ThingType,
							ThingPkgDesc: thingPkgDesc,
							ThingType: ThingType,
							ParentThingID: ParentThingID,
							Category: category,
							PropertySet: thingConfigData.PropertySet,
							Icon: icon,
							WorkCenter: erp_wc,
							WorkCenterDesc: erp_wcDesc,
							Visible: true
						});
					}

				});
			}
		});
		//create the tree structure from the flat data which is in data JSON, based on parent id
		var ltt = LTT(data, {
			idKey: 'ThingId',
			parentKey: 'ParentThingID'
		});
		//add each tree in hrcGrp
		hrcGrp.push(ltt[0]);
		if (Array.isArray(hierarchies) == false) {
			//if only 1 hierarchy
			break;
		}
	}
	var hrcGroupedByPkg = groupBy(hrcGrp, 'ThingPkg');
	//console.log("hrcGroupedByPkg " + JSON.stringify(hrcGroupedByPkg));
	//set the package detail for each grouped data
	for (var i in uniquePck) {
		if (hrcGroupedByPkg[uniquePck[i]] != undefined) {
			result.children.push({
				Name: uniquePck[i],
				Category: "IBM_Plant",
				children: hrcGroupedByPkg[uniquePck[i]]
			});
		}
	}
	result = JSON.parse(JSON.stringify(result));
	traverse(result).forEach(function (x) {
		if (x.children != undefined && x.Category == undefined && x.ThingType != undefined) {
			category = x.ThingType.split("_")[1];
			x.Category = category;
		}
	});
	//console.log(" result " + result);
	res.type("application/json").status(200).send(JSON.stringify(result));
});

app.post("/GetIoTAEMultiLevelHierarchy", function (req, res) {
	//	var CustomerID = req.body.CustomerID;
	var Token = getToken();
	var Hostname = "appiot-mds.cfapps.eu10.hana.ondemand.com";
	var options = {
		hostname: Hostname,
		path: "/Things",
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	//get all the things 
	var requst = https.request(options, function (resp) {
		var body = '';
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on('end', function () {
			var tempArr = [];
			var value = JSON.parse(body).value;

			//add the package of each thing in tempArr. NOTE: 2 or more things can have same package
			for (var i in value) {
				tempArr.push(value[i]._thingType.toString().substring(value[i]._thingType.toString().lastIndexOf(".") + 1, value[i]._thingType.toString()
					.indexOf(":")));
			}
			//filter the unique pakcage names
			let uniquePck = [...new Set(tempArr)];
			//this will help in grouping data based on package name
			var groupBy = function (xs, key) {
				return xs.reduce(function (rv, x) {
					(rv[x[key]] = rv[x[key]] || []).push(x);
					return rv;
				}, {});
			};
			var eqpData = {},
				eqpGrp = [],
				hrcGrp = [],
				thingArray = [],
				thingTypeId = "",
				thingType = "",
				thingPkg = "",
				thingPkgName = "",
				thingPkgDesc = "",
				hierarchyID = "",
				rootThingID = "",
				isSingleHierarchy = "",
				path = "",
				category = "",
				data = [],
				hierarchyElements, found, erp_wc = "",
				erp_wcDesc = "",
				icon = "",
				thingConfigData, str1, str2, thingNameData, hierarchyName;
			var result = {
				children: [],
				Host: req.headers.host
			};
			var packages = getPackages("config-package-sap.cfapps.eu10.hana.ondemand.com", Token, "/Package/v1/Packages");
			var mappedThings = getDbDataWith2WhereClause("%", "%",
				'Select "ThingId","ThingType" from  "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" where "PackageName" like ? and "ThingId" like ? '
			);
			//get all the hierarchy data
			var hierarchies = getThingHierarchy(Token, "/ThingHierarchy/v1/ThingHierarchies", "").feed.entry;
			for (var i in hierarchies) {
				if (Array.isArray(hierarchies) == false) {
					//that means only one hierarchy is there
					hierarchyID = hierarchies.content.properties.HierarchyID;
					rootThingID = hierarchies.content.properties.RootThingID;
					hierarchyName = hierarchies.content.properties.Name;
				} else {
					hierarchyID = hierarchies[i].content.properties.HierarchyID;
					rootThingID = hierarchies[i].content.properties.RootThingID;
					hierarchyName = hierarchies[i].content.properties.Name;
				}
				//for each hierarchyID : read the elements 
				path = "/ThingHierarchy/v1/ThingHierarchies('" + hierarchyID + "')/ThingHierarchyElements?$filter=";
				hierarchyElements = getThingHierarchy(Token, path, encodeURIComponent("(ThingID eq '" + rootThingID + "')")).feed.entry;
				//for each rootThingID : read the configuration
				if (Array.isArray(hierarchyElements) === false) {
					isSingleHierarchy = true;

				} else {
					isSingleHierarchy = false;
				}
				thingConfigData = getThingConfiguration(Token, Hostname, "/Things('" + rootThingID + "')/Configuration");
				thingTypeId = thingConfigData.ThingType;
				thingPkg = thingTypeId.substring(thingTypeId.lastIndexOf(".") + 1, thingTypeId.lastIndexOf(":"));
				thingPkgName = thingTypeId.substring(0, thingTypeId.lastIndexOf(":"));
				for (var i in packages) {
					if (packages[i].content.properties.Name === thingPkgName) {
						thingPkgDesc = packages[i].content.properties.Description;
						break;
					}
				}
				//based on thing type set the category
				category = "";
				// Modified by Sudipta to remove SAP_
				//str1 = thingConfigData.ThingType.split(":")[1].split("_")[0]; //thingConfigData.ThingTypeDescription.split("_")[0];
				str2 = thingConfigData.ThingType.split("_")[1]; //thingConfigData.ThingTypeDescription.split("_")[1];
				category = str2;
				//console.log("category1------" + category);
				//if (str1 == undefined) category = str2;
				//if (str2 == undefined) category = str1;
				//if (str1 != undefined && str2 != undefined) category = str1 + "_" + str2;
				// Modified by Sudipta to remove SAP_
				if (category.toUpperCase().includes(("WorkCenter").toUpperCase())) {
					erp_wc = hierarchyElements[0].content.properties.ParentThingName;
					erp_wcDesc = hierarchyElements[0].content.properties.ParentThingDescription;
				} else {
					erp_wc = "";
					erp_wcDesc = "";
				}
				data = [];
				//add thing which are there in any hierarchy in thingArray
				thingArray.push(rootThingID);
				//if thing is mapped then add icon
				icon = "";
				if (mappedThings.length > 0) {
					found = JSON.parse(JSON.stringify(mappedThings), function (key, value) {
						if (value.ThingId === rootThingID) icon = "sap-icon://sys-enter-2";
						return value;
					});
				}

				if (isSingleHierarchy === false) {
					//set the details of the root thing in  data JSON
					data.push({
						ThingId: rootThingID,
						Name: hierarchyElements[0].content.properties.ParentThingName,
						ThingDesc: hierarchyElements[0].content.properties.ParentThingDescription,
						ThingPkgName: thingPkgName,
						ThingPkg: thingPkg,
						ThingTypeName: thingConfigData.ThingType,
						ThingPkgDesc: thingPkgDesc,
						ThingType: thingConfigData.ThingType, //.split(":")[1],//thingConfigData.ThingTypeDescription,
						ParentThingID: "0",
						Category: category,
						PropertySet: thingConfigData.PropertySet,
						Icon: icon,
						WorkCenter: erp_wc,
						WorkCenterDesc: erp_wcDesc,
						Visible: true
					});
					for (var k in hierarchyElements) {
						//for each hierarchyElement eq thing , read the configuration
						// thingArray.push(hierarchyElements[k].content.properties.ThingID);
						thingArray.push(hierarchyElements[k].content.properties.ThingID);
						thingConfigData = getThingConfiguration(Token, Hostname, "/Things('" + hierarchyElements[k].content.properties.ThingID +
							"')/Configuration");
						// Added by Sudipta Start
						thingNameData = getThingData(Token, "/Things('" + hierarchyElements[k].content.properties.ThingID + "')");

						// Added by Sudipta End    

						//based on thing type set the category
						category = "",
							str1 = thingConfigData.ThingType.split("_")[0]; //thingConfigData.ThingTypeDescription.split("_")[0];
						str2 = thingConfigData.ThingType.split("_")[1]; //thingConfigData.ThingTypeDescription.split("_")[1];
						if (str1 == undefined) category = str2;
						if (str2 == undefined) category = str1;
						if (str1 != undefined && str2 != undefined) category = str1 + "_" + str2;
						//console.log("category2------" + category);
						//if thing is mapped then add icon
						icon = "";
						if (mappedThings.length > 0) {
							found = JSON.parse(JSON.stringify(mappedThings), function (key, value) {
								if (value.ThingId === hierarchyElements[k].content.properties.ThingID) icon = "sap-icon://sys-enter-2";
								return value;
							});
						}
						//set the details of the hierarchyElement eq thing in data JSON
						data.push({
							ThingId: hierarchyElements[k].content.properties.ThingID,
							Name: thingNameData._name,
							//Name: hierarchyElements[k].content.properties.ThingName,
							ThingDesc: hierarchyElements[k].content.properties.ThingDescription,
							ThingPkgName: thingPkgName,
							ThingPkgDesc: thingPkgDesc,
							ThingTypeName: thingConfigData.ThingType,
							ThingType: thingConfigData.ThingType.split(":")[1], //thingConfigData.ThingTypeDescription,
							ParentThingID: hierarchyElements[k].content.properties.ParentThingID,
							PropertySet: thingConfigData.PropertySet,
							Icon: icon,
							WorkCenter: erp_wc,
							WorkCenterDesc: erp_wcDesc,
							Visible: true
						});
					}
				} else {
					//set the details of the root thing in  data JSON
					data.push({
						ThingId: rootThingID,
						Name: hierarchyElements.content.properties.ParentThingName,
						ThingDesc: hierarchyElements.content.properties.ParentThingDescription,
						ThingPkgName: thingPkgName,
						ThingPkg: thingPkg,
						ThingTypeName: thingConfigData.ThingType,
						ThingPkgDesc: thingPkgDesc,
						ThingType: thingConfigData.ThingType, //.split(":")[1],//thingConfigData.ThingTypeDescription,
						ParentThingID: "0",
						Category: category,
						PropertySet: thingConfigData.PropertySet,
						Icon: icon,
						WorkCenter: erp_wc,
						WorkCenterDesc: erp_wcDesc,
						Visible: true
					});
					for (var k in hierarchyElements) {
						//for each hierarchyElement eq thing , read the configuration
						// thingArray.push(hierarchyElements[k].content.properties.ThingID);
						thingArray.push(hierarchyElements.content.properties.ThingID);
						thingConfigData = getThingConfiguration(Token, Hostname, "/Things('" + hierarchyElements.content.properties.ThingID +
							"')/Configuration");
						// Added by Sudipta Start
						thingNameData = getThingData(Token, "/Things('" + hierarchyElements.content.properties.ThingID + "')");
					}
					// Added by Sudipta End    

					//based on thing type set the category
					category = "",
						str1 = thingConfigData.ThingType.split("_")[0]; //thingConfigData.ThingTypeDescription.split("_")[0];
					str2 = thingConfigData.ThingType.split("_")[1]; //thingConfigData.ThingTypeDescription.split("_")[1];
					if (str1 == undefined) category = str2;
					if (str2 == undefined) category = str1;
					if (str1 != undefined && str2 != undefined) category = str1 + "_" + str2;
					//console.log("category3------" + category);
					//if thing is mapped then add icon
					icon = "";
					/*   if (mappedThings.length > 0) {
					       found = JSON.parse(JSON.stringify(mappedThings), function (key, value) {
					           if (value.ThingId === hierarchyElements[k].content.properties.ThingID) icon = "sap-icon://sys-enter-2";
					           return value;
					       });
					   } */
					//set the details of the hierarchyElement eq thing in data JSON
					data.push({
						ThingId: hierarchyElements.content.properties.ThingID,
						Name: thingNameData._name,
						//Name: hierarchyElements[k].content.properties.ThingName,
						ThingDesc: hierarchyElements.content.properties.ThingDescription,
						ThingPkgName: thingPkgName,
						ThingPkgDesc: thingPkgDesc,
						ThingTypeName: thingConfigData.ThingType,
						ThingType: thingConfigData.ThingType.split(":")[1], //thingConfigData.ThingTypeDescription,
						ParentThingID: hierarchyElements.content.properties.ParentThingID,
						PropertySet: thingConfigData.PropertySet,
						Icon: icon,
						WorkCenter: erp_wc,
						WorkCenterDesc: erp_wcDesc,
						Visible: true
					});

				}
				//create the tree structure from the flat data which is in data JSON, based on parent id
				var ltt = LTT(data, {
					idKey: 'ThingId',
					parentKey: 'ParentThingID'
				});
				//add each tree in hrcGrp
				hrcGrp.push(ltt[0]);
				if (Array.isArray(hierarchies) == false) {
					//if only 1 hierarchy
					break;
				}

				//	}
			} //end of custID filter if
			//iterate on the all the things 
			JSON.parse(body).value.forEach(function (eachRecord) {
				var thingId = eachRecord._id.toString();
				// for the thing which is not present in hierarchy, fetch the configuration and set it in eqpData
				if (!thingArray.includes(thingId)) {
					thingTypeId = eachRecord._thingType.toString();
					thingPkg = thingTypeId.substring(thingTypeId.lastIndexOf(".") + 1, thingTypeId.lastIndexOf(":"));
					thingType = thingTypeId.substring(thingTypeId.lastIndexOf(":") + 1, thingTypeId.length);
					path = "/Things('" + thingId + "')/Configuration"
					thingConfigData = getThingConfiguration(Token, Hostname, path);
					for (var i in packages) {
						if (packages[i].content.properties.Name === thingTypeId.substring(0, thingTypeId.lastIndexOf(":"))) {
							thingPkgDesc = packages[i].content.properties.Description;
							break;
						}
					}
					//based on thing type set the category
					category = "",
						str1 = thingType.split("_")[0];
					str2 = thingType.split("_")[1];
					if (str1 == undefined) category = str2;
					if (str2 == undefined) category = str1;
					if (str1 != undefined && str2 != undefined) category = str1 + "_" + str2;
					//console.log("category4------" + category);
					//console.log(str1 + "-------" + str2);
					//if thing is mapped then add icon
					icon = "";
					if (mappedThings.length > 0) {
						found = JSON.parse(JSON.stringify(mappedThings), function (key, value) {
							if (value.ThingId === thingId) icon = "sap-icon://sys-enter-2";
							return value;
						});
					}
					eqpData = {
						ThingId: thingId,
						Name: eachRecord._name.toString(),
						//Name: eachRecord._name,
						ThingDesc: eachRecord._description.en.toString(),
						ThingPkgName: thingTypeId.substring(0, thingTypeId.lastIndexOf(":")),
						ThingPkg: thingPkg,
						ThingPkgDesc: thingPkgDesc,
						ThingTypeName: thingTypeId,
						ThingType: thingType,
						Category: category,
						PropertySet: thingConfigData.PropertySet,
						Icon: icon,
						Visible: true
					}
					eqpGrp.push(eqpData);
				}
			});

			// grp things based on package
			var groupedByPkg = groupBy(eqpGrp, 'ThingPkg');
			var hrcGroupedByPkg = groupBy(hrcGrp, 'ThingPkg');
			//set the package detail for each grouped data
			for (var i in uniquePck) {
				/*if (groupedByPkg[uniquePck[i]] != undefined) {
					result.children.push({
						Name: uniquePck[i],
						Category: "IBM_Plant",
						children: groupedByPkg[uniquePck[i]]
					});
				}*/
				if (hrcGroupedByPkg[uniquePck[i]] != undefined) {
					result.children.push({
						Name: uniquePck[i], // CustID,
						Category: "IBM_Plant", //"Customer",
						children: hrcGroupedByPkg[uniquePck[i]]
					});
				}
			}
			result = JSON.parse(JSON.stringify(result));
			//replace the key "Group" with key "children"
			//result = JSON.parse(JSON.stringify(result).split('"Group":').join('"children":'));
			//traverse on the tree strucutre, things for which category is missing, set the category based on thing type
			traverse(result).forEach(function (x) {
				if (x.children != undefined && x.Category == undefined && x.ThingType != undefined) {
					//based on thing type set the category
					// modified by Sudipta to remove SAP_
					//category = x.ThingType.split("_")[0];
					category = x.ThingType.split("_")[1];
					//category = x.ThingType.split("_")[0] + "_" + x.ThingType.split("_")[1];
					x.Category = category;
				}
			});
			console.log(result);
			res.type("application/json").status(200).send(JSON.stringify(result));
			//res.type("application/json").status(200).send(result);
		});
	});
	requst.end();
});

var getPropertyData = deasync(function (Token, Path, callback) {
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: Path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error(error);
		});
		res.on('end', function () {
			var dat = JSON.parse(body);
			callback(null, dat);
		});
	});
	req.end();
});
app.post('/getEquipmentPrpAndChildTags', function (req, res) {
	var Token = getToken();
	var Hostname = "appiot-mds.cfapps.eu10.hana.ondemand.com";
	var PackageName = req.body.PackageName;
	var ThingId = req.body.ThingId;
	var ThingType = req.body.ThingType;
	var result = getDbDataWith2WhereClause(PackageName, ThingId,
		'select "Image" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" where "PackageName"=? AND "ThingId"=?'
	);
	var spanData = "",
		imgDiv = "",
		data = {};
	var min = 0,
		max = 100,
		firstrange = 40,
		secondrange = 70,
		thirdrange = 100,
		maxcol = "FA0E0E",
		locol = "0F9A30",
		valcol = "FAD30E";

	var prpSetResults = {
		records: []
	};
	var childEpqResults = {
		records: []
	};
	var gauge = {
		records: []
	};
	var childEqpList = [];
	//console.log(JSON.stringify(result));
	if (result.length > 0) {
		imgDiv = "<div style='position:relative'><img src='" + "data:image/jpg;base64," + result[0].Image + "'/>";
		var prpSetList = getDbDataWith2WhereClause(ThingId, ThingType,
			'select "PropertySet","Coordinates","Shape","DataPosition","Flag" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag" where "ThingId"=? and "ThingType"=?'
		);
		//console.log(JSON.stringify(prpSetList));
		childEqpList = getDbDataWith2WhereClause(PackageName, ThingId,
			'select "ThingId","ThingName","ThingDesc","Coordinates","ThingType","Flag" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ChildThing" where "PackageName"=? AND "ParentThingId"=?'
		);
		//console.log("--------------------------");
		//console.log(JSON.stringify(childEqpList));
		try {
			async.each(childEqpList, function (eachRecord, callback) {
					var tempPrpSetData,
						tempPrpData;
					var currentitem = childEqpList.indexOf(eachRecord);
					var thingData = getThingData(Token, "/Snapshot(thingId='" + childEqpList[currentitem].ThingId +
						"',fromTime='',dataCategory='TimeSeriesData')").value;
					//console.log(JSON.stringify(thingData));
					var childThingType = PackageName + ":" + childEqpList[currentitem].ThingType;
					var category = "";
					var str1 = childEqpList[currentitem].ThingType.split("_")[0];
					var str2 = childEqpList[currentitem].ThingType.split("_")[1];
					if (str1 == undefined) category = str2;
					if (str2 == undefined) category = str1;
					if (str1 != undefined && str2 != undefined) category = str1 + "_" + str2;
					var count = 0;
					var propertyElm = "",
						uom, val;
					if (thingData.length > 0)
						Object.keys(thingData[0]).forEach(function (key) {
							if (key == childThingType) {
								tempPrpSetData = thingData[0][key];
								//console.log("tempPrpSetData----" + JSON.stringify(tempPrpSetData));
								for (var i in tempPrpSetData) {
									var PropertySet = tempPrpSetData[i]._propertySetType.name.split(":")[1].trim();
									var key = "/" + tempPrpSetData[i]._propertySetType.name.split(":")[1].trim();
									//console.log("PropertySet----" + PropertySet);
									//console.log("--------------------------------");
									var properties = getDbDataWith2WhereClause(PropertySet, childEqpList[currentitem].ThingId,
										'select * from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty"  where "PropertySet"=? and "ThingId"=?'
									);
									//console.log(JSON.stringify(properties));
									//console.log("--------------------------------");
									//console.log(properties.length);
									tempPrpData = tempPrpSetData[i][key];

									if (properties.length !== 0) {
										if (PropertySet === properties[0].PropertySet) {
											//console.log("PropertySet-----" + PropertySet + "---properties[0].PropertySet-----" + properties[0].PropertySet);
											for (var p in tempPrpData) {
												Object.keys(tempPrpData[p]).forEach(function (key) {
													if (tempPrpData[p][key]._unitOfMeasure != "" && tempPrpData[p][key]._unitOfMeasure != undefined && tempPrpData[p][key]._unitOfMeasure !=
														null) {
														uom = tempPrpData[p][key]._unitOfMeasure;
													} else {
														uom = "";
													}
													if (tempPrpData[p][key]._value != "" && tempPrpData[p][key]._value != undefined && tempPrpData[p][key]._value != null) {
														val = tempPrpData[p][key]._value;
													} else {
														val = "NA";
													}
													if (count == 0) {
														//propertyElm = tempPrpData[p][key].description + " : " + val + " " + uom;
														propertyElm = (tempPrpData[p][key].description == "" || tempPrpData[p][key].description == null ? Object.keys(
																tempPrpData[
																	p]) :
															tempPrpData[p][key].description) + " : " + val + " " + uom;
														count++;
													} else {
														//propertyElm = propertyElm + "<br>" + tempPrpData[p][key].description + " : " + val + " " + uom;
														propertyElm = propertyElm + "<br>" + (tempPrpData[p][key].description == "" || tempPrpData[p][key].description == null ?
															Object.keys(tempPrpData[p]) :
															tempPrpData[p][key].description) + " : " + val + " " + uom;
													}
												});
											}
										}
									}
									//console.log("tempPrpData----" + JSON.stringify(tempPrpData));
									/*for (var p in tempPrpData) {
										Object.keys(tempPrpData[p]).forEach(function (key) {
											if (tempPrpData[p][key]._unitOfMeasure != "" && tempPrpData[p][key]._unitOfMeasure != undefined && tempPrpData[p][key]._unitOfMeasure !=
												null) {
												uom = tempPrpData[p][key]._unitOfMeasure;
											} else {
												uom = "";
											}
											if (tempPrpData[p][key]._value != "" && tempPrpData[p][key]._value != undefined && tempPrpData[p][key]._value != null) {
												val = tempPrpData[p][key]._value;
											} else {
												val = "NA";
											}
											if (count == 0) {
												//propertyElm = tempPrpData[p][key].description + " : " + val + " " + uom;
												propertyElm = (tempPrpData[p][key].description == "" || tempPrpData[p][key].description == null ? Object.keys(
														tempPrpData[
															p]) :
													tempPrpData[p][key].description) + " : " + val + " " + uom;
												count++;
											} else {
												//propertyElm = propertyElm + "<br>" + tempPrpData[p][key].description + " : " + val + " " + uom;
												propertyElm = propertyElm + "<br>" + (tempPrpData[p][key].description == "" || tempPrpData[p][key].description == null ?
													Object.keys(tempPrpData[p]) :
													tempPrpData[p][key].description) + " : " + val + " " + uom;
											}
										});
									}*/
								}
							}
						});
					spanData = spanData + getChildEqpDiv(childEqpList[currentitem].Coordinates, "<u>" + childEqpList[
							currentitem]
						.ThingDesc + "(" + childEqpList[currentitem].ThingName + ")</u> :<br>" + propertyElm, childEqpList[currentitem].ThingName);
					callback(null);
					//commented to remove the category from the functional location image
					/*spanData = spanData + getChildEqpDiv(childEqpList[currentitem].Coordinates, "<u>" + (category.includes("SAP_") == true ||
							category.includes(
								"IBM_") == true ? category.replace("SAP_", "") || category.replace("IBM_", "") : category) + "</u><br><u>" + childEqpList[
							currentitem]
						.ThingDesc + "(" + childEqpList[currentitem].ThingName + ")</u> :<br>" + propertyElm, childEqpList[currentitem].ThingName);
					callback(null);*/
					//commented by maviya to remove the list of properties in functional location image tage
					/*spanData = spanData + getChildEqpDiv(childEqpList[currentitem].Coordinates, "<u>" + (category.includes("SAP_") == true ||
							category.includes(
								"IBM_") == true ? category.replace("SAP_", "") || category.replace("IBM_", "") : category) + "</u><br><u>" + childEqpList[
							currentitem]
						.ThingDesc + "(" + childEqpList[currentitem].ThingName +
						")</u>", childEqpList[currentitem]
						.ThingName);
					callback(null);*/
				},
				function (err) {
					if (err) {
						console.error('getEquipmentPrpAndChildTags something went wrong err===>>>' + JSON.stringify(err));
					}
				});
			async.each(prpSetList, function (eachRecord, callback) {
					var currentitem = prpSetList.indexOf(eachRecord);
					var propertySet = prpSetList[currentitem].PropertySet;
					var coords = prpSetList[currentitem].Coordinates;
					var Shape = prpSetList[currentitem].Shape;
					var DataPosition = prpSetList[currentitem].DataPosition;
					var Flag = prpSetList[currentitem].Flag; //by raaga
					prpSetResults.records.push({
						PopertySet: propertySet
					});
					var path = "/Things('" + ThingId + "')/" + PackageName + ":" + ThingType + "/" + propertySet +
						"?orderby=_time&timerange=1M&$top=1";
					var thingData = getThingData(Token, path);
					var properties = getDbDataWith2WhereClause(ThingId, propertySet,
						'select * from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty"  where "ThingId"=? and "PropertySet"=?'
					);
					var rPath = encodeURI("/Things('" + ThingId + "')/ReferenceProperties/" + PackageName + ":" + ThingType + "/" + propertySet +
						"?$filter=_time gt 2020-01-06T09:00:00.000Z");
					var thingReferenceData = getThingData(Token, rPath);
					var Prop_Path = "/Things('" + ThingId + "')/Configuration";
					var PropertyData = getPropertyData(Token, Prop_Path);
					//console.log("-------------------------------------------------------");
					//console.log(JSON.stringify(PropertyData));
					var propertyElm = "",
						uom, Color;
					var propertyLabelTd = "",
						gaugeData = "",
						chart = "";
					for (var i in properties) {
						var Propertydesc;
						for (var q = 0; q < PropertyData.propertySetTypes.length; q++) {
							var Property_Array = PropertyData.propertySetTypes[q].propertyTypes.map(function (result) {
								//console.log("result------" + result.value.id + "------properties[i].Property-----" + properties[i].Property);
								if (result.value.id == properties[i].Property) {
									if (result.value.description.en == "" || result.value.description.en == null) {
										//console.log("entered in if");
										Propertydesc = properties[i].Property;
									} else {
										//console.log("entered in else");
										Propertydesc = result.value.description.en;
									}
									//console.log("--------------------------" + Propertydesc + "----------------------------");
								}
							});
						}
						if (properties[i].UOM != "") {
							uom = "(" + properties[i].UOM + ")";
						} else {
							uom = properties[i].UOM;
						}
						if (i == 0) {
							propertyLabelTd = "<td style='color:black;' align='center'>" + properties[i].Property + uom + "</td>";
						} else {
							propertyLabelTd = propertyLabelTd + "<td style='color:black;'  align='center'>" + properties[i].Property + uom + "</td>";
						}
						var upperThreshHold = 0;
						if (thingData.value != undefined && thingData.value !== "") {
							if (thingData.value.length > 0) {
								if (thingReferenceData.value != undefined) {
									if (thingReferenceData.value.length > 0) {
										Object.keys(thingReferenceData.value[0]).forEach(function (key) {
											if (key.includes(properties[i].Property + "L")) {
												min = thingReferenceData.value[0][key];
											} else if (key.includes(properties[i].Property + "U")) {
												upperThreshHold = thingReferenceData.value[0][key];
												if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
													Color = "red";
													max = Number(thingData.value[0][properties[i].Property]) + 10;
												} else {
													Color = "green";
													max = Number(upperThreshHold) + 10;
												}
												firstrange = Number(upperThreshHold) - 1;
												secondrange = Number(upperThreshHold) - 1;
												thirdrange = max;
											}
										});
									} else {
										min = 0;
										upperThreshHold = 100;
										if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
											Color = "red";
											max = Number(thingData.value[0][properties[i].Property]) + 20;
										} else {
											Color = "green";
											max = Number(upperThreshHold) + 20;
										}
										firstrange = Number(upperThreshHold) - 1;
										secondrange = Number(upperThreshHold) - 1;
										thirdrange = max;
									}
								} else {
									min = 0;
									upperThreshHold = 100;
									if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
										Color = "red";
										max = Number(thingData.value[0][properties[i].Property]) + 20;
									} else {
										Color = "green";
										max = Number(upperThreshHold) + 20;
									}
									firstrange = Number(upperThreshHold) - 1;
									secondrange = Number(upperThreshHold) - 1;
									thirdrange = max;
								}
								if (i == 0) {
									if (Flag === "P") {
										propertyElm = Propertydesc + " : " + thingData.value[0][properties[i].Property];
									} else {
										//propertyElm = properties[i].Property + " : " + thingData.value[0][properties[i].Property] + " " + properties[i].UOM;
										propertyElm = Propertydesc + "(HH=" + Number(upperThreshHold) + ")" + " : " + thingData.value[0][properties[i].Property] + " " +
											properties[i].UOM;
										gaugeData = "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" + min +
											"%26max=" +
											max +
											"%26val=" +
											thingData.value[0][properties[i].Property] +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 4rem;width: 6rem;border: 0px;'></iframe></td>";
									}
								} else {
									//propertyElm = propertyElm + "<br>" + properties[i].Property + " : " + thingData.value[0][properties[i].Property] + " " +
									//properties[i].UOM;
									if (Flag === "P") {
										propertyElm = propertyElm + "<br>" + Propertydesc + " : " + thingData.value[0][properties[i].Property];
									} else {
										propertyElm = propertyElm + "<br>" + Propertydesc + "(HH=" + Number(upperThreshHold) + ")" + " : " + thingData.value[0][
												properties[i].Property
											] + " " +
											properties[i].UOM;
										gaugeData = gaugeData +
											"<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" + min +
											"%26max=" +
											max +
											"%26val=" + thingData.value[0][properties[i].Property] +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 4rem;width: 6rem;border: 0px;'></iframe></td>";
									}
								}
							} else {
								if (thingReferenceData.value != undefined) {
									if (thingReferenceData.value.length > 0) {
										Object.keys(thingReferenceData.value[0]).forEach(function (key) {
											if (key.includes(properties[i].Property + "L")) {
												min = thingReferenceData.value[0][key];
											} else if (key.includes(properties[i].Property + "U")) {
												upperThreshHold = thingReferenceData.value[0][key];
												max = Number(upperThreshHold) + 100;
												firstrange = Number(upperThreshHold) - 1;
												secondrange = Number(upperThreshHold) - 1;
												thirdrange = max;
											}
										});
									} else {
										min = 0;
										upperThreshHold = 28;
										max = upperThreshHold;
										Color = "green";
										firstrange = Number(upperThreshHold) - 1;
										secondrange = Number(upperThreshHold) - 1;
										thirdrange = max;
									}
								} else {
									min = 0;
									upperThreshHold = 28;
									max = upperThreshHold;
									Color = "green";
									firstrange = Number(upperThreshHold) - 1;
									secondrange = Number(upperThreshHold) - 1;
									thirdrange = max;
								}
								if (i == 0) {
									propertyElm = properties[i].Property + " : NA";
									gaugeData = "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" + min +
										"%26max=" +
										max +
										"%26val=0" +
										"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
										secondrange + "%26highlimit=" + thirdrange +
										"%26label=" + properties[i].Property + " " + properties[i].UOM +
										"' height='100%' width='100%'  align='center' style='height: 4rem;width: 6rem;border: 0px;'></iframe></td>";
								} else {
									propertyElm = propertyElm + "<br>" + properties[i].Property + " : NA";
									gaugeData = gaugeData + "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
										min +
										"%26max=" +
										max +
										"%26val=0" +
										"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
										secondrange + "%26highlimit=" + thirdrange +
										"%26label=" + properties[i].Property + " " + properties[i].UOM +
										"' height='100%' width='100%'  align='center' style='height: 4rem;width: 6rem;border: 0px;'></iframe></td>";
								}
							}
						}
					}
					var tempData = {};
					tempData[propertySet] = "<table><tr>" + propertyLabelTd + "</tr><tr>" + gaugeData + "</tr></table>";
					gauge.records.push(tempData);
					//check if the property is anamoly or prediction property
					//for anamoly
					//added by raaga
					if (Flag == "A") {

						var Equipment = ThingType.replace("Equipment_", "");
						var GetAnomalyScore = GetEquipmentMeasureTimeSeriesData(Equipment);
						var value = GetAnomalyScore.value;
						var Status = GetAnomalyScore.status;

						var val = value.toFixed(1);
						//if we need a chart to show anamoly score
						/*	var chart =
								"<iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Chart.html?value=" + val + "Status=Decreased" + // Status +
								"' height='50px' width='10%'  align='center' style='height: 8rem;width: 10rem;border: 0px;'></iframe>";*/
						//based on the status the tile colour changes
						if (Status == "Increased") {
							Color = "Green";
							spanData = spanData + getSpanStr(Color, coords, "Anomaly", propertySet,
								"<table><tr><br><br><font size=20>" + value.toFixed(1) +
								"</font><img src='/SustainableManufacturingAsset_MonitoringDashboard/Images/darkGreen.png'/></tr><br><tr> " + Propertydesc +
								"</tr></table>");

						} else {
							Color = "red";
							spanData = spanData + getSpanStr(Color, coords, "Anomaly", propertySet,
								"<table><tr><br><br><font size=20>" + value.toFixed(1) +
								"</font><img src='/SustainableManufacturingAsset_MonitoringDashboard/Images/redArrow.png'/></tr><br><tr> " + Propertydesc +
								"</tr></table>");

						}
						callback(null);
					} //if the property is Prediction
					else if (Flag == "P") {
						//Based on the status the colour changes and chart is shown
						if (thingData.value.length > 0 && thingData.value[0][properties[i].Property] === "Pass") {
							Color = "Green";
						} else {
							Color = "red";
						}
						var val = "80.1";
						var chart =
							"<iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Chart.html?value=" + val +
							"' height='100%' width='100%'  align='center' style='height: 8rem;width: 10rem;border: 0px;'></iframe>";
						spanData = spanData + getSpanStr(Color, coords, "Prediction", propertySet,
							"<table><tr>" + propertyElm + "</tr><tr>" + chart + "</tr></table>");
						callback(null);
					} else {
						spanData = spanData + getSpanStr(Color, coords, propertyElm, propertySet,
							"<table><tr>" + gaugeData + "</tr></table>");
						callback(null);
					}
				},
				function (err) {
					if (err) {
						console.error('getEquipmentPrpAndChildTags something went wrong err===>>>' + JSON.stringify(err));
					}
				});
			var result = JSON.stringify({
				prpSetRecords: prpSetResults,
				childEpqRecords: childEpqResults,
				span: spanData + "</div>",
				imgDiv: imgDiv,
				gaugeRecord: gauge,
				EquipmentRecords: childEqpList
			});
			return res.type("application/json").status(202).send(result);
		} catch (error) {
			console.error('getEquipmentPrpAndChildTags error===>>>' + error);
			return res.type("application/json").status(500).send(error);
		}
	} else {
		var result = JSON.stringify({
			prpSetRecords: prpSetResults,
			childEpqRecords: childEpqResults,
			span: spanData + "</div>",
			imgDiv: imgDiv,
			gaugeRecord: gauge,
			EquipmentRecords: childEqpList
		});
		//console.log(result);
		return res.type("application/json").status(202).send(result);
	}
});

app.post('/getEquipmentPrpAndChildTags2', function (req, res) {
	var Token = getToken();
	var Hostname = "appiot-mds.cfapps.eu10.hana.ondemand.com";
	var PackageName = req.body.PackageName;
	var ThingId = req.body.ThingId;
	var ThingType = req.body.ThingType;
	var result = getDbDataWith2WhereClause(PackageName, ThingId,
		'select "Image" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" where "PackageName"=? AND "ThingId"=?'
	);
	var spanData = "",
		imgDiv = "",
		data = {};
	var min = 0,
		max = 100,
		firstrange = 40,
		secondrange = 70,
		thirdrange = 100,
		maxcol = "FA0E0E",
		locol = "0F9A30",
		valcol = "FAD30E";

	var prpSetResults = {
		records: []
	};
	var childEpqResults = {
		records: []
	};
	var gauge = {
		records: []
	};
	var childEqpList = [];
	//console.log(JSON.stringify(result));
	if (result.length > 0) {
		imgDiv = "<div style='position:relative'><img src='" + "data:image/jpg;base64," + result[0].Image + "'/>";
		var prpSetList = getDbDataWith2WhereClause(ThingId, ThingType,
			'select "PropertySet","Coordinates","Shape","DataPosition","Flag" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag" where "ThingId"=? and "ThingType"=?'
		);
		//console.log("prpSetList " + JSON.stringify(prpSetList));
		childEqpList = getDbDataWith2WhereClause(PackageName, ThingId,
			'select "ThingId","ThingName","ThingDesc","Coordinates","ThingType","Flag" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ChildThing" where "PackageName"=? AND "ParentThingId"=?'
		);
		//console.log("--------------------------");
		//console.log("childEqpList " + JSON.stringify(childEqpList));
		try {
			async.each(childEqpList, function (eachRecord, callback) {
					var tempPrpSetData,
						tempPrpData;
					var currentitem = childEqpList.indexOf(eachRecord);
					var thingData = getThingData(Token, "/Snapshot(thingId='" + childEqpList[currentitem].ThingId +
						"',fromTime='',dataCategory='TimeSeriesData')").value;
					//console.log("thingData " + thingData.length);
					var childThingType = PackageName + ":" + childEqpList[currentitem].ThingType;
					var category = "";
					var str1 = childEqpList[currentitem].ThingType.split("_")[0];
					var str2 = childEqpList[currentitem].ThingType.split("_")[1];
					if (str1 == undefined) category = str2;
					if (str2 == undefined) category = str1;
					if (str1 != undefined && str2 != undefined) category = str1 + "_" + str2;
					var count = 0;
					var propertyElm = "",
						uom, val;
					if (thingData.length > 0)
						Object.keys(thingData[0]).forEach(function (key) {
							if (key == childThingType) {
								tempPrpSetData = thingData[0][key];
								//console.log("tempPrpSetData----" + JSON.stringify(tempPrpSetData));
								for (var i in tempPrpSetData) {
									var PropertySet = tempPrpSetData[i]._propertySetType.name.split(":")[1].trim();
									var key = "/" + tempPrpSetData[i]._propertySetType.name.split(":")[1].trim();
									//console.log("PropertySet----" + PropertySet);
									//console.log("--------------------------------");
									var properties = getDbDataWith2WhereClause(PropertySet, childEqpList[currentitem].ThingId,
										'select * from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty"  where "PropertySet"=? and "ThingId"=?'
									);
									//console.log(JSON.stringify(properties));
									//console.log("--------------------------------");
									//console.log(properties.length);
									tempPrpData = tempPrpSetData[i][key];

									if (properties.length !== 0) {
										if (PropertySet === properties[0].PropertySet) {
											//console.log("PropertySet-----" + PropertySet + "---properties[0].PropertySet-----" + properties[0].PropertySet);
											for (var p in tempPrpData) {
												Object.keys(tempPrpData[p]).forEach(function (key) {
													if (tempPrpData[p][key]._unitOfMeasure != "" && tempPrpData[p][key]._unitOfMeasure != undefined && tempPrpData[p][key]._unitOfMeasure !=
														null) {
														uom = tempPrpData[p][key]._unitOfMeasure;
													} else {
														uom = "";
													}
													if (tempPrpData[p][key]._value != "" && tempPrpData[p][key]._value != undefined && tempPrpData[p][key]._value != null) {
														val = tempPrpData[p][key]._value;
													} else {
														val = "NA";
													}
													if (count == 0) {
														//propertyElm = tempPrpData[p][key].description + " : " + val + " " + uom;
														propertyElm = (tempPrpData[p][key].description == "" || tempPrpData[p][key].description == null ? Object.keys(
																tempPrpData[
																	p]) :
															tempPrpData[p][key].description) + " : " + val + " " + uom;
														count++;
													} else {
														//propertyElm = propertyElm + "<br>" + tempPrpData[p][key].description + " : " + val + " " + uom;
														propertyElm = propertyElm + "<br>" + (tempPrpData[p][key].description == "" || tempPrpData[p][key].description == null ?
															Object.keys(tempPrpData[p]) :
															tempPrpData[p][key].description) + " : " + val + " " + uom;
													}
												});
											}
										}
									}
									//console.log("tempPrpData----" + JSON.stringify(tempPrpData));
									/*for (var p in tempPrpData) {
										Object.keys(tempPrpData[p]).forEach(function (key) {
											if (tempPrpData[p][key]._unitOfMeasure != "" && tempPrpData[p][key]._unitOfMeasure != undefined && tempPrpData[p][key]._unitOfMeasure !=
												null) {
												uom = tempPrpData[p][key]._unitOfMeasure;
											} else {
												uom = "";
											}
											if (tempPrpData[p][key]._value != "" && tempPrpData[p][key]._value != undefined && tempPrpData[p][key]._value != null) {
												val = tempPrpData[p][key]._value;
											} else {
												val = "NA";
											}
											if (count == 0) {
												//propertyElm = tempPrpData[p][key].description + " : " + val + " " + uom;
												propertyElm = (tempPrpData[p][key].description == "" || tempPrpData[p][key].description == null ? Object.keys(
														tempPrpData[
															p]) :
													tempPrpData[p][key].description) + " : " + val + " " + uom;
												count++;
											} else {
												//propertyElm = propertyElm + "<br>" + tempPrpData[p][key].description + " : " + val + " " + uom;
												propertyElm = propertyElm + "<br>" + (tempPrpData[p][key].description == "" || tempPrpData[p][key].description == null ?
													Object.keys(tempPrpData[p]) :
													tempPrpData[p][key].description) + " : " + val + " " + uom;
											}
										});
									}*/
								}
							}
						});
					spanData = spanData + getChildEqpDiv(childEqpList[currentitem].Coordinates, "<u>" + childEqpList[
							currentitem]
						.ThingDesc + "(" + childEqpList[currentitem].ThingName + ")</u> :<br>" + propertyElm, childEqpList[currentitem].ThingName);
					callback(null);
					//commented to remove the category from the functional location image
					/*spanData = spanData + getChildEqpDiv(childEqpList[currentitem].Coordinates, "<u>" + (category.includes("SAP_") == true ||
							category.includes(
								"IBM_") == true ? category.replace("SAP_", "") || category.replace("IBM_", "") : category) + "</u><br><u>" + childEqpList[
							currentitem]
						.ThingDesc + "(" + childEqpList[currentitem].ThingName + ")</u> :<br>" + propertyElm, childEqpList[currentitem].ThingName);
					callback(null);*/
					//commented by maviya to remove the list of properties in functional location image tage
					/*spanData = spanData + getChildEqpDiv(childEqpList[currentitem].Coordinates, "<u>" + (category.includes("SAP_") == true ||
							category.includes(
								"IBM_") == true ? category.replace("SAP_", "") || category.replace("IBM_", "") : category) + "</u><br><u>" + childEqpList[
							currentitem]
						.ThingDesc + "(" + childEqpList[currentitem].ThingName +
						")</u>", childEqpList[currentitem]
						.ThingName);
					callback(null);*/
				},
				function (err) {
					if (err) {
						console.error('getEquipmentPrpAndChildTags something went wrong err===>>>' + JSON.stringify(err));
					}
				});
			async.each(prpSetList, function (eachRecord, callback) {
					var currentitem = prpSetList.indexOf(eachRecord);
					var propertySet = prpSetList[currentitem].PropertySet;
					var coords = prpSetList[currentitem].Coordinates;
					var Shape = prpSetList[currentitem].Shape;
					var DataPosition = prpSetList[currentitem].DataPosition;
					var Flag = prpSetList[currentitem].Flag; //by raaga
					prpSetResults.records.push({
						PopertySet: propertySet
					});
					var path = "/Things('" + ThingId + "')/" + PackageName + ":" + ThingType + "/" + propertySet +
						"?orderby=_time&timerange=1M&$top=1";
					var thingData = getThingData(Token, path);
					//console.log("in prpSetList thingData " + JSON.stringify(thingData));
					var properties = getDbDataWith2WhereClause(ThingId, propertySet,
						'select * from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty"  where "ThingId"=? and "PropertySet"=?'
					);
					//console.log("in prpSetList properties " + JSON.stringify(properties));
					var rPath = encodeURI("/Things('" + ThingId + "')/ReferenceProperties/" + PackageName + ":" + ThingType + "/" + propertySet +
						"?$filter=_time gt 2020-01-06T09:00:00.000Z");
					var thingReferenceData = getThingData(Token, rPath);
					//console.log("in prpSetList thingReferenceData " + JSON.stringify(thingReferenceData));
					var Prop_Path = "/Things('" + ThingId + "')/Configuration";
					var PropertyData = getPropertyData(Token, Prop_Path);
					//console.log("in prpSetList PropertyData " + JSON.stringify(PropertyData));
					//console.log("-------------------------------------------------------");
					//console.log(JSON.stringify(PropertyData));
					var propertyElm = "",
						uom, Color;
					var propertyLabelTd = "",
						gaugeData = "",
						chart = "";
					for (var i in properties) {
						var Propertydesc;
						for (var q = 0; q < PropertyData.propertySetTypes.length; q++) {
							var Property_Array = PropertyData.propertySetTypes[q].propertyTypes.map(function (result) {
								//console.log("result------" + result.value.id + "------properties[i].Property-----" + properties[i].Property);
								if (result.value.id == properties[i].Property) {
									if (result.value.description.en == "" || result.value.description.en == null) {
										//console.log("entered in if");
										Propertydesc = properties[i].Property;
									} else {
										//console.log("entered in else");
										Propertydesc = result.value.description.en;
									}
									//console.log("--------------------------" + Propertydesc + "----------------------------");
								}
							});
						}
						if (properties[i].UOM != "") {
							uom = "(" + properties[i].UOM + ")";
						} else {
							uom = properties[i].UOM;
						}
						if (i == 0) {
							propertyLabelTd = "<td style='color:black;' align='center'>" + properties[i].Property + uom + "</td>";
						} else {
							propertyLabelTd = propertyLabelTd + "<td style='color:black;'  align='center'>" + properties[i].Property + uom + "</td>";
						}
						var upperThreshHold = 0;
						if (thingData.value != undefined && thingData.value != "") {
							if (thingData.value.length > 0) {
								if (thingReferenceData.value != undefined) {
									if (thingReferenceData.value.length > 0) {
										Object.keys(thingReferenceData.value[0]).forEach(function (key) {
											if (key.includes(properties[i].Property + "L")) {
												min = thingReferenceData.value[0][key];
											} else if (key.includes(properties[i].Property + "U")) {
												upperThreshHold = thingReferenceData.value[0][key];
												if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
													Color = "red";
													max = Number(thingData.value[0][properties[i].Property]) + 10;
												} else {
													Color = "green";
													max = Number(upperThreshHold) + 10;
												}
												firstrange = Number(upperThreshHold) - 1;
												secondrange = Number(upperThreshHold) - 1;
												thirdrange = max;
											}
										});
									} else {
										min = 0;
										upperThreshHold = 100;
										if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
											Color = "red";
											max = Number(thingData.value[0][properties[i].Property]) + 20;
										} else {
											Color = "green";
											max = Number(upperThreshHold) + 20;
										}
										firstrange = Number(upperThreshHold) - 1;
										secondrange = Number(upperThreshHold) - 1;
										thirdrange = max;
									}
								} else {
									min = 0;
									upperThreshHold = 100;
									if (Number(thingData.value[0][properties[i].Property]) >= Number(upperThreshHold)) {
										Color = "red";
										max = Number(thingData.value[0][properties[i].Property]) + 20;
									} else {
										Color = "green";
										max = Number(upperThreshHold) + 20;
									}
									firstrange = Number(upperThreshHold) - 1;
									secondrange = Number(upperThreshHold) - 1;
									thirdrange = max;
								}
								if (i == 0) {
									if (Flag === "P") {
										propertyElm = Propertydesc + " : " + thingData.value[0][properties[i].Property];
									} else {
										//propertyElm = properties[i].Property + " : " + thingData.value[0][properties[i].Property] + " " + properties[i].UOM;
										propertyElm = Propertydesc + "(HH=" + Number(upperThreshHold) + ")" + " : " + thingData.value[0][properties[i].Property] +
											" " +
											properties[i].UOM;
										gaugeData = "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" + min +
											"%26max=" +
											max +
											"%26val=" +
											thingData.value[0][properties[i].Property] +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 4rem;width: 6rem;border: 0px;'></iframe></td>";
									}
								} else {
									//propertyElm = propertyElm + "<br>" + properties[i].Property + " : " + thingData.value[0][properties[i].Property] + " " +
									//properties[i].UOM;
									if (Flag === "P") {
										propertyElm = propertyElm + "<br>" + Propertydesc + " : " + thingData.value[0][properties[i].Property];
									} else {
										propertyElm = propertyElm + "<br>" + Propertydesc + "(HH=" + Number(upperThreshHold) + ")" + " : " + thingData.value[0][
												properties[i].Property
											] + " " +
											properties[i].UOM;
										gaugeData = gaugeData +
											"<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" + min +
											"%26max=" +
											max +
											"%26val=" + thingData.value[0][properties[i].Property] +
											"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
											secondrange + "%26highlimit=" + thirdrange +
											"%26label=" + properties[i].Property + " " + properties[i].UOM +
											"' height='100%' width='100%'  align='center' style='height: 4rem;width: 6rem;border: 0px;'></iframe></td>";
									}
								}
							} else {
								if (thingReferenceData.value != undefined) {
									if (thingReferenceData.value.length > 0) {
										Object.keys(thingReferenceData.value[0]).forEach(function (key) {
											if (key.includes(properties[i].Property + "L")) {
												min = thingReferenceData.value[0][key];
											} else if (key.includes(properties[i].Property + "U")) {
												upperThreshHold = thingReferenceData.value[0][key];
												max = Number(upperThreshHold) + 100;
												firstrange = Number(upperThreshHold) - 1;
												secondrange = Number(upperThreshHold) - 1;
												thirdrange = max;
											}
										});
									} else {
										min = 0;
										upperThreshHold = 28;
										max = upperThreshHold;
										Color = "green";
										firstrange = Number(upperThreshHold) - 1;
										secondrange = Number(upperThreshHold) - 1;
										thirdrange = max;
									}
								} else {
									min = 0;
									upperThreshHold = 28;
									max = upperThreshHold;
									Color = "green";
									firstrange = Number(upperThreshHold) - 1;
									secondrange = Number(upperThreshHold) - 1;
									thirdrange = max;
								}
								if (i == 0) {
									propertyElm = properties[i].Property + " : NA";
									gaugeData = "<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" + min +
										"%26max=" +
										max +
										"%26val=0" +
										"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
										secondrange + "%26highlimit=" + thirdrange +
										"%26label=" + properties[i].Property + " " + properties[i].UOM +
										"' height='100%' width='100%'  align='center' style='height: 4rem;width: 6rem;border: 0px;'></iframe></td>";
								} else {
									propertyElm = propertyElm + "<br>" + properties[i].Property + " : NA";
									gaugeData = gaugeData +
										"<td><iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Gauge.html?min=" +
										min +
										"%26max=" +
										max +
										"%26val=0" +
										"%26locol=" + locol + "%26valcol=" + valcol + "%26maxcol=" + maxcol + "%26lowlimit=" + firstrange + "%26midlimit=" +
										secondrange + "%26highlimit=" + thirdrange +
										"%26label=" + properties[i].Property + " " + properties[i].UOM +
										"' height='100%' width='100%'  align='center' style='height: 4rem;width: 6rem;border: 0px;'></iframe></td>";
								}
							}
						}
					}
					var tempData = {};
					tempData[propertySet] = "<table><tr>" + propertyLabelTd + "</tr><tr>" + gaugeData + "</tr></table>";
					gauge.records.push(tempData);
					//check if the property is anamoly or prediction property
					//for anamoly
					//added by raaga
					console.log("in if Flag " + Flag);
					if (Flag == "A") {
						var Equipment = ThingType.replace("Equipment_", "");
						var GetAnomalyScore = GetEquipmentMeasureTimeSeriesData(Equipment);
						var value = GetAnomalyScore.value;
						var Status = GetAnomalyScore.status;

						var val = value.toFixed(1);
						//if we need a chart to show anamoly score
						/*	var chart =
								"<iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Chart.html?value=" + val + "Status=Decreased" + // Status +
								"' height='50px' width='10%'  align='center' style='height: 8rem;width: 10rem;border: 0px;'></iframe>";*/
						//based on the status the tile colour changes
						if (Status == "Increased") {
							Color = "Green";
							spanData = spanData + getSpanStr(Color, coords, "Anomaly", propertySet,
								"<table><tr><br><br><font size=20>" + value.toFixed(1) +
								"</font><img src='/SustainableManufacturingAsset_MonitoringDashboard/Images/darkGreen.png'/></tr><br><tr> " + Propertydesc +
								"</tr></table>");

						} else {
							Color = "red";
							spanData = spanData + getSpanStr(Color, coords, "Anomaly", propertySet,
								"<table><tr><br><br><font size=20>" + value.toFixed(1) +
								"</font><img src='/SustainableManufacturingAsset_MonitoringDashboard/Images/redArrow.png'/></tr><br><tr> " + Propertydesc +
								"</tr></table>");

						}
						callback(null);
					} //if the property is Prediction
					else if (Flag == "P") {
						//Based on the status the colour changes and chart is shown
						if (thingData.value[0][properties[i].Property] === "Pass") {
							Color = "Green";
						} else {
							Color = "red";
						}
						var val = "80.1";
						var chart =
							"<iframe target='_top' src='/SustainableManufacturingAsset_MonitoringDashboard/lib/Chart.html?value=" + val +
							"' height='100%' width='100%'  align='center' style='height: 8rem;width: 10rem;border: 0px;'></iframe>";
						spanData = spanData + getSpanStr(Color, coords, "Prediction", propertySet,
							"<table><tr>" + propertyElm + "</tr><tr>" + chart + "</tr></table>");
						callback(null);
					} else {
						spanData = spanData + getSpanStr(Color, coords, propertyElm, propertySet,
							"<table><tr>" + gaugeData + "</tr></table>");
						callback(null);
					}
				},
				function (err) {
					if (err) {
						console.error('getEquipmentPrpAndChildTags something went wrong err===>>>' + JSON.stringify(err));
					}
				});
			var result = JSON.stringify({
				prpSetRecords: prpSetResults,
				childEpqRecords: childEpqResults,
				span: spanData + "</div>",
				imgDiv: imgDiv,
				gaugeRecord: gauge,
				EquipmentRecords: childEqpList
			});
			return res.type("application/json").status(202).send(result);
		} catch (error) {
			console.error('getEquipmentPrpAndChildTags error===>>>' + error);
			return res.type("application/json").status(500).send(error);
		}
	} else {
		var result = JSON.stringify({
			prpSetRecords: prpSetResults,
			childEpqRecords: childEpqResults,
			span: spanData + "</div>",
			imgDiv: imgDiv,
			gaugeRecord: gauge,
			EquipmentRecords: childEqpList
		});
		//console.log(result);
		return res.type("application/json").status(202).send(result);
	}
});

var getChildEqpDiv = deasync(function (Coordinates, data, ThingName, callback) {
	var coorArr = Coordinates.split(',');
	var top = coorArr[0];
	var left = coorArr[1];
	var bottom = coorArr[2];
	var right = coorArr[3];
	var height = bottom - top;
	var width = right - left;
	var borderColor, boxShadow, cssClass;
	//var Color = "black";
	var Color = "white";
	borderColor = "transparent";
	//boxShadow = "20px 20px 20px #505050";
	cssClass = "clickableChildDiv dataDiv";
	var selectedArea = "<div id='" + ThingName + "Area' class='mappedDiv' style='top:" + top + "px ; left:" + left + "px; height:" +
		height + "px; width:" + width +
		"px;'></div>";
	top = Number(top) + Number(height) + 15;
	var dataDiv = "<div id='" + ThingName + "' class='" + cssClass + "' style='top:" + top + "px; left:" + left +
		"px; border-color:" + borderColor + ";  box-shadow: " + boxShadow + ";  color: " + Color + "'>" + data + "</div>";
	callback(null, selectedArea + dataDiv);
});

var getChildConfiguration = deasync(function (Token, Hostname, Path, ThingName, coords, category, ThingDesc, callback) {
	var options = {
		hostname: Hostname,
		path: Path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error("getChildConfiguration error >> " + JSON.stringify(error));
		});
		res.on('end', function () {
			var dat = JSON.parse(body);
			var prpSetId;
			var uom, spanData = "",
				propertyElm = "";
			var count = 0;
			dat.propertySetTypes.forEach(function (eachPrpSet) {
				if (eachPrpSet.dataCategory == "TimeSeriesData") {
					prpSetId = eachPrpSet.name.toString().substring(eachPrpSet.name.toString().lastIndexOf(":") + 1, eachPrpSet.name.toString().length);
					eachPrpSet.propertyTypes.forEach(function (eachPrp) {
						if (eachPrp.value.unitOfMeasure != "" && eachPrp.value.unitOfMeasure != undefined) {
							uom = "(" + eachPrp.value.unitOfMeasure + ")";
						} else {
							uom = "";
						}
						if (count == 0) {
							propertyElm = eachPrp.value.id + uom;
							count++;
						} else {
							propertyElm = propertyElm + "<br>" + eachPrp.value.id + uom;
						}
					});
				}
			});
			spanData = spanData + getChildEqpDiv(coords, "<u>" + category + "</u><br><u>" + ThingDesc + "(" + ThingName + ")</u> :<br>" +
				propertyElm, ThingName);
			callback(null, {
				spanData: spanData
			});
		});
	});
	req.end();
});

var getDbDataWith2WhereClause = deasync(function (param1, param2, sqlQuery, cb) {
	var sql = sqlQuery;
	hdbext.createConnection(hanaConfig, function (error, client) {
		if (error) {
			console.error("getDbDataWith2WhereClause: error=" + JSON.stringify(error));
			return;
		}
		client.prepare(sql, function (err, statement) {
			if (err) {
				console.error("getDbDataWith2WhereClause: err=" + JSON.stringify(err));
				return;
			}
			statement.exec([param1, param2], function (er, results) {
				if (er) {
					console.error("getDbDataWith2WhereClause error " + JSON.stringify(er));
				} else {
					cb(null, results);
				}
			});
		});
	});
});

app.post('/getMappedCoordinates', function (req, res) {
	var Token = getToken();
	var Hostname = "appiot-mds.cfapps.eu10.hana.ondemand.com";
	var PackageName = req.body.PackageName;
	var ThingId = req.body.ThingId;
	var result = getDbDataWith2WhereClause(PackageName, ThingId,
		'select "ThingType", "Image" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingImage" where "PackageName"=? AND "ThingId"=?'
	);
	var thingConfigData;
	var spanData = "";
	var data = {},
		childEqpList = [],
		imgDiv = "";
	var prpResults = {
		records: []
	};
	var childEpqResults = {
		records: []
	};
	if (result.length > 0) {
		imgDiv = "<div style='position:relative'><img src='" + "data:image/jpg;base64," + result[0].Image + "'/>";
		var prpSetList = getDbDataWith2WhereClause(ThingId, result[0].ThingType,
			'select "PropertySet","Coordinates","Shape","DataPosition" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ImageTag" where "ThingId"=? and "ThingType"=?'
		);
		childEqpList = getDbDataWith2WhereClause(PackageName, ThingId,
			'select "ThingId","ThingName","Coordinates","ThingDesc" ,"ThingType" from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ChildThing" where "PackageName"=? AND "ParentThingId"=?'
		);
		try {
			async.each(childEqpList, function (eachRecord, callback) {
				var currentitem = childEqpList.indexOf(eachRecord);
				var category = "";
				var str1 = childEqpList[currentitem].ThingType.split("_")[0];
				var str2 = childEqpList[currentitem].ThingType.split("_")[1];
				if (str1 == undefined) category = str2;
				if (str2 == undefined) category = str1;
				if (str1 != undefined && str2 != undefined) category = str1 + "_" + str2;
				thingConfigData = getChildConfiguration(Token, Hostname, "/Things('" + childEqpList[currentitem].ThingId +
					"')/Configuration", childEqpList[currentitem].ThingName, childEqpList[currentitem].Coordinates, category, childEqpList[
						currentitem].ThingDesc);
				spanData = spanData + thingConfigData.spanData;
				callback(null);
			}, function (err) {
				if (err) {
					console.error('getMappedCoordinates something went wrong err===>>>' + JSON.stringify(err));
				}
			});
			var data;
			async.each(prpSetList, function (eachRecord, callback) {
				var currentitem = prpSetList.indexOf(eachRecord);
				var propertySet = prpSetList[currentitem].PropertySet;
				var coords = prpSetList[currentitem].Coordinates;
				var Shape = prpSetList[currentitem].Shape;
				var DataPosition = prpSetList[currentitem].DataPosition;
				var properties = getDbDataWith2WhereClause(ThingId, propertySet,
					'select * from "SustainableManufacturingAsset.SustainableManufacturingAsset_DB.Tables::ThingProperty"  where "ThingId"=? and "PropertySet"=?'
				);
				data = {
					PropertySet: propertySet,
					coords: coords,
					Property: properties
				}
				prpResults.records.push(data);
				var propertyElm = "",
					uom;
				for (var i in properties) {
					if (properties[i].UOM != "" && properties[i].UOM != undefined) {
						uom = "(" + properties[i].UOM + ")";
					} else {
						uom = "";
					}
					if (i == 0) {
						propertyElm = properties[i].Property + uom;
					} else {
						propertyElm = propertyElm + "<br>" + properties[i].Property + uom;
					}
				}
				spanData = spanData + getUsedCoordsStr(coords, "Property Set : " + propertySet + "<br>" + propertyElm,
					DataPosition);
				callback(null);
			}, function (err) {
				if (err) {
					console.error('getMappedCoordinates something went wrong err===>>>' + JSON.stringify(err));
				}
			});
			var result = JSON.stringify({
				prpRecords: prpResults,
				childEpqRecords: childEqpList,
				span: spanData + "</div>",
				imgDiv: imgDiv
			});
			return res.type("application/json").status(202).send(result);
		} catch (error) {
			console.error('getMappedCoordinates error===>>>' + error);
			return res.type("application/json").status(500).send(error);
		}
	} else {
		var result = JSON.stringify({
			prpRecords: prpResults,
			childEpqRecords: childEqpList,
			span: spanData + "<div/>",
			imgDiv: imgDiv
		});
		return res.type("application/json").status(202).send(result);
	}
});
server.listen(soketPort);
io.of('/PTM_Socket').on('connection', (socket) => {
	console.log('New user connected ');
	socketObj = socket;
	socket.on('disconnect', () => {
		console.log('disconnected from user');
	});
});

/*var cronJob = cron.job("50 * * * * *", function () {
	console.log("cron job");
	if (socketObj != undefined) {
		console.log("cron job socketObj = ");
		var dt = new Date();
		var dateTime = dt.toISOString();
		socketObj.emit('RefreshImg', dateTime);
	}
});
cronJob.start();*/
/*****************************Sending message**********************/
app.get('/Confirmation', async function (req, res) {

	const workflowInstanceId = req.query.workflowInstanceId;

	const definitionId = req.query.definitionId;

	const config = {
		method: 'POST',
		url: '/v1/messages',
		headers: {
			"content-type": "application/json"
		},
		data: {
			"definitionId": definitionId,
			"workflowInstanceId": workflowInstanceId
		}
	}
	try {
		let resp = await WF_axios(config);
		var response = "Confirmation done successfully";
		return res.type("text/plain").status(202).send(response);
	} catch (error) {
		console.error('Link error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

/******* To Trigger WorkFlow *****************/
app.post('/WrokFlowTrigger', async function (req, res) {

	var config = {
		method: 'POST',
		url: '/v1/workflow-instances',
		headers: {
			"content-type": "application/json"
		},
		data: {
			"definitionId": "leadtoorderwf",
			"context": {
				"OpportunityID": 12892
			}
		}
	};
	try {
		let resp = await WF_axios(config);
		if (resp.status == 201) {
			return res.type("application/json").status(202).send({
				status: "success"
			});
		} else {
			return res.type("application/json").status(202).send({
				status: "failed"
			});
		}
	} catch (error) {
		console.error('error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

/************************ODATA service call to release MaintenanceOrder************/
app.post('/ReleaseMaintenanceOrder', async function (req, res) {
	var MaintenanceOrder = req.body.MaintenanceOrder;
	var Plant = req.body.Plant;
	var currentDate = new Date(new Date().toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0];
	var time = currentDate.split("T")[1];
	var Basicstart = "PT" + time.substring(0, 2) + "H" + time.substring(3, 5) + "M" + time.substring(6, 8) + "S";
	const config = {
		method: 'POST',
		url: '/sap/opu/odata/sap/ZGLB_DEVPM_MAINT_ORDER_SRV/MaintenaceOrderSet',
		headers: {
			"content-type": "application/json"
		},
		data: {
			"IvMmsrvExternalMaintence": "",
			"Methods": [{
				"Refnumber": "000001",
				"Objecttype": "HEADER",
				"Method": "RELEASE",
				"Objectkey": "00000" + MaintenanceOrder
			}, {
				"Refnumber": "000001",
				"Objecttype": "",
				"Method": "SAVE",
				"Objectkey": "00000" + MaintenanceOrder
			}],
			"Header": [{
				"Orderid": "00000" + MaintenanceOrder,
				"OrderType": "YBA1",
				"Planplant": Plant,
				"Plant": Plant,
				"Equipment": "",
				"StartDate": currentDate,
				"Basicstart": Basicstart, //need to check
				"ShortText": "",
				"NotifNo": ""
			}],
			"Operation": [],
			"Component": [],
			"Returns": []
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var Response = util.inspect(resp, false, null);
		var status = util.inspect(resp.status);
		var statusText = util.inspect(resp.statusText);
		var Message = util.inspect(resp.data.d.Returns.results[0].Message);
		var JSON_respdata = {
			"status": status,
			"statusText": statusText,
			"Message": Message
		};
		return res.type("application/json").status(202).send(JSON_respdata);
	} catch (error) {
		console.error('ReleaseMaintenanceOrder error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
/************************ODATA service call to retreive the cost based on MaintenanceOrder************/
app.post('/GetMaintenanceOrderWithCost', async function (req, res) {
	var MaintenanceOrder = req.body.MaintenanceOrder;
	var filterstring = '?$filter=(MaintenanceOrder eq \'' + MaintenanceOrder + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetMaintenanceOrderWithcost error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
/*************************NodeJS service to get the users***************************************/
app.get('/GetUserEmailId', async function (req, res) {
	var config = {
		method: 'GET',
		url: '/Users',
		headers: {
			"content-type": "application/json"
		}
	}
	try {
		let resp = await WF_Users_axios(config);
		var emailID_Array = [];
		for (var i = 0; i < resp.data.resources.length; i++) {
			var result = resp.data.resources[i].groups.some(function (item) {
				//return item.value === "PM_Supervisior";
				return item.value === "MaintenancePlanner";
			});
			if (result === true) {
				var emailIDs = resp.data.resources[i].emails[0].value;
				emailID_Array.push(emailIDs);
			}
		}
		return res.type("application/json").status(202).send(emailID_Array);
	} catch (error) {
		console.error('GetUser error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
/*************************NodeJS service to get the list of destinations***************************************/
app.get('/GetListOfDestinations', async function (req, res) {
	var config = {
		method: 'GET',
		url: '/destination-configuration/v1/subaccountDestinations',
		headers: {
			"content-type": "application/json"
		}
	}
	try {
		let resp = await WF_Destinations(config);
		var response = resp.data;
		var DestURL_Array = [];
		for (var i = 0; i < resp.data.length; i++) {
			if (resp.data[i].Name === "S4HANA_Destination") {
				var url = resp.data[i].URL;
				var DestURLJSON = {
					"Name": "S4HANA_Destination",
					"URL": url
				};
				DestURL_Array.push(DestURLJSON);
			}
			if (resp.data[i].Name === "NodeJS_ODATA_Service") {
				var url = resp.data[i].URL;
				var DestURLJSON = {
					"Name": "NodeJS_ODATA_Service",
					"URL": url
				};
				DestURL_Array.push(DestURLJSON);
			}
		}
		//return res.type("application/json").status(202).send(response);
		return res.type("application/json").status(202).send(DestURL_Array);
	} catch (error) {
		console.error('GetDestination error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
/****************Node JS to get the equipment Measure TimeSeries Data from PDMS *********************/
/*
{
    "Equipment": "100000000000000047"
}
*/
//app.post('/GetEquipmentMeasureTimeSeriesData', async function (req, res) {
var GetEquipmentMeasureTimeSeriesData = deasync(function (Equipment, callback) {
	var token = getPDMSTokenTS();
	var ACToken = getPDMSToken();
	//var Equipment = req.body.Equipment;
	var GetEquipmentID = GetEquipmentDetailsByName(Equipment, ACToken);
	var EquipmentID = GetEquipmentID.EquipmentId;
	var TemplateID = GetEquipmentID.TemplateId;
	var GetIndicatorGroupID = GetIndicatorsforTemplateID(TemplateID, ACToken);
	for (var a = 0; a < GetIndicatorGroupID[0].indicatorGroups.length; a++) {
		var indicatorGroupName = GetIndicatorGroupID[0].indicatorGroups[a].internalId;
		if (indicatorGroupName.includes("Anomaly")) {
			var IndicatorGroupID = GetIndicatorGroupID[0].indicatorGroups[a].id;
		} else {
			var IndicatorGroupID = GetIndicatorGroupID[0].indicatorGroups[a].id;
		}
	}
	//var IndicatorGroupID = GetIndicatorGroupID[0].indicatorGroups[1].id;
	var dt = new Date();
	var formatted_dt = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var toDt = formatted_dt + "T00:00:00Z";
	dt.setMonth(dt.getMonth() - 3);
	var formatted_dt2 = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var fromDt = formatted_dt2 + "T00:00:00Z";
	//fromDt = "2021-02-26T03:32:51Z";
	//toDt = "2021-02-28T13:32:51Z";
	var path = "/timeseries/api/v1/measurements/equipment/" + EquipmentID + "/template/" + TemplateID + "/indicatorGroup/" +
		IndicatorGroupID +
		"?from=" + fromDt + "&to=" + toDt;
	var options = {
		hostname: "pdms-poc-pdms.cfapps.eu10.hana.ondemand.com",
		path: path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + token
		}
	};
	var reqt = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error(error);
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			if (dat.length !== 0) {
				dat = JSON.parse(body);
				var top2 = dat.sort(function (a, b) {
						return a.time < b.time ? 1 : -1;
					})
					.slice(0, 2);
				var first_values = Object.values(top2[0]);
				var value1 = first_values[1];
				var second_values = Object.values(top2[1]);
				var value2 = second_values[1];
				var status;
				if (value1 > value2) {
					status = "Increased";
				} else {
					status = "Decreased";
				}
				var result = {
					"value": value1,
					"status": status
				};
			} else {
				var result = {
					"value": 0,
					"status": ""
				};
			}
			callback(null, result);
			//return res.type("application/json").status(200).send(result);
		});
	});
	reqt.end();
});

var getPDMSTokenTS = deasync(function (callback) {
	var options = {
		"method": "POST",
		"hostname": "admi-subaccount.authentication.eu10.hana.ondemand.com",
		//"hostname": "ibm-sapain.authentication.eu10.hana.ondemand.com",
		"port": null,
		"path": "/oauth/token",
		"headers": {
			"content-type": "application/x-www-form-urlencoded"
		}
	};
	var req = https.request(options, function (res) {
		var chunks = [];
		res.on("data", function (chunk) {
			chunks.push(chunk);
		});
		res.on("end", function () {
			var body = Buffer.concat(chunks);
			var tokenJson = JSON.parse(body);
			callback(null, tokenJson.access_token);
		});
	});
	req.write(qs.stringify({
		/*	client_id: 'sb-f8834d08-6828-4d73-b213-7968aa82aeb2!b28702|pdms_broker_poc!b428',
			client_secret: 'mnYt2MWC7b+VLkpGdOy4gcU3Q+s=',
			grant_type: 'client_credentials',
			response_type: 'token'*/
		'client_id': 'sb-f84bc6a5-6f86-4595-b1df-9c96f7af8b44!b11739|pdms_broker_poc!b428',
		'client_secret': 'DePTrpjRb3e4SdSuZLic9OGHtbE=',
		'grant_type': 'client_credentials',
		'response_type': 'token'
	}));
	req.end();
});

var getPDMSToken = deasync(function (callback) {
	var options = {
		"method": "POST",
		"hostname": "admi-subaccount.authentication.eu10.hana.ondemand.com",
		//"hostname": "ibm-sapain.authentication.eu10.hana.ondemand.com",
		"port": null,
		"path": "/oauth/token",
		"headers": {
			"content-type": "application/x-www-form-urlencoded"
		}
	};
	var req = https.request(options, function (res) {
		var chunks = [];
		res.on("data", function (chunk) {
			chunks.push(chunk);
		});
		res.on("end", function () {
			var body = Buffer.concat(chunks);
			var tokenJson = JSON.parse(body);
			callback(null, tokenJson.access_token);
		});
	});
	req.write(qs.stringify({
		/*client_id: 'sb-2dd5594f-53d2-481f-977f-6421df62392d!b28702|ac_broker_poc!b1537',
		client_secret: 'O5aAML4PyMM7ABwUn+uLv0M7ZaE=',
		grant_type: 'client_credentials',
		response_type: 'token'*/
		'client_id': 'sb-86c0ec15-72c2-47b1-8742-5031a73b4293!b11739|ac_broker_poc!b1537',
		'client_secret': 'YCF6UmKlAQqFuORvX+cFxyDC47s=',
		'grant_type': 'client_credentials',
		'response_type': 'token'
	}));
	req.end();
});
var GetEquipmentDetailsByName = deasync(function (Equipment, Token, callback) {
	//var Equipment = req.body.Equipment;
	//	var Token = getPDMSToken();
	var options = {
		hostname: "ac-poc.cfapps.eu10.hana.ondemand.com",
		path: "/services/api/v1/equipment?$filter=substringof('" + Equipment + "',name)",
		method: "GET",
		protocol: "https:",
		headers: {
			"content-type": "application/json",
			"Authorization": "Bearer " + Token
		}
	};
	var reqt = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error(error);
			//res.type("application/json").status(500).send(JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			//Code added for getting the equipment details only for 100000000000000047
			var arrayEquip = [];
			for (var i = 0; i < dat.length; i++) {
				var EquipName = dat[i].name;
				if (EquipName.includes(Equipment)) {
					arrayEquip.push(dat[i]);
				}
			}
			dat = arrayEquip;
			//Code ended
			var result = {
				"EquipmentId": dat[0].equipmentId,
				"TemplateId": dat[0].templateId
			};
			//EquipTemplateIDs.push(result);
			callback(null, result);
			//res.type("application/json").status(202).send(records);
		});
	});
	reqt.end();
});
var GetIndicatorsforTemplateID = deasync(function (TemplateID, Token, callback) {
	//var TemplateId = req.body.TemplateId;
	//var Token = getPDMSToken();
	var options = {
		hostname: "ac-poc.cfapps.eu10.hana.ondemand.com",
		path: "/services/api/v1/template(" + TemplateID + ")",
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};

	var requst = https.request(options, function (resp) {
		var body = '';
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error(error);
			//res.type("application/json").status(500).send(JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);

			callback(null, dat);
			//res.type("application/json").status(200).send(body);
		});
	});
	requst.end();
});
app.post('/GetOpenWorkOrdersListData', async function (req, res) {
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var equipment = req.body.Equipment;
	var fromdate = req.body.FromDate;
	var todate = req.body.ToDate;
	var EquipfilterString = "";
	if (Array.isArray(equipment) === true) {
		for (var i = 0; i < equipment.length; i++) {
			var String = "Equipment eq '" + equipment[i] + "'";
			if (i == equipment.length - 1) {
				//console.log("entered in if");
				EquipfilterString = EquipfilterString + String;
				//console.log("strg:::::"+strg);
			} else {
				//console.log("entered in else");
				EquipfilterString = EquipfilterString + String + "or ";
				//console.log("strg:::::"+strg);
			}
		}
		//console.log(EquipfilterString);
	} else {
		EquipfilterString = "Equipment eq '" + equipment + "'";
	}

	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and (' + EquipfilterString +
		') and MaintOrdSchedBasicStartDate gt datetime\'' + fromdate + '\' and MaintOrdSchedBasicStartDate lt datetime\'' +
		todate + '\')';

	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		var result = [];
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;

			var dataString = data[i].ConcatenatedActiveSystStsName;
			if (dataString.includes('TECO') === false) {
				//console.log("entered in if");
				result.push(data[i]);
			}
		}
		data = result;
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
	} catch (error) {
		console.error('GetOpenWorkOrdersListData error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
app.post('/GetPMWorkOrdersDueListData', async function (req, res) {
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var equipment = req.body.Equipment;
	var fromdate = req.body.FromDate;
	var todate = req.body.ToDate;
	var EquipfilterString = "";
	if (Array.isArray(equipment) === true) {
		for (var i = 0; i < equipment.length; i++) {
			var String = "Equipment eq '" + equipment[i] + "'";
			if (i == equipment.length - 1) {
				//console.log("entered in if");
				EquipfilterString = EquipfilterString + String;
				//console.log("strg:::::"+strg);
			} else {
				//console.log("entered in else");
				EquipfilterString = EquipfilterString + String + "or ";
				//console.log("strg:::::"+strg);
			}
		}
		//console.log(EquipfilterString);
	} else {
		EquipfilterString = "Equipment eq '" + equipment + "'";
	}
	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and (' + EquipfilterString +
		') and MaintOrdSchedBasicStartDate gt datetime\'' + todate + '\')';

	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;
		}
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetPMWorkOrdersDueListData error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
app.post('/GetWOHistoryListData', async function (req, res) {
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var equipment = req.body.Equipment;
	var fromdate = req.body.FromDate;
	var todate = req.body.ToDate;
	var filterString = "";
	if (Array.isArray(equipment) === true) {
		for (var i = 0; i < equipment.length; i++) {
			var String = "Equipment eq '" + equipment[i] + "'";
			if (i == equipment.length - 1) {
				//console.log("entered in if");
				filterString = filterString + String;
				//console.log("strg:::::"+strg);
			} else {
				//console.log("entered in else");
				filterString = filterString + String + "or ";
				//console.log("strg:::::"+strg);
			}
		}
		//console.log(filterString);
	} else {
		filterString = "Equipment eq '" + equipment + "'";
	}
	/*var date = new Date(currentdate); //converts the string into date object
	var yesterdayDate = new Date(date.setDate(date.getDate() - 1));
	var previousMonthDate = new Date(date.setMonth(date.getMonth() - 1));
	previousMonthDate = previousMonthDate.toISOString().slice(0, 19);
	yesterdayDate = yesterdayDate.toISOString().slice(0, 19);*/

	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and (' + filterString +
		') and MaintOrdBasicEndDate gt datetime\'' + fromdate + '\' and MaintOrdBasicEndDate lt datetime\'' + todate + '\' )';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;
		}
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetMaintenanceHistoryForFunctLoc error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
app.post('/GetNotificationListData', async function (req, res) {
	var equipment = req.body.equipment;
	var FromDate = req.body.FromDate;
	var ToDate = req.body.ToDate;
	//	console.log(FromDate);
	var filterString = "";
	if (Array.isArray(equipment) === true) {
		for (var i = 0; i < equipment.length; i++) {
			var String = "Equipment eq '" + equipment[i] + "'";
			if (i == equipment.length - 1) {
				//console.log("entered in if");
				filterString = filterString + String;
				//console.log("strg:::::"+strg);
			} else {
				//console.log("entered in else");
				filterString = filterString + String + "or ";
				//console.log("strg:::::"+strg);
			}
		}
		//console.log(filterString);
	} else {
		filterString = "Equipment eq '" + equipment + "'";
	}
	/*if ((FromDate === "" || FromDate === undefined) || (ToDate === "" || ToDate === undefined)) {
		//24hrs date change
		var dt = new Date();
		var formatted_dt = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
		var toDate = formatted_dt + "T00:00:00";
		dt.setDate(dt.getDate() - 1);
		var formatted_dt2 = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
		fromDate = formatted_dt2 + "T00:00:00";
		console.log(toDate + "---------" + fromDate);
	} else {
		//selected date change
		fromDate = FromDate
	}*/

	var url = '/sap/opu/odata/sap/CB_EQUIPMENT_SRV/MaintenanceNotifications?$filter=((' + filterString +
		') and NotifProcessingPhase eq \'1\' and NotificationCreationDate  gt datetime\'' + FromDate + '\')';
	const config = {
		method: 'GET',
		url: url,
		headers: {
			"content-type": "application/json"
		},
	}
	try {
		let resp = await axios(config);
		var ms, time, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].NotificationCreationDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().split('.')[0].split("T")[0];
			time = data[i].MZEIT; // time in PT12H56M04S format 
			data[i].NotificationCreationDate = tempDate + " " + time.substring(2, 4) + ":" + time.substring(5, 7) + ":" + time.substring(8, 10);
		}
		data.sort(function (a, b) {
			return a.MaintenanceNotification.localeCompare(b.MaintenanceNotification);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
	} catch (error) {
		console.error('GetNotificationListData error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/GetNotificationListForFunctionalLocation', async function (req, res) {
	var equipment = req.body.equipment;
	//console.log(equipment);
	var filterString = "";
	for (var i = 0; i < equipment.length; i++) {
		var String = "Equipment eq '" + equipment[i] + "'";
		if (i == equipment.length - 1) {
			//console.log("entered in if");
			filterString = filterString + String;
			//console.log("strg:::::"+strg);
		} else {
			//console.log("entered in else");
			filterString = filterString + String + "or ";
			//console.log("strg:::::"+strg);
		}
	}
	//console.log(filterString);

	//fetching data for last 1 week
	var dt = new Date();
	var formatted_dt = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var toDate = formatted_dt + "T00:00:00";
	dt.setDate(dt.getDate() - 1);
	var formatted_dt2 = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var fromDate = formatted_dt2 + "T00:00:00";
	//console.log(fromDate);
	var url = '/sap/opu/odata/sap/CB_EQUIPMENT_SRV/MaintenanceNotifications?$filter=((' + filterString +
		') and NotifProcessingPhase eq \'1\' and NotificationCreationDate  gt datetime\'' + fromDate + '\')';
	//console.log(url);
	const config = {
		method: 'GET',
		url: url,
		headers: {
			"content-type": "application/json"
		},
	}
	try {
		let resp = await axios(config);
		var ms, time, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].NotificationCreationDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().split('.')[0].split("T")[0];
			time = data[i].MZEIT; // time in PT12H56M04S format 
			data[i].NotificationCreationDate = tempDate + " " + time.substring(2, 4) + ":" + time.substring(5, 7) + ":" + time.substring(8, 10);
		}
		data.sort(function (a, b) {
			return a.MaintenanceNotification.localeCompare(b.MaintenanceNotification);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
	} catch (error) {
		console.error('GetNotificationListForFunctionalLocation error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
app.post('/GetMaintenanceHistoryForFunctLoc', async function (req, res) {
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var equipment = req.body.Equipment;
	var currentdate = req.body.currentDate;
	var filterString = "";
	for (var i = 0; i < equipment.length; i++) {
		var String = "Equipment eq '" + equipment[i] + "'";
		if (i == equipment.length - 1) {
			//console.log("entered in if");
			filterString = filterString + String;
			//console.log("strg:::::"+strg);
		} else {
			//console.log("entered in else");
			filterString = filterString + String + "or ";
			//console.log("strg:::::"+strg);
		}
	}
	//console.log(filterString);
	var date = new Date(currentdate); //converts the string into date object
	var yesterdayDate = new Date(date.setDate(date.getDate() - 1));
	var previousMonthDate = new Date(date.setMonth(date.getMonth() - 1));
	previousMonthDate = previousMonthDate.toISOString().slice(0, 19);
	yesterdayDate = yesterdayDate.toISOString().slice(0, 19);

	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and (' + filterString +
		') and MaintOrdBasicEndDate gt datetime\'' + previousMonthDate + '\' and MaintOrdBasicEndDate lt datetime\'' + yesterdayDate + '\' )';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;
		}
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetMaintenanceHistoryForFunctLoc error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
app.post('/GetOpenWorkOrdersCountForFL', async function (req, res) {
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var Equipment = req.body.Equipment;
	var currentdate = req.body.currentDate;
	var date = new Date(currentdate); //converts the string into date object
	var previousMonthDate = new Date(date.setMonth(date.getMonth() - 6));
	previousMonthDate = previousMonthDate.toISOString().slice(0, 19);
	var EquipfilterString = "";
	for (var i = 0; i < Equipment.length; i++) {
		var String = "Equipment eq '" + Equipment[i] + "'";
		if (i == Equipment.length - 1) {
			//console.log("entered in if");
			EquipfilterString = EquipfilterString + String;
			//console.log("strg:::::"+strg);
		} else {
			//console.log("entered in else");
			EquipfilterString = EquipfilterString + String + "or ";
			//console.log("strg:::::"+strg);
		}
	}
	//console.log(EquipfilterString);
	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and (' + EquipfilterString +
		') and MaintOrdSchedBasicStartDate gt datetime\'' + previousMonthDate + '\' and MaintOrdSchedBasicStartDate lt datetime\'' +
		currentdate + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		var result = [];
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;

			var dataString = data[i].ConcatenatedActiveSystStsName;
			if (dataString.includes('TECO') === false) {
				//console.log("entered in if");
				result.push(data[i]);
			}
		}
		data = result;
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetOpenWorkOrdersCountForFL error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
app.post('/GetPMWorkOrdersDueCountForFL', async function (req, res) {
	var MaintenanceOrderType = req.body.MaintenanceOrderType;
	var Equipment = req.body.Equipment;
	var currentdate = req.body.currentDate;
	var EquipfilterString = "";
	for (var i = 0; i < Equipment.length; i++) {
		var String = "Equipment eq '" + Equipment[i] + "'";
		if (i == Equipment.length - 1) {
			//console.log("entered in if");
			EquipfilterString = EquipfilterString + String;
			//console.log("strg:::::"+strg);
		} else {
			//console.log("entered in else");
			EquipfilterString = EquipfilterString + String + "or ";
			//console.log("strg:::::"+strg);
		}
	}
	//console.log(EquipfilterString);
	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and (' + EquipfilterString +
		') and MaintOrdSchedBasicStartDate gt datetime\'' + currentdate + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;
		}
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetPMWorkOrdersDueCountForFL error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/GetOpenWorkOrdersCount', async function (req, res) {
	var MaintenanceOrderType = "YBA2";
	var Equipment = req.body.Equipment;
	var currentdate = req.body.currentDate;
	var date = new Date(currentdate); //converts the string into date object
	var previousMonthDate = new Date(date.setMonth(date.getMonth() - 6));
	previousMonthDate = previousMonthDate.toISOString().slice(0, 19);
	/*var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and Equipment eq \'' + Equipment +
		'\' and CreationDate gt datetime\'' + previousMonthDate + '\')'; */
	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and Equipment eq \'' + Equipment +
		'\' and MaintOrdSchedBasicStartDate gt datetime\'' + previousMonthDate + '\' and MaintOrdSchedBasicStartDate lt datetime\'' +
		currentdate + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		var result = [];
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;

			var dataString = data[i].ConcatenatedActiveSystStsName;
			if (dataString.includes('TECO') === false) {
				//console.log("entered in if");
				result.push(data[i]);
			}
		}
		data = result;
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetOpenWorkOrdersCount error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});
app.post('/GetPMWorkOrdersDueCount', async function (req, res) {
	var MaintenanceOrderType = "YBA2";
	var Equipment = req.body.Equipment;
	var currentdate = req.body.currentDate;
	/*var date = new Date(currentdate); //converts the string into date object
	var previousMonthDate = new Date(date.setMonth(date.getMonth() - 4));
	previousMonthDate = previousMonthDate.toISOString().slice(0, 19);*/
	/*var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and Equipment eq \'' + Equipment +
		'\' and CreationDate gt datetime\'' + previousMonthDate + '\')'; */
	var filterstring = '?$filter=(MaintenanceOrderType eq \'' + MaintenanceOrderType + '\' and Equipment eq \'' + Equipment +
		'\' and MaintOrdSchedBasicStartDate gt datetime\'' + currentdate + '\')';
	const config = {
		method: 'GET',
		url: '/sap/opu/odata/sap/EAM_OBJPG_MAINTENANCEORDER_SRV/C_ObjPgMaintOrder' + filterstring,
		headers: {
			"content-type": "application/json"
		},
		xsrfHeaderName: "x-csrf-token"
	}
	try {
		let resp = await axiosCSRF(config);
		var ms, tempDate, data = resp.data.d.results;
		for (var i in data) {
			ms = data[i].MaintOrdSchedBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdSchedBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicStartDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicStartDate = tempDate;

			ms = data[i].MaintOrdBasicEndDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().replace(/T/, ' ').replace(/\..+/, '');
			data[i].MaintOrdBasicEndDate = tempDate;
		}
		data.sort(function (a, b) {
			return b.MaintOrdSchedBasicStartDate.localeCompare(a.MaintOrdSchedBasicStartDate);
		});
		return res.type("application/json").status(202).send({
			results: data
		});
		//return res.type("application/json").status(202).send(resp.data.d);
	} catch (error) {
		console.error('GetPMWorkOrdersDueCount error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

app.post('/getThingData', async function (req, res) {
	console.log("1");
	var ThingId = req.body.ThingId;
	var PackageName = req.body.PackageName;
	var ThingType = req.body.ThingType;
	var propertySet = req.body.propertySet;
	var path = "/Things('" + ThingId + "')/" + PackageName + ":" + ThingType + "/" + propertySet +
		"?orderby=_time&timerange=1M&$top=1";
	var Token = getToken();
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var reqst = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error(error);
			return res.type("application/json").status(500).send(JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			return res.type("application/json").status(202).send(dat);
		});
	});
	reqst.end();
});
var getPDMSIotAEToken = deasync(function (callback) {
	var options = {
		"method": "POST",
		"hostname": "ibm-sapain.authentication.eu10.hana.ondemand.com",
		"port": null,
		"path": "/oauth/token",
		"headers": {
			"content-type": "application/x-www-form-urlencoded"
		}
	};
	var req = https.request(options, function (res) {
		var chunks = [];
		res.on("data", function (chunk) {
			chunks.push(chunk);
		});
		res.on("end", function () {
			var body = Buffer.concat(chunks);
			var tokenJson = JSON.parse(body);
			//console.log(tokenJson);
			callback(null, tokenJson.access_token);
		});
	});
	req.write(qs.stringify({
		client_id: 'sb-35e9f559-8d48-43e6-8be6-c56b5bf082c0!b28702|iotae_service!b5',
		client_secret: 'vIa9UUtOeCsQks2UPHEdY106pAc=',
		grant_type: 'client_credentials',
		response_type: 'token'
	}));
	req.end();
});

/******************** This Code is to test S4 connection only***********************/
app.post('/GetNotificationListTest', async function (req, res) {

	var url = '/sap/opu/odata/sap/CB_EQUIPMENT_SRV/MaintenanceNotifications';
	const config = {
		method: 'GET',
		url: url,
		headers: {
			"content-type": "application/json"
		},
	}
	try {
		let resp = await axios(config);
		var data = resp.data.d.results;

		return res.type("application/json").status(202).send({
			results: data
		});
	} catch (error) {
		console.error('GetNotificationListData error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

/****************** Post IoT Data to SAP EHS ****************************/
app.post('/PostToSAPEHS', async function (req, res) {

	var url = '/sap/opu/odata/sap/Z_ADC_IMPORT_SRV/$batch';
	var tagvalue = {
		"TagId": "DAILY CO2",
		"AmountTimestamp": "\/Date(1663331221070)\/",
		"AmountValue": "2200",
		"AmountUnit": "ppm",
		"FaultInd": "",
		"CalibrationInd": "X",
		"OutofprecisenessOperator": "",
		"NotavailableInd": "",
		"Remark": "TESTING44"
	};

	var data =
		'--batch\r\nContent-Type:multipart/mixed;boundary=changeset_1\r\n\r\n\r\n--changeset_1\r\nContent-Type:application/http\r\nContent-Transfer-Encoding:binary\r\n\r\n\r\nPOST ItAmountsSet HTTP/1.1\r\nContent-Type:application/json\r\n\r\n\r\n' +
		JSON.stringify(tagvalue) + '\r\n\r\n\r\n--changeset_1--\r\n--batch--';

	const config = {
		method: 'POST',
		url: url,

		headers: {
			"content-type": "multipart/mixed;boundary=batch"
		},
		xsrfHeaderName: "x-csrf-token",
		data: data
	};
	var resp;
	try {
		resp = await axiosCSRF(config);
		//	var  data = resp.data.d.results;
		return res.type("application/json").status(202).send({
			results: resp
		});
	} catch (error) {
		//console.log(resp);
		console.error('GetNotificationListData error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));

	}

});

/************************** Get Compliance Data From EHS *********************/
app.post('/GetComplianceFromSAPEHS', async function (req, res) {
	//var filter ="(  FUNCT_LOC_ID eq '1710-CKR-AA1' or  FUNCT_LOC_ID eq '33' ) and ( PLANT_ID eq '1710' ) and ( VALUETIMESTAMP ge datetime'2021-09-06T00:00:00'  or VALUETIMESTAMP le datetime'2021-09-30T00:00:00'   )";
	var filter = "?$filter=" + req.body.Filter;
	var url =
		"/sap/opu/odata/sap/Z_GET_COMPLAINCE_DATA_SRV/COMPLAINCE_DATASet" + filter;
	const config = {
		method: 'GET',
		url: url
	};
	var resp;
	try {
		resp = await axios(config);
		var data = resp.data.d.results;
		/*var jsonData = xml2json(data, {
			ignoreNameSpace: true
		});
		//console.log("jsonData " + jsonData);
		return res.type("application/json").status(202).send({
			results: JSON.stringify(jsonData)
		});*/
		/*xml2js.parseString(data, {
			explicitArray: false,
			ignoreAttrs: true,
			trim: true,
			tagNameProcessors: [stripNS]
		}, function (err, result) {
			//console.log("result",result);
			return res.type("application/json").status(202).send({
				results: JSON.stringify(result)
			});
		});*/
		return res.type("application/json").status(202).send({
			results: JSON.stringify(data)
		});
	} catch (error) {
		//	console.log(resp.status);
		if (resp.status == 200) {
			return res.type("application/json").status(200).send(JSON.stringify(resp.data));
		} else {
			console.error('GetNotificationListData error===>>>' + JSON.stringify(error));
			return res.type("application/json").status(500).send(JSON.stringify(error));
		}
	}
});

app.post('/PostDataInIotAEMultiple', async function (req, res) {
	var Token;
	var ThingID = req.body.ThingID;
	var Package = req.body.Package;
	if (Package.includes("admi")) {
		//console.log("includes admi");
		Token = getToken();
	} else if (Package.includes("sapain")) {
		//console.log("includes sapain");
		Token = getPDMSIotAEToken();
	}
	var ThingType = req.body.ThingType;
	var records = req.body.PropertySetRecords;
	for (var i = 0; i < records.length; i++) {
		var PropertySet = records[i].PropertySet;
		var Curret_datenow = new Date();
		//console.log(Curret_datenow);
		Curret_datenow.setSeconds(0, 0);
		//console.log(Curret_datenow);
		var UTC_Time = Curret_datenow.toISOString().replace(/.000Z/, "Z");
		//console.log(UTC_Time);
		var InputReq = records[i].InputReq;
		InputReq.value.forEach(function iter(a) {
			a._time = UTC_Time;
		});
		//console.log(JSON.stringify(InputReq));
		var options = {
			"method": "PUT",
			"hostname": "appiot-mds.cfapps.eu10.hana.ondemand.com",
			"path": "/Things('" + ThingID + "')/" + Package + ":" + ThingType + "/" + PropertySet,
			"headers": {
				"Authorization": "bearer " + Token,
				"Content-Type": "application/json"
			}
		};

		var reqst = https.request(options, function (resp) {
			var chunks = [];
			resp.on("data", function (chunk) {
				chunks.push(chunk);
			});
			resp.on("end", function (chunk) {
				var body = Buffer.concat(chunks);
				//console.log(body);
				/*var response = {
					"result": "Value posted successfully"
				};
				console.log(response);
				return res.type("application/json").status(200).send(response.result);*/
			});
			resp.on("error", function (error) {
				console.error(error);
				//return res.type("application/json").status(500).send(JSON.stringify(error));
			});
		});
		var postData = JSON.stringify(InputReq);
		//console.log(postData);
		/*for (var i = 0; i < InputReq[0].value.length; i++) {
			var postData = JSON.stringify(InputReq[0]);
			console.log(postData);
			reqst.write(postData);
		}*/
		reqst.write(postData);
		reqst.end();
	}
	return res.type("text/plain").status(200).send("Values posted successfully");
});

//////////////////// Swati - changes start 

var getPropertySet = deasync(function (Token, Hostname, Path, PropertySet, callback) {
	var options = {
		hostname: Hostname,
		path: Path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error("getThingPropertySet error >> " + JSON.stringify(error));
		});
		res.on('end', function () {
			var dat = JSON.parse(body);
			var prpSetId, property, prpSet;
			var result = {
				PropertySet: []
			};
			dat.propertySetTypes.forEach(function (eachPrpSet) {
				var propertyGrp = [];
				if (eachPrpSet.dataCategory == "TimeSeriesData") {
					prpSetId = eachPrpSet.name.toString().substring(eachPrpSet.name.toString().lastIndexOf(":") + 1, eachPrpSet.name.toString().length);
					if (prpSetId.toUpperCase().indexOf(PropertySet) != -1) {
						eachPrpSet.propertyTypes.forEach(function (eachPrp) {
							property = {
								Name: eachPrp.value.id,
								UOM: eachPrp.value.unitOfMeasure
							};
							propertyGrp.push(property);
						});
						prpSet = {
							Name: prpSetId,
							Property: propertyGrp
						};
						result.PropertySet.push(prpSet);
					}
				}
			});
			callback(null, result);
		});
	});
	req.end();
});

app.post('/GetAvgDataForPlant', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PropertySet = req.body.PropertySet;
	var filter = "?$filter=startswith(_thingType,'" + PackageName + ":FunctionLocation')";
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: "/Things" + filter,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token //req.body.InputRequest.token
		}
	};
	var result = {
		value: []
	};
	var thingData, uom;
	var mergedArray = [];
	var req = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error("getPropertySet error >> " + JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			var thingPropertySet;
			dat.value.forEach(function (eachThing) {
				thingPropertySet = getPropertySet(Token, "appiot-mds.cfapps.eu10.hana.ondemand.com", "/Things('" + eachThing._id +
					"')/Configuration", PropertySet);
				//	console.log(eachThing._id + "-", JSON.stringify(thingPropertySet));
				if (thingPropertySet.PropertySet.length > 0) {
					thingPropertySet.PropertySet.forEach(function (eachPropertySet) {
						thingData = getThingData(Token,
							"/Things('" + eachThing._id + "')/" + eachThing._thingType + "/" + eachPropertySet.Name +
							"?orderby=_time&timerange=" + fromDateTime + "-" + toDateTime);
						//	console.log("thingData", thingData);
						if (thingData.value.length > 0) {
							mergedArray = [...mergedArray, ...thingData.value];
						}
						eachPropertySet.Property.forEach(function (eachProperty) {
							uom = eachProperty.UOM
						});
					});
				}
			});
			//	console.log("mergedArray", JSON.stringify(mergedArray));
			var avg = Array.from(mergedArray.reduce(
					(acc, obj) => Object.keys(obj).reduce(
						(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
						acc),
					new Map()),
				([name, values]) =>
				({
					name,
					average: Math.round((values.reduce((a, b) => a + b) / values.length) * 100) / 100,
				})
			);
			avg.map(i => i.uom = uom);
			res.type("application/json").status(200).send(JSON.stringify(avg));
			//	console.log("avg", avg);

		});
	});
	req.end();
});

app.post('/GetDataForPlantFLWise', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PropertySet = req.body.PropertySet;
	var filter = "?$filter=startswith(_thingType,'" + PackageName + ":FunctionLocation')";
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: "/Things" + filter,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token //req.body.InputRequest.token
		}
	};
	var result = {
		PropertyWise: [],
		PrpFLWise: []
	};
	var thingData, uom, thingPrpSumSet;
	var mergedArray = [],
		mergedArraybyThing = [];
	var req = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error("GetDataForPlantFLWise error >> " + JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			var thingPropertySet, arr, arrSumByThingProp;
			dat.value.forEach(function (eachThing) {
				mergedArraybyThing = [];
				thingPropertySet = getPropertySet(Token, "appiot-mds.cfapps.eu10.hana.ondemand.com", "/Things('" + eachThing._id +
					"')/Configuration", PropertySet);
				//console.log('Test1',JSON.stringify(thingPropertySet));
				if (thingPropertySet.PropertySet.length > 0) {
					thingPropertySet.PropertySet.forEach(function (eachPropertySet) {
						thingData = getThingData(Token,
							"/Things('" + eachThing._id + "')/" + eachThing._thingType + "/" + eachPropertySet.Name +
							"?orderby=_time&timerange=" + fromDateTime + "-" + toDateTime);
						//	console.log("Test2",eachThing._name + "  : " + JSON.stringify(thingData));
						//merge data based on thing name
						if (thingData.value.length > 0) {
							mergedArraybyThing = [...mergedArraybyThing, ...thingData.value];
						}
						//sum all the values of the given thing
						arr = Array.from(thingData.value.reduce(
								(acc, obj) => Object.keys(obj).reduce(
									(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
									acc),
								new Map()),
							([name, values]) =>
							({
								name: eachThing._name,
								property: name,
								total: Math.round((values.reduce((a, b) => a + b)) * 100) / 100
									//total: values.reduce((a, b) => a + b)
							})
						);
						//console.log("arr " + JSON.stringify(arr));
						//merge the summed up data 
						if (thingData.value.length > 0) {
							mergedArray = [...mergedArray, ...arr];
						}
						//get uom
						eachPropertySet.Property.forEach(function (eachProperty) {
							uom = eachProperty.UOM
						});
					});
				}
				//	console.log("Test3 " + eachThing._name + " : " + JSON.stringify(mergedArraybyThing));
				//sum values based on property & thing
				arrSumByThingProp = Array.from(mergedArraybyThing.reduce(
						(acc, obj) => Object.keys(obj).reduce(
							(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
							acc),
						new Map()),
					([name, values]) =>
					({
						ThingName: eachThing._name,
						name,
						total: Math.round((values.reduce((a, b) => a + b)) * 100) / 100
							//total: values.reduce((a, b) => a + b)
					})
				);
				arrSumByThingProp.map(i => i.uom = uom);
				if (arrSumByThingProp.length > 0) {
					thingPrpSumSet = {
						ThingName: eachThing._name,
						TotalEmission: arrSumByThingProp
					};
					result.PropertyWise.push(thingPrpSumSet);
				}
				//console.log("arrSumByThingProp " + eachThing._name + " : " + JSON.stringify(arrSumByThingProp));
			});
			//console.log(JSON.stringify(mergedArray));
			mergedArray.map(i => i.uom = uom);
			result.PrpFLWise = mergedArray;
			// first, convert data into a Map with reduce
			let counts = mergedArray.reduce((prev, curr) => {
				let count = prev.get(curr.name) || 0;
				prev.set(curr.name, curr.total + count);
				return prev;
			}, new Map());
			// then, map your counts object back to an array
			let reducedObjArr = [...counts].map(([name, total]) => {
				return {
					name,
					total
				}
			});
			reducedObjArr.map(i => i.uom = uom);
			result.FLWise = reducedObjArr;
			try {
				let arrSum = reducedObjArr.reduce((a, c) => ({
					total: a.total + c.total
				}));
				arrSum.uom = uom;
				result.PlantWise = arrSum;
			} catch (err) {}

			res.type("application/json").status(200).send(JSON.stringify(result));
		});
	});
	req.end();
});
/******************** This Code is to get notification for plant***********************/
app.post('/GetNotificationListForPlant', async function (req, res) {
	//var url = '/sap/opu/odata/sap/CB_EQUIPMENT_SRV/MaintenanceNotifications';
	/*var dt = new Date();
	var formatted_dt = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var toDate = formatted_dt + "T00:00:00";
	dt.setDate(dt.getDate() - 1);
	var formatted_dt2 = new Date(dt.toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].split('T')[0];
	var fromDate = formatted_dt2 + "T00:00:00";*/
	var url = '/sap/opu/odata/sap/CB_EQUIPMENT_SRV/MaintenanceNotifications?$filter=(MaintenancePlant eq \'' + req.body.Plant +
		'\' and  NotifProcessingPhase eq \'1\' )';
	//and NotificationCreationDate  gt datetime\'' + fromDate + '\')';
	const config = {
		method: 'GET',
		url: url,
		headers: {
			"content-type": "application/json"
		},
	}
	try {
		let resp = await axios(config);
		var data = resp.data.d.results;
		return res.type("application/json").status(202).send({
			results: data
		});
	} catch (error) {
		console.error('GetNotificationListForPlant error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

/******************** This Code is to get total emission incidents***********************/
app.post('/GetTotalIncidents', async function (req, res) {
	var url =
		"/sap/opu/odata/sap/Z_EHS_GET_INCIDENTS_SRV/A_Incident?$filter=" +
		req.body.Filter + " and (INC_GROUP eq\ '" + req.body.INC_GROUP + "\') and (IncidentUTCDateTime ge datetime\'" + req.body.StartDate +
		"\'  or IncidentUTCDateTime le datetime\'" + req.body.EndDate + "\')";
	//console.log(url);
	const config = {
		method: 'GET',
		url: encodeURI(url),
		headers: {
			"content-type": "application/json"
		},
	}
	try {
		let resp = await axios(config);
		var data = resp.data.d.results;
		//console.log("Incidents", data);
		var count = data.reduce(function (sum, inc) {
			return sum + parseInt(inc.INCIDENT_COUNT);
		}, 0);
		//console.log("count", count);
		return res.type("application/json").status(202).send({
			Count: count
		});
	} catch (error) {
		console.error('GetNotificationListForPlant error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});


var getDMCToken = deasync(function (callback) {
	var options = {
		"method": "POST",
		"hostname": "admi-subaccount.authentication.eu10.hana.ondemand.com",
		//"hostname": "ibm-sapain.authentication.eu10.hana.ondemand.com",
		"port": null,
		"path": "/oauth/token",
		"headers": {
			"content-type": "application/x-www-form-urlencoded"
		}
	};
	var req = https.request(options, function (res) {
		var chunks = [];
		res.on("data", function (chunk) {
			chunks.push(chunk);
		});
		res.on("end", function () {
			var body = Buffer.concat(chunks);
			var tokenJson = JSON.parse(body);
			callback(null, tokenJson.access_token);
		});
	});
	req.write(qs.stringify({
		client_id: 'sb-7a81a798-121b-4b1c-97ac-dafb04c8a2bf!b11739|dmc-services-quality!b1334',
		client_secret: 'TOGHxLC9SbXIsuCTczl0GTKK3e4=',
		grant_type: 'client_credentials',
		response_type: 'token'
	}));
	req.end();
});

function getReleasedShopOrder(plant, user, startDateTime, endDateTime, token, callback) {
	var options = {
		hostname: 'api.test.eu10.dmc.cloud.sap',
		path: encodeURI("/reo/v1/shoporderschedules"),
		method: 'POST',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + token
		}
	};
	var body = JSON.stringify({
		"endDateTime": endDateTime,
		"plant": plant,
		"startDateTime": startDateTime,
		"user": user
	});
	var requst = https.request(options, function (resp) {
		var body = '';
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on('end', function () {
			var data = JSON.parse(body);
			var dataCount = Object.keys(data).length;
			if ((data.message == undefined) && (dataCount > 0)) {
				var uniqueOrderArray = data.reduce(function (a, d) {
					if (a.indexOf(d.shopOrder) === -1) {
						a.push(d.shopOrder);
					}
					return a;
				}, []);
				return callback(uniqueOrderArray);
			} else {
				return callback([]);
			}
		});
	});
	requst.write(body);
	requst.end();
}

var getShopOrderDetail = deasync(function (plant, order, token, callback) {
	var options = {
		hostname: 'api.test.eu10.dmc.cloud.sap',
		path: encodeURI("/order/v1/orders?order=" + order + "&plant=" + plant),
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + token
		}
	};
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error(error);
		});
		res.on('end', function () {
			var dat = JSON.parse(body);
			callback(null, dat);
		});
	});
	req.end();
});

app.post('/GetStockPlantwise', function (req, res) {
	//console.log("GetStockPlantwise");
	var token = getDMCToken();
	var startDateTime = req.body.startDateTime;
	var endDateTime = req.body.endDateTime;
	var plant = req.body.plant;
	var user = "supmalak@in.ibm.com"; //req.query.user;
	var orderList, orderDetail, totalProduction = 0,
		uom;
	getReleasedShopOrder(plant, user, startDateTime, endDateTime, token, function (results) {
		orderList = results;
		//console.log("orderList " + orderList);
		for (var i in orderList) {
			orderDetail = getShopOrderDetail(plant, orderList[i], token);
			//console.log("orderDetail " + JSON.stringify(orderDetail));
			totalProduction = totalProduction + orderDetail.doneQuantityInProductionUom;
			uom = orderDetail.erpUnitOfMeasure;
		}
		//console.log('totalProduction ' + totalProduction + " " + uom);
		var jsonResp = {
			totalProduction: totalProduction,
			uom: uom
		}
		return res.type("application/json").status(202).send(jsonResp);
	});
});

app.post('/GetTotalDataForPlant', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PropertySet = req.body.PropertySet;
	var filter = "?$filter=startswith(_thingType,'" + PackageName + ":FunctionLocation')";
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: "/Things" + filter,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token //req.body.InputRequest.token
		}
	};
	var result = {
		value: []
	};
	var thingData, uom;
	var mergedArray = [];
	var req = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error("GetAvgDataForPlant error >> " + JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			var thingPropertySet;
			dat.value.forEach(function (eachThing) {
				thingPropertySet = getPropertySet(Token, "appiot-mds.cfapps.eu10.hana.ondemand.com", "/Things('" + eachThing._id +
					"')/Configuration", PropertySet);
				//console.log(JSON.stringify(thingPropertySet));
				if (thingPropertySet.PropertySet.length > 0) {
					thingPropertySet.PropertySet.forEach(function (eachPropertySet) {
						thingData = getThingData(Token,
							"/Things('" + eachThing._id + "')/" + eachThing._thingType + "/" + eachPropertySet.Name +
							"?orderby=_time&timerange=" + fromDateTime + "-" + toDateTime);
						if (thingData.value.length > 0) {
							mergedArray = [...mergedArray, ...thingData.value];
						}
						eachPropertySet.Property.forEach(function (eachProperty) {
							uom = eachProperty.UOM
						});
					});
				}
			});
			//console.log("mergedArray ", JSON.stringify(mergedArray));
			var avg = Array.from(mergedArray.reduce(
					(acc, obj) => Object.keys(obj).reduce(
						(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
						acc),
					new Map()),
				([name, values]) =>
				({
					name,
					total: Math.round((values.reduce((a, b) => a + b)) * 100) / 100
						//total: values.reduce((a, b) => a + b)
				})
			);
			res.type("application/json").status(200).send(JSON.stringify(avg));
		});
	});
	req.end();
});

app.post("/GetIoTAEMultiLevelHierarchyToMap_Test", function (req, res) {
	var Token = getToken();
	var Hostname = "appiot-mds.cfapps.eu10.hana.ondemand.com";
	var eqpData = {},
		eqpGrp = [],
		hrcGrp = [],
		thingArray = [],
		thingTypeId = "",
		thingType = "",
		thingPkg = "",
		thingPkgName = "",
		thingPkgDesc = "",
		hierarchyID = "",
		rootThingID = "",
		isSingleHierarchy = "",
		path = "",
		category = "",
		data = [],
		hierarchyElements, found, erp_wc = "",
		erp_wcDesc = "",
		icon = "",
		thingConfigData, str1, str2, thingNameData;
	var ParentThingID = "",
		ThingID = "",
		ThingType = "";
	const packageMap = new Map();
	var result = {
		children: [],
		Host: req.headers.host
	};
	var groupBy = function (xs, key) {
		return xs.reduce(function (rv, x) {
			(rv[x[key]] = rv[x[key]] || []).push(x);
			return rv;
		}, {});
	};
	var hierarchies = getThingHierarchy(Token, "/ThingHierarchy/v1/ThingHierarchies", "").feed.entry;
	//.log("hierarchies", JSON.stringify(hierarchies));
	//console.log("hierarchies", hierarchies.length);
	var packages = getPackages("config-package-sap.cfapps.eu10.hana.ondemand.com", Token, "/Package/v1/Packages");
	//console.log("packages", JSON.stringify(packages));
	var uniquePck = [];
	packages.forEach(function (pkg) {
		packageMap.set(pkg.content.properties.Name, pkg.content.properties.Description);
		uniquePck.push(pkg.content.properties.Name.substring(pkg.content.properties.Name.lastIndexOf(".") + 1));
	});
	//console.log("uniquePck", uniquePck);
	res.type("application/json").status(200).send(JSON.stringify(result));
});
//////////////////////////////////////////////////////////////////////////////////////////
app.post('/GetTotalDataForPlantOrThing', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PropertySet = req.body.PropertySet;
	var filter = req.body.filter;
	var path = encodeURI("/Things" + filter);
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token //req.body.InputRequest.token
		}
	};
	var result = {
		value: []
	};
	var thingData, uom;
	var mergedArray = [];
	var req = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error("GetAvgDataForPlant error >> " + JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			//console.log("dat", JSON.stringify(dat));
			var thingPropertySet;
			if (dat.value.length > 0) {
				dat.value.forEach(function (eachThing) {
					thingPropertySet = getPropertySet(Token, "appiot-mds.cfapps.eu10.hana.ondemand.com", "/Things('" + eachThing._id +
						"')/Configuration", PropertySet);
					//console.log(JSON.stringify(thingPropertySet));
					if (thingPropertySet.PropertySet.length > 0) {
						thingPropertySet.PropertySet.forEach(function (eachPropertySet) {
							thingData = getThingData(Token,
								"/Things('" + eachThing._id + "')/" + eachThing._thingType + "/" + eachPropertySet.Name +
								"?orderby=_time&timerange=" + fromDateTime + "-" + toDateTime);
							if (thingData.value.length > 0) {
								mergedArray = [...mergedArray, ...thingData.value];
							}
							eachPropertySet.Property.forEach(function (eachProperty) {
								uom = eachProperty.UOM
							});
						});
					}
				});
			}
			//console.log("mergedArray ", JSON.stringify(mergedArray));
			var total = Array.from(mergedArray.reduce(
					(acc, obj) => Object.keys(obj).reduce(
						(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
						acc),
					new Map()),
				([name, values]) =>
				({
					name,
					total: Math.round((values.reduce((a, b) => a + b)) * 100) / 100
						//total: values.reduce((a, b) => a + b)
				})
			);
			total.map(i => i.uom = uom);
			res.type("application/json").status(200).send(JSON.stringify(total));
		});
	});
	req.end();
});

app.post('/GetAvgDataForPlantOrThing', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PropertySet = req.body.PropertySet;
	var filter = req.body.filter;
	var path = encodeURI("/Things" + filter);
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token //req.body.InputRequest.token
		}
	};
	var result = {
		value: []
	};
	var thingData, uom;
	var mergedArray = [];
	var req = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error("getPropertySet error >> " + JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			var thingPropertySet;
			dat.value.forEach(function (eachThing) {
				thingPropertySet = getPropertySet(Token, "appiot-mds.cfapps.eu10.hana.ondemand.com", "/Things('" + eachThing._id +
					"')/Configuration", PropertySet);
				//console.log(eachThing._id + "-", JSON.stringify(thingPropertySet));
				if (thingPropertySet.PropertySet.length > 0) {
					thingPropertySet.PropertySet.forEach(function (eachPropertySet) {
						thingData = getThingData(Token,
							"/Things('" + eachThing._id + "')/" + eachThing._thingType + "/" + eachPropertySet.Name +
							"?orderby=_time&timerange=" + fromDateTime + "-" + toDateTime);
						//	console.log("thingData", thingData);
						if (thingData.value.length > 0) {
							mergedArray = [...mergedArray, ...thingData.value];
						}
						eachPropertySet.Property.forEach(function (eachProperty) {
							uom = eachProperty.UOM
						});
					});
				}
			});
			//	console.log("mergedArray", JSON.stringify(mergedArray));
			var avg = Array.from(mergedArray.reduce(
					(acc, obj) => Object.keys(obj).reduce(
						(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
						acc),
					new Map()),
				([name, values]) =>
				({
					name,
					average: Math.round((values.reduce((a, b) => a + b) / values.length) * 100) / 100,
				})
			);
			avg.map(i => i.uom = uom);
			res.type("application/json").status(200).send(JSON.stringify(avg));
			//	console.log("avg", avg);

		});
	});
	req.end();
});
app.post('/GetDrillDownDataForPlantOrThing', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PropertySet = req.body.PropertySet;
	var filter = req.body.filter;
	var path = encodeURI("/Things" + filter);
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token //req.body.InputRequest.token
		}
	};
	var result = {
		PropertyWise: [],
		PrpFLWise: []
	};
	var thingData, uom, thingPrpSumSet;
	var mergedArray = [],
		mergedArraybyThing = [];
	var req = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error("GetDataForPlantFLWise error >> " + JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			var thingPropertySet, arr, arrSumByThingProp;
			dat.value.forEach(function (eachThing) {
				mergedArraybyThing = [];
				thingPropertySet = getPropertySet(Token, "appiot-mds.cfapps.eu10.hana.ondemand.com", "/Things('" + eachThing._id +
					"')/Configuration", PropertySet);
				//console.log('Test1',JSON.stringify(thingPropertySet));
				if (thingPropertySet.PropertySet.length > 0) {
					thingPropertySet.PropertySet.forEach(function (eachPropertySet) {
						thingData = getThingData(Token,
							"/Things('" + eachThing._id + "')/" + eachThing._thingType + "/" + eachPropertySet.Name +
							"?orderby=_time&timerange=" + fromDateTime + "-" + toDateTime);
						//	console.log("Test2",eachThing._name + "  : " + JSON.stringify(thingData));
						//merge data based on thing name
						if (thingData.value.length > 0) {
							mergedArraybyThing = [...mergedArraybyThing, ...thingData.value];
						}
						//sum all the values of the given thing
						arr = Array.from(thingData.value.reduce(
								(acc, obj) => Object.keys(obj).reduce(
									(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
									acc),
								new Map()),
							([name, values]) =>
							({
								name: eachThing._name,
								property: name,
								total: Math.round((values.reduce((a, b) => a + b)) * 100) / 100
									//total: values.reduce((a, b) => a + b)
							})
						);
						//console.log("arr " + JSON.stringify(arr));
						//merge the summed up data 
						if (thingData.value.length > 0) {
							mergedArray = [...mergedArray, ...arr];
						}
						//get uom
						eachPropertySet.Property.forEach(function (eachProperty) {
							uom = eachProperty.UOM
						});
					});
				}
				//	console.log("Test3 " + eachThing._name + " : " + JSON.stringify(mergedArraybyThing));
				//sum values based on property & thing
				arrSumByThingProp = Array.from(mergedArraybyThing.reduce(
						(acc, obj) => Object.keys(obj).reduce(
							(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
							acc),
						new Map()),
					([name, values]) =>
					({
						ThingName: eachThing._name,
						name,
						total: Math.round((values.reduce((a, b) => a + b)) * 100) / 100
							//total: values.reduce((a, b) => a + b)
					})
				);
				arrSumByThingProp.map(i => i.uom = uom);
				if (arrSumByThingProp.length > 0) {
					thingPrpSumSet = {
						ThingName: eachThing._name,
						TotalEmission: arrSumByThingProp
					};
					result.PropertyWise.push(thingPrpSumSet);
				}
				//console.log("arrSumByThingProp " + eachThing._name + " : " + JSON.stringify(arrSumByThingProp));
			});
			//console.log(JSON.stringify(mergedArray));
			mergedArray.map(i => i.uom = uom);
			result.PrpFLWise = mergedArray;
			// first, convert data into a Map with reduce
			let counts = mergedArray.reduce((prev, curr) => {
				let count = prev.get(curr.name) || 0;
				prev.set(curr.name, curr.total + count);
				return prev;
			}, new Map());
			// then, map your counts object back to an array
			let reducedObjArr = [...counts].map(([name, total]) => {
				return {
					name,
					total
				}
			});
			reducedObjArr.map(i => i.uom = uom);
			result.FLWise = reducedObjArr;
			try {
				let arrSum = reducedObjArr.reduce((a, c) => ({
					total: a.total + c.total
				}));
				arrSum.uom = uom;
				result.PlantWise = arrSum;
			} catch (err) {}

			res.type("application/json").status(200).send(JSON.stringify(result));
		});
	});
	req.end();
});

app.post('/GetDataForPlantFLWiseOrThing', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PropertySet = req.body.PropertySet;
	var filter = req.body.filter;
	var path = encodeURI("/Things" + filter);
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token //req.body.InputRequest.token
		}
	};
	var result = {
		PropertyWise: [],
		PrpFLWise: []
	};
	var thingData, uom, thingPrpSumSet;
	var mergedArray = [],
		mergedArraybyThing = [];
	var req = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error("GetDataForPlantFLWise error >> " + JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			var thingPropertySet, arr, arrSumByThingProp;
			dat.value.forEach(function (eachThing) {
				mergedArraybyThing = [];
				thingPropertySet = getPropertySet(Token, "appiot-mds.cfapps.eu10.hana.ondemand.com", "/Things('" + eachThing._id +
					"')/Configuration", PropertySet);
				//console.log('Test1',JSON.stringify(thingPropertySet));
				if (thingPropertySet.PropertySet.length > 0) {
					thingPropertySet.PropertySet.forEach(function (eachPropertySet) {
						thingData = getThingData(Token,
							"/Things('" + eachThing._id + "')/" + eachThing._thingType + "/" + eachPropertySet.Name +
							"?orderby=_time&timerange=" + fromDateTime + "-" + toDateTime);
						//	console.log("Test2",eachThing._name + "  : " + JSON.stringify(thingData));
						//merge data based on thing name
						if (thingData.value.length > 0) {
							mergedArraybyThing = [...mergedArraybyThing, ...thingData.value];
						}
						//sum all the values of the given thing
						arr = Array.from(thingData.value.reduce(
								(acc, obj) => Object.keys(obj).reduce(
									(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
									acc),
								new Map()),
							([name, values]) =>
							({
								name: eachThing._name,
								property: name,
								total: Math.round((values.reduce((a, b) => a + b)) * 100) / 100
									//total: values.reduce((a, b) => a + b)
							})
						);
						//console.log("arr " + JSON.stringify(arr));
						//merge the summed up data 
						if (thingData.value.length > 0) {
							mergedArray = [...mergedArray, ...arr];
						}
						//get uom
						eachPropertySet.Property.forEach(function (eachProperty) {
							uom = eachProperty.UOM
						});
					});
				}
				//	console.log("Test3 " + eachThing._name + " : " + JSON.stringify(mergedArraybyThing));
				//sum values based on property & thing
				arrSumByThingProp = Array.from(mergedArraybyThing.reduce(
						(acc, obj) => Object.keys(obj).reduce(
							(acc, key) => typeof obj[key] == "number" ? acc.set(key, (acc.get(key) || []).concat(obj[key])) : acc,
							acc),
						new Map()),
					([name, values]) =>
					({
						ThingName: eachThing._name,
						name,
						total: Math.round((values.reduce((a, b) => a + b)) * 100) / 100
							//total: values.reduce((a, b) => a + b)
					})
				);
				arrSumByThingProp.map(i => i.uom = uom);
				if (arrSumByThingProp.length > 0) {
					thingPrpSumSet = {
						ThingName: eachThing._name,
						TotalEmission: arrSumByThingProp
					};
					result.PropertyWise.push(thingPrpSumSet);
				}
				//console.log("arrSumByThingProp " + eachThing._name + " : " + JSON.stringify(arrSumByThingProp));
			});
			//console.log(JSON.stringify(mergedArray));
			mergedArray.map(i => i.uom = uom);
			result.PrpFLWise = mergedArray;
			// first, convert data into a Map with reduce
			let counts = mergedArray.reduce((prev, curr) => {
				let count = prev.get(curr.name) || 0;
				prev.set(curr.name, curr.total + count);
				return prev;
			}, new Map());
			// then, map your counts object back to an array
			let reducedObjArr = [...counts].map(([name, total]) => {
				return {
					name,
					total
				}
			});
			reducedObjArr.map(i => i.uom = uom);
			result.FLWise = reducedObjArr;
			try {
				let arrSum = reducedObjArr.reduce((a, c) => ({
					total: a.total + c.total
				}));
				arrSum.uom = uom;
				result.PlantWise = arrSum;
			} catch (err) {}

			res.type("application/json").status(200).send(JSON.stringify(result));
		});
	});
	req.end();
});

app.post('/GetNotificationListForFL', async function (req, res) {
	var equipment = req.body.equipment;
	var fromDate = req.body.FromDate;
	var toDate = req.body.ToDate;
	var filterString = "";
	for (var i = 0; i < equipment.length; i++) {
		var String = "Equipment eq '" + equipment[i] + "'";
		if (i == equipment.length - 1) {
			filterString = filterString + String;
		} else {
			filterString = filterString + String + "or ";
		}
	}
	var url = '/sap/opu/odata/sap/CB_EQUIPMENT_SRV/MaintenanceNotifications?$filter=((' + filterString +
		') and NotifProcessingPhase eq \'1\' and NotificationCreationDate  gt datetime\'' + fromDate + '\')';
	const config = {
		method: 'GET',
		url: url,
		headers: {
			"content-type": "application/json"
		},
	}
	try {
		let resp = await axios(config);
		var ms, time, tempDate, data = resp.data.d.results;
		/*for (var i in data) {
			ms = data[i].NotificationCreationDate.split("(")[1].split(")")[0];
			tempDate = new Date(Number(ms)).toISOString().split('.')[0].split("T")[0];
			time = data[i].MZEIT; // time in PT12H56M04S format 
			data[i].NotificationCreationDate = tempDate + " " + time.substring(2, 4) + ":" + time.substring(5, 7) + ":" + time.substring(8, 10);
		}
		data.sort(function (a, b) {
			return a.MaintenanceNotification.localeCompare(b.MaintenanceNotification);
		});*/
		return res.type("application/json").status(202).send({
			results: data
		});
	} catch (error) {
		console.error('GetNotificationList error===>>>' + JSON.stringify(error));
		return res.type("application/json").status(500).send(JSON.stringify(error));
	}
});

var getAllPropertySet = deasync(function (Token, Hostname, Path, PrpCat, callback) {
	var options = {
		hostname: Hostname,
		path: Path,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token
		}
	};
	var flag = (PrpCat == "") ? 0 : 1;
	var req = https.request(options, function (res) {
		var body = '';
		var chunks = [];
		res.on('data', function (chunk) {
			body += chunk;
		});
		res.on("error", function (error) {
			console.error("getThingPropertySet error >> " + JSON.stringify(error));
		});
		res.on('end', function () {
			var dat = JSON.parse(body);
			var prpSetId, property, prpSet;
			var result = {
				PropertySet: []
			};
			var propertyArr = [];
			dat.propertySetTypes.forEach(function (eachPrpSet) {
				if (eachPrpSet.dataCategory == "TimeSeriesData") {
					prpSetId = eachPrpSet.name.toString().substring(eachPrpSet.name.toString().lastIndexOf(":") + 1, eachPrpSet.name.toString().length);
					if (flag == 0) {
						eachPrpSet.propertyTypes.forEach(function (eachPrp) {
							property = {
								PropertySet: prpSetId,
								property: eachPrp.value.id,
								UOM: eachPrp.value.unitOfMeasure
							};
							result.PropertySet.push(property);
						});
					} else {
						if (prpSetId.toUpperCase().indexOf(PrpCat) != -1) {
							eachPrpSet.propertyTypes.forEach(function (eachPrp) {
								property = {
									PropertySet: prpSetId,
									property: eachPrp.value.id,
									UOM: eachPrp.value.unitOfMeasure
								};
								result.PropertySet.push(property);
							});
						}
					}
				}
			});
			callback(null, result);
		});
	});
	req.end();
});

app.post('/GetAllEmissionDataForPlantOrFlorThing', function (req, res) {
	var Token = getToken();
	var PackageName = req.body.PackageName;
	var fromDateTime = req.body.fromDateTime;
	var toDateTime = req.body.toDateTime;
	var PropertSetCat = req.body.PropertySet;
	var filter = req.body.Filter;
	//var filter = "?$filter=startswith(_thingType,'" + PackageName + ":FunctionLocation')";
	var urlPath = encodeURI("/Things" + filter);
	var options = {
		hostname: "appiot-mds.cfapps.eu10.hana.ondemand.com",
		path: urlPath,
		method: 'GET',
		protocol: 'https:',
		headers: {
			"content-type": "application/json",
			"authorization": "Bearer " + Token //req.body.InputRequest.token
		}
	};
	var thingData, uom;
	var mergedArray = [];
	var req = https.request(options, function (resp) {
		var body = '';
		var chunks = [];
		resp.on('data', function (chunk) {
			body += chunk;
		});
		resp.on("error", function (error) {
			console.error("GetAllThingDataForPlant error >> " + JSON.stringify(error));
		});
		resp.on('end', function () {
			var dat = JSON.parse(body);
			var thingPropertySet, prpSet = "",
				prpArr = [],
				uniquePrpSet;
			var properties;
			dat.value.forEach(function (eachThing) {
				prpSet = "";
				thingPropertySet = getAllPropertySet(Token, "appiot-mds.cfapps.eu10.hana.ondemand.com", "/Things('" + eachThing._id +
					"')/Configuration", PropertSetCat);
				uniquePrpSet = [...new Set(thingPropertySet.PropertySet.map(({
					PropertySet
				}) => PropertySet))];
				if (uniquePrpSet.length > 0) {
					uniquePrpSet.forEach(function (eachPropertySet) {
						if (prpSet != eachPropertySet) {
							thingData = getThingData(Token,
								"/Things('" + eachThing._id + "')/" + eachThing._thingType + "/" + eachPropertySet +
								"?orderby=_time&timerange=" + fromDateTime + "-" + toDateTime);
							//console.log(thingData);
							if (thingData.value && thingData.value.length > 0) {
								mergedArray = [...mergedArray, ...thingData.value];
								prpSet = eachPropertySet.PropertySet;
							}

						}
					});
					thingPropertySet.PropertySet.forEach(function (eachNode) {
						prpArr.push(eachNode.property);
						uom = eachNode.UOM;
					});
				}
			});
			let set = new Set();
			var unionArray = mergedArray.filter(item => {
				if (!set.has(item._time)) {
					set.add(item._time);
					return true;
				}
				return false;
			}, set);
			if (unionArray.length > 0) {
				unionArray.sort(function (a, b) {
					return a._time.localeCompare(b._time);
				});
			}
			var uniquePrpArr = [...new Set(prpArr)];
			/*result.value = unionArray;
			result.property = uniquePrpArr;*/
			res.type("application/json").status(200).send(JSON.stringify({
				value: unionArray,
				property: uniquePrpArr
			}));
		});
	});
	req.end();
});
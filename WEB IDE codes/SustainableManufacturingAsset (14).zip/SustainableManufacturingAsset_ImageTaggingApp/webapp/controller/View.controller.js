sap.ui.define([
	"sap/m/upload/Uploader",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/ui/core/BusyIndicator",
	"sap/m/MessageStrip",
	"sap/ui/core/mvc/Controller"
], function (Uploader, MessageBox, Fragment, BusyIndicator, MessageStrip, Controller) {
	"use strict";
	var oControllerThis, appView, imgType, reqBody, propertySet, prpSetSelected, tabBar, previewTab, editTab, ifImageEditorSet, dbImgBase64,
		tagDataPositionModel, positionDropdown, selectedPosition, mappedPropertyArr = [],
		ifContinueUpdt = 0,
		propertySetArr = [],
		isOtherPrpMapped = 0,
		isOtherChildMapped = 0,
		ifChangeImg = 0,
		oTree, treeModelData, aSelectedItems, childEqp, childEqpSelected, mappedChildArr = [];
	var Flag;
	return Controller.extend("ui_app.SustainableManufacturingAsset_ImageTaggingApp.controller.View", {
		onInit: function () {
			BusyIndicator.show(0);
			oControllerThis = this;
			appView = this.getView();

			tabBar = appView.byId("tabBar");
			previewTab = appView.byId("previewTab");
			editTab = appView.byId("editTab");

			/*tagDataPositionModel = new sap.ui.model.json.JSONModel({
				records: [{
					"value": "Left"
				}, {
					"value": "Right"
				}, {
					"value": "Top",
				},{
					"value": "Bottom"
				}]
			});
			positionDropdown = new sap.m.ComboBox("tagDataPositionCombobox", {
				selectionChange: function (oAction) {
					selectedPosition= oAction.getSource().getSelectedKey();
				},
				items: {
					path: "/records",
					template: new sap.ui.core.ListItem({
						key: "{value}",
						text: "{value}"
					})
				}
			});
			positionDropdown.setModel(tagDataPositionModel);*/
		},

		onAfterRendering: function () {
			//call the service to get the digital twin model
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/GetIoTAEMultiLevelHierarchyToMap",
				async: false,
				success: function (result) {
					treeModelData = new sap.ui.model.json.JSONModel(result);
					appView.byId("DigitalTwinTree").setModel(treeModelData);
					BusyIndicator.hide();
				},
				error: function (errorThrown) {
					console.error("GetIoTAEMultiLevelHierarchyToMap error " + JSON.stringify(errorThrown));
					BusyIndicator.hide();
					oControllerThis.showMsgStrip("Failed to load the Hierarchy. Please reload the dashboard.", "Error", "view");
				}
			});
		},

		onSelect: function () {
			oTree = appView.byId("DigitalTwinTree");
			aSelectedItems = oTree.getSelectedItem();
			if (aSelectedItems != null) {
				var category = aSelectedItems.getBindingContext().getProperty("Category");
				var thingID = aSelectedItems.getBindingContext().getProperty("ThingId");
				console.log(category + " thing id=" + aSelectedItems.getBindingContext().getProperty("ThingId"));
				//if selected item is a Thing in IoT then proceed
				if (thingID != undefined) {
					//make preview tab as default selection
					tabBar.setSelectedKey("previewTab");
					//reset the set ImageEditor flag
					ifImageEditorSet = 0;
					//if not a previous selected thingId then remove the image from image editor
					if (reqBody != undefined && aSelectedItems.getBindingContext().getProperty("ThingId") == reqBody.InputRequest.ThingId) {
						appView.byId("uploadedImg").setSrc("");
					}
					//enable the file uploader & save btn
					appView.byId("imgUploader").setEnabled(true);
					appView.byId("saveBtn").setEnabled(true);
					//set the propertySet of selected thingId 
					propertySet = aSelectedItems.getBindingContext().getProperty("PropertySet");
					childEqp = aSelectedItems.getBindingContext().getProperty("children");
					// set the reqBody for insert service
					reqBody = {
						InputRequest: {
							PackageName: aSelectedItems.getBindingContext().getProperty("ThingPkgName"),
							ThingId: aSelectedItems.getBindingContext().getProperty("ThingId"),
							ThingName: aSelectedItems.getBindingContext().getProperty("Name"),
							ThingDesc: aSelectedItems.getBindingContext().getProperty("ThingDesc"),
							ThingType: aSelectedItems.getBindingContext().getProperty("ThingType"),
							Category: category,
							ParentThingID: aSelectedItems.getBindingContext().getProperty("ParentThingID"),
							HierarchyID: aSelectedItems.getBindingContext().getProperty("HierarchyID"),
							RootThingID: aSelectedItems.getBindingContext().getProperty("RootThingID")
						}
					};
					//call this function to set the already tagged img in preview tab
					oControllerThis.getEquipmentTags();
				} else {
					appView.byId("imgUploader").setEnabled(false);
					appView.byId("saveBtn").setEnabled(false);
				}
			}
		},

		getEquipmentTags: function () {
			BusyIndicator.show(0);
			var dataJSON = {
				"PackageName": reqBody.InputRequest.PackageName,
				"ThingId": reqBody.InputRequest.ThingId
			};
			$.ajax({
				method: "POST",
				contentType: "application/json",
				url: "/node/getMappedCoordinates",
				data: JSON.stringify(dataJSON),
				async: false,
				success: function (result) {
					var pnl = appView.byId("panelForImgPreview");
					pnl.destroyContent();
					var htmlElm = new sap.ui.core.HTML();
					var content, iDelay = 0;
					if (result.imgDiv == "" || result.imgDiv == undefined) {
						content = "<div class='centerDiv'>No data found</div>";
						iDelay = 1000;
						ifImageEditorSet = 0;
						mappedPropertyArr = [];
						mappedChildArr = [];
					} else {
						dbImgBase64 = result.imgDiv.split("src='")[1].split("'/>")[0];
						content = result.imgDiv + result.span;
						iDelay = 2000;
						ifImageEditorSet = 1;
						mappedPropertyArr = result.prpRecords.records;
						mappedChildArr = result.childEpqRecords;
					}
					htmlElm.setContent(content);
					pnl.addContent(htmlElm);
					setTimeout(function () {
						BusyIndicator.hide();
						$(".clickableChildDiv").on("click", function (e) {
							e.preventDefault();
							var selectedThingName = e.currentTarget.attributes.id.nodeValue;
							oTree.expand(oTree.indexOfItem(aSelectedItems));
							var oNode = aSelectedItems.getBindingContext().getObject();
							if (oNode.children) {
								for (var i in oNode.children) {
									if (oNode.children[i].Name == selectedThingName) {
										oNode.children[i].selected = true;
										treeModelData.refresh();
										oTree.fireSelectionChange();
										break;
									}
								}
							}
						});
					}, iDelay);
				},
				error: function (errorThrown) {
					console.error("getMappedCoordinates error " + JSON.stringify(errorThrown));
					BusyIndicator.hide();
					oControllerThis.showMsgStrip("Failed to get Mapped Image. Please reload the dashboard.", "Error", "view");
				}
			});
		},

		onFileChange: function (oEvent) {
			var oFile = oEvent.getParameter("files")[0],
				oUploadedImg = appView.byId("uploadedImg");
			if (oFile) {
				imgType = oFile.type;
				if (/^image\//i.test(imgType)) {
					var oMs = sap.ui.getCore().byId("msgStrip");
					if (oMs) {
						oMs.destroy();
						appView.byId("oMsgLayoutView").setVisible(false);
					}
					console.log('valid image!');
					var reader = new FileReader();
					oUploadedImg.setVisible(true);
					reader.onloadend = function () {
						//set the src of image editor with uploaded image content 
						oUploadedImg.setSrc(reader.result);
						//set up the property set dialog
						oControllerThis.setUpDialog();
					}
					reader.readAsDataURL(oFile);
				} else {
					console.error('Not a valid image!');
					oControllerThis.showMsgStrip("Please upload a valid image.", "Error", "view");
				}
			} else {
				return;
			}
		},

		_getDialog: function () {
			if (!oControllerThis._oDialog) {
				oControllerThis._oDialog = sap.ui.xmlfragment("ui_app.SustainableManufacturingAsset_ImageTaggingApp.view.PropertySetDialog",
					appView.getController());
				oControllerThis.getView().addDependent(oControllerThis._oDialog);
			}
			return oControllerThis._oDialog;
		},

		setUpDialog: function () {
			//destroy the old content of the dialog
			oControllerThis._getDialog().destroyContent();
			oControllerThis._getDialog().open();
			var count = 0;
			var oRadioBtn, chkbox, lbl, rbPropertyTypeGr, rbAnomaly, rbPrediction, rbNormal;
			var allFBox = new sap.m.FlexBox({
				justifyContent: sap.m.FlexJustifyContent.Center
			});
			var allPrpFBox = new sap.m.FlexBox({
				direction: sap.m.FlexDirection.Column,
				alignItems: sap.m.FlexAlignItems.Center
			});
			//Start of changes to add radiobutton group to choose Property Type
			var allrbPrpTypeFBox = new sap.m.FlexBox({
				alignItems: sap.m.FlexAlignItems.Center,
				justifyContent: sap.m.FlexJustifyContent.Center
			});

			rbPropertyTypeGr = new sap.m.RadioButtonGroup({
				id: "RadioBtnGrpId",
				columns: 3,
				select: oControllerThis.onRadioBtnSelect
			});
			rbNormal = new sap.m.RadioButton({
				id: "idRBPrpTypeNormal",
				text: "Normal"
			});
			rbAnomaly = new sap.m.RadioButton({
				id: "idRBPrpTypeAnomaly",
				text: "Anomaly"
			});
			rbPrediction = new sap.m.RadioButton({
				id: "idRBPrpTypePrediction",
				text: "Prediction"
			});

			rbPropertyTypeGr.addButton(rbNormal);
			rbPropertyTypeGr.addButton(rbAnomaly);
			rbPropertyTypeGr.addButton(rbPrediction);

			allrbPrpTypeFBox.addItem(rbPropertyTypeGr);
			allPrpFBox.addItem(allrbPrpTypeFBox);
			allFBox.addItem(allPrpFBox);
			var oRadioGroup = sap.ui.getCore().byId("RadioBtnGrpId");

			var RadioBtnIndex = oRadioGroup.getSelectedIndex();
			if (RadioBtnIndex === 0) {
				Flag = "N";
			}
			//End of changes to add radiobutton group to choose Property Type

			var tempFBox = new sap.m.FlexBox({
				direction: sap.m.FlexDirection.Row
			});
			if (propertySet.length > 0) {
				//lbl for prp set
				lbl = new sap.m.Label({
					text: "Property Set & Property"
				});
				lbl.addStyleClass("customFont");
				allPrpFBox.addItem(lbl);
			}
			//iterate on the property sets of the selected thingId/eqpId
			for (var i in propertySet) {
				count = count + 1;
				//create a flex box with current property set as id
				var prpFBox = new sap.m.FlexBox({
					id: propertySet[i].Name,
					direction: sap.m.FlexDirection.Column
				});
				//create a radio with the current property set > add it in the flex box
				oRadioBtn = new sap.m.RadioButton({
					text: propertySet[i].Name,
					select: oControllerThis.onPropSetSelect
				});
				prpFBox.addItem(oRadioBtn);
				//get the properties of the current property set
				var property = propertySet[i].Property;
				//iterate on each property > create check box for each > add it in the flex box
				for (var j in property) {
					var txt;
					if (property[j].UOM != "" && property[j].UOM != undefined) {
						txt = property[j].Name + "(" + property[j].UOM + ")";
					} else {
						txt = property[j].Name;
					}
					chkbox = new sap.m.CheckBox({
						text: txt,
						selected: false,
						enabled: false
					});
					prpFBox.addItem(chkbox);
				}
				//add the current property set flex box to main flex box
				//allPrpFBox.addItem(prpFBox);
				tempFBox.addItem(prpFBox);
			}
			/*selectedPosition = "";
			var flexbox = new sap.m.FlexBox({
				justifyContent: sap.m.FlexJustifyContent.Center
			});
			var lbl = new sap.m.Label({
				id:"posLbl",
				text: "Position",
				required: true
			});
			flexbox.addItem(lbl);
			flexbox.addItem(positionDropdown);*/
			allPrpFBox.addItem(tempFBox);
			var chldFBox = new sap.m.FlexBox({
				direction: sap.m.FlexDirection.Column
			});
			lbl = new sap.m.Label({
				text: "Child Thing/Equipment"
			});
			lbl.addStyleClass("customFont");
			chldFBox.addItem(lbl);
			for (var i in childEqp) {
				count = count + 1;
				oRadioBtn = new sap.m.RadioButton({
					text: childEqp[i].Name,
					select: oControllerThis.onChildSelect
				});
				chldFBox.addItem(oRadioBtn);
			}
			if (propertySet.length > 0) {
				allFBox.addItem(allPrpFBox);
			}
			if (childEqp != undefined && childEqp.length > 0) {
				allFBox.addItem(chldFBox);
			}
			//add the main flex box to the dialog
			var msfElm = new sap.ui.layout.VerticalLayout({
				id: "oMsgLayout",
				width: "100%",
				visible: false
			});
			oControllerThis._getDialog().addContent(msfElm);
			oControllerThis._getDialog().addContent(allFBox);
			if (count <= 4) {
				sap.ui.getCore().byId("MapFragment").setContentWidth("65%");
			} else {
				sap.ui.getCore().byId("MapFragment").setContentWidth("80%");
			}
		},

		//Start of function on select of Property Type Radio Button
		onRadioBtnSelect: function (oEvent) {
			var iIndex = oEvent.getParameter("selectedIndex");
			var oGroup = oEvent.getSource();
			console.log(iIndex);

			if (iIndex === 0) {
				Flag = "N";
			} else if (iIndex === 1) {
				Flag = "A";
			} else if (iIndex === 2) {
				Flag = "P";
			}
		},
		//End of function on select of Property Type Radio Button		

		onChildSelect: function (oEvent) {
			var oMs = sap.ui.getCore().byId("msgStrip");
			if (oMs) {
				oMs.destroy();
				sap.ui.getCore().byId("oMsgLayout").setVisible(false);
			}
			var isSelected = oEvent.getParameters().selected;
			var oRadioBtnId = oEvent.oSource.mProperties.text;
			if (isSelected == true) {
				prpSetSelected = "";
				propertySetArr = [];
				for (var i in childEqp) {
					if (childEqp[i].Name == oRadioBtnId) {
						childEqpSelected = {
							ThingId: childEqp[i].ThingId,
							ThingName: childEqp[i].Name,
							ThingDesc: childEqp[i].ThingDesc,
							ThingType: childEqp[i].ThingType,
							PackageName: childEqp[i].ThingPkg
						};
						break;
					}
				}
				isOtherChildMapped = 0;
				if (ifChangeImg == 0) {
					for (var j = 0; j < mappedChildArr.length; j++) {
						if (mappedChildArr[j].ThingName == oRadioBtnId) {
							oControllerThis.showMsgStrip("Selected child is already mapped.", "Information", "dailog");
							break;
						} else {
							isOtherChildMapped = 1;
						}
					}
				}
			}
		},
		onPropSetSelect: function (oEvent) {
			var oMs = sap.ui.getCore().byId("msgStrip");
			if (oMs) {
				oMs.destroy();
				sap.ui.getCore().byId("oMsgLayout").setVisible(false);
			}
			var isSelected = oEvent.getParameters().selected;
			var oRadioBtnId = oEvent.oSource.mProperties.text;
			var chkBox;
			//if the proeprty set is selected then enable the properties of that property set
			if (isSelected == true) {
				childEqpSelected = "";
				prpSetSelected = oRadioBtnId;
				for (var i = 1; i < sap.ui.getCore().byId(oRadioBtnId).getItems().length; i++) {
					chkBox = sap.ui.getCore().byId(oRadioBtnId).getItems()[i];
					chkBox.setEnabled(true);
					var prpName;
					if (chkBox.getText().includes("(")) {
						prpName = chkBox.getText().split("(")[0];
					} else {
						prpName = chkBox.getText()
					}
					isOtherPrpMapped = 0;
					if (ifChangeImg == 0) {
						for (var j = 0; j < mappedPropertyArr.length; j++) {
							if (mappedPropertyArr[j].PropertySet == prpSetSelected) {
								for (var k = 0; k < mappedPropertyArr[j].Property.length; k++) {
									if (mappedPropertyArr[j].Property[k].Property == prpName) {
										chkBox.setSelected(true);
										oControllerThis.showMsgStrip("Selected property is already mapped.", "Information", "dailog");
										break;
									}
								}
							} else {
								isOtherPrpMapped = 1;
							}
						}
					}
				}
			} else {
				//if the proeprty set is not selected then uncheck & disable the properties of that property set
				for (var i = 1; i < sap.ui.getCore().byId(oRadioBtnId).getItems().length; i++) {
					chkBox = sap.ui.getCore().byId(oRadioBtnId).getItems()[i];
					chkBox.setSelected(false);
					chkBox.setEnabled(false);
				}
			}
		},

		onPressConfirm: function () {
			if ((prpSetSelected == "" || prpSetSelected == undefined) && (childEqpSelected == "" || childEqpSelected == undefined)) {
				sap.m.MessageBox.error("Please select at least One Data to Map.");
			} else {
				ifContinueUpdt = 0;
				var flag = 0;
				for (var j = 0; j < mappedPropertyArr.length; j++) {
					if (mappedPropertyArr[j].PropertySet == prpSetSelected) {
						flag = 1;
						break;
					}
				}
				for (var k = 0; k < mappedChildArr.length; k++) {
					if (mappedChildArr[k].ThingName == childEqpSelected.ThingName) {
						flag = 1;
						break;
					}
				}
				if (flag == 1) {
					//check if the current property set is already mapped
					console.log("already mapped");
					sap.m.MessageBox.show("Selected Data is already mapped. Do you want to update the mapping?", {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: "WARNING",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.YES) {
								ifContinueUpdt = 1;
								if (prpSetSelected != "" && prpSetSelected != undefined) {
									oControllerThis.addSelectedPrpToReq(0);
								} else {
									oControllerThis.addSelectedChildEqp(0);
								}
							} else {
								ifContinueUpdt = 0;
								return;
							}
						}
					});
				} else {
					ifContinueUpdt = 0;
					if (prpSetSelected != "" && prpSetSelected != undefined) {
						oControllerThis.addSelectedPrpToReq(1);
					} else {
						oControllerThis.addSelectedChildEqp(1);
					}
				}
			}
		},

		addSelectedChildEqp: function (showConfirmMsg) {
			if (showConfirmMsg != 0) {
				sap.m.MessageBox.show("Do you want to save image tag at selected area?", {
					icon: sap.m.MessageBox.Icon.CONFIRMATION,
					title: "CONFIRMATION",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							oControllerThis._getDialog().close();
							//resize the crop area
							appView.byId("uploadedImg").setCropArea(2, 2, 130, 100);
						} else {
							ifContinueUpdt = 0;
						}
					}
				});
			} else {
				oControllerThis._getDialog().close();
				//resize the crop area
				appView.byId("uploadedImg").setCropArea(2, 2, 130, 100);
			}
		},
		addSelectedPrpToReq: function (showConfirmMsg) {
			var chkBox, selectedChkCount = 0,
				isSelected, txt, propertyName, propertUOM;
			var p = {},
				temp = {
					PropertySet: prpSetSelected,
					Property: []
				};
			//add selectd property set & properties to the request Body
			for (var i = 1; i < sap.ui.getCore().byId(prpSetSelected).getItems().length; i++) {
				chkBox = sap.ui.getCore().byId(prpSetSelected).getItems()[i];
				isSelected = chkBox.getSelected();
				if (isSelected == true) {
					txt = chkBox.getText();
					if (txt.includes("(")) {
						propertyName = txt.split("(")[0];
						propertUOM = txt.split("(")[1].split(")")[0];
					} else {
						propertyName = txt;
						propertUOM = "";
					}
					p = {
						Property: propertyName,
						UOM: propertUOM
					};
					temp.Property.push(p);
					selectedChkCount++;
				}
			}
			if (showConfirmMsg != 0) {
				if (selectedChkCount <= 0) {
					sap.m.MessageBox.error("Please select at least One Data to Map.");
				} else {
					sap.m.MessageBox.show("Do you want to save image tag at selected area?", {
						icon: sap.m.MessageBox.Icon.CONFIRMATION,
						title: "CONFIRMATION",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.YES) {
								propertySetArr = [];
								propertySetArr.push(temp);
								oControllerThis._getDialog().close();
								//resize the crop area
								appView.byId("uploadedImg").setCropArea(2, 2, 130, 100);
							} else {
								ifContinueUpdt = 0;
							}
						}
					});
				}
			} else {
				propertySetArr = [];
				propertySetArr.push(temp);
				oControllerThis._getDialog().close();
				//resize the crop area
				appView.byId("uploadedImg").setCropArea(2, 2, 130, 100);
			}
		},

		onPressCancel: function () {
			oControllerThis._getDialog().close();
			tabBar.setSelectedKey("previewTab");
			ifImageEditorSet = 0;
			oControllerThis.getEquipmentTags();
		},
		onSaveAsPress: function () {
			// convert img to base64 code
			var oUploadedImg = appView.byId("uploadedImg");
			if (oUploadedImg.getSrc() != "") {
				var imgBase64 = oUploadedImg.getImageDataURL(imgType);
				//console.log(imgBase64);
				imgBase64 = imgBase64.replace(/^data:image\/(png|jpg|jpeg);base64,/, "");
				// get the coords from the cropped area
				var cropArea = oUploadedImg.getCropArea();
				var top = cropArea.y;
				var left = cropArea.x;
				var bottom = top + cropArea.height;
				var right = left + cropArea.width;
				var coords = top + "," + left + "," + bottom + "," + right;
				sap.m.MessageBox.show("Do you want to save image tag at selected area?", {
					icon: sap.m.MessageBox.Icon.CONFIRMATION,
					title: "CONFIRMATION",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							BusyIndicator.show(0);
							reqBody.InputRequest.basecode = imgBase64;
							reqBody.InputRequest.coords = coords;
							reqBody.InputRequest.DateTime = new Date().toISOString();
							reqBody.InputRequest.DataPosition = selectedPosition;
							//Selected Property Type Flag added
							reqBody.InputRequest.Flag = Flag;
							if (isOtherPrpMapped == 1) {
								//when one or more property set already mapped, and we are updating the selected property set
								reqBody.InputRequest.ifUpdt = "-1";
							} else {
								//ifContinueUpdt = 1 :when one or more property set already mapped, and we are adding the selected property set
								//ifContinueUpdt = 0 :when adding the 1st property set
								reqBody.InputRequest.ifUpdt = ifContinueUpdt;
							}
							reqBody.InputRequest.PropertySets = propertySetArr;
							reqBody.InputRequest.ChildEqp = childEqpSelected;
							reqBody.InputRequest.ifChangeImg = ifChangeImg;
							//reset flag
							ifChangeImg = 0;
							//call insertService
							$.ajax({
								method: "POST",
								contentType: "application/json",
								url: "/node/insertThingDetails",
								data: JSON.stringify(reqBody),
								success: function (result) {
									sap.m.MessageBox.show("Image mapping saved successfully ", {
										icon: sap.m.MessageBox.Icon.SUCCESS,
										title: "SUCCESS",
										actions: [sap.m.MessageBox.Action.OK],
										onClose: function (oAction) {
											if (oAction === sap.m.MessageBox.Action.OK) {
												//take to preview tab
												tabBar.setSelectedKey("previewTab");
												ifImageEditorSet = 0;
												oControllerThis.getEquipmentTags();
												aSelectedItems.getBindingContext().getObject().Icon = "sap-icon://sys-enter-2";
												treeModelData.refresh();
											}
										}
									});
								},
								error: function (errorThrown) {
									console.error("insertThingDetails error " + JSON.stringify(errorThrown));
									BusyIndicator.hide();
									oControllerThis.showMsgStrip("Failed to save Mapped Image. Please reload the dashboard and try again.", "Error", "view");
								}
							});
						}
					}
				});
			}
		},

		onPressChangeImg: function () {
			sap.m.MessageBox.show("All the mappings will be removed for this Object. Do you want to continue?", {
				icon: sap.m.MessageBox.Icon.WARNING,
				title: "WARNING",
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.YES) {
						oControllerThis._getDialog().close();
						ifChangeImg = 1;
						//clr img 
						appView.byId("uploadedImg").setSrc("");
						appView.byId("imgUploader").clear();
					} else {
						ifChangeImg = 0;
						return;
					}
				}
			});
		},

		onTabBarSelect: function (oEvent) {
			var oItem = oEvent.getParameter('item');
			var selectedKey = oItem.getKey();
			var oUploadedImg = appView.byId("uploadedImg");
			// if editTab is selected & ifImageEditorSet = 1 then set that in image editor in editTab 
			//else ifImageEditorSet = 0, then clear the image editor
			if (selectedKey == "editTab" && ifImageEditorSet == 1) {
				oUploadedImg.setVisible(true);
				oUploadedImg.setSrc(dbImgBase64);
				appView.byId("imgUploader").clear();
				oControllerThis.setUpDialog();
			} else if (selectedKey == "editTab" && ifImageEditorSet == 0) {
				oUploadedImg.setSrc("");
				appView.byId("imgUploader").clear();
				oUploadedImg.setVisible(false);
			}
		},

		showMsgStrip: function (msgText, type, source) {
			var oVC, oMs = sap.ui.getCore().byId("msgStrip");
			if (oMs) {
				oMs.destroy();
			}
			if (source == "view") {
				oVC = appView.byId("oMsgLayoutView");
			} else {
				oVC = sap.ui.getCore().byId("oMsgLayout");
			}
			this._generateMsgStrip(msgText, type, oVC);
		},

		_generateMsgStrip: function (msgText, type, oVC) {
			oVC.setVisible(true);
			var oMsgStrip = new MessageStrip("msgStrip", {
				text: msgText,
				type: type,
				showIcon: true,
				showCloseButton: true
			});
			oVC.addContent(oMsgStrip);
			setTimeout(function () {
				oMsgStrip.close();
				oVC.setVisible(false);
			}, 10000);
		},
		////////////////////////////////// unused code//////////////////////////////////
		onPressBrowseImage: function () {
			console.log("onPressBrowseImage");
			jQuery("#" + oControllerThis.createId("inputFile")).click();
			appView.byId("inputFile").getDomRef().addEventListener("change", oControllerThis.onImgChange, false);
		},

		onImgChange: function (e) {
			console.log("onImgChange");
			var file = e.target.files[0];
			if (file) {
				if (/^image\//i.test(file.type)) {
					oControllerThis.readFile(file);
					console.log('valid image!');
				} else {
					console.log('Not a valid image!');
				}
			}
		},

		readFile: function (file) {
			var reader = new FileReader();
			reader.onloadend = function () {
				oControllerThis.processFile(reader.result, file.type);
			}
			reader.onerror = function () {
				console.log('There was an error reading the file!');
			}
			reader.readAsDataURL(file);
		},

		processFile: function (dataURL, fileType) {
			console.log("fileType" + fileType);
		},

	});
});
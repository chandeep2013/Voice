/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"ui_app/SustainableManufacturingAsset_ImageTaggingApp/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
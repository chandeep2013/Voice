sap.ui.define([
	"ui_app/SustainableManufacturingAsset_ImageTaggingApp/test/unit/controller/View.controller"
], function () {
	"use strict";
});
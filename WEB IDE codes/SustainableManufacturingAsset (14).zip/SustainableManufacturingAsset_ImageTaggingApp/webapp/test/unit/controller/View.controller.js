/*global QUnit*/

sap.ui.define([
	"ui_app/SustainableManufacturingAsset_ImageTaggingApp/controller/View.controller"
], function (Controller) {
	"use strict";

	QUnit.module("View Controller");

	QUnit.test("I should test the View controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
Set a release type below using one of the following keywords and then **REMOVE** this line: patch, minor, major, skip

+semver: patch

# Overview
This repository houses the source code for the fuelsordersearchui5 SAP UI5 application.

# Build
The Azure DevOps YAML CI pipeline is located under the `azure-devops/pipelines` folder and is linked to the `fuelsordersearchui5-ci` pipeline. 

# Guidance
Before setting security scans to `true` please see [this documentation](https://dev.azure.com/bp-digital/DevOps-SRE/_wiki/wikis/1Click/14304/Build)

The CI pipeline is configured to run each time changes are pushed to this repository.

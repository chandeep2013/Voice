sap.ui.define([], function () {
	"use strict";

	return {

		dateFormatterMedium: function (value) {
			var oDate;
			if (value) {
				value = value.substring(0, 4) + "/" + value.substring(4, 6) + "/" + value.substr(6, 8);
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					style: "medium"
				});
				oDate = oDateFormat.format(new Date(value), false);
			}
			return oDate;
		},

		timeFormatterMedium: function (value) {
	var sCurrentCountry = sap.ui.getCore().getConfiguration().getLocale().getRegion();
			var oDate; 
			if (value  !== "" && value !== "00:00:00") {
				//	value = value.substring(0, 2) + "/" + value.substring(2, 4) + "/" + value.substr(4, 6);
				var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					format: "HH:mm aa"

				});
				oDate = oTimeFormat.format(new Date(1970, 0, 1, value.substring(0, 2), value.substring(2, 4), value.substr(4, 6)), false);
				return oDate;
			} else {
				oDate = "";
				return oDate;
			}

		},

		DateFormatt: function (st) {
			var val = '';
			if (st) {

				if (st) {
					var oFormat = sap.ui.core.format.DateFormat.getInstance({
						format: "yMMMd"
					});
					var dat = new Date(st);

					val = oFormat.format(dat);
				}
			}
			return val;
		},
		/**  
		 * Format the Amount values by applying $/,/. charecters. 
		 * @param {String} amount for Gross Amount, Net Amount & Fee columns
		 */
		numberFormatter: function (amount) {
			amount += '';
			var x = amount.split('.');
			var x1 = x[0];
			var x2 = x[1].length > 1 ? '.' + x[1] : '.' + x[1] + '0';
			var rgx = /(\d+)(\d{3})/;
			while (rgx.test(x1)) {
				x1 = x1.replace(rgx, '$1' + ',' + '$2');
			}
			return x1 + x2;
		},

		encode64: function (input) {
			var keyStr = "ABCDEFGHIJKLMNOP" +
				"QRSTUVWXYZabcdef" +
				"ghijklmnopqrstuv" +
				"wxyz0123456789+/" +
				"=";
			input = escape(input);
			var output = "";
			var chr1, chr2, chr3 = "";
			var enc1, enc2, enc3, enc4 = "";
			var i = 0;
			do {
				chr1 = input.charCodeAt(i++);
				chr2 = input.charCodeAt(i++);
				chr3 = input.charCodeAt(i++);
				enc1 = chr1 >> 2;
				enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
				enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
				enc4 = chr3 & 63;
				if (isNaN(chr2)) {
					enc3 = enc4 = 64;
				} else if (isNaN(chr3)) {
					enc4 = 64;
				}
				output = output +
					keyStr.charAt(enc1) +
					keyStr.charAt(enc2) +
					keyStr.charAt(enc3) +
					keyStr.charAt(enc4);
				chr1 = chr2 = chr3 = "";
				enc1 = enc2 = enc3 = enc4 = "";
			} while (i < input.length);
			return output;
		},
		// R7 reqdeldate formatting
		getDisplayDate: function (eValue, bIsNextDayDelivery) {
			if (!eValue) {
				return "";
			}

			if (bIsNextDayDelivery) {
				return this.formatter.getNextDayDeliveryRange(eValue);
			} else {

				return eValue;
			}
		},
		getNextDayDeliveryRange: function (date) {
			var oNextdayDelDate = new Date(date.substring(6, 10), date.substring(3, 5) - 1, date.substring(0, 2));
			var onewDate = oNextdayDelDate.getDate() + 1;
			oNextdayDelDate = new Date(oNextdayDelDate.getFullYear(), oNextdayDelDate.getMonth(), onewDate);
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd/MM/yyyy"
			});
			oNextdayDelDate = oDateFormat.format(oNextdayDelDate, false);
			/*	var oDateFrom = new Date(date);
				var oDateTo = new Date(new Date(oDateFrom).setDate(oDateFrom.getDate() + 1));
				
				var oFormatter = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd MMM yyyy",
					UTC: false
				});*/

			return date + " - " + oNextdayDelDate;

		},
		getShiftText: function (sValue) {
			if (!sValue) {
				return "";
			}
			var aShift = sValue.split("_");

			return aShift[1];
		},
		formatRowHighlight: function (StatusBgColor) {
			if(StatusBgColor == "#A9DDA5") {
				return "Success";
			} else if(StatusBgColor == "#FFFF90") {
				return "Warning";
			} else if(StatusBgColor == "#0000FF") {
				return "Information";
			} else if(StatusBgColor == "#FF8787") {
				return "Error";
			} else {
				return "None";
			}
		}
	};

});
sap.ui.define([
	"com/bp/fuels-ordersearch-ui5/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
sap.ui.define([
"sap/ui/core/mvc/Controller"
], function (Controller) {
"use strict";

 return Controller.extend("com.bp.fuels-ordersearch-ui5.controller.OrdPrint", {

 onInit: function () {
var odata = JSON.parse(sessionStorage.getItem('printData'));
var oModel = new sap.ui.model.json.JSONModel(odata);
this.getView().setModel(oModel, "viewModel");

 var i18nModelC = new sap.ui.model.resource.ResourceModel({
bundleUrl: sap.ui.require.toUrl("com/bp/fuels-ordersearch-ui5/i18n/i18n.properties"),
bundleLocale : odata.ui.UserLanguage
});

 this.getView().setModel(i18nModelC, "i18n");
// _oModelVWRI.setProperty('/ui/UserLanguage', sap.ushell.Container.getService('UserInfo').getUser().getLanguage());

 // sap.m.MessageToast.show("Record Created Successfully!!!");
// //storing data in session for print
// sessionStorage.setItem('printData', JSON.stringify(_oModelVWRI.getData()));


 }

 });

});
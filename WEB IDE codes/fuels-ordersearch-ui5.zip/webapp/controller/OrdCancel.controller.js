jQuery.sap.require("jquery.sap.storage");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/ValueState",
	"sap/ui/core/routing/History",
	"sap/base/Log",
	"com/bp/fuels-ordersearch-ui5/util/formatter",
	"sap/m/Dialog",
	"sap/m/DialogType"
], function (Controller, JSONModel, MessageBox, MessageToast, ValueState, History, Log, formatter, Dialog, DialogType) {
	"use strict";
	var oItems = {};
	return Controller.extend("com.bp.fuels-ordersearch-ui5.controller.OrdCancel", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.bp.fuels-ordersearch-ui5.view.OrdCancel
		 */
		onInit: function () {
			var oRouter = this.getOwnerComponent().getRouter(this);
			oRouter.getRoute("OrdCancel").attachMatched(this._onRouteMatched, this);

		},

		_navBack: function () {
			//this.getOwnerComponent().getModel("RefreshTableKeys").getData().refresh = true;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("Main", true);

		},

		onPressMSDS: function (oEvent) {
			//var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			//var sBindingContextPath = oEvent.getSource().getParent().getBindingContextPath();
			var country = window.userInfoObj.country;
			var language = window.userInfoObj.language.toUpperCase();
			var MaterialId = this.getView().getModel("viewModel").getProperty('/postData/ProductNo');
			var sPath = "/MsdsPdfReadSet(Wrkst='" + MaterialId + "',Langu='" + language + "',Land1='" + country + "')/$value";
			var oPDFViewer = new sap.m.PDFViewer();
			this.getView().addDependent(oPDFViewer);
			var sServiceURL = this.getView().getModel().sServiceUrl;
			var sSource = sServiceURL + sPath;
			oPDFViewer.setSource(sSource);
			oPDFViewer.setTitle("PDF Document Preview");
			oPDFViewer.open();
		},

		_onRouteMatched: function (oEvent) {
			var oArgs, oView;
			var sSentInfo = this.getView().getModel("i18n").getResourceBundle().getText("sentInformation");

			oArgs = oEvent.getParameter("arguments");
			var oJsonModelView = new JSONModel(sap.ui.require.toUrl("com/bp/fuels-ordersearch-ui5/model/viewModel.json"));
			this.getView().setModel(oJsonModelView, "viewModel");

			// code for language and country
			var country = 'MX';
			var language = 'EN';
			if (window.userInfoObj && window.userInfoObj.country) {
				country = window.userInfoObj.country;
			}
			if (window.userInfoObj && window.userInfoObj.language) {
				language = window.userInfoObj.language.toUpperCase();
			}

			oJsonModelView.attachRequestCompleted(function () {
				//oArgs.estimateNumber
				this.getView().getModel('viewModel').setProperty('/UI/mode', oArgs.objectId);
				//this.getView().getModel('viewModel').setProperty('/UI/estimateNumber', oArgs.sOrderItemNo);
				this.getView().setBusy(true);
				this.getOwnerComponent().getModel().read("/OrderReadSet", {

					urlParameters: {
						'$expand': "BapiretOrderRead,CommentsOrderRead,CompartmentsOrderRead,DocumentflowOrderRead,DriversOrderRead,OrderitemsOrderRead,TrailersOrderRead,TrucksOrderRead,TusdataOrderRead,CompTusdataOrderRead,ControlFlagsOrderRead"

					},
					filters: [new sap.ui.model.Filter('OrderNumber', 'EQ', oArgs.objectId), new sap.ui.model.Filter('EditMode', 'EQ', 'CANCEL'),
						new sap.ui.model.Filter('CountryCode', 'EQ', country), new sap.ui.model.Filter('Language', 'EQ', language)
					],
					success: function (response) {
						this.getView().setBusy(false);
						/*	var oRouter = this.getOwnerComponent().getRouter();
						
							if (response.results[0].BapiretOrderRead.results.length > 0) {
							//set Error message
							var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
							// errorData.push(JSON.parse(oError.responseText).error.message.value);
							errorData = [];
							response.results[0].BapiretOrderRead.results.forEach(function (item) {
								var errMessageStruct = {
									"description": item.Message,
									"type": 'Error',
									"title": item.Message
								};
								errorData.push(errMessageStruct);
								oRouter.navTo("Main", true);
	

							});

							this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);
							
							}
							
							else {*/

						var oViewModel = this.getView().getModel('viewModel');

						var resObj = response.results[0];

						// assign control flags
						if (resObj.ControlFlagsOrderRead) {
							oViewModel.setProperty("/postData/ControlFlagsOrderRead", resObj.ControlFlagsOrderRead);
						}

						// assign whole order data in single property first
						oViewModel.setProperty("/postData/WholeOrderRead", resObj);

						if (resObj.ShowSentFields.length === 0) {
							this.byId("idTitleSentInfo").setText("");
						} else {
							this.byId("idTitleSentInfo").setText(sSentInfo);
						}

						if (resObj.ShowReqDelDate == true) {
							oViewModel.setProperty("/postData/reqDelDateFromflag", resObj.ReqDelDate);
						}
						if (resObj.ShowReqDelDateTo == true) {
							oViewModel.setProperty("/postData/reqDelDateToflag", resObj.ReqDelDateTo);
						}
						if (resObj.ShowLoadingDate == true) {
							oViewModel.setProperty("/postData/loadingDateFromflag", resObj.ReqDelDate);
						}
						if (resObj.ShowLoadingDateTo == true) {
							oViewModel.setProperty("/postData/loadingDateToflag", resObj.ReqDelDateTo);
						}

						if (resObj.TusdataOrderRead.results.length > 0) {
							var resObj5 = resObj.TusdataOrderRead.results[0];
							oViewModel.setProperty("/postData/drivercode", resObj.DriverCode);
							oViewModel.setProperty("/postData/drivername", resObj.DriverName);
							oViewModel.setProperty("/postData/licenseplate", resObj5.LicensePlate);
							oViewModel.setProperty("/postData/tuTypeDesc", resObj5.TuTypeDesc);

						}
						//assign products
						if (resObj.OrderitemsOrderRead.results.length > 0) {
							oViewModel.setProperty("/postData/products", resObj.OrderitemsOrderRead.results);
						}

						// assign compartments
						this.byId("idCompartmentPageSection").setVisible(false);
						if (resObj.CompTusdataOrderRead.results.length > 0) {
							this.byId("idCompartmentPageSection").setVisible(true);
							oViewModel.setProperty("/postData/compartments", resObj.CompTusdataOrderRead.results);
						}

						// assign final destination
						oViewModel.setProperty("/postData/finalDestinationNum", resObj.FinalBpNumber);
						oViewModel.setProperty("/postData/finalDestinationName", resObj.FinalLongName);
						oViewModel.setProperty("/postData/finalDestinationAdd", resObj.FinalLongAddress);

						var resObj1 = resObj.OrderitemsOrderRead.results[0];
						if (resObj.DriversOrderRead.results["length"] > 0) {
							var resObj2 = resObj.DriversOrderRead.results[0];
						}
						if (resObj.TrucksOrderRead.results["length"] > 0) {
							var resObj3 = resObj.TrucksOrderRead.results[0];
						}
						if (resObj.TrailersOrderRead.results["length"] > 0) {
							var resObj4 = resObj.TrailersOrderRead.results[0];
						}
						//var resObj4 = resObj.TrailersOrderReads.results[0];

						if (resObj) {
							oViewModel.setProperty('/postData/CustNum', resObj.SoldBpNumber);
							oViewModel.setProperty('/postData/CustName', resObj.SoldName);
							oViewModel.setProperty('/postData/CustNameAdd', resObj.SoldShortAddress);
							oViewModel.setProperty('/postData/DeleryNum', resObj.ShipBpNumber);
							oViewModel.setProperty('/postData/DeliveryName', resObj.ShipName);
							oViewModel.setProperty('/postData/DeliveryAdd', resObj.ShipShortAddress);
							if (resObj.CommentsOrderRead.results[0]) {
								var str = '';
								resObj.CommentsOrderRead.results.forEach(function (item) {
									str = str + item.Tdline;
								});

								oViewModel.setProperty('/postData/DeliveryInsuc', str);
							} else {
								oViewModel.setProperty('/postData/DeliveryInsuc', "");
							}
							oViewModel.setProperty('/postData/Terminal', resObj.PickBpNumber);
							oViewModel.setProperty('/postData/TerminalName', resObj.PickName);
							oViewModel.setProperty('/postData/TerminalAdd', resObj.PickShortAddress);
							oViewModel.setProperty('/postData/OrderReq', resObj.ReqDelDate);
							oViewModel.setProperty('/postData/ProductNum', resObj1.MaterialId + ' ' + resObj1.MaterialDescription);
							oViewModel.setProperty('/postData/ProductNo', resObj1.MaterialId);
							oViewModel.setProperty('/postData/Condition', resObj1.StatusDescription);
							oViewModel.setProperty('/postData/Quantity', resObj1.Quantity + ' ' + resObj1.Uom);
							oViewModel.setProperty('/postData/ShowPrices', resObj.ShowPrices);
							oViewModel.setProperty('/postData/ShowTotals', resObj.ShowTotals);
							oViewModel.setProperty('/postData/ShowVat', resObj.ShowVat);
							oViewModel.setProperty('/postData/Currency', resObj.Currency);
							oViewModel.setProperty('/postData/VolumeUom', resObj.Currency);
							oViewModel.setProperty('/postData/NetPrice', resObj.NetPrice);
							oViewModel.setProperty('/postData/orderRequire', resObj.PoNumber);
							oViewModel.setProperty('/postData/StatusId', resObj.StatusId);
							oViewModel.setProperty('/postData/docFlwRead', resObj.DocumentflowOrderRead);
							oViewModel.setProperty('/postData/ShipBpNumber', resObj.ShipBpNumber);
							oViewModel.setProperty('/postData/SoldBpNumber', resObj.SoldBpNumber);
							oViewModel.setProperty('/postData/SoldBpNumber', resObj.SoldBpNumber);
							oViewModel.setProperty('/postData/CanCancel', resObj.CanCancel);
							this.selectedData = {
								//ShipmentNumber:oViewModel.getProperty('/postData/docFlwRead/results/0/DocumentNumber'),
								SoldToPartner: oViewModel.getProperty('/postData/SoldBpNumber'),
								ShipToPartner: oViewModel.getProperty('/postData/ShipBpNumber')
							};

							if (oViewModel.getProperty('/postData/docFlwRead/results/0')) {
								var oBillingDocIds = [];
								var deliveries = oViewModel.getProperty('/postData/docFlwRead/results');
								if (!$.isEmptyObject(deliveries)) {
									deliveries.forEach(function (oItem) {
										if (oItem.DocumentType == "r") {
											oBillingDocIds.push({
												docNum: oItem.DocumentNumber,
												docDes: oItem.DocumentDesc

											});
										}
									});
								}
								if (oBillingDocIds[0]) {
									this.getView().byId("idStatusIndDel").setValue(100);
									this.getView().byId("idlinkDel").setEnabled(true);
								}

								oViewModel.setProperty('/postData/docFlwRead/docIdsDel', oBillingDocIds);
							} else {
								this.getView().byId("idStatusIndDel").setValue(99);
							}
							if (oViewModel.getProperty('/postData/docFlwRead/results/0')) {
								var oBillingDocIds1 = [];
								var Inv = oViewModel.getProperty('/postData/docFlwRead/results');
								if (!$.isEmptyObject(Inv)) {
									Inv.forEach(function (oItem) {
										if (oItem.DocumentType == "M" || oItem.DocumentType == "N") {
											oBillingDocIds1.push(oItem.DocumentNumber);
										}
									});
								}
								if (oBillingDocIds1[0]) {
									this.getView().byId("idStatusIndInv").setValue(100);
									this.getView().byId("idlinkInv").setEnabled(true);
								}
								oViewModel.setProperty('/postData/docFlwRead/docIdsInv', oBillingDocIds1);
							} else {
								this.getView().byId("idStatusIndInv").setValue(99);
							}
							if (oViewModel.getProperty('/postData/StatusId', resObj.StatusId) === 928 || oViewModel.getProperty('/postData/StatusId',
									resObj.StatusId) === 929) {

								this.getView().byId("idStatusIndOrder").setValue(100);
							}
							// else if (oViewModel.getProperty('/postData/StatusId', resObj.StatusId) === 926) {
							// 	this.getView().byId("idStatusIndOrder").setValue(50);
							// }
							if (resObj2) {
								if (resObj2.Zzdrivercode) {

									this.getView().byId("DriverPageSection").setVisible(true);
									oViewModel.setProperty('/postData/DriverNum', resObj2.Zzdrivercode);
									oViewModel.setProperty('/postData/NID', resObj2.Zzperscode);
									oViewModel.setProperty('/postData/DrivingLicense', resObj2.Zzlicenseno);
									oViewModel.setProperty('/postData/DriverName', resObj2.ZzfirstName + ',' + resObj2.ZzlastName);
								}
							}
							if (resObj3) {

								if (resObj3.Zzvehicleid) {
									this.getView().byId("TruckPageSection").setVisible(true);
									oViewModel.setProperty('/postData/VehicalNum', resObj3.Zzvehicleid);
									oViewModel.setProperty('/postData/RegirationNum', resObj3.Zzvehicleno);
									oViewModel.setProperty('/postData/VehicalTye', resObj3.ZzvehTypeDesc);
								}
							}
							if (resObj4) {

								if (resObj4.Zzvehicleid) {
									this.getView().byId("TrailerPageSection").setVisible(true);
									oViewModel.setProperty('/postData/TrailerNum', resObj4.Zzvehicleid);
									oViewModel.setProperty('/postData/TrailerRegirationNum', resObj4.Zzvehicleno);
									oViewModel.setProperty('/postData/TrailerVehicalTye', resObj4.ZzvehTypeDesc);
								}
							}
							//resObj.StatusId
							if (resObj.StatusId === 932) {

								this.getView().byId("idBarSI").setVisible(false);
							}
							//++SS20210610
							else {
								this.getView().byId("idBarSI").setVisible(true);
							}
							//++SS20210610

						}
						// }
					}.bind(this),
					error: function (err) {
						this.getView().setBusy(false);
					}.bind(this)
				});

			}.bind(this));
		},

		getGroupHeader: function (oEvent) {
			return new sap.m.GroupHeaderListItem({
				title: oEvent.key
			});
		},
		getCounty: function (oContext) {
			return oContext.getProperty('TuNumber');
		},
		onFullScreen: function (oEvent) {
			var sSize = this.getView().byId("idSplitterLayout").getSize();
			if (sSize === "25%") {
				this.getView().byId("idSplitterLayout").setSize("0%");
				this.getView().byId("idActionBtn").setIcon("sap-icon://exit-full-screen");
			} else {
				this.getView().byId("idSplitterLayout").setSize("25%");
				this.getView().byId("idActionBtn").setIcon("sap-icon://full-screen");
			}
		},

		onCancelWholeOrder: function () {
		var oResource =	this.getView().getModel("i18n").getResourceBundle();
		var sOrderNo = this.getView().getModel("viewModel").getProperty('/UI/mode');
			if (!this.oApproveDialog) {
				this.oApproveDialog = new Dialog({
					type: DialogType.Message,
					title: oResource.getText("titleMsgCancel"),
					content: new sap.m.Text({
						text: oResource.getText("confirmCancelOrder") + " " + sOrderNo
					}),
					beginButton: new sap.m.Button({
						type: "Emphasized",
						text: oResource.getText("btnMsgSave"),
						press: function () {
							this.onCancelWholeOrder1(sOrderNo, oResource);
							this.oApproveDialog.close();
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: oResource.getText("btnMsgCancel"),
						press: function () {
							this.oApproveDialog.close();
						}.bind(this)
					})
				});
			}

			this.oApproveDialog.open();
		},

		onCancelWholeOrder1: function (sOrderNo, oResource) {

			// var oViewModel = this.getView().getModel("viewModel");
			var oModel = this.getView().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var oPayload = {};
			oPayload.OrderNumber = sOrderNo;
			oPayload.CancelWholeOrder = true;
			oPayload.UserType = $.sap.UserType;
			oPayload.SalesareasOrderCancelWrite = [];
			oPayload.BapiretMsgOrderCancelWrite = [];
			oPayload.CancelitemsOrderCancelWrite = [];
            this.getView().setBusy(true);
			oModel.create('/OrderCancelWriteSet', oPayload, {

				success: function (data) {
					this.getView().setBusy(false);
					sap.m.MessageBox.success((oResource.getText("successMsgCancelOrder")), {
						actions: [sap.m.MessageBox.Action.OK],
						emphasizedAction: sap.m.MessageBox.Action.OK,
						onClose: function (sAction) {
							//navigate to order search
							oRouter.navTo("Main", true);

						}.bind(this)
					});

				}.bind(this),
				error: function (oError) {
					// sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("errcancellation"));
					sap.m.MessageBox.error(oResource.getText("errorMsgText"));
					this.getView().setBusy(false);

				}.bind(this)
			});

		},

		onCancelItem: function (oEvent) {
			var sIcon = oEvent.getSource().getIcon();

			if (sIcon == "sap-icon://delete") {
				oEvent.getSource().setIcon("sap-icon://refresh");
				oEvent.getSource().getParent().addStyleClass("rowBackground");

			} else {
				oEvent.getSource().setIcon("sap-icon://delete");
				oEvent.getSource().getParent().removeStyleClass("rowBackground");
			}

			var oTable = this.getView().byId("idProductTable");
			var canBtnFlag = false;

			for (var i = 0; i < oTable.getItems().length; i++) {
				var sItem = oTable.getItems()[i];
				var sIconTab = sItem.getCells()[11].getIcon();

				if (sIconTab == "sap-icon://refresh") {
					canBtnFlag = true;
				}
				this.getView().byId("btnCancelItem").setEnabled(canBtnFlag);
			
			}
		},

		onCancelOrder: function () {
			    var oResource =	this.getView().getModel("i18n").getResourceBundle();
				var oViewModel = this.getView().getModel("viewModel");
				var oModel = this.getView().getModel();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				var aItems = oViewModel.getProperty("/postData/products");
				var oTableItems = this.getView().byId("idProductTable").getItems();

				var oPayload = {};
				oPayload.OrderNumber = oViewModel.getProperty('/UI/mode');
				oPayload.UserType = $.sap.UserType;
				oPayload.CancelitemsOrderCancelWrite = [];

                
				
			/*	aItems.forEach(function (item, index) {
					
					for(var i = 0; i<= oTableItems.length;i++){
	         	var sItem = oTableItems()[i];
				var sIconTab = sItem.getCells()[11].getIcon();

				if (sIconTab == "sap-icon://refresh") {
				}
					}
					
					var oItem = {};
					oItem.ItemNumber = item.ItemNumber;
					oPayload.CancelitemsOrderCancelWrite.push(oItem);
				}.bind(this));*/
					var item;
					var sItem;
					var sIconTab;
					for(var i = 0; i< oTableItems.length;i++){
	         	 sItem = oTableItems[i];
				 sIconTab = sItem.getCells()[11].getIcon();

				if (sIconTab == "sap-icon://refresh") {
					item = aItems[i];
					var oItem = {};
					oItem.ItemNumber = item.ItemNumber;
					oPayload.CancelitemsOrderCancelWrite.push(oItem);
				}
					
				}

				oPayload.SalesareasOrderCancelWrite = [];
				oPayload.BapiretMsgOrderCancelWrite = [];
				this.getView().setBusy(true);
				oModel.create('/OrderCancelWriteSet', oPayload, {

					success: function (data) {
						this.getView().setBusy(false);
						if (data.BapiretMsgOrderCancelWrite.results.length > 0) {
							//set Error message
							var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
							// errorData.push(JSON.parse(oError.responseText).error.message.value);
							errorData = [];
							data.BapiretMsgOrderCancelWrite.results.forEach(function (item) {
								var errMessageStruct = {
									"description": item.Message,
									"type": 'Error',
									"title": item.Message
								};
								errorData.push(errMessageStruct);

							});

							this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);

							this.getView().setBusy(false);
						} else {

							sap.m.MessageBox.success(oResource.getText("successMsgCancelOrder"), {
								actions: [sap.m.MessageBox.Action.OK],
								emphasizedAction: sap.m.MessageBox.Action.OK,
								onClose: function (sAction) {
									//navigate to order search
									oRouter.navTo("Main", true);

								}.bind(this)
							});
						}
					}.bind(this),
					error: function (oError) {
						// sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("errcancellation"));
						sap.m.MessageBox.error(oResource.getText("errorMsgText"));
						this.getView().setBusy(false);

					}.bind(this)
				});

			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.bp.fuels-ordersearch-ui5.view.OrdCancel
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.bp.fuels-ordersearch-ui5.view.OrdCancel
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.bp.fuels-ordersearch-ui5.view.OrdCancel
		 */
		//	onExit: function() {
		//
		//	}

	});

});
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/ui/core/Fragment',
	"com/bp/fuels-ordersearch-ui5/util/formatter",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/Token",
	"sap/ui/unified/DateRange",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library"
], function (Controller, JSONModel, Fragment, formatter, History, MessageBox, Filter, FilterOperator, Token, DateRange, DateFormat,
	library) {
	"use strict";
	var sPathSelected = "";
	var internalGroup;
	var flagCustomerDrop1 = false;
	var oMessagePopover;
	//var oFilter2;
	//daterange changes
	var showerrormsgFlag, setflag;
	var CalendarType = library.CalendarType;
	var vFlagTo = false;
	var vFlagFrom = false;
	return Controller.extend("com.bp.fuels-ordersearch-ui5.controller.Main", {
		formatter: formatter,

		/*handleRouteMatched: function (oEvent) {
			var oParams;

		},*/

		onInit: function () {
			var oMessageTemplate = new sap.m.MessageItem({
				type: '{errorMsgModel>type}',
				title: '{errorMsgModel>title}',
				description: '{errorMsgModel>description}'

			});
			oMessagePopover = new sap.m.MessagePopover({
				items: {
					path: 'errorMsgModel>/results',
					template: oMessageTemplate
				},
				activeTitlePress: function () {
					sap.m.MessageToast.show('Active title is pressed');
				}
			});
			this.byId("messagePopoverBtn").addDependent(oMessagePopover);

			var oJsonModelView = this.getOwnerComponent().getModel("userModel");
			oJsonModelView.pSequentialImportCompleted.then(function () {

				if (this.getOwnerComponent().getModel("userModel").getData()) {
					//G SCP GSD PRTL Internal User
					this.bFlag = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel("userModel").getData()
						.groups.find(function (ele) {
							if ((ele.name.search(/G(\s?)SCP(\s?)GSD(\s?)PRTL(\s?)Internal(\s?)User/) > -1)) {
								return true;
							}
						});
					if (this.bFlag) {
						if (this.bFlag.name) {
							internalGroup = true;
						}
					} else {
						internalGroup = false;
					}
					//G SCP GSD PRTL Payment Advice

				}

			}.bind(this));
			var model = new sap.ui.model.json.JSONModel();
			model.loadData("/services/userapi/attributes?multiValuesAsArrays=true");
			this.getView().setModel(model, "userapiModel");

			/*this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);*/
			//this.oRouter.getRoute("Main").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
			/*this.oRouter.getRoute("Main").attachMatched(this.handleRouteMatched, this);
			this.appNav = true;
			this.oRouter.getRoute("Main").attachPatternMatched(this._onMasterMatched, this);*/

			//Default 3 months Date range for search
			var currentDate = new Date();
			var toDate = new Date();
			var fromDate = new Date(currentDate.setDate(currentDate.getDate() - 14));
			var country = 'GB'; // change MX later after local testing
			var language = 'EN';

			if (window.userInfoObj && window.userInfoObj.country) {
				country = window.userInfoObj.country;

				if (country === "DF") {
					country = "GB";

				}
			} else { //added to handle undefined country specifically for columns personlisation in table
				var oCountry = sap.ui.getCore().getConfiguration().getLanguage().split("-")[1];

				if (oCountry !== undefined) {
					country = oCountry;
				}

			}
			if (window.userInfoObj && window.userInfoObj.language) {
				language = window.userInfoObj.language.toUpperCase();
			}

			if (country === 'GB') {
				this.getView().byId("idReqDelDateOut").setVisible(true);
				this.getView().byId("idColumnLoadID").setVisible(false);
				//++20220524 Sustain Start Poland Order Change adjustments
				// this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
				// 	"PlantDesc,LoadID,ReqDelTime,TermDays,LoadingDateTo,ReqDelDateTo,DeliveryNumber,Division,FromDate,Limit,SalesOrg,UomDescription,UserType,AuthorizationNumber,ReqDelDate,FinalDestination,Flag,PartnerNo,OrderItemNo,OrderTyp,Date,Trailers,Drivers,Imo,Trucks,Flag,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,PaymentTerm,Vessel,ShowLoadingTime,ShowLoadingDate,LoadingTime,LoadIDIn,LoadIdDisplay,LoadIdAddon,ShowReqDelDate,ShipToName,PaymentTerm,TsaStatusDesc,TsaStatus"
				// );
				this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"OrdStausMessage,PlantDesc,OrdStatus,LoadID,ReqDelTime,TermDays,LoadingDateTo,ReqDelDateTo,DeliveryNumber,Division,FromDate,Limit,SalesOrg,UomDescription,UserType,AuthorizationNumber,ReqDelDate,FinalDestination,Flag,PartnerNo,OrderItemNo,OrderTyp,Date,Trailers,Drivers,Imo,Trucks,Flag,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,PaymentTerm,Vessel,ShowLoadingTime,ShowLoadingDate,LoadingTime,LoadIDIn,LoadIdDisplay,LoadIdAddon,ShowReqDelDate,ShipToName,PaymentTerm,TsaStatusDesc,TsaStatus"
				);
				//++20220524 Sustain End Poland Order Change adjustments
				//	that.getView().byId("idColumnBillingDate").setVisible(false);	
			} // condition for othe fuels countries -- 21 jan
			else if (country === 'AU' || country === 'NZ' || country === 'AT') {
				//++20220524 Sustain Start Poland Order Change adjustments
				// this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
				// 	"PlantDesc,TermDays,ModifiedBy,ModifiedDate,DeliveryNumber,Division,FromDate,Limit,SalesOrg,SentStatusId,UomDescription,UserType,AuthorizationNumber,ReqDelDate,ShipToName,FinalDestination,Flag,PartnerNo,OrderTyp,Date,Trailers,Drivers,Imo,Trucks,Flag,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,PaymentTerm,Vessel,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,TsaStatusDesc,LoadingDateTo,LoadIdDisplay,ReqDelDateTo,LoadIdAddon,ShowReqDelDate,PaymentTerm"
				// );
				this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"OrdStausMessage,PlantDesc,OrdStatus,TermDays,ModifiedBy,ModifiedDate,DeliveryNumber,Division,FromDate,Limit,SalesOrg,SentStatusId,UomDescription,UserType,AuthorizationNumber,ReqDelDate,ShipToName,FinalDestination,Flag,PartnerNo,OrderTyp,Date,Trailers,Drivers,Imo,Trucks,Flag,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,PaymentTerm,Vessel,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,TsaStatusDesc,LoadingDateTo,LoadIdDisplay,ReqDelDateTo,LoadIdAddon,ShowReqDelDate,PaymentTerm"
				);
				//++20220524 Sustain End Poland Order Change adjustments
			} else if (country === 'PT' || country === "ES" || country === "NL") {
				//++20220524 Sustain Start Poland Order Change adjustments
				// this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
				// 	"PlantDesc,TermDays,ModifiedBy,ModifiedDate,DeliveryNumber,Division,FromDate,Limit,SalesOrg,SentStatusId,UomDescription,UserType,AuthorizationNumber,ReqDelDate,ShipToName,FinalDestination,Flag,PartnerNo,OrderTyp,Date,Trailers,Drivers,Imo,Trucks,Flag,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,PaymentTerm,Vessel,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,TsaStatusDesc,LoadingDateTo,LoadIdDisplay,ReqDelDateTo,LoadIdAddon,ShowReqDelDate,PaymentTerm"
				// );
				this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"OrdStausMessage,PlantDesc,OrdStatus,TermDays,ModifiedBy,ModifiedDate,DeliveryNumber,Division,FromDate,Limit,SalesOrg,SentStatusId,UomDescription,UserType,AuthorizationNumber,ReqDelDate,ShipToName,FinalDestination,Flag,PartnerNo,OrderTyp,Date,Trailers,Drivers,Imo,Trucks,Flag,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,PaymentTerm,Vessel,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,TsaStatusDesc,LoadingDateTo,LoadIdDisplay,ReqDelDateTo,LoadIdAddon,ShowReqDelDate,PaymentTerm"
				);
				//++20220524 Sustain End Poland Order Change adjustments
			} else if (country === 'PL') {
				//++20220524 Sustain Start Poland Order Change adjustments
				// this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
				// 	"PlantDesc,LoadingTime,ModifiedBy,ModifiedDate,DeliveryNumber,Division,FromDate,Limit,SalesOrg,SentStatusId,UomDescription,UserType,AuthorizationNumber,ReqDelDate,ShipToName,FinalDestination,Flag,PartnerNo,OrderTyp,Date,Imo,Flag,SentSenderId,SentRelevancyTrailers,PaymentTerm,Vessel,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,SentPickupId,TsaStatusDesc,ReqDelDate,LoadIdDisplay,ShowReqDelDate,PaymentTerm"
				// );
				//this.getView().byId("idColumnTasStatus").setVisible(true);
				this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"OrdStatus,OrdStausMessage,PlantDesc,LoadingTime,ModifiedBy,ModifiedDate,DeliveryNumber,Division,FromDate,Limit,SalesOrg,SentStatusId,UomDescription,UserType,AuthorizationNumber,ReqDelDate,ShipToName,FinalDestination,Flag,PartnerNo,OrderTyp,Date,Imo,Flag,SentSenderId,SentRelevancyTrailers,PaymentTerm,Vessel,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,SentPickupId,TsaStatusDesc,ReqDelDate,LoadIdDisplay,ShowReqDelDate,PaymentTerm"
				);
				//++20220524 Sustain End Poland Order Change adjustments
			} else if (country === 'FR') {
				//++20220524 Sustain Start Poland Order Change adjustments
				// this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
				// 	"PlantDesc,AuthorizationNumber,TermDays,ModifiedBy,ModifiedDate,DeliveryNumber,Division,FromDate,Limit,SalesOrg,UomDescription,UserType,ReqDelDate,ShipToName,PartnerNo,OrderTyp,Date,Trailers,Drivers,Trucks,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,TsaStatusDesc,LoadingDateTo,LoadIdDisplay,ReqDelDateTo,LoadIdAddon,ShowReqDelDate"
				// );
				this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"OrdStausMessage,PlantDesc,OrdStatus,AuthorizationNumber,TermDays,ModifiedBy,ModifiedDate,DeliveryNumber,Division,FromDate,Limit,SalesOrg,UomDescription,UserType,ReqDelDate,ShipToName,PartnerNo,OrderTyp,Date,Trailers,Drivers,Trucks,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,TsaStatusDesc,LoadingDateTo,LoadIdDisplay,ReqDelDateTo,LoadIdAddon,ShowReqDelDate"
				);
				//++20220524 Sustain End Poland Order Change adjustments
			} else {
				//++20220524 Sustain Start Poland Order Change adjustments
				// this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
				// 	"PlantDesc,TermDays,ReqDelDateOut,ModifiedBy,ModifiedDate,DeliveryNumber,Division,ReqDelTime,FromDate,Limit,SalesOrg,UomDescription,UserType,AuthorizationNumber,ReqDelDate,ShipToName,FinalDestination,Flag,PartnerNo,OrderTyp,Date,Trailers,Drivers,Imo,Trucks,Flag,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,Vessel,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,TsaStatusDesc,LoadingDateTo,LoadIdDisplay,ReqDelDateTo,LoadIdAddon,ShowReqDelDate,PaymentTerm"
				// );
				this.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"OrdStausMessage,PlantDesc,OrdStatus,TermDays,ReqDelDateOut,ModifiedBy,ModifiedDate,DeliveryNumber,Division,ReqDelTime,FromDate,Limit,SalesOrg,UomDescription,UserType,AuthorizationNumber,ReqDelDate,ShipToName,FinalDestination,Flag,PartnerNo,OrderTyp,Date,Trailers,Drivers,Imo,Trucks,Flag,SentPickupId,SentPickup,SentSenderId,SentSender,SentNumber,SentCarrierKey,SentRecipientKey,SentStatusId,SentStatus,SentRelevancyId,SentRelevancyTrailers,Vessel,ShowLoadingTime,ShowLoadingDate,LoadIDIn,TsaStatus,TsaStatusDesc,LoadingDateTo,LoadIdDisplay,ReqDelDateTo,LoadIdAddon,ShowReqDelDate,PaymentTerm"
				);
				//++20220524 Sustain End Poland Order Change adjustments
			} // end
			//DateRange changes
			this.oFormatYyyymmdd = DateFormat.getInstance({
				pattern: "dd/MM/yyyy",
				calendarType: CalendarType.Gregorian
			});
			var currentDate = new Date();
			var toDate = new Date();
			var fromDate = new Date(currentDate.setMonth(currentDate.getMonth() - 1));
			//dateRange Changes

			var currentDate = new Date();
			var toDate = new Date();
			var fromDate = new Date(currentDate.setDate(currentDate.getDate() - 14));
			var oDefaultFilter = {
				"Date": {
					"high": toDate,
					"low": fromDate,
					"ranges": [{
						"exclude": false,
						"operation": "BT",
						"keyField": "Date",
						"value1": toDate,
						"value2": fromDate
					}]
				}

			};
			var that = this;
			this.getView().byId("idSmartFilterBar").attachInitialise(function () {
				//Set Default Filter value
				/*if (oFilter2) {
					that.getView().byId("idSmartFilterBar").setFilterData(oFilter2);
				} else {*/
				that.getView().byId("idSmartFilterBar").setFilterData(oDefaultFilter);
				//}
				//used this because there is no public method/property to hide 'Hide Filter Bar' button
				that.getView().byId("idSmartFilterBar")._oHideShowButton.setVisible(false);
				that._fnSetFilterWidth();
			});
			this.getUserDetails();

		},
		onSearchSmartFilterBar: function (oEvent) {

			var oControl = oEvent.getSource().getControlByKey("CustomerNumber");
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var sOrderNumber = oEvent.getSource().getControlByKey("OrderNumber").getValue();
			var sDate = oEvent.getSource().getControlByKey("Date").getValue();
			var sReqDate = oEvent.getSource().getControlByKey("ReqDelDate").getValue();
			if (oControl.getTokens().length > 5) {
				MessageBox.alert(resourceModel.getText("selectionError"));
				return;
			} else if (oControl.getTokens().length === 5 && oControl.getValue() !== "") {
				oControl.setValue("");
				MessageBox.alert(resourceModel.getText("selectionError"));
				return;
			}
			/*else if (internalGroup && flagCustomerDrop1 && oControl.getTokens().length == 0) {
				MessageBox.error(resourceModel.getText("customerdefaultingError"));
			}
			// Validations for search parameters
			var sOrderNumber = oEvent.getSource().getControlByKey("OrderNumber").getValue();

			if (sOrderNumber === "") {
				var sDate = oEvent.getSource().getControlByKey("Date").getValue();
				var sReqDate = oEvent.getSource().getControlByKey("ReqDelDate").getValue();

				if (sDate === "" && sReqDate === "") {

					MessageBox.error((resourceModel.getText("selectionError1")));

				}
			}*/
			//For Internal user customer, date is mandatory and for external user date is mandatory if Order number fiter is not there. Below code is for that condirtion.
			if (window.history.state !== '') {
				var getHistory = window.history.state.sap.history.length - 1; // 02022022 SG+ when Navigated from New Order to Order Display byPass the validation
				if (!(window.history.state.sap.history[getHistory].includes("detailed"))) {
					if (sOrderNumber === "" && sDate === "" && sReqDate === "") {
						if (internalGroup && flagCustomerDrop1) {
							if (oControl.getTokens().length === 0) {
								MessageBox.error(resourceModel.getText("selectionError1") + "\n" + resourceModel.getText("customerdefaultingError"));
							} else {
								MessageBox.error((resourceModel.getText("selectionError1")));
							}
						} else {
							MessageBox.error((resourceModel.getText("selectionError1")));
						}
					} else if (!(sOrderNumber)) {
						if (internalGroup && flagCustomerDrop1) {
							if (oControl.getTokens().length === 0) {
								MessageBox.error(resourceModel.getText("customerdefaultingError"));
							}
						}
					} else if (!(sOrderNumber || sDate || sReqDate)) {
						MessageBox.error((resourceModel.getText("selectionError1")));
					}
				}
			} else {
				if (sOrderNumber === "" && sDate === "" && sReqDate === "") {
					if (internalGroup && flagCustomerDrop1) {
						if (oControl.getTokens().length === 0) {
							MessageBox.error(resourceModel.getText("selectionError1") + "\n" + resourceModel.getText("customerdefaultingError"));
						} else {
							MessageBox.error((resourceModel.getText("selectionError1")));
						}
					} else {
						MessageBox.error((resourceModel.getText("selectionError1")));
					}
				} else if (!(sOrderNumber)) {
					if (internalGroup && flagCustomerDrop1) {
						if (oControl.getTokens().length === 0) {
							MessageBox.error(resourceModel.getText("customerdefaultingError"));
						}
					}
				} else if (!(sOrderNumber || sDate || sReqDate)) {
					MessageBox.error((resourceModel.getText("selectionError1")));
				}

			}
		},

		onValueHelpRequestedLoc1: function (oLocationControl) {
			var oView = this.getView();
			if (oLocationControl instanceof sap.m.MultiInput) {

				if (!this._pDialogDuplicate1) {
					this._pDialogDuplicate1 = Fragment.load({
						id: oView.getId(),
						name: "com.bp.fuels-ordersearch-ui5.view.fragment.PopoverLocation",
						controller: this
					}).then(function (oDialog) {
						oView.addDependent(oDialog);
						return oDialog;
					});
				}
				this._pDialogDuplicate1.then(function (oDialog) {
					oDialog.openBy(oLocationControl);
				}.bind(this));
			}
		},
		onValueHelpRequestedLoc: function (oLocationControl) {
			var oView = this.getView();
			if (oLocationControl instanceof sap.m.MultiInput) {

				if (!this._pDialogDuplicate) {
					this._pDialogDuplicate = Fragment.load({
						id: oView.getId(),
						name: "com.bp.fuels-ordersearch-ui5.view.fragment.PopoverCustomer",
						controller: this
					}).then(function (oDialog) {
						oView.addDependent(oDialog);
						return oDialog;
					});
				}
				this._pDialogDuplicate.then(function (oDialog) {
					oDialog.openBy(oLocationControl);
				}.bind(this));
			}
		},

		onValueHelpRequestedDate: function (oLocationControl) {
			var oView = this.getView();
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var sFrom = oLocationControl.getFrom();
			var sTo = oLocationControl.getTo();

			var sdiff = Math.abs(sFrom.getTime() - sTo.getTime());
			var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));

			if (sdiffD > 365) {
				oLocationControl.setValueState("Error");
				oLocationControl.setValueStateText((resourceModel.getText("selectionError2")));
				// MessageBox.error((resourceModel.getText("selectionError2")));
			} else {
				oLocationControl.setValueState("None");
			}

		},

		onValueHelpRDDDate: function (oRDDControl) {
			var oView = this.getView();
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var sFrom = oRDDControl.getFrom();
			var sTo = oRDDControl.getTo();

			var sdiff = Math.abs(sFrom.getTime() - sTo.getTime());
			var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));

			if (sdiffD > 365) {
				oRDDControl.setValueState("Error");
				oRDDControl.setValueStateText((resourceModel.getText("selectionError2")));
				// MessageBox.error((resourceModel.getText("selectionError2")));

			} else {
				oRDDControl.setValueState("None");
			}

		},

		smartFilterIntializeFunction: function (oEvent) {
			var oView = this.getView();
			var country = 'GB'; // change to MX after local testing
			if (window.userInfoObj && window.userInfoObj.country) {
				country = window.userInfoObj.country;
				if (country === "DF") {
					country = "GB";

				}
			}
			var oSmartFilterBar = oEvent.getSource();
			var dateFormatByCountry = "MM/dd/yyyy";
			//code for Public option hiding in varient
			this.getView().byId("idSmartTable")._oVariantManagement.setShowShare(false);
			this.getView().byId("idSmartFilterBar")._oVariantManagement.setShowShare(false);
			//Date Validation
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			if (resourceModel.getText("dateFormatByCountry") && resourceModel.getText("dateFormatByCountry") != "dateFormatByCountry") {
				dateFormatByCountry = resourceModel.getText("dateFormatByCountry");
			}

			/*	var oControlDate = oEvent.getSource().getControlByKey("Date");
				oControlDate.setDisplayFormat(dateFormatByCountry);
				var aDate = oControlDate["mEventRegistry"]["change"];
				// oControlDate.detachValueHelpRequest(aDate[1]["fFunction"]);

				oControlDate.detachChange(aDate[0]["fFunction"]);

				oControlDate.attachChange(function () {
					this.onValueHelpRequestedDate(oControlDate);
				}.bind(this));*/ // commented for date fragment change

			////
			//DateRange Changes  // 12 jan
			var oControlDate = oEvent.getSource().getControlByKey("Date");
			var currentDate = new Date();
			var toDate = new Date();
			var fromDate = new Date(currentDate.setMonth(currentDate.getMonth() - 1));
			toDate = this.oFormatYyyymmdd.format(toDate);
			fromDate = this.oFormatYyyymmdd.format(fromDate);
			this.getView().byId("idSmartFilterBar").getControlByKey("Date").setValue(fromDate + " - " + toDate);
			var aValueHelpRequestFunctions1 = oControlDate["mEventRegistry"]["valueHelpRequest"];
			oControlDate.detachValueHelpRequest(aValueHelpRequestFunctions1[0]["fFunction"]);

			oControlDate.attachValueHelpRequest(function () {
				this.onPressToDateRange(oControlDate);
			}.bind(this));
			var aValueHelpRequestFunctions1 = oControlDate["mEventRegistry"]["valueHelpRequest"];
			oControlDate.detachValueHelpRequest(aValueHelpRequestFunctions1[0]["fFunction"]);

			oControlDate.attachValueHelpRequest(function () {
				this.onPressToDateRange(oControlDate);
			}.bind(this));
			//end
			//Requested Delivery Date Validation
			var oControlRDDDate = oEvent.getSource().getControlByKey("ReqDelDate");
			oControlRDDDate.setDisplayFormat(dateFormatByCountry);
			var aDate = oControlRDDDate["mEventRegistry"]["change"];
			// oControlDate.detachValueHelpRequest(aDate[1]["fFunction"]);

			oControlRDDDate.detachChange(aDate[0]["fFunction"]);
			oControlRDDDate.attachChange(function () {
				this.onValueHelpRequestedDate(oControlRDDDate);
			}.bind(this));

			////

			// code for latest pagination request
			var oControl = oEvent.getSource().getControlByKey("CustomerNumber");
			var oLocationMultiInput = oEvent.getSource().getControlByKey("CustomerNumber");
			var aValueHelpRequestFunctions = oLocationMultiInput["mEventRegistry"]["valueHelpRequest"];
			oLocationMultiInput.detachValueHelpRequest(aValueHelpRequestFunctions[1]["fFunction"]);

			oLocationMultiInput.attachValueHelpRequest(function () {
				this.onValueHelpRequestedLoc(oLocationMultiInput);
			}.bind(this));

			// attach validator

			//sap-icon://slim-arrow-down
			oControl._getValueHelpIcon()["mProperties"]["src"] = "sap-icon://slim-arrow-down";

			// set max tokens
			oControl.setMaxTokens(5);

			// for location here
			var oControl1 = oEvent.getSource().getControlByKey("ShipToNumber");
			var oLocationMultiInput1 = oEvent.getSource().getControlByKey("ShipToNumber");
			var aValueHelpRequestFunctions1 = oLocationMultiInput1["mEventRegistry"]["valueHelpRequest"];
			oLocationMultiInput1.detachValueHelpRequest(aValueHelpRequestFunctions1[1]["fFunction"]);

			oLocationMultiInput1.attachValueHelpRequest(function () {
				this.onValueHelpRequestedLoc1(oLocationMultiInput1);
			}.bind(this));

			//sap-icon://slim-arrow-down
			oControl1._getValueHelpIcon()["mProperties"]["src"] = "sap-icon://slim-arrow-down";
			oControl1.setMaxTokens(5);

			//{++SS20210827   Manual Input in Customer Drop down
			oLocationMultiInput.removeAllValidators();
			var fnValidator = function (args) {
				var text = args.text;
				return new Token({
					key: text,
					text: text
				});
			};

			oLocationMultiInput.addValidator(fnValidator);
			//++SS20210827}

			// code for latest pagination request
			oView.setBusy(true);
			var oModel = this.getView().getModel();
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var oUserModel = oView.getModel("userModel");
			var odataModel = this.getView().getModel();
			var oToday = new Date();
			var timezoneoffset = oToday.getTimezoneOffset() * -1 + "";
			var afilters = [];
			afilters.push(new sap.ui.model.Filter("UtcOffset", "EQ", timezoneoffset));
			var urlParameters = {
				'$expand': "BapiretGetuser"
			};
			oView.setBusy(true);
			var t = this;
			odataModel.read("/GetuserReadSet", {
				urlParameters: urlParameters,
				filters: afilters,
				success: function (data1) {
					if (data1 && data1.results && data1.results.length > 0) {
						$.sap.UserType = data1.results[0].UserType; //Will be used in Order Cancellation

						var resFlag = data1.results[0];
						// start condition to toggle to multiorder report also adding country condition for Petchem only
						var oCountryRegion = sap.ui.getCore().getConfiguration().getLocale().getRegion();
						if (resFlag.CanCreateMultiple === true && (country === "DE" || oCountryRegion === "DE")) {
							t.getView().byId("idMultiorder").setVisible(true);
						}
						//end  +SG21042022
						if (resFlag.OvrShowParamOtype === true) {
							t.getView().byId("idOrderType").setVisible(true);
						}
						if (resFlag.UomBlank === true) {
							t.getView().byId("idLoadid").setVisible(true);
						}
					}

				}.bind(this),
				error: function (oError) {},
				complete: function (xhr1, data2) {}.bind(this)
			});

			oModel.read("/CustomerSrchSet", {
				urlParameters: {
					'$top': "5"
				},
				filters: [new Filter("IntUser", FilterOperator.EQ, internalGroup)],
				success: function (response) {
					if (response.results.length > 0) {

						/*for (var i = 0; i < 6 && i <= response.results.length; i++){
						    	oControl.setTokens([new sap.m.Token({
																key: response.results[i].BpNumber,
																text: response.results[i].Name
															})
																]);
																
						}

							// search call here
												oSmartFilterBar.search();*/
						if (!setflag && $.sap.UserType !== "CA" && country === "GB" || !setflag && country !== "GB") { // adjustment to check length of tokens if 0 as per variant saved for UK Hoyer users  +SG10022022
							setflag = false;
							if (response.results.length >= 5) {
								oControl.setTokens([new sap.m.Token({
										key: response.results[0].BpNumber,
										text: response.results[0].Name
									}),
									new sap.m.Token({
										key: response.results[1].BpNumber,
										text: response.results[1].Name
									}),
									new sap.m.Token({
										key: response.results[2].BpNumber,
										text: response.results[2].Name
									}),
									new sap.m.Token({
										key: response.results[3].BpNumber,
										text: response.results[3].Name
									}),
									new sap.m.Token({
										key: response.results[4].BpNumber,
										text: response.results[4].Name
									})

								]);

							} else if (response.results.length === 4) {
								oControl.setTokens([new sap.m.Token({
										key: response.results[0].BpNumber,
										text: response.results[0].Name
									}),
									new sap.m.Token({
										key: response.results[1].BpNumber,
										text: response.results[1].Name
									}),
									new sap.m.Token({
										key: response.results[2].BpNumber,
										text: response.results[2].Name
									}),
									new sap.m.Token({
										key: response.results[3].BpNumber,
										text: response.results[3].Name
									})
								]);

							} else if (response.results.length === 3) {
								oControl.setTokens([new sap.m.Token({
										key: response.results[0].BpNumber,
										text: response.results[0].Name
									}),
									new sap.m.Token({
										key: response.results[1].BpNumber,
										text: response.results[1].Name
									}),
									new sap.m.Token({
										key: response.results[2].BpNumber,
										text: response.results[2].Name
									})
								]);

							} else if (response.results.length === 2) {
								oControl.setTokens([new sap.m.Token({
										key: response.results[0].BpNumber,
										text: response.results[0].Name
									}),
									new sap.m.Token({
										key: response.results[1].BpNumber,
										text: response.results[1].Name
									})
								]);

							} else {
								oControl.setTokens([new sap.m.Token({
									key: response.results[0].BpNumber,
									text: response.results[0].Name
								})]);

							}
						}
						flagCustomerDrop1 = true;
						// search call here
						oSmartFilterBar.search();
					} else {
						// 02022022 SG+ when Navigated from New Order to Order Display byPass the validation
						var getHistory = window.history.state.sap.history.length - 1;
						if (!(window.history.state.sap.history[getHistory].includes("detailed"))) {
							MessageBox.error(resourceModel.getText("customerNullError"));
						}
					}

					oView.setBusy(false);

				},
				error: function (err) {
					oView.setBusy(false);
				}
			});

		},
		/*
		 *Experimental method - This is written to set the SmartFilterBar width
		 *Can be removed if the method causes any trouble
		 */
		onSelectionChangePopupListLocation: function (oEvent) {
			var aSelectedPaths = oEvent.getSource().getSelectedContextPaths();
			var oModel = this.getView().getModel();
			var oControl = this.byId('idSmartFilterBar').getControlByKey("ShipToNumber");
			aSelectedPaths.forEach(function (item) {
				var oo = oModel.getProperty(item);
				var nToken = new sap.m.Token({
					key: oo.BpNumber,
					text: oo.Name
				});
				var aTokens = oControl.getTokens();
				if (aTokens.some(function (ele) {
						return oo.BpNumber === ele.getKey();
					})) {

				} else {
					oControl.addToken(nToken);
					//		oControl.setSelectedKey(oo.BpNumber);
					oControl.fireTokenUpdate();
				}
			});
		},
		onSelectionChangePopupList: function (oEvent) {
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var aSelectedPaths = oEvent.getSource().getSelectedContextPaths();
			if (aSelectedPaths.length > 5) {
				MessageBox.alert(resourceModel.getText("customerSelection"));
				return oEvent.getParameters().listItem.setSelected(false);
			}
			var oModel = this.getView().getModel();
			var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");

			var aTokens = oControl.getTokens();

			var deSelected = oEvent.getParameter("listItem").getTitle();
			if (!oEvent.getParameter('selected')) {
				if (aTokens.some(function (ele, index) {
						if (deSelected === ele.getKey()) {
							aTokens.splice(index, 1);
						}
						return deSelected === ele.getKey();
					})) {
					oControl.setTokens(aTokens);
				}
			}

			aSelectedPaths.forEach(function (item) {
				var oo = oModel.getProperty(item);
				var nToken = new sap.m.Token({
					key: oo.BpNumber,
					text: oo.Name
				});
				aTokens = oControl.getTokens();

				if (aTokens.some(function (ele) {
						return oo.BpNumber === ele.getKey();
					})) {

				} else {
					//oControl.addToken(nToken);
					aTokens.push(nToken);
					oControl.setTokens(aTokens);
				}
			});
		},
		onFnDeselectAll: function (oEvent) {
			this.getView().byId("idListPopover").removeSelections(true);

			var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");
			var vLen = oControl.getTokens().length;
			var aTokens = oControl.getTokens();
			for (var i = 0; i < vLen; i++) {

				aTokens.splice(0, 1);
			}
			oControl.setTokens(aTokens);

		},
		onBeforeOpenLocation: function (oEvent) {
			var aFilter = [];
			var oControl = this.byId('idSmartFilterBar').getControlByKey("ShipToNumber");

			var oList = this.byId("idListPopoverLocation");
			oList.removeSelections(true);
			var oBinding = oList.getBinding("items");
			aFilter.push(new Filter("IntUser", FilterOperator.EQ, internalGroup));
			oBinding.filter(aFilter);

		},
		onUpdateFinishedLocation: function (oEvent) {
			var oControl = this.byId('idSmartFilterBar').getControlByKey("ShipToNumber");
			var aTokens = oControl.getTokens();
			var oList = this.byId("idListPopoverLocation");

			aTokens.forEach(function (item) {
				//setSelectedItemById(sId, bSelect?) 
				var oSelected = '';
				var bSelect = oList.getItems().some(function (element) {
					if (element.getTitle() === item.getKey()) {
						oSelected = element;
					}
					return element.getTitle() === item.getKey();
				});
				if (bSelect) {
					oList.setSelectedItem(oSelected);
				}

			});
		},
		onUpdateFinishedCustomer: function (oEvent) {
			var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");
			var aTokens = oControl.getTokens();
			var oList = this.byId("idListPopover");

			aTokens.forEach(function (item) {
				//setSelectedItemById(sId, bSelect?) 
				var oSelected = '';
				var bSelect = oList.getItems().some(function (element) {
					if (element.getTitle() === item.getKey()) {
						oSelected = element;
					}
					return element.getTitle() === item.getKey();
				});
				if (bSelect) {
					oList.setSelectedItem(oSelected);
				}

			});
		},
		onBeforeOpenCustomer: function (oEvent) {
			//	if (flagCustomerDrop == true) {
			var aFilter = [];
			var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");
			var oList = this.byId("idListPopover");
			oList.removeSelections(true);
			var oBinding = oList.getBinding("items");
			aFilter.push(new Filter("IntUser", FilterOperator.EQ, internalGroup));
			oBinding.filter(aFilter);
			//flagCustomerDrop = false;
			//}

		},
		onSearchLocation: function (oEvent) {
			var oList = this.byId("idListPopoverLocation");
			if (oList) {

				var aFilter = [];
				var sQuery = oEvent.getParameter("newValue");
				if (sQuery) {
					aFilter.push(new Filter("Search", FilterOperator.Contains, sQuery));
					aFilter.push(new Filter("IntUser", FilterOperator.EQ, internalGroup));
					//	aFilter.push(new Filter("BpNumber", FilterOperator.EQ, sQuery));
				}

				// filter binding

				var oBinding = oList.getBinding("items");
				oBinding.filter(aFilter);
			}
		},
		onSearchCustomer: function (oEvent) {
			var oList = this.byId("idListPopover");
			if (oList) {

				var aFilter = [];
				var sQuery = oEvent.getParameter("newValue");
				if (sQuery) {
					aFilter.push(new Filter("Search", FilterOperator.Contains, sQuery));
					aFilter.push(new Filter("IntUser", FilterOperator.EQ, internalGroup));
					//	aFilter.push(new Filter("BpNumber", FilterOperator.EQ, sQuery));
				}

				// filter binding

				var oBinding = oList.getBinding("items");
				oBinding.filter(aFilter);
			}

		},

		_fnSetFilterWidth: function () {
			var oSmartFilterBarAggregations = this.getView().byId("idSmartFilterBar").getAggregation("content");
			var ControlName;
			if (!$.isEmptyObject(oSmartFilterBarAggregations)) {
				for (var i = 0; i < oSmartFilterBarAggregations.length; i++) {
					ControlName = sap.ui.getCore().byId(oSmartFilterBarAggregations[i].getId()).getMetadata().getName();
					if (ControlName.search("AlignedFlowLayout") > 0) {
						sap.ui.getCore().byId(oSmartFilterBarAggregations[i].getId()).setMinItemWidth("15rem");
						sap.ui.getCore().byId(oSmartFilterBarAggregations[i].getId()).setMaxItemWidth("20rem");
					}
				}
			}
		},

		handleMessagePopoverPress: function (oEvt) {
			oMessagePopover.toggle(oEvt.getSource());
		},
		onDataReceived: function (oEvent) {

			var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
			// errorData.push(JSON.parse(oError.responseText).error.message.value);
			errorData = [];
			var arr = [];
			arr = oEvent.mParameters.oSource.oDataState.mChangedProperties.modelMessages;
			if (!Boolean(oEvent.mParameters.mParameters.data)) {
				for (var i = 0; i < arr.length; i++) {
					if (arr[i].code !== "" && !(arr[i].code.includes("EXCEPTION")) && !(arr[i].message.includes("Exception")) && arr[i].type !==
						"None") {
						errorData.push({
							"description": arr[i].message,
							"type": arr[i].type,
							"title": arr[i].message
						});

					}
				}
			}

			this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);
			this.byId("messagePopoverBtn").setType(sap.m.ButtonType.Emphasized);
			this.byId("messagePopoverBtn").setText(errorData.length);
			if (errorData.length > 0) {
				oMessagePopover.toggle(this.byId("messagePopoverBtn"));
			}
		},

		getUserDetails: function () {
			//var url = "/sap/fiori/bpappsshellplugin/services/userapi/attributes?multiValuesAsArrays=true";
			// var url = "/sap/fiori/bpappsshellplugin/UserAdmin_API/users/groups?userId=" + userInfoService.getId();
			var userGroups;
			$.ajax({
				url: "/UserAdmin_API/users/groups?userId=" + sap.ushell.Container.getService("UserInfo").getId(),
				method: "GET",
				contentType: "application/json",

				success: function (result2) {
					userGroups = result2.groups;
					// check if only 1 grp is assinged
					if (Boolean(userGroups) && (!Array.isArray(userGroups))) {
						userGroups = Array(userGroups);
					}
					this.bFlag4 = result2.groups.find(function (ele) {
						if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Management/) > -1)) {
							return true;
						}
					});
					if (!this.bFlag4) {
						this.bFlag4 = result2.groups.find(function (ele) {
							if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Via(\s?)Load(\s?)Id/) > -1)) { // checking if load id group is present for user
								return true;
							}
						});
					}
					if (this.bFlag4 && this.bFlag4.name) {
						// this.getView().byId("idDuplicate").setVisible(true);
						this.getView().byId("idNewOrder").setVisible(true);
					} else {
						// this.getView().byId("idDuplicate").setVisible(false);
						this.getView().byId("idNewOrder").setVisible(false);
					}
					this.bFlag5 = result2.groups.find(function (ele) {
						if ((ele.name.search(/G(\s?)SCP(\s?)GSD(\s?)PRTL(\s?)Internal(\s?)User/) > -1)) {
							return true;
						}
					});
					if (this.bFlag5 && this.bFlag5.name === "G SCP GSD PRTL Internal User") {
						internalGroup = true;
					} else {
						internalGroup = false;
					}
					this.bFlag6 = result2.groups.find(function (ele) {
						if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Upload/) > -1)) {
							return true;
						}
					});
					if (this.bFlag6 && this.bFlag6.name) {
						this.getView().byId("idBulkOrder").setVisible(true);
					} else {
						this.getView().byId("idBulkOrder").setVisible(false);
					}

				}.bind(this),
				error: function (oError) {},
				complete: function (xhr1, data1) {}.bind(this)
			});

		},
		onBeforeRebindTable: function (oEvent) {

			var that = this;
			var country = 'GB'; // change to MX after local testing

			var language = 'EN';
			if (window.userInfoObj && window.userInfoObj.country) {
				country = window.userInfoObj.country;
				if (country === "DF") {
					country = sap.ui.getCore().getConfiguration().getLocale().getRegion();

				}
			}
			if (window.userInfoObj && window.userInfoObj.language) {
				language = window.userInfoObj.language.toUpperCase();
			}

			var binding = oEvent.getParameter("bindingParams");
			var oFilter = this.getView().byId("idSmartFilterBar").getFilterData();
			var aFs = Object.keys(oFilter);
			var ooFilter;
			if (aFs.indexOf("Country") === -1) {
				ooFilter = new sap.ui.model.Filter("Country", sap.ui.model.FilterOperator.EQ, country);
				binding.filters.push(ooFilter);

			}
			if (aFs.indexOf("Language") === -1) {
				ooFilter = new sap.ui.model.Filter("Language", sap.ui.model.FilterOperator.EQ, language);
				binding.filters.push(ooFilter);

			}
			//date filter
			var VDateRanageFromTo = this.getView().byId("idValueHelpDateRange").getValue();
			if (VDateRanageFromTo !== "") {
				var VDateRanageForm = VDateRanageFromTo.split(" - ")[0];
				var VDateRanageTo = VDateRanageFromTo.split(" - ")[1];
				var vDateRangeStartPart = VDateRanageForm.split("/");
				var vDateRangeStartEnd = VDateRanageTo.split("/");
				var vDateRangeStart = new Date(+vDateRangeStartPart[2], vDateRangeStartPart[1] - 1, +vDateRangeStartPart[0] + 1);
				var vDateRangeEnd = new Date(+vDateRangeStartEnd[2], vDateRangeStartEnd[1] - 1, +vDateRangeStartEnd[0] + 1);
			}
			if (VDateRanageFromTo !== "") {
				binding.filters.push(new sap.ui.model.Filter("Date", "BT", vDateRangeStart, vDateRangeEnd));
			}

		},

		onPressOverflowIcon: function (oEvent) {
			var oButton = oEvent.getSource(),
				oView = this.getView();
			var sPath = oEvent.getSource().getBindingContext().getPath();
			var oModel = new JSONModel(oEvent.getSource().getModel().getProperty(sPath));
			if (!this._pPopover) {
				this._pPopover = Fragment.load({
					id: oView.getId(),
					name: "com.bp.fuels-ordersearch-ui5.view.fragment.MoreDetails",
					controller: this
				}).then(function (oPopover) {
					this._pPopover = oPopover;
					oView.addDependent(oPopover);
					oPopover.bindElement(sPath);
					oPopover.setModel(oModel, 'moreInfo');
					oPopover.openBy(oButton);
				}.bind(this));
			} else {
				this._pPopover.setModel(oModel, 'moreInfo');
				this._pPopover.openBy(oButton);
			}

		},
		handleCloseButton: function (oEvent) {
			this.byId("myPopover").close();
		},
		attachBeforeExport: function (oEvent) {
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var mExcelSettings = oEvent.getParameter("exportSettings");
			//	mExcelSettings.fileName = mExcelSettings.fileName;
			var oExcelDownloadDate = new Date();
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd.MM.yyyy"
			});
			var date = new Date(oExcelDownloadDate),
				val = oDateFormat.format(date);
			mExcelSettings.fileName = mExcelSettings.fileName + "_" + val;
			mExcelSettings.workbook.columns.push({
				label: "Termina Name",
				property: "PlantDesc"
			});
			mExcelSettings.workbook.columns.push({
				label: "Product Name",
				property: "MaterialDesc"
			});
			mExcelSettings.workbook.columns.push({
				label: "Customer Name",
				property: "CustomerName"
			});
			mExcelSettings.workbook.columns.push({
				label: "Location Address",
				// property: "ShipToName" --SS20210614
				property: "DeliveryPointAddress" //++SS20210614
			});
			mExcelSettings.workbook.columns.push({
				label: "UOM",
				property: "Uom"
			});
			var finalColums = mExcelSettings.workbook.columns.filter(function (item) { // to remove Action columns from excel download + SG 020222
				return item.property !== "Action"
			});

			mExcelSettings.workbook.columns = finalColums;
			// end
			/*			mExcelSettings.workbook.columns.push({
							label: "LoadingDate",
							property: "LoadingDate"
						});

						mExcelSettings.workbook.columns.push({
							label: resourceModel.getText("PONumber"),
							property: "PONumber"
						});
						//++SS20210614
						mExcelSettings.workbook.columns.push({
							label: resourceModel.getText("TimeCreated"),
							property: "TimeCreated"
						});
						mExcelSettings.workbook.columns.push({
							label: resourceModel.getText("CreatedById"),
							property: "CreatedByID"
						});
						//++20210614
						mExcelSettings.workbook.columns.push({
							label: resourceModel.getText("CreatedByName"),
							property: "CreatedByName"
						});*/

		},

		onNewOrder: function (oEvent) {
			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			// code added to navigate to Order create via load id if group exists  + SG16032022 
			this.UFlag = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel("userModel").getData()
				.groups.find(function (ele) {
					if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Via(\s?)Load(\s?)Id/) > -1)) {
						return true;
					}
				});
			if (this.UFlag) {
				var sShellPath = "OrdJourneyLoadid-Display"; // "#Order-New" via load id;
				this.oCrossAppNav.toExternal({
					target: {
						shellHash: sShellPath
					}
				});
			} else {
				var sShellPath = "NewOrderV2-Display"; // "#Order-New";
				this.oCrossAppNav.toExternal({
					target: {
						shellHash: sShellPath
					}
				});
			}
		},
		onBulkOrder: function () {
			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			//var country = 'MX';
			var countryHungary = this.getView().getModel("userapiModel");
			var country = countryHungary.getData().country;
			if (country === "DF") {
				country = "GB";

			}
			/*if (window.userInfoObj && window.userInfoObj.country) {
				country = window.userInfoObj.country;
			}*/
			/*	if (country === "PT" || country === "ES" || country === "HU") {
					var sShellPath = "#Order-Upload";
				} else {*/
			var sShellPath = "#Bulkorder-Upload"; //"#Order-Upload";
			//	}
			this.oCrossAppNav.toExternal({
				target: {
					shellHash: sShellPath
				}
			});

		},
		/*_onMasterMatched: function () {
			var supplierID;
			var startupParams = this.getOwnerComponent().getComponentData().startupParameters; // get Startup params from Owner Component
			if ((startupParams.supplierID && startupParams.supplierID[0])) {
				this.getRouter().navTo("object", {
					supplierID: startupParams.supplierID[0] // read Supplier ID. Every parameter is placed in an array therefore [0] holds the value
				}, true);
			} else {
				this.getOwnerComponent().oListSelector.oWhenListLoadingIsDone.then(
					function (mParams) {
						if (mParams.list.getMode() === "None") {
							return;
						}
						supplierID = mParams.firstListitem.getBindingContext().getProperty("SupplierID");
						this.getRouter().navTo("object", {
							supplierID: supplierID
						}, true);
					}.bind(this),
					function (mParams) {
						if (mParams.error) {
							return;
						}
						this.getRouter().getTargets().display("detailNoObjectsAvailable");
					}.bind(this)
				);
			}

		},*/
		// _refreshTable: function () {
		// 	//explicitely trigger search because table freezes upon navigation
		// 	//can be removed if performance is an issue
		// 	this.getView().byId("idSmartFilterBar").search();
		// },

		/*		_navTodetailItemDetails: function (sOrderNumber, sOrderItemNo) {
					this.oRouter.navTo("detailed", {
						objectId: sOrderNumber,
						itemNo: sOrderItemNo
					});
				},*/

		onPressActionBtn: function (evt) {
			var oSource = evt.getSource();
			var sOrderNumber = oSource.getBindingContext().getObject(oSource.getBindingContext().getPath()).OrderNumber;
			var sOrderItemNo = evt.getSource().getBindingContext().getObject(oSource.getBindingContext().getPath()).OrderItemNo;
			var sCanEdit = oSource.getParent().getBindingContext().getProperty("CanEdit");
			var sCanCopy = oSource.getParent().getBindingContext().getProperty("CanCopy");
			//++20220524 Sustain Start Poland Order Change adjustments
			/*var sOrderStatusMsg = oSource.getParent().getBindingContext().getProperty("OrdStausMessage");*/
			//++20220524 Sustain End Poland Order Change adjustments
			//Cancel Button Visibility Logic
			this.bFlagCan = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel("userModel").getData()
				.groups.find(function (ele) {
					if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Cancel/) > -1)) {
						return true;
					}
				});
			var sCancel;
			if (this.bFlagCan && this.bFlagCan.name) {
				sCancel = true;
			} else {
				sCancel = false;
			}

			//Edit Button Visibility logic
			this.bFlagEdit = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel("userModel").getData()
				.groups.find(function (ele) {
					if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Change/) > -1)) {
						return true;
					}
				});

			var sEdit;
			if (this.bFlagEdit && this.bFlagEdit.name && sCanEdit) {
				sEdit = true;
			} else {
				sEdit = false;
			}

			//Edit Button Visibility logic
			this.bFlagDup = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel("userModel").getData()
				.groups.find(function (ele) {
					if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Management/) > -1)) {
						return true;
					}
				});
			// to check if loadid group is present
			if (!this.bFlagDup) {
				this.bFlagDup = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel("userModel").getData()
					.groups.find(function (ele) {
						if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Via(\s?)Load(\s?)Id/) > -1)) {
							return true;
						}
					});
			}
			var sDuplicate;
			if (this.bFlagDup && this.bFlagDup.name && sCanCopy) {
				sDuplicate = true;
			} else {
				sDuplicate = false;
			}
			////////
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			//oFilter2 = this.getView().byId("idSmartFilterBar").getFilterData();
			///////////		
			var a = new sap.m.ActionSheet({
				buttons: [new sap.m.Button({
						text: resourceModel.getText("view"),
						icon: "sap-icon://detail-view",
						press: function (evt) {
							this.getOwnerComponent().getRouter().navTo("detailed", {
								objectId: sOrderNumber,
								itemNo: sOrderItemNo
							});
						}.bind(this)
					}),
					new sap.m.Button({
						text: resourceModel.getText("copyorder"),
						icon: "sap-icon://copy",
						enabled: sDuplicate,
						press: function (evt) {
							this.UFlag = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel(
									"userModel").getData()
								.groups.find(function (ele) {
									if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Via(\s?)Load(\s?)Id/) > -1)) {
										return true;
									}
								});
							if (this.UFlag) {
								this.oCrossAppNav.toExternal({
									target: {
										shellHash: "OrdJourneyLoadid-Display?" + "OrderNo=" + sOrderNumber + "&mode=" + 'Duplicate'
									}
								});
							} else {

								this.oCrossAppNav.toExternal({
									target: {
										shellHash: "NewOrderV2-Display?" + "OrderNo=" + sOrderNumber + "&mode=" + 'Duplicate'
									}
									/*	params: {
											"OrderNo": sOrderNumber,
											"mode": "Duplicate"
										}*/

								});
							}
						}.bind(this)
					}),

					new sap.m.Button({
						text: resourceModel.getText("editorder"),
						icon: "sap-icon://edit",
						enabled: sEdit,
						press: function (evt) {
							//++20220524 Sustain Start Poland Order Change adjustments
							//To add a popup status msg if there is any for poland users
							/*if (window.userInfoObj.country === 'PL' && sOrderStatusMsg && sOrderStatusMsg !== "") {
								var cancel = this.getView().getModel("i18n").getResourceBundle().getText("cancel");
								sap.m.MessageBox.information(sOrderStatusMsg, {
									actions: ["Ok", cancel],
									onClose: function (sAction) {
										if (sAction === "Ok") {
											this.oCrossAppNav.toExternal({
												target: {
													shellHash: "NewOrderV2-Display?" + "OrderNo=" + sOrderNumber
												}
											});
										}
									}.bind(this)
								});
							} else {*/
							//++20220524 Sustain Start Poland Order Change adjustments
							this.UFlag = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel(
									"userModel").getData()
								.groups.find(function (ele) {
									if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Via(\s?)Load(\s?)Id/) > -1)) {
										return true;
									}
								});
							if (this.UFlag) {
								this.oCrossAppNav.toExternal({
									target: {
										shellHash: "OrdJourneyLoadid-Display?" + "OrderNo=" + sOrderNumber
									}
								});
							} else {
								this.oCrossAppNav.toExternal({
									target: {
										shellHash: "NewOrderV2-Display?" + "OrderNo=" + sOrderNumber
									}

								});
							}
							//++20220524 Sustain Start Poland Order Change adjustments
							/*}*/
							//++20220524 Sustain End Poland Order Change adjustments
						}.bind(this)
					})
					// Removing Cancel Button from Search Screen
					/*			new sap.m.Button({
									text: resourceModel.getText("cancelorder"),
									icon: "sap-icon://delete",
									enabled: sCancel,
									press: function (evt) {

										this.onOrderCancel(sOrderNumber, sOrderItemNo);

									}.bind(this)
								})*/

				]
			});

			a.openBy(evt.getSource());
		},

		onOrderCancel: function (sOrderNumber, sOrderItemNo) {
			var that = this;
			this.getOwnerComponent().getModel().read("/OrderReadSet", {
				urlParameters: {
					'$expand': "BapiretOrderRead"
				},
				filters: [new sap.ui.model.Filter('OrderNumber', 'EQ', sOrderNumber), new sap.ui.model.Filter('EditMode', 'EQ', 'CANCEL'),

				],

				success: function (response) {
					if (response.results[0].BapiretOrderRead.results.length > 0) {
						//set Error message
						var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
						errorData = [];
						response.results[0].BapiretOrderRead.results.forEach(function (item) {
							var errMessageStruct = {
								"description": item.Message,
								"type": 'Error',
								"title": item.Message
							};
							errorData.push(errMessageStruct);
							that.byId("messagePopoverBtn").setType(sap.m.ButtonType.Emphasized);
							that.byId("messagePopoverBtn").setText(errorData.length);

						});

						this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);

					} else {
						this.getOwnerComponent().getRouter().navTo("OrdCancel", {
							objectId: sOrderNumber,
							itemNo: sOrderItemNo
						});
					}
				}.bind(this),
				error: function (err) {
					this.getView().setBusy(false);
				}.bind(this)

			});

		},
		// 10 jan deselection all locations-- start
		onFnDeselectAllLOC: function () {
			this.getView().byId("idListPopoverLocation").removeSelections(true);

			var oControl = this.byId('idSmartFilterBar').getControlByKey("ShipToNumber");
			var vLen = oControl.getTokens().length;
			var aTokens = oControl.getTokens();
			for (var i = 0; i < vLen; i++) {

				aTokens.splice(0, 1);
			}
			oControl.setTokens(aTokens);

		},
		//DateDefault Changes
		onPressToDateRange: function (oEvent) {
			var oView = this.getView();
			var getFromDate = oEvent.getSource().getProperty("value").split(" - ")[0];
			var gettoDate = oEvent.getSource().getProperty("value").split(" - ")[1];
			// check date field is blank 
			if (getFromDate !== "" && (gettoDate !== "" || gettoDate === undefined)) {
				var fromDate = new Date(getFromDate.substring(6, 10), getFromDate.substring(3, 5) - 1, getFromDate.substring(0, 2));
				var toDate = new Date(gettoDate.substring(6, 10), gettoDate.substring(3, 5) - 1, gettoDate.substring(0, 2));
				if (!this.oDialog1) {
					this.oDialog1 = sap.ui.xmlfragment("com.bp.fuels-ordersearch-ui5.view.fragment.dateRangeFrag", this);
				}
				oView.addDependent(this.oDialog1);

				var oCalendar = sap.ui.getCore().byId("calendar");
				var oCalendar1 = sap.ui.getCore().byId("calendar1");
				oCalendar.removeAllSelectedDates();
				//	oCalendar1.removeAllSelectedDates();
				oCalendar.addSelectedDate(new DateRange({
					startDate: new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate())
				}));

				oCalendar.focusDate(new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate()));
				//	oCalendar1.focusDate(new Date(toDate.getFullYear(), toDate.getMonth(), toDate.getDate()));
				sap.ui.getCore().byId("selectedDateFrom").setValue(this.oFormatYyyymmdd.format(fromDate));
				sap.ui.getCore().byId("selectedDateTo").setValue(this.oFormatYyyymmdd.format(toDate));

				this.oDialog1.open();

			} else {
				var toDate = new Date();
				var currentDate = new Date();
				var fromDate = new Date(currentDate.setMonth(currentDate.getMonth() - 1));
				if (!this.oDialog1) {
					this.oDialog1 = sap.ui.xmlfragment("com.bp.fuels-ordersearch-ui5.view.fragment.dateRangeFrag", this);
				}
				oView.addDependent(this.oDialog1);
				var oCalendar = sap.ui.getCore().byId("calendar");
				var oCalendar1 = sap.ui.getCore().byId("calendar1");
				oCalendar.removeAllSelectedDates();
				var onewDate = new Date();

				oCalendar.addSelectedDate(new DateRange({
					startDate: new Date(onewDate.getFullYear(), onewDate.getMonth() - 1, onewDate.getDate())
				}));

				oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth() - 1, onewDate.getDate()));

				// start -30/12/2021 change in focus for 2nd calendar
				var oCalendar1 = sap.ui.getCore().byId("calendar1");
				oCalendar1.removeAllSelectedDates();
				// var onewDate1 = new Date();

				oCalendar1.addSelectedDate(new DateRange({
					startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate())
				}));

				oCalendar1.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate()));
				//end -30/12/2021 change in focus for 2nd calendar
				sap.ui.getCore().byId("selectedDateFrom").setValue(this.oFormatYyyymmdd.format(fromDate));
				sap.ui.getCore().byId("selectedDateTo").setValue(this.oFormatYyyymmdd.format(toDate));
				sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
				sap.ui.getCore().byId("selectedDateTo").setValueState("None");
				this.oDialog1.open();
			}

		},
		fnClosesDialogox: function (oEvent) {
			var ofromDate = sap.ui.getCore().byId("selectedDateFrom").getValue();
			var oToDate = sap.ui.getCore().byId("selectedDateTo").getValue();
			if (ofromDate != "" && oToDate != "") {
				this.getView().byId("idSmartFilterBar").getControlByKey("Date").setValue(ofromDate + " - " + oToDate);
			} else {
				this.getView().byId("idSmartFilterBar").getControlByKey("Date").setValue("");
				sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
				sap.ui.getCore().byId("selectedDateTo").setValueState("None");

			}

			var getstatusFrom = sap.ui.getCore().byId("selectedDateFrom").getValueState();
			var getstatusTo = sap.ui.getCore().byId("selectedDateTo").getValueState();
			if (getstatusFrom === "Error" || getstatusTo === "Error") {
				if (showerrormsgFlag) {
					var resourceModel = this.getView().getModel("i18n").getResourceBundle();
					sap.m.MessageToast.show(resourceModel.getText("selectionError2"));
					showerrormsgFlag = "";
				} else {
					var resourceModel = this.getView().getModel("i18n").getResourceBundle();
					sap.m.MessageToast.show(resourceModel.getText("datecheckVal"));
				}
			} else {
				this.oDialog1.close();
				//	this.getView().byId("idInputValueHelp").setValue("");
				//	this.getView().byId("idInputValueHelp1").setValue("");
			}
		},
		fnAbortDialogox: function (oEvent) {
			// var ValueHelpDate = this.getView().byId("idValueHelpDateRange");
			// ValueHelpDate.setValue("");
			this.getView().byId("idSmartFilterBar").getControlByKey("Date").setValue("");
			this.oDialog1.close();
			// this.oDialog1.destroy();
		},
		handleSelectToday: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");

			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date()
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date()
			}));
			oCalendar.focusDate(new Date());
			oCalendar1.focusDate(new Date());
			this._updateText(oCalendar, oCalendar1);
		},
		handleSelectYesterady: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");
			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			var onewDate = new Date();

			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 1)
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 1)
			}));
			oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 1));
			oCalendar1.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 1));
			this._updateText(oCalendar, oCalendar1);
		},
		handleSelectLst7Days: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");
			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			var onewDate = new Date();

			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 7)
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date()
			}));
			oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 7));
			oCalendar1.focusDate(new Date());
			this._updateText(oCalendar, oCalendar1);
		},
		handleSelectLstMonth: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");
			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			var onewDate = new Date();

			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth() - 1, 1)
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), 0)
			}));
			oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth() - 1, 1));
			oCalendar1.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), 0));
			this._updateText(oCalendar, oCalendar1);
		},
		handleSelectThisMonth: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");
			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			var onewDate = new Date();

			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), 1)
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth() + 1, 0)
			}));
			oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), 1));
			oCalendar1.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth() + 1, 0));
			this._updateText(oCalendar, oCalendar1);
		},
		changeStartDate: function (evt) {

			var oSDate = evt.getParameters("NewValue").newValue;
			if (oSDate.substring(6, 10).length < 4) {

				sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");
			} else {
				var oSDateCheck = oSDate.substring(0, 2) + "/" + oSDate.substring(3, 5) + "/" + oSDate.substring(6, 10);
				var pattern =
					/^((0[1-9]|[12][0-9]|3[01])(\/)(0[13578]|1[02]))|((0[1-9]|[12][0-9])(\/)(02))|((0[1-9]|[12][0-9]|3[0])(\/)(0[469]|11))(\/)\d{4}$/;
				var oEDate = sap.ui.getCore().byId("selectedDateTo").getValue();
				oEDate = oEDate.substring(6, 10) + " " + oEDate.substring(3, 5) + " " + oEDate.substring(0, 2);
				this.oEnddate = new Date(oEDate);
				var resourceModel = this.getView().getModel("i18n").getResourceBundle();
				if (pattern.test(oSDateCheck) === true) {
					oSDate = new Date(oSDate.substring(6, 10), oSDate.substring(3, 5) - 1, oSDate.substring(0, 2));
					//oneyear date validation -- 11 jan
					var sdiff = Math.abs(oSDate.getTime() - this.oEnddate.getTime());
					var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));
					if (oSDate > this.oEnddate) {
						sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");
						var resourceModel = this.getView().getModel("i18n").getResourceBundle();
						sap.ui.getCore().byId("selectedDateFrom").setValueStateText(resourceModel.getText("datecheckVal"));

					} else if (sdiffD > 365) {

						sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");
						//sap.ui.getCore().byId("selectedDateTo").setValueState("Error");
						sap.ui.getCore().byId("selectedDateFrom").setValueStateText(resourceModel.getText("selectionError2"));
						showerrormsgFlag = true;
						//end
					} else {
						var oCalendar = sap.ui.getCore().byId("calendar");
						oCalendar.removeAllSelectedDates();
						oCalendar.addSelectedDate(new DateRange({
							startDate: oSDate
						}));
						//oCalendar.focusDate(oSDate);
						sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
						sap.ui.getCore().byId("selectedDateTo").setValueState("None");
					}
					oCalendar.focusDate(oSDate);
				} else {
					sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");

				}
			}
		},
		changeEndDate: function (evt) {

			var oEDate = evt.getParameters("NewValue").newValue;
			if (oEDate.substring(6, 10).length < 4) {

				sap.ui.getCore().byId("selectedDateTo").setValueState("Error");
				sap.ui.getCore().byId("selectedDateTo").setValueStateText("Invalid entry");
			} else {
				var oEDateCheck = oEDate.substring(0, 2) + "/" + oEDate.substring(3, 5) + "/" + oEDate.substring(6, 10);
				var pattern =
					/^((0[1-9]|[12][0-9]|3[01])(\/)(0[13578]|1[02]))|((0[1-9]|[12][0-9])(\/)(02))|((0[1-9]|[12][0-9]|3[0])(\/)(0[469]|11))(\/)\d{4}$/;

				if (pattern.test(oEDateCheck) === true) {
					oEDate = oEDate.substring(6, 10) + " " + oEDate.substring(3, 5) + " " + oEDate.substring(0, 2);
					oEDate = new Date(oEDate);
					var getStartdate = sap.ui.getCore().byId("selectedDateFrom").getValue();
					getStartdate = new Date(getStartdate.substring(6, 10), getStartdate.substring(3, 5) - 1, getStartdate.substring(0, 2));
					var resourceModel = this.getView().getModel("i18n").getResourceBundle();
					//oneyear date validation -- 11 jan
					var sdiff = Math.abs(getStartdate.getTime() - oEDate.getTime());
					var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));
					if (oEDate < getStartdate) {
						sap.ui.getCore().byId("selectedDateTo").setValueState("Error");

						sap.ui.getCore().byId("selectedDateTo").setValueStateText(resourceModel.getText("datecheckVal"));

						this.getView().byId("selectedDateFrom").setValueState("None");
						var oCalendar = sap.ui.getCore().byId("calendar1");
						oCalendar.removeAllSelectedDates();
						oCalendar.addSelectedDate(new DateRange({
							startDate: oEDate
						}));

					} else if (sdiffD > 365) {

						sap.ui.getCore().byId("selectedDateTo").setValueState("Error");
						//sap.ui.getCore().byId("selectedDateTo").setValueState("Error");
						sap.ui.getCore().byId("selectedDateTo").setValueStateText(resourceModel.getText("selectionError2"));
						showerrormsgFlag = true;
						//end
					} else {

						sap.ui.getCore().byId("selectedDateTo").setValueState("None");
						sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
						var oCalendar = sap.ui.getCore().byId("calendar1");
						oCalendar.removeAllSelectedDates();
						oCalendar.addSelectedDate(new DateRange({
							startDate: oEDate
						}));
					}
					oCalendar.focusDate(oEDate);
				} else {
					sap.ui.getCore().byId("selectedDateTo").setValueState("Error");

				}
			}
		},
		handleCalendarSelect: function (oEvent) {

			var oCalendar = oEvent.getSource();
			this._updateTextClickTo(oCalendar.getSelectedDates()[0]);
		},
		handleCalendarSelectTo: function (oEvent) {
			var oCalendar = oEvent.getSource();
			this._updateTextClickFrom(oCalendar.getSelectedDates()[0]);
		},
		_updateTextClickTo: function (oCalendar) {
			var oSelectedDateFrom = sap.ui.getCore().byId("selectedDateFrom");
			var oEDate = sap.ui.getCore().byId("selectedDateTo").getValue();
			oEDate = oEDate.substring(6, 10) + " " + oEDate.substring(3, 5) + " " + oEDate.substring(0, 2);
			var oEnddate = new Date(oEDate);
			var oSDate = oCalendar.getProperty("startDate");
			var sdiff = Math.abs(oSDate.getTime() - oEnddate.getTime());
			var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			showerrormsgFlag = "";
			if (oCalendar !== undefined) {
				this.oStartdate = oCalendar.getStartDate();

				oSelectedDateFrom.setValue(this.oFormatYyyymmdd.format(this.oStartdate));
				vFlagTo = true;

				//	this.fnSetDate(vFlagTo, vFlagFrom);
			}
			if (oSDate > oEnddate) {
				sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");

				sap.m.MessageToast.show(resourceModel.getText("datecheckVal"));
			} else if (sdiffD > 365) {
				sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");

				sap.m.MessageToast.show(resourceModel.getText("selectionError2"));
				showerrormsgFlag = true;

			} else {

				sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
				sap.ui.getCore().byId("selectedDateTo").setValueState("None");
			}
		},
		_updateTextClickFrom: function (oCalendar) {
			var oSelectedDateTo = sap.ui.getCore().byId("selectedDateTo");
			var oSDate = sap.ui.getCore().byId("selectedDateFrom").getValue();
			oSDate = oSDate.substring(6, 10) + " " + oSDate.substring(3, 5) + " " + oSDate.substring(0, 2);
			var oSDate = new Date(oSDate);
			var oEDate = oCalendar.getProperty("startDate");
			var sdiff = Math.abs(oSDate.getTime() - oEDate.getTime());
			var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			showerrormsgFlag = "";

			if (oCalendar !== undefined) {
				this.oEnddate = oCalendar.getStartDate();
				oSelectedDateTo.setValue(this.oFormatYyyymmdd.format(this.oEnddate));
				vFlagFrom = true;
				//	this.fnSetDate(vFlagTo, vFlagFrom);
			}
			if (oEDate < oSDate) {
				sap.ui.getCore().byId("selectedDateTo").setValueState("Error");

				sap.m.MessageToast.show(resourceModel.getText("datecheckVal"));
			} else if (sdiffD > 365) {
				sap.ui.getCore().byId("selectedDateTo").setValueState("Error");

				sap.m.MessageToast.show(resourceModel.getText("selectionError2"));
				showerrormsgFlag = true;

			} else {

				sap.ui.getCore().byId("selectedDateTo").setValueState("None");
				sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
			}
		},
		_updateText: function (oCalendar, oCalendar1) {
			var oSelectedDateFrom = sap.ui.getCore().byId("selectedDateFrom"),
				oSelectedDateTo = sap.ui.getCore().byId("selectedDateTo");
			// var oSelectedDateFrom1 = this.getView().byId("selectedDateFrom1"),
			// 	oSelectedDateTo1 = this.getView().byId("selectedDateTo1");
			var ValueHelpDate = this.getView().byId("idValueHelpDateRange");

			var aSelectedDates = oCalendar.getSelectedDates();
			var aSelectedDatesEnd = oCalendar1.getSelectedDates();

			this.oStartdate = aSelectedDates[0].getStartDate();
			this.oEnddate = aSelectedDatesEnd[0].getStartDate();
			// oSelectedDateFrom.setValue(this.oStartdate);
			// oSelectedDateTo.setValue(this.oEnddate);
			oSelectedDateFrom.setValue(this.oFormatYyyymmdd.format(this.oStartdate));
			oSelectedDateTo.setValue(this.oFormatYyyymmdd.format(this.oEnddate));
			// oSelectedDateFrom1.setValue(this.oFormatYyyymmdd.format(this.oStartdate));
			// oSelectedDateTo1.setValue(this.oFormatYyyymmdd.format(this.oEnddate));

			var vMargedDate = this.oStartdate + " - " + this.oEnddate;
			// var vMargedDate = this.oFormatYyyymmdd.format(this.oStartdate) + " - " + this.oFormatYyyymmdd.format(this.oEnddate);
			ValueHelpDate.setValue(vMargedDate);
		},
		// date custom field save to variant +SG17012022
		onBeforeVariantFetch: function (oevt) {
			var getTokenLength = this.getView().byId("idSmartFilterBar").getControlByKey("CustomerNumber").getTokens().length;
			var customFiltersObject = this.getView().byId("idValueHelpDateRange").getValue();
			this.byId("idSmartFilterBar").setFilterData({
				_CUSTOM: customFiltersObject
			});
		},
		onAfterVariantLoad: function () {
			var getTokenLength = this.getView().byId("idSmartFilterBar").getControlByKey("CustomerNumber").getTokens().length;
			if (getTokenLength === 0) {

				setflag = true;
			}
			var filterData = this.byId("idSmartFilterBar").getFilterData();
			this.getView().byId("idValueHelpDateRange").setValue(filterData._CUSTOM);
			//this.getModel("customFilterModel").setData(filterData._CUSTOM);	
		},
		// navigate to multiorderreport Petchem
		onMultiorder: function () {
			sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {

				oService.toExternal({
					target: {
						semanticObject: "CheckStatusMultiOrder",
						action: "Display"
					}

				});

				// do something with sHref
			});

		}
	});
});
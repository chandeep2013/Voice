jQuery.sap.require("jquery.sap.storage");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/ValueState",
	"sap/ui/core/routing/History",
	"sap/base/Log",
	"com/bp/fuels-ordersearch-ui5/util/formatter",
	"sap/m/Dialog",
	"sap/m/DialogType"

], function (Controller, JSONModel, MessageBox, MessageToast, ValueState, History, Log, formatter, Dialog, DialogType) {
	"use strict";

	return Controller.extend("com.bp.fuels-ordersearch-ui5.controller.detailed", {
		formatter: formatter,
		onInit: function () {
			var model = new sap.ui.model.json.JSONModel();
			model.loadData("/services/userapi/attributes?multiValuesAsArrays=true");
			this.getView().setModel(model, "userapiModel");
			//G GSD Order Change - R GSD Order Change
			//G GSD Order Cancel - R GSD Order Cancel - Order Cancel

			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.getRoute("detailed").attachMatched(this._onRouteMatched, this);
			var oRouter = this.getOwnerComponent().getRouter(this);
			oRouter.getRoute("detailed").attachMatched(this._onRouteMatched, this);
			//oRouter.getRoute("detailed").attachPatternMatched(this._onRouteMatched, this);
			this.appNav = true;
			try {
				sap.ui.getCore().byId("backBtn").attachPress(this, function (oEvent) {
					this._navBack(oEvent);
				}.bind(this));
			} catch (err) {
				Log.error(err);
			}
		},
		_navBack: function () {
			//this.getOwnerComponent().getModel("RefreshTableKeys").getData().refresh = true;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash.match(/^DeliveryDetail.*$/)) {
				window.history.go(-1);
			} else {
				oRouter.navTo("Main");
				/*oRouter.navTo("Main", true);*/
			}
		},

		onPressDelivery: function (oEvent) {
			if (this.getView().byId("idStatusIndDel").getValue() === 99) {

			} else if (this.getView().getModel("viewModel").getProperty("/postData/docFlwRead/docIdsDel")) {

				var oViewModel = this.getView().getModel("viewModel");
				var sCustomer = oViewModel.getProperty("/postData/SoldBpNumber");
				var sShipToNumber = oViewModel.getProperty("/postData/ShipBpNumber");
				var sStatusId;
				//var sStatusId = oViewModel.getProperty("/postData/WholeOrderRead/ShipmentStatShipmentRead/0/StatusId");
				var shipmentNumber1 = this.getView().getModel("viewModel").getProperty("/postData/docFlwRead/docIdsDel/0/docNum");
				var shipToNumber1 = this.getView().getModel("viewModel").getProperty("/postData/DeleryNum");
				var soldToNumber1 = this.getView().getModel("viewModel").getProperty("/postData/CustNum");
				var selectedDataOrder = {
					"ShipmentNumber": shipmentNumber1,
					"SoldToPartner": soldToNumber1,
					"ShipToPartner": shipToNumber1
				};
				var stingfySelectedOrder = JSON.stringify(selectedDataOrder);
				if (this.getView().getModel("viewModel").getProperty("/postData/docFlwRead/docIdsDel").length === 1) {
					this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
					var sShellPath = "#DelSearchv2-Display&/DeliveryDetail/" + stingfySelectedOrder;
					//sShellPath = "#DelSearchv2-Display&/DeliveryDetail/" + shipmentNumber1 + "&customer=" + sCustomer  + "&shipToNumber=" + sShipToNumber; 
					this.oCrossAppNav.toExternal({
						target: {
							shellHash: sShellPath
						}
					});
				} else {
					var that = this;
					var dialog = new sap.m.Dialog({
						title: 'Delivery List',
						contentWidth: "550px",
						contentHeight: "300px",
						content: new sap.m.List({
							//mode: "MultiSelect",
							items: {
								path: 'viewModel>/postData/docFlwRead/docIdsDel',
								template: new sap.m.StandardListItem({
									title: "{viewModel>docNum} {viewModel>docDes}",
									type: "Navigation",
									press: function () {
										/*var shipmentNumber = oEvent.getSource("list").mProperties.title.split(" ")[0];*/
										that.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
										var sShellPath = "#DelSearchv2-Display&/DeliveryDetail/" + stingfySelectedOrder;
										//var sShellPath = "#OrderV2-Display&/detailed/" + OrderNumber + "/000010";
										that.oCrossAppNav.toExternal({
											target: {
												shellHash: sShellPath
											}
										});
									}
								})
							}

						}),

						beginButton: new sap.m.Button({
							text: 'Close',
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});

					//to get access to the global model
					this.getView().addDependent(dialog);
					dialog.open();

				}
			}

		},
		onPressMSDS: function (oEvent) {
			var country = window.userInfoObj.country;
			if (country === "DF") {
				country = "GB";

			}
			var language = window.userInfoObj.language.toUpperCase();
			var MaterialId = oEvent.getSource().getBindingContext("viewModel").getObject().BaseMaterialId;
			// var MaterialId = this.getView().getModel("viewModel").getProperty('/postData/ProductNo');
			var sPath = "/MsdsPdfReadSet(Wrkst='" + MaterialId + "',Langu='" + language + "',Land1='" + country + "')/$value";
			var oPDFViewer = new sap.m.PDFViewer();
			this.getView().addDependent(oPDFViewer);
			var sServiceURL = this.getView().getModel().sServiceUrl;
			var sSource = sServiceURL + sPath;
			oPDFViewer.setSource(sSource);
			oPDFViewer.setTitle("PDF Document Preview");
			oPDFViewer.open();
		},

		onPrint: function (oEvent) {
			var oViewModel = this.getView().getModel("viewModel");
			oViewModel.setProperty('/ui/UserLanguage', sap.ushell.Container.getService('UserInfo').getUser().getLanguage());

			//sap.m.MessageToast.show("Record Created Successfully!!!");
			//storing data in session for print
			sessionStorage.setItem('printData', JSON.stringify(oViewModel.getData()));

			//	var url = jQuery.sap.getModulePath('com.bp.fuels-ordersearch-ui5');
			//	url = url + '/OrdPrint.html';
			//	window.open(url);

			//--- Print Formatting Changes
			var oViewID = this.getView().getId();
			var oTitle = this.getView().byId("idTitle").getText();
			var oblocklayout = "";

			var oGridpanel = this.getView().byId("idGridPanel");
			var oCellLength = oGridpanel.getAggregation("content")[0].getAggregation("content").length;

			for (var i = 0; i < oCellLength; i++) {
				var isVisible = oGridpanel.getAggregation("content")[0].getAggregation("content")[i].getProperty("visible");
				if (isVisible === true) {
					document.getElementById(oViewID + "--title" + i + "-inner").style.color = "green";
					var oBlock = this.getView().byId("idBlockCell" + i);
					var oTargetBlock = oBlock.$()[0],
						sTargetContentblock = oTargetBlock.innerHTML;

					oblocklayout += sTargetContentblock + "<hr style='width:100%;text-align:left;margin-left:0;background-color:black'>";
				}

			}
			var oBlockForm = this.getView().byId("SimpleFormDisplay480_Trial");
			var oTargetBlockForm = oBlockForm.$()[0];
			document.getElementById(oViewID + "--formTitle").style.color = "green";
			document.getElementById(oViewID + "--formTitle").style.fontSize = '16px';
			document.getElementById(oViewID + "--formTitle").style.fontWeight = 'normal';
			var sTargetContentblockForm = oTargetBlockForm.innerHTML;
			oblocklayout += sTargetContentblockForm +
				"<hr style='width:100%;font-weight='normal';text-align:left;margin-left:0;background-color:black'>";

			var oSFForm = this.getView().byId("idSFTotal");
			var oTargetSFForm = oSFForm.$()[0];

			if (oTargetSFForm !== undefined) {
				var sTargetContentSFForm = oTargetSFForm.innerHTML;
				oblocklayout += sTargetContentSFForm + "<hr style='width:100%;text-align:left;margin-left:0;background-color:black'>";
			}
			//	oblocklayout += "<br>";
			var oTable = this.getView().byId("idProductTable");
			var oTargetTable = oTable.$()[0];
			var autFlagFrance = this.getView().getModel("viewModel").getProperty("/postData/WholeOrderRead/ShowFranceFields");
			if (oTargetTable !== undefined) {
				var oTableProductsTitle = this.getView().byId("productHeader").getTitle();
				//	document.getElementById(oViewID + "--productHeader-title").style.fontcolor = 'green';
				//	oblocklayout += oTableProductsTitle + "<hr style='width:100%;text-align:left;margin-left:0'>";
				//	var sTargetContentTable = oTargetTable.innerHTML;
				var ohheadProdNo = this.getView().getModel("i18n").getResourceBundle().getText("productNumber");
				var oheadOrder = this.getView().getModel("i18n").getResourceBundle().getText("quantity");
				var oCondition = this.getView().getModel("i18n").getResourceBundle().getText("condition");
				var oAuthNumber = this.getView().getModel("i18n").getResourceBundle().getText("AuthorizationNumber");
				var oTotal = this.getView().getModel("i18n").getResourceBundle().getText("Total");
				var oNetPrce = this.getView().getModel("i18n").getResourceBundle().getText("unitPrice");
				var len = this.getView().getModel("viewModel").getProperty("/postData/products").length;
				if (autFlagFrance === true) {
					oblocklayout += "<h4 style='color:green;line-height:16px'>" + oTableProductsTitle +
						"</h4><hr style='width:100%;text-align:left;margin-left:0;background-color:black'><table style='width:100%'><tr><th>" +
						ohheadProdNo + "</th><th>" + oCondition + "</th><th>" + oheadOrder + "</th><th>" + oAuthNumber + "</th></tr>";
				} else if (window.userInfoObj && window.userInfoObj.country === 'PL') {
					oblocklayout += "<h4 style='color:green;line-height:16px'>" + oTableProductsTitle +
						"</h4><hr style='width:100%;text-align:left;margin-left:0;background-color:black'><table style='width:100%'><tr><th>" +
						ohheadProdNo + "</th><th>" + oCondition + "</th><th>" + oNetPrce + "</th><th>" + oheadOrder + "</th><th>" + oTotal +
						"</th></tr>";
				} else {
					oblocklayout += "<h4 style='color:green;line-height:16px'>" + oTableProductsTitle +
						"</h4><hr style='width:100%;text-align:left;margin-left:0;background-color:black'><table style='width:100%'><tr><th>" +
						ohheadProdNo + "</th><th>" + oCondition + "</th><th>" + oheadOrder + "</th></tr>";
				}
				for (var i = 0; i < len; i++) {
					//var oQuantity = this.getView().getModel("viewModel").getProperty("/postData/products")[i].Quantity;

					var oMatid = this.getView().getModel("viewModel").getProperty("/postData/products")[i].MaterialId;
					var oMatDesc = this.getView().getModel("viewModel").getProperty("/postData/products")[i].MaterialDescription;
					var oStatus = this.getView().getModel("viewModel").getProperty("/postData/products")[i].StatusDescription;
					var oQty = this.getView().getModel("viewModel").getProperty("/postData/products")[i].Quantity;
					var oUom = this.getView().getModel("viewModel").getProperty("/postData/products")[i].Uom;
					var oAuthNum = this.getView().getModel("viewModel").getProperty("/postData/products")[i].AuthorizationNumber;
					var oTotalNum = this.getView().getModel("viewModel").getProperty("/postData/products")[i].NetPrice;
					var oTotalcurrency = this.getView().getModel("viewModel").getProperty("/postData/products")[i].Currency;
					var oUnitPrice = this.getView().getModel("viewModel").getProperty("/postData/products")[i].UnitPrice;
					var oPricingUnit = this.getView().getModel("viewModel").getProperty("/postData/products")[i].PricingUnitUom;
					if (autFlagFrance === true) {
						oblocklayout += "<tr>";
						oblocklayout += "<td>" + oMatDesc + " " + oMatid + "</td><td>" + oStatus + "</td><td>" + oQty + " " + oUom + "</td><td>" +
							oAuthNum + "</td></tr>";
					} else if (window.userInfoObj && window.userInfoObj.country === 'PL') {
						oblocklayout += "<tr>";
						oblocklayout += "<td>" + oMatDesc + " " + oMatid + "</td><td>" + oStatus + "</td><td>" + oUnitPrice + " " + oPricingUnit +
							"</td><td>" + oQty + " " + oUom + "</td><td>" + oTotalNum + " " + oTotalcurrency + "</td></tr>";
					} else {
						oblocklayout += "<tr>";
						oblocklayout += "<td>" + oMatDesc + " " + oMatid + "</td><td>" + oStatus + "</td><td>" + oQty + " " + oUom + "</td></tr>";
					}

				}
				oblocklayout += "</table><hr style='width:100%;text-align:left;margin-left:0;background-color:black'>";
			}
			var oTableCompartment = this.getView().byId("idCompartmentTable");
			var oTargetTableComp = oTableCompartment.$()[0];

			if (oTargetTableComp !== undefined) {
				var oTableCompTitle = this.getView().byId("idCompartmentPageSection").getTitle();
				//	document.getElementById(oViewID + "--idCompartmentPageSection-title").style.color = "green";
				//	oblocklayout += oTableCompTitle + "<hr style='width:100%;text-align:left;margin-left:0'>";
				var sTargetContentTableComp = oTargetTableComp.innerHTML;
				oblocklayout += "<h4 style='color:green;line-height:16px'>" + oTableCompTitle +
					"</h4><hr style='width:100%;text-align:left;margin-left:0;background-color:black'>" + sTargetContentTableComp +
					"<hr style='width:100%;text-align:left;margin-left:0;background-color:black'>";
			}

			var oTableDriver = this.getView().byId("driverTable");
			var oTargetTableDriver = oTableDriver.$()[0];

			if (oTargetTableDriver !== undefined) {
				var oTableDriverTitle = this.getView().byId("DriverPageSection").getTitle();
				//	document.getElementById(oViewID + "--DriverPageSection-title").style.color = "green";
				//	oblocklayout += oTableDriverTitle + "<hr style='width:100%;text-align:left;margin-left:0'>";
				//	var sTargetContentTableDriver = oTargetTableDriver.innerHTML;
				var driverCode = this.getView().getModel("i18n").getResourceBundle().getText("driverCode");
				var licenceNumber = this.getView().getModel("i18n").getResourceBundle().getText("licenceNumber");
				var nationalID = this.getView().getModel("i18n").getResourceBundle().getText("nationalID");
				var name = this.getView().getModel("i18n").getResourceBundle().getText("name");
				var lendriver = this.getView().getModel("viewModel").getProperty("/postData/drivers").length;
				oblocklayout += "<h4 style='color:green;line-height:16px'>" + oTableDriverTitle +
					"</h4><hr style='width:100%;text-align:left;margin-left:0;background-color:black'><table style='width:100%'><tr><th>" +
					driverCode + "</th><th>" + licenceNumber + "</th> <th>" + nationalID +
					"</th><th>" + name + "</th></tr>";
				for (var j = 0; j < lendriver; j++) {
					var oTableDRname = this.getView().getModel("viewModel").getProperty("/postData/drivers")[j].ZzfirstName;
					var oTableDRlastname = this.getView().getModel("viewModel").getProperty("/postData/drivers")[j].ZzlastName;
					var oTableDRLincse = this.getView().getModel("viewModel").getProperty("/postData/drivers")[j].Zzlicenseno;
					var oTableDRNIdD = this.getView().getModel("viewModel").getProperty("/postData/drivers")[j].Zzperscode;
					var oTableDRnum = this.getView().getModel("viewModel").getProperty("/postData/drivers")[j].Zzdrivercode;
					oblocklayout += "<tr>";
					oblocklayout += "<td>" + oTableDRnum + "</td><td>" + oTableDRLincse + "</td><td>" + oTableDRNIdD +
						"</td><td>" + oTableDRname + "," + oTableDRlastname +
						"</td></tr>";
				}

				oblocklayout += "</table><hr style='width:100%;text-align:left;margin-left:0;background-color:black'>";
			}

			var oTableVehical = this.getView().byId("vehicalTable");
			var oTargetTableVehical = oTableVehical.$()[0];

			if (oTargetTableVehical !== undefined) {
				var oTableTruckTitle = this.getView().byId("TruckPageSection").getTitle();
				//	document.getElementById(oViewID + "--TruckPageSection-title").style.color = "green";
				//	oblocklayout += oTableTruckTitle + "<hr style='width:100%;text-align:left;margin-left:0'>";
				//	var sTargetContentTableVehical = oTargetTableVehical.innerHTML;
				var oTabVId = this.getView().getModel("i18n").getResourceBundle().getText("vehicleId");
				var oTabVRegisNum = this.getView().getModel("i18n").getResourceBundle().getText("registrationNumber");
				var oTabVahicalType = this.getView().getModel("i18n").getResourceBundle().getText("vehicleType");
				var lenTruck = this.getView().getModel("viewModel").getProperty("/postData/truck").length;
				oblocklayout += "<h4 style='color:green;line-height:16px'>" + oTableTruckTitle +
					"</h4><hr style='width:100%;text-align:left;margin-left:0;background-color:black'><table style='width:100%'><tr><th>" + oTabVId +
					"</th><th>" + oTabVRegisNum + "</th> <th>" + oTabVahicalType +
					"</th></tr>";
				for (var k = 0; k < lenTruck; k++) {

					var oVehicalType = this.getView().getModel("viewModel").getProperty("/postData/truck")[k].ZzvehTypeDesc;
					var oVehicalNum = this.getView().getModel("viewModel").getProperty("/postData/truck")[k].Zzvehicleid;
					var oRegisNum = this.getView().getModel("viewModel").getProperty("/postData/truck")[k].Zzvehicleno;
					oblocklayout += "<tr>";
					oblocklayout += "<td>" + oVehicalNum + "</td><td>" + oRegisNum + "</td><td>" + oVehicalType + "</td></tr>";
				}

				oblocklayout += "</table><hr style='width:100%;text-align:left;margin-left:0;background-color:black'>";

			}

			var oTableTrailer = this.getView().byId("trailerTable");
			var oTargetTableTrailer = oTableTrailer.$()[0];

			if (oTargetTableTrailer !== undefined) {
				var oTableTrailerTitle = this.getView().byId("TrailerPageSection").getTitle();
				//	document.getElementById(oViewID + "--TrailerPageSection-title").style.color = "green";
				//	oblocklayout += oTableTrailerTitle + "<hr style='width:100%;text-align:left;margin-left:0'>";
				//	var sTargetContentTableTrailer = oTargetTableTrailer.innerHTML;
				var oTabVId = this.getView().getModel("i18n").getResourceBundle().getText("vehicleId");
				var oTabVRegisNum = this.getView().getModel("i18n").getResourceBundle().getText("registrationNumber");
				var oTabVahicalType = this.getView().getModel("i18n").getResourceBundle().getText("vehicleType");
				var lenTrailer = this.getView().getModel("viewModel").getProperty("/postData/trailor").length;
				oblocklayout += "<h4 style='color:green;line-height:16px'>" + oTableTrailerTitle +
					"</h4><hr style='width:100%;text-align:left;margin-left:0;background-color:black'><table style='width:100%'><tr><th>" + oTabVId +
					"</th><th>" + oTabVRegisNum + "</th> <th>" + oTabVahicalType +
					"</th></tr>";
				for (var l = 0; l < lenTrailer; l++) {

					var oTNum = this.getView().getModel("viewModel").getProperty("/postData/trailor")[l].Zzvehicleid;
					var oTVehicalType = this.getView().getModel("viewModel").getProperty("/postData/trailor")[l].ZzvehTypeDesc;
					var oTrialerNum = this.getView().getModel("viewModel").getProperty("/postData/trailor")[l].Zzvehicleno;
					oblocklayout += "<tr>";
					oblocklayout += "<td>" + oTNum + "</td><td>" + oTrialerNum + "</td><td>" + oTVehicalType +
						"</td></tr>";
				}

				oblocklayout += "</table><hr style='width:100%;text-align:left;margin-left:0;background-color:black'>";
			}

			var hContent = "<html><head>" + oTitle +
				"<style>th {text-align: left;}</style></head><body><br><hr style='width:100%;text-align:left;margin-left:0;background-color:black'>";
			var bodyContent = oblocklayout;
			var closeContent = "</body></html>";
			var htmlpage = hContent + bodyContent + closeContent;
			var ctrlString = "width=600px,height=600px";
			var win = window.open("", "PrintWindow", ctrlString);
			win.document.write(htmlpage);
			win.print();
			win.close();

		},
		createMessagePopover: function () {
			this.oMP = new sap.m.MessagePopover({
				items: {
					path: "errorMsgModel>/results",
					template: new sap.m.MessageItem({
						title: "{errorMsgModel>title}",
						type: "{errorMsgModel>type}",
						description: "{errorMsgModel>description}"
					})
				}
			});

			this.getView().byId("messagePopoverBtn").addDependent(this.oMP);
			this.oMP.toggle(this.byId("messagePopoverBtn"));
			this.getOwnerComponent().getModel("errorMsgModel").refresh();
		},
		handleMessagePopoverPress: function (oEvt) {
			if (!this.oMP) {
				this.createMessagePopover();
			}
			this.oMP.toggle(oEvt.getSource());
		},
		_onRouteMatched: function (oEvent) {
			var that = this;
			var oArgs, oView;
			//Shilpi
			this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", []);
			this.byId("messagePopoverBtn").setText("");

			var sSentInfo = this.getView().getModel("i18n").getResourceBundle().getText("sentInformation");

			oArgs = oEvent.getParameter("arguments");
			var oJsonModelView = new JSONModel(sap.ui.require.toUrl("com/bp/fuels-ordersearch-ui5/model/viewModel.json"));
			this.getView().setModel(oJsonModelView, "viewModel");

			// code for language and country
			var country = 'GB'; //change to MX later once local testing is done 
			var language = 'EN';
			if (window.userInfoObj && window.userInfoObj.country) {
				country = window.userInfoObj.country;
				if (country === "DF") {
					country = "GB";

				}
			}
			if (window.userInfoObj && window.userInfoObj.language) {
				language = window.userInfoObj.language.toUpperCase();
			}

			//Cancellation button logic
			//Cancel Button Visibility Logic
			this.bFlagCan = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel("userModel").getData()
				.groups.find(function (ele) {
					if ((ele.name.search(/G(\s?)GSD(\s?)Order(\s?)Cancel/) > -1)) {
						return true;
					}
				});
			var sCancel;
			if (this.bFlagCan && this.bFlagCan.name) {
				sCancel = true;
			} else {
				sCancel = false;
			}

			oJsonModelView.attachRequestCompleted(function () {
				//oArgs.estimateNumber
				this.getView().getModel('viewModel').setProperty('/UI/mode', oArgs.objectId);
				this.getView().setBusy(true);
				this.getOwnerComponent().getModel().read("/OrderReadSet", {

					urlParameters: {
						'$expand': "BapiretOrderRead,ChangeLogsOrderRead,CommentsOrderRead,CompartmentsOrderRead,DocumentflowOrderRead,DriversOrderRead,OrderitemsOrderRead,TrailersOrderRead,TrucksOrderRead,TusdataOrderRead,CompTusdataOrderRead,ControlFlagsOrderRead"

					},
					filters: [new sap.ui.model.Filter('OrderNumber', 'EQ', oArgs.objectId), new sap.ui.model.Filter('EditMode', 'EQ', 'DISPLAY'),
						new sap.ui.model.Filter('CountryCode', 'EQ', country), new sap.ui.model.Filter('Language', 'EQ', language)
					],
					success: function (response) {
						//{++20211207 R-7 adjustments
						that.createMessagePopover();
						this.oMP.toggle(this.byId("messagePopoverBtn"));
						//	}
						if (response.results[0].BapiretOrderRead.results.length > 0) {
							// show in error message 
							var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
							errorData = [];
							var arr = [];
							arr = response.results[0].BapiretOrderRead.results;
							/*		response.results[0].BapiretOrderRead.results.forEach(function (item) {
										var errMessageStruct = {
											"description": item.Message,
											"type": item.type,
											"title": item.Message
										};
										errorData.push(errMessageStruct);

									});*/
							for (var i = 0; i < arr.length; i++) {
								if (arr[i].Type != "D") {

									var type = "";
									switch (arr[i].Type) {
									case "I":
										type = "Information";
										break;
									case "A":
										type = "Error";
										break;
									case "E":
										type = "Error";
										break;
									case "W":
										type = "Warning";
										break;
									}

									var errMessageStruct = {
										"description": arr[i].Message,
										"type": type,
										"title": arr[i].Message
									};
									errorData.push(errMessageStruct);
								}
							}

							this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);
							this.byId("messagePopoverBtn").setType(sap.m.ButtonType.Emphasized);
							this.byId("messagePopoverBtn").setText(errorData.length);
							// that.createMessagePopover();      //--20211207 R-7 adjustments
						}
						this.getView().setBusy(false);
						var oViewModel = this.getView().getModel('viewModel');

						var resObj = response.results[0];

						// assign control flags
						if (resObj.ControlFlagsOrderRead) {
							oViewModel.setProperty("/postData/ControlFlagsOrderRead", resObj.ControlFlagsOrderRead);
						}

						// assign whole order data in single property first
						oViewModel.setProperty("/postData/WholeOrderRead", resObj);

						if (resObj.ShowSentFields.length === 0) {
							this.byId("idTitleSentInfo").setText("");
						} else {
							this.byId("idTitleSentInfo").setText(sSentInfo);
						}

						if (resObj.ShowReqDelDate == true) {
							oViewModel.setProperty("/postData/reqDelDateFromflag", resObj.ReqDelDate);
							// to display time -- issue Mx SG 31 jan
							if (resObj.ReqDelFromTime !== "" && resObj.ReqDelFromTime !== "00:00:00" && country !== "GB") {
								var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
									pattern: "HH:mm aa"
								});
								var oTime = oTimeFormat.format(new Date(1970, 0, 1, resObj.ReqDelFromTime.substring(0, 2), resObj.ReqDelFromTime.substring(
										3, 5), resObj.ReqDelFromTime.substr(6, 8)),
									false);
								oViewModel.setProperty("/postData/reqDelDateFromTime", oTime);
							} else {
								oViewModel.setProperty("/postData/reqDelDateFromTime", "");

							}

							//end
							//to add date if NextdayDel is true
							if (oViewModel.getProperty("/postData/WholeOrderRead/NextdayDel") === true && country === "GB") {
								var oNextdayDelDate = new Date(resObj.ReqDelDate.substring(6, 10), resObj.ReqDelDate.substring(3, 5) - 1, resObj.ReqDelDate
									.substring(0, 2));
								var onewDate = oNextdayDelDate.getDate() + 1;
								oNextdayDelDate = new Date(oNextdayDelDate.getFullYear(), oNextdayDelDate.getMonth(), onewDate);
								var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
									pattern: "dd/MM/yyyy"
								});
								oNextdayDelDate = oDateFormat.format(oNextdayDelDate, false);
								oViewModel.setProperty("/postData/NextdayDelDate", "-" + oNextdayDelDate);
							} else {
								oNextdayDelDate = "";
							}
						} //end
						if (resObj.ShowReqDelDateTo == true) {
							oViewModel.setProperty("/postData/reqDelDateToflag", resObj.ReqDelDateTo);
						}
						if (resObj.ShowLoadingDate == true) {
							oViewModel.setProperty("/postData/loadingDateFromflag", resObj.ReqDelDate);
						}
						if (resObj.ShowLoadingDateTo == true) {
							oViewModel.setProperty("/postData/loadingDateToflag", resObj.ReqDelDateTo);
						}

						if (resObj.CompTusdataOrderRead.results.length > 0) {
							//var resObj5 = resObj.TusdataOrderRead.results[0];
							oViewModel.setProperty("/postData/drivercode", resObj.DriverCode);
							oViewModel.setProperty("/postData/drivername", resObj.DriverName);
							/*var resObj5 = resObj.CompTusdataOrderRead.results;
							if (resObj5 && resObj5.length < 1) {
								var resObj6 = resObj.CompTusdataOrderRead.results[0];
								oViewModel.setProperty("/postData/licenseplate", resObj6.LicensePlate);
								oViewModel.setProperty("/postData/tuTypeDesc", resObj6.TuTypeDesc);
							}*/
							var resObj5 = resObj.TusdataOrderRead.results;
							var resObj6 = resObj.CompTusdataOrderRead.results;
							var resObj8 = resObj.CompTusdataOrderRead.results[0];
							if (resObj5.length > 1) {
								for (var i = 0; i < resObj5.length; i++) {
									var resObj7 = resObj.TusdataOrderRead.results[i];
									for (var j = 0; j < resObj6.length; j++) {
										if (resObj5[i].TuNumber !== resObj6[j].TuNumber) {
											oViewModel.setProperty("/postData/licenseplate", resObj7.LicensePlate);
											oViewModel.setProperty("/postData/tuTypeDesc", resObj7.TuTypeDesc);
										}
									}
								}
							} else {
								oViewModel.setProperty("/postData/licenseplate", resObj8.LicensePlate);
								oViewModel.setProperty("/postData/tuTypeDesc", resObj8.TuTypeDesc);
							}
						}
						//assign products
						if (resObj.OrderitemsOrderRead.results.length > 0) {
							oViewModel.setProperty("/postData/products", resObj.OrderitemsOrderRead.results);

							//Cancellation
							var products = oViewModel.getProperty("/postData/products");

							var sumVolume = 0; //++20211207 R-7 adjustments
							var sumWeight = 0; //++20211207 R-7 adjustments

							if (!$.isEmptyObject(products)) {
								products.forEach(function (oItem, index) {
									if (sCancel == false && oItem.CanCancel == true) {
										oViewModel.getProperty("/postData/products")[index].CanCancel = false;
									} else if (resObj.ControlFlagsOrderRead.HideCancelLineitem) {
										oViewModel.getProperty("/postData/products")[index].CanCancel = false;
									} else if (resObj.CanCancel == false) { //++20211207 R-7 adjustments
										oViewModel.getProperty("/postData/products")[index].CanCancel = false;
									}

									//{++20211207 R-7 adjustments
									if (resObj.Country === 'GB' && oViewModel.getProperty("/postData/products")[index].CanCancel) {
										sumVolume = sumVolume + parseFloat(oItem.Quantity.replace(/\,/g, ''));
										sumWeight = sumWeight + parseFloat(oItem.Quantity.replace(/\,/g, '')) * parseFloat(oItem.Density.replace(/\,/g, ''));

									}
									oItem.OrderVolume = parseFloat(oItem.OrderVolume.replace(/\,/g, ''));
									//++20211207 R-7 adjustments}

								});

								//{++20211207 R-7 adjustments - Show weight indicator and don't allow if min ord req doen't meet in case of cancellation
								if (resObj.Country === 'GB') {
									oViewModel.setProperty("/postData/sumVolume", sumVolume);
									oViewModel.setProperty("/postData/sumWeight", sumWeight);
									oViewModel.setProperty("/postData/weightLimitPercentage", sumWeight / parseInt(resObj.Maxweight.replace(/\,/g, ''), 10) *
										100);
									var minOrderVolume = Math.max.apply(Math, products.map(function (o) {
										return o.OrderVolume;
									}));
									oViewModel.setProperty("/postData/minOrderVolume", minOrderVolume);
									oViewModel.setProperty("/postData/WholeOrderRead/Maxweight", oViewModel.getProperty("/postData/WholeOrderRead/Maxweight")
										.replace(/\,/g, '')
									);

									//{++20211207 R-7 adjustments - Hide progress bar if no items are available for cancellation

									if (parseInt(oViewModel.getProperty("/postData/WholeOrderRead/Maxweight")) > 0 && products.some(function (ele) {
											return ele.CanCancel === true;
										})) {
										this.getView().byId("idBasketWeightProgress").setVisible(true);

									} else {
										this.getView().byId("idBasketWeightProgress").setVisible(false);
									}

									//++20211207 R-7 adjustments}	

								}
								//++20211207 R-7 adjustments}
							}

						}

						// assign compartments
						this.byId("idCompartmentPageSection").setVisible(false);
						if (resObj.CompTusdataOrderRead.results.length > 0) {
							var prodDescription = [];
							this.byId("idCompartmentPageSection").setVisible(true);
							for (var k = 0; k < resObj.CompTusdataOrderRead.results.length; k++) {
								for (var j = 0; j < resObj.OrderitemsOrderRead.results.length; j++) {
									if (resObj.CompTusdataOrderRead.results[k].MaterialId === resObj.OrderitemsOrderRead.results[j].MaterialId) {
										//	prodDescription.push(resObj.OrderitemsOrderRead.results[j].MaterialDescription);
										//	var a = resObj.OrderitemsOrderRead.results[j].MaterialDescription + resObj.OrderitemsOrderRead.results[j].MaterialId;
										resObj.CompTusdataOrderRead.results[k].MaterialDescription = resObj.OrderitemsOrderRead.results[j].MaterialDescription;
										//oViewModel.setProperty("/postData/compartments/MatDesc", a);
									}
									//prodDescription.push(resObj.OrderitemsOrderRead.results[j]);
								}
							}
							//var compartmentDetails = resObj.CompTusdataOrderRead.results + prodDescription;
							oViewModel.setProperty("/postData/compartments", resObj.CompTusdataOrderRead.results);
						}

						// assign final destination
						oViewModel.setProperty("/postData/finalDestinationNum", resObj.FinalBpNumber);
						oViewModel.setProperty("/postData/finalDestinationName", resObj.FinalLongName);
						oViewModel.setProperty("/postData/finalDestinationAdd", resObj.FinalLongAddress);

						var resObj1 = resObj.OrderitemsOrderRead.results[0];
						if (resObj.DriversOrderRead.results["length"] > 0) {
							//var resObj2 = resObj.DriversOrderRead.results[0];
							this.getView().byId("DriverPageSection").setVisible(true);
							oViewModel.setProperty("/postData/drivers", resObj.DriversOrderRead.results);
						} else {
							this.getView().byId("DriverPageSection").setVisible(false);
						}
						if (resObj.TrucksOrderRead.results["length"] > 0) {
							this.getView().byId("TruckPageSection").setVisible(true);
							oViewModel.setProperty("/postData/truck", resObj.TrucksOrderRead.results);
						} else {
							this.getView().byId("TruckPageSection").setVisible(false);
						}
						if (resObj.TrailersOrderRead.results["length"] > 0) {
							this.getView().byId("TrailerPageSection").setVisible(true);
							oViewModel.setProperty("/postData/trailor", resObj.TrailersOrderRead.results);
						} else {
							this.getView().byId("TrailerPageSection").setVisible(false);
						}
						// code for changelog table-- 11 jan
						//resObj.ChangeLogsOrderRead.results["length"] > 0 && 
						if (resObj.OrderChangeLog === true) {
							this.getView().byId("Changelog").setVisible(true);
							oViewModel.setProperty("/postData/Changelog", resObj.ChangeLogsOrderRead.results);
						} else {
							this.getView().byId("Changelog").setVisible(false);
						}
						// end

						// end
						//var resObj4 = resObj.TrailersOrderReads.results[0];

						if (resObj) {
							oViewModel.setProperty('/postData/CustNum', resObj.SoldBpNumber);
							oViewModel.setProperty('/postData/CustName', resObj.SoldName);
							oViewModel.setProperty('/postData/CustNameAdd', resObj.SoldShortAddress);
							oViewModel.setProperty('/postData/DeleryNum', resObj.ShipBpNumber);
							oViewModel.setProperty('/postData/DeliveryName', resObj.ShipName);
							oViewModel.setProperty('/postData/DeliveryAdd', resObj.ShipShortAddress);
							if (resObj.CommentsOrderRead.results[0]) {
								var str = '';
								resObj.CommentsOrderRead.results.forEach(function (item) {
									str = str + item.Tdline;
								});

								oViewModel.setProperty('/postData/DeliveryInsuc', str);
							} else {
								oViewModel.setProperty('/postData/DeliveryInsuc', "");
							}
							oViewModel.setProperty('/postData/Terminal', resObj.PickBpNumber);
							oViewModel.setProperty('/postData/TerminalName', resObj.PickName);
							// R7 change to display field 

							oViewModel.setProperty('/postData/TerminalLongName', resObj.PickLongName);
							//end
							oViewModel.setProperty('/postData/TerminalAdd', resObj.PickShortAddress);
							oViewModel.setProperty('/postData/OrderReq', resObj.ReqDelDate);
							oViewModel.setProperty('/postData/ProductNum', resObj1.MaterialId + ' ' + resObj1.MaterialDescription);
							oViewModel.setProperty('/postData/ProductNo', resObj1.BaseMaterialId);
							// oViewModel.setProperty('/postData/Condition', resObj1.StatusDescription);   //--20211207 R-7 adjustments
							oViewModel.setProperty('/postData/Condition', resObj.StatusDesc); //++20211207 R-7 adjustments
							oViewModel.setProperty('/postData/Quantity', resObj1.Quantity + ' ' + resObj1.Uom);
							oViewModel.setProperty('/postData/ShowPrices', resObj.ShowPrices);
							oViewModel.setProperty('/postData/ShowMsds', resObj.ShowMsds); //++20221403 showMsds flag
							oViewModel.setProperty('/postData/ShowTotals', resObj.ShowTotals);
							oViewModel.setProperty('/postData/ShowVat', resObj.ShowVat);
							oViewModel.setProperty('/postData/Currency', resObj.Currency);
							oViewModel.setProperty('/postData/VolumeUom', resObj.Currency);
							oViewModel.setProperty('/postData/NetPrice', resObj.NetPrice);
							oViewModel.setProperty('/postData/orderRequire', resObj.PoNumber);
							oViewModel.setProperty('/postData/StatusId', resObj.StatusId);
							oViewModel.setProperty('/postData/docFlwRead', resObj.DocumentflowOrderRead);
							oViewModel.setProperty('/postData/ShipBpNumber', resObj.ShipBpNumber);
							oViewModel.setProperty('/postData/SoldBpNumber', resObj.SoldBpNumber);
							oViewModel.setProperty('/postData/SoldBpNumber', resObj.SoldBpNumber);
							this.selectedData = {
								//ShipmentNumber:oViewModel.getProperty('/postData/docFlwRead/results/0/DocumentNumber'),
								SoldToPartner: oViewModel.getProperty('/postData/SoldBpNumber'),
								ShipToPartner: oViewModel.getProperty('/postData/ShipBpNumber')
							};

							//If Order is allowed for cancellation

							if (sCancel == true && resObj.CanCancel == true) {
								this.getView().byId("btnCancelItem").setVisible(true);
								this.getView().byId("btnCancelItem").setEnabled(false);
								this.getView().byId("idCancelBtn").setVisible(true);

							} else {
								this.getView().byId("btnCancelItem").setVisible(false);
								this.getView().byId("idCancelBtn").setVisible(false);
								this.getView().byId("idBasketWeightMessage").setVisible(false); //++20211207 R-7 adjustments
							}
							oViewModel.setProperty('/postData/CanCancel', resObj.CanCancel);
							//

							if (oViewModel.getProperty('/postData/docFlwRead/results/0')) {
								var oBillingDocIds = [];
								var deliveries = oViewModel.getProperty('/postData/docFlwRead/results');
								if (!$.isEmptyObject(deliveries)) {
									deliveries.forEach(function (oItem) {
										if (oItem.DocumentType == "r") {
											oBillingDocIds.push({
												docNum: oItem.DocumentNumber,
												docDes: oItem.DocumentDesc

											});
										}
									});
								}
								if (oBillingDocIds[0]) {
									this.getView().byId("idStatusIndDel").setValue(100);
									this.getView().byId("idlinkDel").setEnabled(true);
								}

								oViewModel.setProperty('/postData/docFlwRead/docIdsDel', oBillingDocIds);
							} else {
								this.getView().byId("idStatusIndDel").setValue(99);
							}
							if (oViewModel.getProperty('/postData/docFlwRead/results/0')) {
								var oBillingDocIds1 = [];
								var Inv = oViewModel.getProperty('/postData/docFlwRead/results');
								if (!$.isEmptyObject(Inv)) {
									Inv.forEach(function (oItem) {
										if (oItem.DocumentType == "M" || oItem.DocumentType == "N") {
											oBillingDocIds1.push(oItem.DocumentNumber);
										}
									});
								}
								if (oBillingDocIds1[0]) {
									this.getView().byId("idStatusIndInv").setValue(100);
									this.getView().byId("idlinkInv").setEnabled(true);
								}
								oViewModel.setProperty('/postData/docFlwRead/docIdsInv', oBillingDocIds1);
							} else {
								this.getView().byId("idStatusIndInv").setValue(99);
							}
							if (oViewModel.getProperty('/postData/StatusId', resObj.StatusId) === 928 || oViewModel.getProperty('/postData/StatusId',
									resObj.StatusId) === 929) {

								this.getView().byId("idStatusIndOrder").setValue(100);
							}
							// else if (oViewModel.getProperty('/postData/StatusId', resObj.StatusId) === 926) {
							// 	this.getView().byId("idStatusIndOrder").setValue(50);
							// }

							//resObj.StatusId
							if (resObj.StatusId === 932) {

								this.getView().byId("idBarSI").setVisible(false);
							}
							//++SS20210610
							else {
								this.getView().byId("idBarSI").setVisible(true);
							}
							//++SS20210610

						}

					}.bind(this),
					error: function (err) {
						this.getView().setBusy(false);
					}.bind(this)
				});

			}.bind(this));
		},

		getGroupHeader: function (oEvent) {
			if (oEvent.key !== " ") {
				var trai = "Trailer:";
				return new sap.m.GroupHeaderListItem({
					title: trai + oEvent.key
				});
			} else {
				return new sap.m.GroupHeaderListItem({
					title: " "
				});
			}
		},
		getCounty: function (oContext) {
			var liscenseplat = oContext.getProperty('LicensePlate');
			var tusDesc = oContext.getProperty('TuTypeDesc');
			var comLiscenseplatedesc = liscenseplat + " " + tusDesc;
			return comLiscenseplatedesc;
		},

		onDialogWithSizePress: function (oEvent) {
			if (this.getView().byId("idStatusIndInv").getValue() === 99) {

			} else {

				var oBillingDocIds = this.getView().getModel("viewModel").getProperty('/postData/docFlwRead/docIdsInv');
				if (oBillingDocIds[0]) {

					oBillingDocIds = oBillingDocIds.toString();
					var sPath = "/InvPdfMergeDataSet(BillingDocNumber='" + oBillingDocIds + "')/$value";
					//var sPath = "/InvPdfMergeDataSet(BillingDocNumber='5002796579,5002796586')/$value";
					var oPDFViewer = new sap.m.PDFViewer();
					this.getView().addDependent(oPDFViewer);
					var sServiceURL = this.getView().getModel().sServiceUrl;
					var sSource = sServiceURL + sPath;
					oPDFViewer.setSource(sSource);
					oPDFViewer.setTitle("PDF Document(Merged)");
					oPDFViewer.open();
				}
			}

		},

		//++SS20210616 For expansion Button
		onFullScreen: function (oEvent) {
			var sSize = this.getView().byId("idSplitterLayout").getSize();
			if (sSize === "25%") {
				this.getView().byId("idSplitterLayout").setSize("0%");
				this.getView().byId("idActionBtn").setIcon("sap-icon://exit-full-screen");
			} else {
				this.getView().byId("idSplitterLayout").setSize("25%");
				this.getView().byId("idActionBtn").setIcon("sap-icon://full-screen");
			}
		},

		//Order Cancel Functionality
		onCancelWholeOrder: function () {
			var country = window.userInfoObj.country;
			var oResource = this.getView().getModel("i18n").getResourceBundle();
			var sOrderNo = this.getView().getModel("viewModel").getProperty('/UI/mode');
			var country = window.userInfoObj.country;
			if (!this.oApproveDialog) {

				if (country === "DE") {// PetChem business dont need order number to be displayed in msg
					var oCanConfirmText = oResource.getText("confirmCancelOrder") + "?";
				} else {

					var oCanConfirmText = oResource.getText("confirmCancelOrder") + " " + sOrderNo
				}
				this.oApproveDialog = new Dialog({
					type: DialogType.Message,
					title: oResource.getText("titleMsgCancel"),
					content: new sap.m.Text({
						text: oCanConfirmText
					}),
					beginButton: new sap.m.Button({
						type: "Emphasized",
						text: oResource.getText("btnMsgSave"),
						press: function () {
							this.onCancelWholeOrder1(sOrderNo, oResource);
							this.oApproveDialog.close();
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: oResource.getText("btnMsgCancel"),
						press: function () {
							this.oApproveDialog.close();
						}.bind(this)
					})
				});

			}

			this.oApproveDialog.open();
		},

		onCancelWholeOrder1: function (sOrderNo, oResource) {

			// var oViewModel = this.getView().getModel("viewModel");
			var oModel = this.getView().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var oPayload = {};
			oPayload.OrderNumber = sOrderNo;
			oPayload.CancelWholeOrder = true;
			oPayload.UserType = $.sap.UserType;
			oPayload.SalesareasOrderCancelWrite = [];
			oPayload.BapiretMsgOrderCancelWrite = [];
			oPayload.CancelitemsOrderCancelWrite = [];
			this.getView().setBusy(true);
			oModel.create('/OrderCancelWriteSet', oPayload, {

				success: function (data) {
					this.getView().setBusy(false);

					//++20211207 R-7 adjustments
					if (this.oApproveDialog) {
						this.oApproveDialog = undefined;
					} //order cancel issue

					//{++20211207 R-7 adjustments
					var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
					errorData = [];
					if (data.BapiretMsgOrderCancelWrite && data.BapiretMsgOrderCancelWrite.results && data.BapiretMsgOrderCancelWrite.results.length >
						0) { //++20211207 R-7 adjustments

						data.BapiretMsgOrderCancelWrite.results.forEach(function (item) {

							if (item.Type === "E" || item.Type === "W" || item.Type === "A" || item.Type === "I") {
								var typeMessage = "Information";
								if (item.Type === "E") {
									typeMessage = "Error";
								}
								if (item.Type === "W") {
									typeMessage = "Warning";
								}
								//++SS20210726 - To handle abort messages
								if (item.Type === "A") {
									typeMessage = "Error";
								}

								var errMessageStruct = {
									"description": item.Message,
									"type": typeMessage,
									"title": item.Message
								};

								errorData.push(errMessageStruct);
							}

						});

						this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);

					}
					// handle if there is no E type 
					if (errorData.some(function (element) {
							return element.type === "Error"; //  ++20211207 R-7 adjustments
						})) {
						this.byId("messagePopoverBtn").setText(errorData.length);
						this.oMP.toggle(this.byId("messagePopoverBtn"));

					} else {
						//++20211207 R-7 adjustments}

						sap.m.MessageBox.success((oResource.getText("successMsgCancelOrder")), {
							actions: [sap.m.MessageBox.Action.OK],
							emphasizedAction: sap.m.MessageBox.Action.OK,
							onClose: function (sAction) {
								//navigate to order search
								/*	if (this.oApproveDialog) {      //--20211207 R-7 adjustments
										this.oApproveDialog = undefined;
									} //order cancel issue*/
								oRouter.navTo("Main", true);

							}.bind(this)
						});
					}
				}.bind(this),
				error: function (oError) {
					// sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("errcancellation"));
					sap.m.MessageBox.error(oResource.getText("errorMsgText"));
					this.getView().setBusy(false);

				}.bind(this)
			});

		},

		onCancelItem: function (oEvent) {
			var sIcon = oEvent.getSource().getIcon();
			//{++20211207 R-7 adjustments
			var oViewModel = this.getView().getModel("viewModel");
			var sQua = parseFloat(oEvent.getSource().getBindingContext("viewModel").getObject().Quantity.replace(/\,/g, ''));
			var sDen = parseFloat(oEvent.getSource().getBindingContext("viewModel").getObject().Density.replace(/\,/g, ''));
			var sumVolume = oViewModel.getProperty("/postData/sumVolume");
			var sumWeight = oViewModel.getProperty("/postData/sumWeight");
			var weightLimitPercentage = oViewModel.getProperty("/postData/weightLimitPercentage");
			//++20211207 R-7 adjustments}
			var oResource = this.getView().getModel("i18n").getResourceBundle();
			if (sIcon == "sap-icon://delete") {
				oEvent.getSource().setIcon("sap-icon://refresh");
				oEvent.getSource().setTooltip(oResource.getText("Restore"));
				oEvent.getSource().getParent().addStyleClass("rowBackground");

				//{++20211207 R-7 adjustments
				if (oViewModel.getProperty("/postData/WholeOrderRead/Country") === 'GB') {
					oViewModel.setProperty("/postData/sumVolume", sumVolume - sQua);
					oViewModel.setProperty("/postData/sumWeight", sumWeight - (sQua * sDen));
					oViewModel.setProperty("/postData/weightLimitPercentage", (sumWeight - (sQua * sDen)) / parseInt(oViewModel.getProperty(
						"/postData/WholeOrderRead/Maxweight")) * 100);
				}
				//++20211207 R-7 adjustments}

			} else {
				oEvent.getSource().setIcon("sap-icon://delete");
				oEvent.getSource().setTooltip(oResource.getText("delete"));
				oEvent.getSource().getParent().removeStyleClass("rowBackground");

				//{++20211207 R-7 adjustments
				if (oViewModel.getProperty("/postData/WholeOrderRead/Country") === 'GB') {
					oViewModel.setProperty("/postData/sumVolume", sumVolume + sQua);
					oViewModel.setProperty("/postData/sumWeight", sumWeight + (sQua * sDen));
					oViewModel.setProperty("/postData/weightLimitPercentage", (sumWeight + (sQua * sDen)) / parseInt(oViewModel.getProperty(
						"/postData/WholeOrderRead/Maxweight")) * 100);

				}
				//++20211207 R-7 adjustments}
			}

			var oTable = this.getView().byId("idProductTable");
			var canBtnFlag = false;

			for (var i = 0; i < oTable.getItems().length; i++) {
				var sItem = oTable.getItems()[i];
				var sIconTab = sItem.getCells()[11].getIcon();

				if (sIconTab == "sap-icon://refresh") {
					canBtnFlag = true;
				}
				// this.getView().byId("btnCancelItem").setEnabled(canBtnFlag); //--20211207 R-7 adjustments

			}

			// {20211207 R-7 adjustments 
			if (!oViewModel.getProperty("/postData/WholeOrderRead/NoCutOffFlag") && this.getView().byId("idBasketWeightProgress").getState() ===
				"Error" && this.getView().byId(
					"idBasketWeightMessage").getVisible()) {
				canBtnFlag = false;

			}

			// 20211207 R-7 adjustments 
			this.getView().byId("btnCancelItem").setEnabled(canBtnFlag);
		},

		onCancelOrder: function () {
			var oResource = this.getView().getModel("i18n").getResourceBundle();
			var oViewModel = this.getView().getModel("viewModel");
			var oModel = this.getView().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var aItems = oViewModel.getProperty("/postData/products");
			var oTableItems = this.getView().byId("idProductTable").getItems();

			var oPayload = {};
			oPayload.OrderNumber = oViewModel.getProperty('/UI/mode');
			oPayload.UserType = $.sap.UserType;
			oPayload.CancelitemsOrderCancelWrite = [];

			var item;
			var sItem;
			var sIconTab;
			for (var i = 0; i < oTableItems.length; i++) {
				sItem = oTableItems[i];
				sIconTab = sItem.getCells()[11].getIcon();

				if (sIconTab == "sap-icon://refresh") {
					item = aItems[i];
					var oItem = {};
					oItem.ItemNumber = item.ItemNumber;
					oPayload.CancelitemsOrderCancelWrite.push(oItem);
				}

			}

			oPayload.SalesareasOrderCancelWrite = [];
			oPayload.BapiretMsgOrderCancelWrite = [];
			this.getView().setBusy(true);

			//{++20211207 R-7 adjustments 
			var sCancelItemsLen = oPayload.CancelitemsOrderCancelWrite.length;
			// we compare items that can be cancelled vs items selected to be cancelled
			var sCanCancelItemLen = aItems.filter(function (i) {
				return i.CanCancel;
			}).length;

			if (sCancelItemsLen === sCanCancelItemLen && oViewModel.getProperty("/postData/WholeOrderRead/Country") === 'GB') {

				if (!this.oConfirmDialog) {
					this.oConfirmDialog = new Dialog({
						type: DialogType.Message,
						title: oResource.getText("titleMsgCancel"),
						content: new sap.m.Text({
							text: oResource.getText("cancelAllOrderItems") + " " + oViewModel.getProperty('/UI/mode')
						}),
						beginButton: new sap.m.Button({
							type: "Emphasized",
							text: oResource.getText("btnMsgSave"),
							press: function () {
								this.onCancelOrderItems(oPayload);
								this.oConfirmDialog.close();
							}.bind(this)
						}),
						endButton: new sap.m.Button({
							text: oResource.getText("btnMsgCancel"),
							press: function () {
								this.getView().setBusy(false);
								this.oConfirmDialog.close();
							}.bind(this)
						})
					});
				}

				this.oConfirmDialog.open();

			} else {
				this.onCancelOrderItems(oPayload);
			}

			//++20211207 R-7 adjustments}

			//--20211207 R-7 adjustments}

			// 			oModel.create('/OrderCancelWriteSet', oPayload, {

			// 				success: function (data) {
			// 					this.getView().setBusy(false);
			// 						var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
			// 						errorData = [];
			// 					if (data.BapiretMsgOrderCancelWrite && data.BapiretMsgOrderCancelWrite.results && data.BapiretMsgOrderCancelWrite.results.length > 0) { //++20211207 R-7 adjustments
			// 						//set Error message

			// 						//--20211207 R-7 adjustments
			// /*						var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
			// 						errorData = [];*/
			// 			/*			data.BapiretMsgOrderCancelWrite.results.forEach(function (item) {
			// 							var errMessageStruct = {
			// 								"description": item.Message,
			// 								"type": 'Error',
			// 								"title": item.Message
			// 							};
			// 							errorData.push(errMessageStruct);

			// 						});*/

			// 						//++20211207 R-7 adjustments
			// 						data.BapiretMsgOrderCancelWrite.results.forEach(function (item) {

			// 								if (item.Type === "E" || item.Type === "W" || item.Type === "A" || item.Type === "I") {
			// 									var typeMessage = "Information";
			// 									if (item.Type === "E") {
			// 										typeMessage = "Error";
			// 									}
			// 									if (item.Type === "W") {
			// 										typeMessage = "Warning";
			// 									}
			// 									//++SS20210726 - To handle abort messages
			// 									if (item.Type === "A") {
			// 										typeMessage = "Error";
			// 									}

			// 									var errMessageStruct = {
			// 										"description": item.Message,
			// 										"type": typeMessage,
			// 										"title": item.Message
			// 									};

			// 									errorData.push(errMessageStruct);
			// 								}

			// 							});

			// 						this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);

			// 					}
			// 								// handle if there is no E type 
			// 						if (errorData.some(function (element) {
			// 								return element.Type === "Error";
			// 							})) {
			// 							this.byId("messagePopoverBtn").setText(errorData.length);
			// 							this.oMP.toggle(this.byId("messagePopoverBtn"));

			// 					} else {

			// 						sap.m.MessageBox.success(oResource.getText("successMsgCancelOrder"), {
			// 							actions: [sap.m.MessageBox.Action.OK],
			// 							emphasizedAction: sap.m.MessageBox.Action.OK,
			// 							onClose: function (sAction) {
			// 								//navigate to order search
			// 								oRouter.navTo("Main", true);

			// 							}.bind(this)
			// 						});
			// 					}
			// 				}.bind(this),
			// 				error: function (oError) {
			// 					// sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("errcancellation"));
			// 					sap.m.MessageBox.error(oResource.getText("errorMsgText"));
			// 					this.getView().setBusy(false);

			// 				}.bind(this)
			// 			});

		},

		//++20211207 R-7 adjustments 

		onCancelOrderItems: function (oPayload) {

			var oResource = this.getView().getModel("i18n").getResourceBundle();
			var oModel = this.getView().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oModel.create('/OrderCancelWriteSet', oPayload, {

				success: function (data) {
					this.getView().setBusy(false);
					var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
					errorData = [];
					//++20211207 R-7 adjustments
					if (this.oConfirmDialog) {
						this.oConfirmDialog = undefined;
					}

					if (data.BapiretMsgOrderCancelWrite && data.BapiretMsgOrderCancelWrite.results && data.BapiretMsgOrderCancelWrite.results.length >
						0) { //++20211207 R-7 adjustments
						//set Error message

						data.BapiretMsgOrderCancelWrite.results.forEach(function (item) {

							if (item.Type === "E" || item.Type === "W" || item.Type === "A" || item.Type === "I") {
								var typeMessage = "Information";
								if (item.Type === "E") {
									typeMessage = "Error";
								}
								if (item.Type === "W") {
									typeMessage = "Warning";
								}
								//++SS20210726 - To handle abort messages
								if (item.Type === "A") {
									typeMessage = "Error";
								}

								var errMessageStruct = {
									"description": item.Message,
									"type": typeMessage,
									"title": item.Message
								};

								errorData.push(errMessageStruct);
							}

						});

						this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);

					}
					// handle if there is no E type 
					if (errorData.some(function (element) {
							return element.type === "Error";
						})) {
						this.byId("messagePopoverBtn").setText(errorData.length);
						this.oMP.toggle(this.byId("messagePopoverBtn"));

					} else {

						sap.m.MessageBox.success(oResource.getText("successMsgCancelOrder"), {
							actions: [sap.m.MessageBox.Action.OK],
							emphasizedAction: sap.m.MessageBox.Action.OK,
							onClose: function (sAction) {

								//navigate to order search
								oRouter.navTo("Main", true);

							}.bind(this)
						});
					}
				}.bind(this),
				error: function (oError) {
					sap.m.MessageBox.error(oResource.getText("errorMsgText"));
					this.getView().setBusy(false);
					//++20211207 R-7 adjustments
					if (this.oConfirmDialog) {
						this.oConfirmDialog = undefined;
					}

				}.bind(this)
			});
		}

	});

});
sap.ui.define([
	"bosch/SmartControls/test/unit/controller/View1.controller",
	"../../../Chandeep"
], function () {
	"use strict";
});
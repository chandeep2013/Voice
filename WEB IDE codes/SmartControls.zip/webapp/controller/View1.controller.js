sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("bosch.SmartControls.controller.View1", {
		onInit: function () {
			this.check();
			var aa = $("page").context.title;
			console.log(aa);
		},
		onSelectionRow: function (evt) {
			var item = evt.getSource().getSelectedContextPaths()[0];
			var selectedRow = this.getView().getModel().getProperty(item);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View2", {
				ID: selectedRow.ZzFundC
			});
		}
	});
});
function initModel() {
	var sUrl = "/ODP/odata/SAP/ZCSP_GSD_PORTAL_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}
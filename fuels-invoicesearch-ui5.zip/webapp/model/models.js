sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		createUserModel: function(){
			var oModel = new JSONModel("/UserAdmin_API/users/groups?userId="+ sap.ushell.Container.getService("UserInfo").getId());
			return oModel;
		},
		errorMsgModel: function () {
			var oModel = new JSONModel({
				results: []
			}); 
			return oModel;
		}

	};
});
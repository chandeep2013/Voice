sap.ui.define([
	"sap/ui/core/mvc/Controller", 
	"com/bp/fuels-invoicesearch-ui5/util/formatter",
	"sap/m/PDFViewer",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/Token",
	"sap/ui/unified/DateRange",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/library",
], function (Controller, formatter, PDFViewer, MessageBox, Fragment, Filter, FilterOperator, JSONModel, Token, DateRange, DateFormat,
	library) {
	"use strict";
	var internalGroup;
	var paymentIcon;
	var flagCustomerDrop1 = false;
	var oMessagePopover;
	//daterange changes
	var CalendarType = library.CalendarType;
	var vFlagTo = false;
	var vFlagFrom = false;
	var showerrormsgFlag;
	return Controller.extend("com.bp.fuels-invoicesearch-ui5.controller.Main", {
		formatter: formatter,
		onInit: function () {
			var that = this;
			var oMessageTemplate = new sap.m.MessageItem({
				type: '{errorMsgModel>type}',
				title: '{errorMsgModel>title}',
				description: '{errorMsgModel>description}'

			});
			oMessagePopover = new sap.m.MessagePopover({
				items: {
					path: 'errorMsgModel>/results',
					template: oMessageTemplate
				},
				activeTitlePress: function () {
					sap.m.MessageToast.show('Active title is pressed');
				}
			});
			this.byId("messagePopoverBtn").addDependent(oMessagePopover);
			this.getOwnerComponent().getModel("errorMsgModel").refresh();
			var oJsonModelView = this.getOwnerComponent().getModel("userModel");
			oJsonModelView.pSequentialImportCompleted.then(function () {
				if (this.getOwnerComponent().getModel("userModel").getData()) {
					//G SCP GSD PRTL Internal User
					this.bFlag = this.getOwnerComponent().getModel("userModel").getData().groups && this.getOwnerComponent().getModel("userModel").getData()
						.groups.find(function (ele) {
							if ((ele.name.search(/G(\s?)SCP(\s?)GSD(\s?)PRTL(\s?)Internal(\s?)User/) > -1)) {
								return true;
							}
						});
					if (this.bFlag) {
						if (this.bFlag.name) {
							internalGroup = true;
						}
					} else {
						internalGroup = false;
					}
					this.bFlag1 = this.getOwnerComponent().getModel("userModel").getData().groups.find(function (ele) {
						if ((ele.name.search(/G(\s?)SCP(\s?)GSD(\s?)PRTL(\s?)Payment(\s?)Advice/) > -1)) {
							return true;
						}
					});
					if (this.bFlag1 && this.bFlag1.name === "G SCP GSD PRTL Payment Advice") {
						paymentIcon = true;
					} else {
						paymentIcon = false;
					}
				}
			}.bind(this));
			var model = new sap.ui.model.json.JSONModel();
			var countryHungary;
			var country;
			model.loadData("/services/userapi/attributes?multiValuesAsArrays=true");
			//personalization changes
			if (window.userInfoObj && window.userInfoObj.country) {
				country = window.userInfoObj.country;

				if (country === "DF") {
					country = "GB";

				}
			} else { //added to handle undefined country specifically for columns personlisation in table
				var oCountry = sap.ui.getCore().getConfiguration().getLanguage().split("-")[1];

				if (oCountry !== undefined) {
					country = oCountry;
				}

			}
			if (country === "PL") {
				that.getView().byId("idColumnDownloadDate").setVisible(true);
				that.getView().byId("idColumncreadteDate").setVisible(false);
				/*that.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"CreatedDate,DeldocItemDelivery,AuthorizationNumber,PaymentAdvice,FinalDestination,Flag,Imo,PaymentTerm,Vessel,DownloadTime,CreatedTime,CompanyCode,Dates,Payer,PoNumber"
				);*/

			} else if (country === "AU") {
				that.getView().byId("idColumnDeliveryDocket").setVisible(true);
				that.getView().byId("delbutton").setVisible(true);
				/*that.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"DownloadDate,AuthorizationNumber,FinalDestination,Flag,Imo,PaymentTerm,Vessel,DownloadTime,CreatedTime,CompanyCode,Dates,Payer,PoNumber"
				);*/
			} else if (country === 'FR' || country === 'AT' || country === 'NL') {
				that.getView().byId("idColumncreadteDate").setVisible(false);
				that.getView().byId("idPaymentAdvice").setVisible(true);
				/*that.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"Vessel,DeldocItemDelivery,DownloadTime,CreatedTime,CompanyCode,Dates,Payer,PoNumber"
				);*/
			} else if (country === 'NZ' || country === 'MX') {
				that.getView().byId("idPaymentAdvice").setVisible(false);
				/*that.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"AuthorizationNumber,DeldocItemDelivery,DownloadDate,PaymentAdvice,FinalDestination,Flag,Imo,PaymentTerm,Vessel,DownloadTime,CreatedTime,CompanyCode,Dates,Payer,PoNumber"
				);*/
			} else if (country === 'DE') {
				that.getView().byId("idPaymentAdvice").setVisible(true);
				that.getView().byId("idColumnBillingDate").setVisible(false);
				that.getView().byId("idColumncreadteDate").setVisible(false);
				/*that.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"AuthorizationNumber,CreatedDate,DeldocItemDelivery,DownloadDate,PaymentAdvice,FinalDestination,Flag,Imo,PaymentTerm,Vessel,DownloadTime,CreatedTime,CompanyCode,Dates,Payer,PoNumber"
				);*/
			} else {
				that.getView().byId("idPaymentAdvice").setVisible(true);
				/*that.getView().byId("idSmartTable").setIgnoreFromPersonalisation(
					"AuthorizationNumber,DeldocItemDelivery,DownloadDate,FinalDestination,Flag,Imo,PaymentTerm,Vessel,DownloadTime,CreatedTime,CompanyCode,Dates,Payer,PoNumber"
				);*/
			}
			//DateRange changes
			this.oFormatYyyymmdd = DateFormat.getInstance({
				pattern: "dd/MM/yyyy",
				calendarType: CalendarType.Gregorian
			});
			var currentDate = new Date();
			var toDate = new Date();
			var fromDate = new Date(currentDate.setMonth(currentDate.getMonth() - 1));
			this.getView().byId("idSmartFilterBar")._oHideShowButton.setVisible(false);
			//dateRange Changes

			var currentDate = new Date();
			var toDate = new Date();
			var fromDate = new Date(currentDate.setDate(currentDate.getDate() - 14));
			var oDefaultFilter = {
				"Dates": {
					"high": toDate,
					"low": fromDate,
					"ranges": [{
						"exclude": false,
						"operation": "BT",
						"keyField": "Dates",
						"value1": toDate,
						"value2": fromDate
					}]
				}

			};
			that.getView().byId("idSmartFilterBar").attachInitialise(function () {
				that.getView().byId("idSmartFilterBar").setFilterData(oDefaultFilter);
				//used this because there is no public method/property to hide 'Hide Filter Bar' button
				that.getView().byId("idSmartFilterBar")._oHideShowButton.setVisible(false);
				that._fnSetFilterWidth();
			});

		},

		smartFilerComboSelection: function (oEvent) {

		},

		onValueHelpRequestedDate: function (oLocationControl) {
			var oView = this.getView();
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var sFrom = oLocationControl.getFrom();
			var sTo = oLocationControl.getTo();

			var sdiff = Math.abs(sFrom.getTime() - sTo.getTime());
			var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));

			if (sdiffD > 365) {
				oLocationControl.setValueState("Error");
				oLocationControl.setValueStateText((resourceModel.getText("selectionError2")));
				// MessageBox.error((resourceModel.getText("selectionError2")));

			} else {
				oLocationControl.setValueState("None");
			}

		},

		smartFilterIntializeFunction: function (oEvent) {
			this.getView().byId("idSmartTable")._oVariantManagement.setShowShare(false); //++SS20210902 - To hide pulic option in variant saving
			this.getView().byId("idSmartFilterBar")._oVariantManagement.setShowShare(false); //++SS20210902 - To hide pulic option in variant saving
			//	var internalGr = this.returnUserDetails();
			var oView = this.getView();
			var oSmartFilterBar = oEvent.getSource();
			var oModel = this.getView().getModel();
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			// Customer Search Dropdown
			// code for latest pagination request
			var oControl = oEvent.getSource().getControlByKey("CustomerNumber");
			var oLocationMultiInput = oEvent.getSource().getControlByKey("CustomerNumber");
			var aValueHelpRequestFunctions = oLocationMultiInput["mEventRegistry"]["valueHelpRequest"];
			oLocationMultiInput.detachValueHelpRequest(aValueHelpRequestFunctions[1]["fFunction"]);

			oLocationMultiInput.attachValueHelpRequest(function () {
				this.onValueHelpRequestedLoc(oLocationMultiInput);
			}.bind(this));
			oControl._getValueHelpIcon()["mProperties"]["src"] = "sap-icon://slim-arrow-down";
			oControl.setMaxTokens(5);
			//{++SS20210827   Manual Input in Customer Drop down
			oLocationMultiInput.removeAllValidators();
			var fnValidator = function (args) {
				var text = args.text;
				return new Token({
					key: text,
					text: text
				});
			};

			oLocationMultiInput.addValidator(fnValidator);

			//++SS20210827}
			oView.setBusy(true);
			oModel.read("/CustomerSrchSet", {
				urlParameters: {
					'$top': "5"

				},
				filters: [new Filter("IntUser", FilterOperator.EQ, internalGroup)],

				success: function (response) {
					if (response.results[0]) {
						if (response.results[1]) {
							if (response.results[2]) {
								if (response.results[3]) {
									if (response.results[4]) {
										oControl.setTokens([new sap.m.Token({
												key: response.results[0].BpNumber,
												text: response.results[0].Name
											}),
											new sap.m.Token({
												key: response.results[1].BpNumber,
												text: response.results[1].Name
											}),
											new sap.m.Token({
												key: response.results[2].BpNumber,
												text: response.results[2].Name
											}),
											new sap.m.Token({
												key: response.results[3].BpNumber,
												text: response.results[3].Name
											}),
											new sap.m.Token({
												key: response.results[4].BpNumber,
												text: response.results[4].Name
											})
										]);
									} else {
										oControl.setTokens([new sap.m.Token({
												key: response.results[0].BpNumber,
												text: response.results[0].Name
											}),
											new sap.m.Token({
												key: response.results[1].BpNumber,
												text: response.results[1].Name
											}),
											new sap.m.Token({
												key: response.results[2].BpNumber,
												text: response.results[2].Name
											}),
											new sap.m.Token({
												key: response.results[3].BpNumber,
												text: response.results[3].Name
											})
										]);
									}
								} else {
									oControl.setTokens([new sap.m.Token({
											key: response.results[0].BpNumber,
											text: response.results[0].Name
										}),
										new sap.m.Token({
											key: response.results[1].BpNumber,
											text: response.results[1].Name
										}),
										new sap.m.Token({
											key: response.results[2].BpNumber,
											text: response.results[2].Name
										})
									]);
								}

							} else {
								oControl.setTokens([new sap.m.Token({
										key: response.results[0].BpNumber,
										text: response.results[0].Name
									}),
									new sap.m.Token({
										key: response.results[1].BpNumber,
										text: response.results[1].Name
									})
								]);
							}
						} else {
							oControl.setTokens([new sap.m.Token({
								key: response.results[0].BpNumber,
								text: response.results[0].Name
							})]);
						}
						// search call here
						flagCustomerDrop1 = true;
						oSmartFilterBar.search();
					} else {
						MessageBox.error(resourceModel.getText("customerNullError"));
					}
					oView.setBusy(false);

				},
				error: function (err) {
					oView.setBusy(false);
				}
			});
			//Date Validation
			//var dateFormatByCountry = "MM/dd/yyyy";
			/*var resourceModel = this.getView().getModel("i18n").getResourceBundle();*/
			/*	if (resourceModel.getText("dateFormatByCountry") && resourceModel.getText("dateFormatByCountry") != "dateFormatByCountry") {
					dateFormatByCountry = resourceModel.getText("dateFormatByCountry");
				}
				var oControlDate = oEvent.getSource().getControlByKey("Dates");
				oControlDate.setDisplayFormat(dateFormatByCountry);
				var aDate = oControlDate["mEventRegistry"]["change"];*/
			// oControlDate.detachValueHelpRequest(aDate[1]["fFunction"]);
			/*
						oControlDate.detachChange(aDate[0]["fFunction"]);

						oControlDate.attachChange(function () {
							this.onValueHelpRequestedDate(oControlDate);
						}.bind(this));*/

			//DateRange Changes
			var oControlDate = oEvent.getSource().getControlByKey("Dates");
			var currentDate = new Date();
			var toDate = new Date();
			var fromDate = new Date(currentDate.setMonth(currentDate.getMonth() - 1));
			toDate = this.oFormatYyyymmdd.format(toDate);
			fromDate = this.oFormatYyyymmdd.format(fromDate);
			this.getView().byId("idSmartFilterBar").getControlByKey("Dates").setValue(fromDate + " - " + toDate);
			var aValueHelpRequestFunctions1 = oControlDate["mEventRegistry"]["valueHelpRequest"];
			oControlDate.detachValueHelpRequest(aValueHelpRequestFunctions1[0]["fFunction"]);

			oControlDate.attachValueHelpRequest(function () {
				this.onPressToDateRange(oControlDate);
			}.bind(this));
			var aValueHelpRequestFunctions1 = oControlDate["mEventRegistry"]["valueHelpRequest"];
			oControlDate.detachValueHelpRequest(aValueHelpRequestFunctions1[0]["fFunction"]);

			oControlDate.attachValueHelpRequest(function () {
				this.onPressToDateRange(oControlDate);
			}.bind(this));
			// for location here
			var oControl1 = oEvent.getSource().getControlByKey("Location");
			var oLocationMultiInput1 = oEvent.getSource().getControlByKey("Location");
			var aValueHelpRequestFunctions1 = oLocationMultiInput1["mEventRegistry"]["valueHelpRequest"];
			oLocationMultiInput1.detachValueHelpRequest(aValueHelpRequestFunctions1[1]["fFunction"]);

			oLocationMultiInput1.attachValueHelpRequest(function () {
				this.onValueHelpRequestedLoc1(oLocationMultiInput1);
			}.bind(this));

			//sap-icon://slim-arrow-down
			oControl1._getValueHelpIcon()["mProperties"]["src"] = "sap-icon://slim-arrow-down";
			oControl1.setMaxTokens(5);

			//UTC Offset Logic
			//Logic for timezone sending to backend & determining to show France fields
			var oToday = new Date();
			var timezoneoffset = oToday.getTimezoneOffset() * -1 + "";
			var afilters = [];
			afilters.push(new sap.ui.model.Filter("UtcOffset", "EQ", timezoneoffset));
			var urlParameters = {
				'$expand': "BapiretGetuser"
			};
			oView.setBusy(true);
			var t = this;
			oModel.read("/GetuserReadSet", {
				urlParameters: urlParameters,
				filters: afilters,
				success: function (data1) {
					if (data1 && data1.results && data1.results.length > 0) {
						var resFlag = data1.results[0];
						if (resFlag.ShowFranceFields === true) {
							t.getView().byId("idColumnDownloadDate").setVisible(true);
						}
					}
				}.bind(this),
				error: function (oError) {},
				complete: function (xhr1, data2) {}.bind(this)
			});

		},
		onSelectRow: function (oEvent) {
			//--This will be handled via role assignment
		/*	if (window.userInfoObj && window.userInfoObj.country) {
				var country = window.userInfoObj.country;

				if (country === "DF" || country === "GB") {
					paymentIcon = true;

				}
			}*/
			if (oEvent.getSource().getSelectedItems().length != 0) {
				if (oEvent.getSource().getSelectedItems().some(function (item) {
						return item.getBindingContext().getObject().ShowPaymentAdvice === true;
					}))

				{
					paymentIcon && this.byId("bViewPaymentAdvice").setVisible(true);

				}
			}else{
				this.byId("bViewPaymentAdvice").setVisible(false);
			}
		},
		onSelectionChangePopupList: function (oEvent) {
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();

			var aSelectedPaths = oEvent.getSource().getSelectedContextPaths();
			if (aSelectedPaths.length > 5) {
				MessageBox.alert(resourceModel.getText("customerSelection"));
				return oEvent.getParameters().listItem.setSelected(false);
			}
			var oModel = this.getView().getModel();
			var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");
			var aTokens = oControl.getTokens();
			var deSelected = oEvent.getParameter("listItem").getTitle();
			if (!oEvent.getParameter('selected')) {
				if (aTokens.some(function (ele, index) {
						if (deSelected === ele.getKey()) {

							aTokens.splice(index, 1);
						}
						return deSelected === ele.getKey();
					})) {
					oControl.setTokens(aTokens);
				}
			}

			aSelectedPaths.forEach(function (item) {
				var oo = oModel.getProperty(item);
				var nToken = new sap.m.Token({
					key: oo.BpNumber,
					text: oo.Name
				});
				aTokens = oControl.getTokens();
				if (aTokens.some(function (ele) {
						return oo.BpNumber === ele.getKey();
					})) {

				} else {
					//oControl.addToken(nToken);
					aTokens.push(nToken);
					oControl.setTokens(aTokens);
				}
			});
		},
		onBeforeOpenCustomer: function (oEvent) {
			/*if (flagCustomerDrop == true) {*/
			var aFilter = [];
			var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");
			var oList = this.byId("idListPopover");
			oList.removeSelections(true);
			var oBinding = oList.getBinding("items");
			aFilter.push(new Filter("IntUser", FilterOperator.EQ, internalGroup));
			oBinding.filter(aFilter);
			/*	flagCustomerDrop = false;
			}
*/
		},
		onSearchCustomer: function (oEvent) {
			var oList = this.byId("idListPopover");
			if (oList) {

				var aFilter = [];
				var sQuery = oEvent.getSource().getValue();
				if (sQuery) {
					aFilter.push(new Filter("Search", FilterOperator.Contains, sQuery));
					// aFilter.push(new Filter("BpNumber", FilterOperator.EQ, sQuery));
					aFilter.push(new Filter("IntUser", FilterOperator.EQ, internalGroup));
				}

				// filter binding

				var oBinding = oList.getBinding("items");
				oBinding.filter(aFilter);
			}

		},
		/*	onToggleDeselectAll: function (oEvent) {
				var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");
				var aTokens = oControl.getTokens();
				var oList = this.byId("idListPopover");
				oList.getSelectedItems();
				return oList.setSelected(false);

			},*/
		//{++SS20210621		
		onUpdateFinishedCustomer: function (oEvent) {
			var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");
			var aTokens = oControl.getTokens();
			var oList = this.byId("idListPopover");

			aTokens.forEach(function (item) {
				//setSelectedItemById(sId, bSelect?) 
				var oSelected = '';
				var bSelect = oList.getItems().some(function (element) {
					if (element.getTitle() === item.getKey()) {
						oSelected = element;
					}
					return element.getTitle() === item.getKey();
				});
				if (bSelect) {
					oList.setSelectedItem(oSelected);
				}

			});
		},
		//++SS20210621}		

		onValueHelpRequestedLoc: function (oLocationControl) {
			var oView = this.getView();
			if (oLocationControl instanceof sap.m.MultiInput) {
				if (!this._pDialogDuplicate) {
					this._pDialogDuplicate = Fragment.load({
						id: oView.getId(),
						name: "com.bp.fuels-invoicesearch-ui5.view.fragment.PopoverCustomer",
						controller: this
					}).then(function (oDialog) {
						oView.addDependent(oDialog);
						return oDialog;
					});
				}
				this._pDialogDuplicate.then(function (oDialog) {
					oDialog.openBy(oLocationControl);
				}.bind(this));

			}

		},
		onDataReceived: function (oEvent) {

			var errorData = this.getOwnerComponent().getModel('errorMsgModel').getProperty("/results");
			// errorData.push(JSON.parse(oError.responseText).error.message.value);
			errorData = [];
			var errorMessages = [];
			var arr = [];
			arr = oEvent.mParameters.oSource.oDataState.mChangedProperties.modelMessages;
			if (!Boolean(oEvent.mParameters.mParameters.data)) {
				for (var i = 0; i < arr.length; i++) {
					if (arr[i].code != "" && !(arr[i].code.includes("EXCEPTION")) && !(arr[i].message.includes("Exception")) && arr[i].type != "None") {
						errorData.push({
							"description": arr[i].message,
							"type": arr[i].type,
							"title": arr[i].message
						});

					}
				}

				/*arr = oEvent.mParameters.oSource.oDataState.mChangedProperties.modelMessages;*/
			}

			/*	arr.forEach(function (item) {
					var errMessageStruct = {
						"description": item.message,
						"type": 'Error',
						"title": item.message
					};
					errorData.push(errMessageStruct);

				});*/

			this.getOwnerComponent().getModel('errorMsgModel').setProperty("/results", errorData);
			this.byId("messagePopoverBtn").setType(sap.m.ButtonType.Emphasized);
			this.byId("messagePopoverBtn").setText(errorData.length);
			if (errorData.length > 0) {
				oMessagePopover.toggle(this.byId("messagePopoverBtn"));
			}

			/*if(errorData.length>0){
				this.createMessagePopover();
			}*/

		},
		handleMessagePopoverPress: function (oEvt) {
			/*if (!this.oMP) {
				this.createMessagePopover();
			}
			this.oMP.toggle(oEvt.getSource());*/
			oMessagePopover.toggle(oEvt.getSource());
		},

		onBeforeRebindTable: function (oEvent) {
			this.getView().byId("idTable").removeSelections(true); //++SS20210902 Download invoice considering earlier selected invoices issue
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var country = 'MX';
			var language = 'EN';
			if (window.userInfoObj && window.userInfoObj.country) {
				country = window.userInfoObj.country;
				if (country === "DF") {

					country = "GB";
				}
			}
			if (window.userInfoObj && window.userInfoObj.language) {
				language = window.userInfoObj.language.toUpperCase();
			}
			var binding = oEvent.getParameter("bindingParams");
			var oFilter = this.getView().byId("idSmartFilterBar").getFilterData();
			var aFs = Object.keys(oFilter);
			var ooFilter;
			if (aFs.indexOf("Country") === -1) {
				ooFilter = new sap.ui.model.Filter("Country", sap.ui.model.FilterOperator.EQ, country);
				binding.filters.push(ooFilter);
			}
			if (aFs.indexOf("Language") === -1) {
				ooFilter = new sap.ui.model.Filter("Language", sap.ui.model.FilterOperator.EQ, language);
				binding.filters.push(ooFilter);
			}
			var VDateRanageFromTo = this.getView().byId("idValueHelpDateRange").getValue();
			if (VDateRanageFromTo !== "") {
				var VDateRanageForm = VDateRanageFromTo.split(" - ")[0];
				var VDateRanageTo = VDateRanageFromTo.split(" - ")[1];
				var vDateRangeStartPart = VDateRanageForm.split("/");
				var vDateRangeStartEnd = VDateRanageTo.split("/");
				var vDateRangeStart = new Date(+vDateRangeStartPart[2], vDateRangeStartPart[1] - 1, +vDateRangeStartPart[0] + 1);
				var vDateRangeEnd = new Date(+vDateRangeStartEnd[2], vDateRangeStartEnd[1] - 1, +vDateRangeStartEnd[0] + 1);
			}
			if (VDateRanageFromTo !== "") {
				binding.filters.push(new sap.ui.model.Filter("Dates", "BT", vDateRangeStart, vDateRangeEnd));
			}
		},

		onSearchSmartFilterBar: function (oEvent) {
			// Validations for search parameters
			var sOrderNumber = oEvent.getSource().getControlByKey("OrderNumber").getValue();
			var sInvoiceNumber = oEvent.getSource().getControlByKey("BillingDocNumber").getValue();
			var sDate = oEvent.getSource().getControlByKey("Dates").getValue();
			var oControl = oEvent.getSource().getControlByKey("CustomerNumber");
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			// if (oControl instanceof sap.m.MultiComboBox && oControl.getTokens().length > 5) {  //-SS20210902 Manual Entry was not displaying err
			if (oControl.getTokens().length > 5) {
				MessageBox.alert(resourceModel.getText("selectionError"));
				return;
			}
			//++SS20210902 Manual Entry was not displaying err
			else if (oControl.getTokens().length === 5 && oControl.getValue() !== "") {
				oControl.setValue("");
				MessageBox.alert(resourceModel.getText("selectionError"));
				return;
			}
		},
		onSearch: function (oEvent) {
			// Validations for search parameters
			var oControl = oEvent.getSource().getControlByKey("CustomerNumber").getTokens().length;
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var sDate = oEvent.getSource().getControlByKey("Dates").getValue();
			var sOrderNumber = oEvent.getSource().getControlByKey("OrderNumber").getValue();
			var sInvoiceNumber = oEvent.getSource().getControlByKey("BillingDocNumber").getValue();
			/*if (sInvoiceNumber && sOrderNumber && sDate) {
				if (internalGroup && flagCustomerDrop1) {
					if (oControl === 0) {
						MessageBox.error(resourceModel.getText("selectionError1") + "\n" + resourceModel.getText("customerdefaultingError"));
					}
				} else {
					MessageBox.error((resourceModel.getText("selectionError1")));
				}
			}
			if (!(sInvoiceNumber || sOrderNumber)) {
				if (internalGroup && flagCustomerDrop1) {
					if (oControl === 0) {
						MessageBox.error(resourceModel.getText("customerdefaultingError"));
					}
				}
			}
			if (!(sInvoiceNumber || sOrderNumber || sDate)) {
				MessageBox.error((resourceModel.getText("selectionError1")));
			}*/
			if (sInvoiceNumber === "" && sOrderNumber === "" && sDate === "") {
				if (internalGroup && flagCustomerDrop1) {
					if (oControl === 0) {
						MessageBox.error(resourceModel.getText("selectionError1") + "\n" + resourceModel.getText("customerdefaultingError"));
					} else {
						MessageBox.error((resourceModel.getText("selectionError1")));
					}
				} else {
					MessageBox.error((resourceModel.getText("selectionError1")));
				}
			} else if (!(sInvoiceNumber || sOrderNumber)) {
				if (internalGroup && flagCustomerDrop1) {
					if (oControl === 0) {
						MessageBox.error(resourceModel.getText("customerdefaultingError"));
					}
				}
			} else if (!(sInvoiceNumber || sOrderNumber || sDate)) {
				MessageBox.error((resourceModel.getText("selectionError1")));
			}
		},

		attachBeforeExport: function (oEvent) {
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var mExcelSettings = oEvent.getParameter("exportSettings");
			mExcelSettings.fileName = mExcelSettings.fileName;

			mExcelSettings.workbook.columns.splice(4, 0, {
				"columnId": "idCustomerName",
				"displayUnit": false,
				"falseValue": undefined,
				"inputFormat": null,
				"label": resourceModel.getText("customerName"),
				"precision": undefined,
				"property": "CustomerName",
				"scale": undefined,
				"template": null,
				"textAlign": "Begin",
				"trueValue": undefined,
				"type": undefined,
				"unitProperty": undefined,
				"width": "10rem"
			});
			mExcelSettings.workbook.columns.splice(9, 0, {
				"columnId": "idCurrency",
				"displayUnit": false,
				"falseValue": undefined,
				"inputFormat": null,
				"label": resourceModel.getText("currency"),
				"precision": undefined,
				"property": "Currency",
				"scale": undefined,
				"template": null,
				"textAlign": "Begin",
				"trueValue": undefined,
				"type": undefined,
				"unitProperty": undefined,
				"width": "5rem"
			});

			// mExcelSettings.workbook.columns.push({
			// 	label: resourceModel.getText("customerName"),
			// 	property: "CustomerName"
			// });

			// mExcelSettings.workbook.columns.push({
			// 	label: resourceModel.getText("currency"),
			// 	property: "Currency"
			// });

		},

		/*
		 *Experimental method - This is written to set the SmartFilterBar width
		 *Can be removed if the method causes any trouble
		 */
		_fnSetFilterWidth: function () {
			var oSmartFilterBarAggregations = this.getView().byId("idSmartFilterBar").getAggregation("content");
			var ControlName;
			if (!$.isEmptyObject(oSmartFilterBarAggregations)) {
				for (var i = 0; i < oSmartFilterBarAggregations.length; i++) {
					ControlName = sap.ui.getCore().byId(oSmartFilterBarAggregations[i].getId()).getMetadata().getName();
					if (ControlName.search("AlignedFlowLayout") > 0) {
						sap.ui.getCore().byId(oSmartFilterBarAggregations[i].getId()).setMinItemWidth("15rem");
						sap.ui.getCore().byId(oSmartFilterBarAggregations[i].getId()).setMaxItemWidth("20rem");
					}
				}
			}
		},
		fnViewPaymentAdvice: function (oEvent) {
			var that = this;
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var oInvoices = this.getView().byId("idTable").getSelectedContextPaths();
			var oBillingDocIds = [];
			var sPDFViewerTitle;
			var oPayloadObject = {
				"PaymentsAdviceInput": [],
				"MessagesPaymentAdviseRead": []
			};
			if (!$.isEmptyObject(oInvoices)) {
				if (oInvoices.length > 1) {
					sPDFViewerTitle = resourceModel.getText("PDFDocumentMerged");
				} else {
					sPDFViewerTitle = resourceModel.getText("PDFDocumentPreview");
				}
				oInvoices.forEach(function (oItem) {
					/*var payDate = that.getView().getModel().getProperty(oItem).PaymentDueDate;
					var payDateNew = payDate.split(".").reverse().join("-");*/
					var payDate = that.getView().getModel().getProperty(oItem).PaymentDueDate;
					if (payDate.includes(".")) {
						var payDateNew = payDate.split(".").reverse().join("");
					}
					if (payDate.includes("/")) {
						var payDateNew = payDate.split("/").reverse().join("");
					}
					if (payDate.includes("-")) {
						var payDateNew = payDate.split("-").reverse().join("");
					}
					oPayloadObject.PaymentsAdviceInput.push({
						"PaymentAdvice": that.getView().getModel().getProperty(oItem).PaymentAdvice,
						"CompanyCode": that.getView().getModel().getProperty(oItem).CompanyCode,
						"PaymentDate": payDateNew,
						"PayerNumber": that.getView().getModel().getProperty(oItem).PayerNumber,
						"GroupingOrigin": that.getView().getModel().getProperty(oItem).GroupingOrigin
					});
					payDate = "";
					payDateNew = "";
				});
			} else {
				MessageBox.alert(resourceModel.getText("SelectInvoicesMessage"));
				return;
			}

			var oModel = this.getView().getModel();
			oModel.create("/PaymentAdviceReadSet", oPayloadObject, {
				success: function (oData, response) {
					if (response.data.PaymentPdf) {
						var blob = response.data.PaymentPdf;
						var decodedPdfContent = atob(blob);
						var byteArray = new Uint8Array(decodedPdfContent.length);
						for (var i = 0; i < decodedPdfContent.length; i++) {
							byteArray[i] = decodedPdfContent.charCodeAt(i);
						}
						var blob = new Blob([byteArray.buffer], {
							type: 'application/pdf'
						});
						var _pdfurl = URL.createObjectURL(blob);
						var oPDFViewer = new sap.m.PDFViewer();
						oPDFViewer.setSource(_pdfurl);
						oPDFViewer.setTitle(sPDFViewerTitle);
						jQuery.sap.addUrlWhitelist("blob");
						oPDFViewer.open();
					} else if (response.data.MessagesPaymentAdviseRead.results && response.data.MessagesPaymentAdviseRead.results.length > 0) {
						var oErrorMessages = oData.MessagesPaymentAdviseRead.results;
						for (var j = 0; i < oErrorMessages.length; i++) {
							if (oErrorMessages[j].Type === "E") {
								MessageBox.error(oErrorMessages[j].Message);
								break; //Terminating at first error - collate if required later
							}
						}
					}
				},
				error: function (oError) {

				}
			});
		},
		onPressDeliveryDocket: function (oEvent) {
			//var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var delDoc = oEvent.getSource().getBindingContext().getObject().BillingDocNumber;
			if (delDoc.length > 0) {
				var str = window.location.href.split("#")[0] + "#Invoice-Search&/invoice/" + delDoc + "/dockets";
				window.location.replace(str);

				/*$.ajax({
					url: "/sap/fiori/fuelsportalframework/src/api/read/sap/bc/zcsp_web/zcsp_read/GetDocument?mode=DELIVDOC&_dc=" + delDoc,
					//	url: "/sap/fiori/bpappsshellplugin/UserAdmin_API/users/groups?userId=" + sap.ushell.Container.getService("UserInfo").getId(),
					method: "POST",
					contentType: "application/json",
					success: function (data) {
						if (data.EV_URL) {
							window.open(data.EV_URL);
						} else if (data.messages[0].type === "E") {

							MessageBox.error((resourceModel.getText("delDocMessage")) + "\n" + "\n" + data.messages[0].message);
						} else {
							MessageBox.error((resourceModel.getText("delDocMessage")) + "\n" + "\n" + data.messages[1].message);
						}
					}.bind(this),
					error: function (oError) {},
					complete: function (xhr1, data1) {}.bind(this)
				});*/
			}

		},
		onAfterRendering: function () {

		},

		//View PDF with download option - displays Merged PDF's if multiple Invoices are selected
		fnViewPDF: function () {
			var that = this;
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			var oInvoices = this.getView().byId("idTable").getSelectedContextPaths();
			var oBillingDocIds = [];
			var sPDFViewerTitle;
			if (!$.isEmptyObject(oInvoices)) {
				if (oInvoices.length > 1) {
					sPDFViewerTitle = resourceModel.getText("PDFDocumentMerged");
				} else {
					sPDFViewerTitle = resourceModel.getText("PDFDocumentPreview");
				}
				oInvoices.forEach(function (oItem) {
					oBillingDocIds.push(that.getView().getModel().getProperty(oItem).BillingDocNumber);
				});
			} else {
				MessageBox.alert(resourceModel.getText("SelectInvoicesMessage"));
				return;
			}
			oBillingDocIds = oBillingDocIds.toString();
			var sPath = "/InvPdfMergeDataSet(BillingDocNumber='" + oBillingDocIds + "')/$value";
			var oPDFViewer = new sap.m.PDFViewer();
			oPDFViewer.attachError(function () {
				this.setErrorPlaceholderMessage(resourceModel.getText("NoDocumentFound"));
			});
			this.getView().addDependent(oPDFViewer);
			var sServiceURL = this.getView().getModel().sServiceUrl;
			var sSource = sServiceURL + sPath;
			oPDFViewer.setSource(sSource);
			oPDFViewer.setTitle(sPDFViewerTitle);
			oPDFViewer.open();
		},
		//DateDefault Changes
		onPressToDateRange: function (oEvent) {
			var oView = this.getView();
			var getFromDate = oEvent.getSource().getProperty("value").split(" - ")[0];
			var gettoDate = oEvent.getSource().getProperty("value").split(" - ")[1];
			// check date field is blank 
			if (getFromDate !== "" && (gettoDate !== "" || gettoDate === undefined)) {
				var fromDate = new Date(getFromDate.substring(6, 10), getFromDate.substring(3, 5) - 1, getFromDate.substring(0, 2));
				var toDate = new Date(gettoDate.substring(6, 10), gettoDate.substring(3, 5) - 1, gettoDate.substring(0, 2));
				if (!this.oDialog1) {
					this.oDialog1 = sap.ui.xmlfragment("com.bp.fuels-invoicesearch-ui5.view.fragment.dateRangeFrag", this);
				}
				oView.addDependent(this.oDialog1);

				var oCalendar = sap.ui.getCore().byId("calendar");
				var oCalendar1 = sap.ui.getCore().byId("calendar1");
				oCalendar.removeAllSelectedDates();
				//	oCalendar1.removeAllSelectedDates();
				oCalendar.addSelectedDate(new DateRange({
					startDate: new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate())
				}));

				oCalendar.focusDate(new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate()));
				//	oCalendar1.focusDate(new Date(toDate.getFullYear(), toDate.getMonth(), toDate.getDate()));
				sap.ui.getCore().byId("selectedDateFrom").setValue(this.oFormatYyyymmdd.format(fromDate));
				sap.ui.getCore().byId("selectedDateTo").setValue(this.oFormatYyyymmdd.format(toDate));

				this.oDialog1.open();

			} else {
				var toDate = new Date();
				var currentDate = new Date();
				var fromDate = new Date(currentDate.setMonth(currentDate.getMonth() - 1));
				if (!this.oDialog1) {
					this.oDialog1 = sap.ui.xmlfragment("com.bp.fuels-invoicesearch-ui5.view.fragment.dateRangeFrag", this);
				}
				oView.addDependent(this.oDialog1);
				var oCalendar = sap.ui.getCore().byId("calendar");
				var oCalendar1 = sap.ui.getCore().byId("calendar1");
				oCalendar.removeAllSelectedDates();
				var onewDate = new Date();

				oCalendar.addSelectedDate(new DateRange({
					startDate: new Date(onewDate.getFullYear(), onewDate.getMonth() - 1, onewDate.getDate())
				}));

				oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth() - 1, onewDate.getDate()));

				// start -30/12/2021 change in focus for 2nd calendar
				var oCalendar1 = sap.ui.getCore().byId("calendar1");
				oCalendar1.removeAllSelectedDates();
				// var onewDate1 = new Date();

				oCalendar1.addSelectedDate(new DateRange({
					startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate())
				}));

				oCalendar1.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate()));
				//end -30/12/2021 change in focus for 2nd calendar
				sap.ui.getCore().byId("selectedDateFrom").setValue(this.oFormatYyyymmdd.format(fromDate));
				sap.ui.getCore().byId("selectedDateTo").setValue(this.oFormatYyyymmdd.format(toDate));
				sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
				sap.ui.getCore().byId("selectedDateTo").setValueState("None");
				this.oDialog1.open();
			}

		},
		fnClosesDialogox: function (oEvent) {
			var ofromDate = sap.ui.getCore().byId("selectedDateFrom").getValue();
			var oToDate = sap.ui.getCore().byId("selectedDateTo").getValue();
			if (ofromDate != "" && oToDate != "") {
				this.getView().byId("idSmartFilterBar").getControlByKey("Dates").setValue(ofromDate + " - " + oToDate);
			} else {
				this.getView().byId("idSmartFilterBar").getControlByKey("Dates").setValue("");
				sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
				sap.ui.getCore().byId("selectedDateTo").setValueState("None");

			}

			var getstatusFrom = sap.ui.getCore().byId("selectedDateFrom").getValueState();
			var getstatusTo = sap.ui.getCore().byId("selectedDateTo").getValueState();
			if (getstatusFrom === "Error" || getstatusTo === "Error") {
				if (showerrormsgFlag) {
					var resourceModel = this.getView().getModel("i18n").getResourceBundle();
					sap.m.MessageToast.show(resourceModel.getText("selectionError2"));
					showerrormsgFlag = "";
				} else {
					var resourceModel = this.getView().getModel("i18n").getResourceBundle();
					sap.m.MessageToast.show(resourceModel.getText("datecheckVal"));
				}
			} else {
				this.oDialog1.close();
				this.getView().byId("idInputValueHelp").setValue("");
				this.getView().byId("idInputValueHelp1").setValue("");
			}
		},
		fnAbortDialogox: function (oEvent) {
			// var ValueHelpDate = this.getView().byId("idValueHelpDateRange");
			// ValueHelpDate.setValue("");
			this.getView().byId("idSmartFilterBar").getControlByKey("Dates").setValue("");
			this.oDialog1.close();
			// this.oDialog1.destroy();
		},
		handleSelectToday: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");

			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date()
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date()
			}));
			oCalendar.focusDate(new Date());
			oCalendar1.focusDate(new Date());
			this._updateText(oCalendar, oCalendar1);
		},
		handleSelectYesterady: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");
			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			var onewDate = new Date();

			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 1)
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 1)
			}));
			oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 1));
			oCalendar1.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 1));
			this._updateText(oCalendar, oCalendar1);
		},
		handleSelectLst7Days: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");
			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			var onewDate = new Date();

			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 7)
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date()
			}));
			oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), onewDate.getDate() - 7));
			oCalendar1.focusDate(new Date());
			this._updateText(oCalendar, oCalendar1);
		},
		handleSelectLstMonth: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");
			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			var onewDate = new Date();

			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth() - 1, 1)
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), 0)
			}));
			oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth() - 1, 1));
			oCalendar1.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), 0));
			this._updateText(oCalendar, oCalendar1);
		},
		handleSelectThisMonth: function () {
			var oCalendar = sap.ui.getCore().byId("calendar");
			var oCalendar1 = sap.ui.getCore().byId("calendar1");
			oCalendar.removeAllSelectedDates();
			oCalendar1.removeAllSelectedDates();
			var onewDate = new Date();

			oCalendar.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth(), 1)
			}));
			oCalendar1.addSelectedDate(new DateRange({
				startDate: new Date(onewDate.getFullYear(), onewDate.getMonth() + 1, 0)
			}));
			oCalendar.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth(), 1));
			oCalendar1.focusDate(new Date(onewDate.getFullYear(), onewDate.getMonth() + 1, 0));
			this._updateText(oCalendar, oCalendar1);
		},
		changeStartDate: function (evt) {

			var oSDate = evt.getParameters("NewValue").newValue;
			if (oSDate.substring(6, 10).length < 4) {

				sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");
			} else {
				var oSDateCheck = oSDate.substring(0, 2) + "/" + oSDate.substring(3, 5) + "/" + oSDate.substring(6, 10);
				var pattern =
					/^((0[1-9]|[12][0-9]|3[01])(\/)(0[13578]|1[02]))|((0[1-9]|[12][0-9])(\/)(02))|((0[1-9]|[12][0-9]|3[0])(\/)(0[469]|11))(\/)\d{4}$/;
				var oEDate = sap.ui.getCore().byId("selectedDateTo").getValue();
				oEDate = oEDate.substring(6, 10) + " " + oEDate.substring(3, 5) + " " + oEDate.substring(0, 2);
				this.oEnddate = new Date(oEDate);
				var resourceModel = this.getView().getModel("i18n").getResourceBundle();
				if (pattern.test(oSDateCheck) === true) {
					oSDate = new Date(oSDate.substring(6, 10), oSDate.substring(3, 5) - 1, oSDate.substring(0, 2));
					//oneyear date validation -- 11 jan
					var sdiff = Math.abs(oSDate.getTime() - this.oEnddate.getTime());
					var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));
					if (oSDate > this.oEnddate) {
						sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");
						var resourceModel = this.getView().getModel("i18n").getResourceBundle();
						sap.ui.getCore().byId("selectedDateFrom").setValueStateText(resourceModel.getText("datecheckVal"));

					} else if (sdiffD > 365) {

						sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");
						//sap.ui.getCore().byId("selectedDateTo").setValueState("Error");
						sap.ui.getCore().byId("selectedDateFrom").setValueStateText(resourceModel.getText("selectionError2"));
						showerrormsgFlag = true;
						//end
					} else {
						var oCalendar = sap.ui.getCore().byId("calendar");
						oCalendar.removeAllSelectedDates();
						oCalendar.addSelectedDate(new DateRange({
							startDate: oSDate
						}));
						//oCalendar.focusDate(oSDate);
						sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
						sap.ui.getCore().byId("selectedDateTo").setValueState("None");
					}
					oCalendar.focusDate(oSDate);
				} else {
					sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");

				}
			}
		},
		changeEndDate: function (evt) {

			var oEDate = evt.getParameters("NewValue").newValue;
			if (oEDate.substring(6, 10).length < 4) {

				sap.ui.getCore().byId("selectedDateTo").setValueState("Error");
				sap.ui.getCore().byId("selectedDateTo").setValueStateText("Invalid entry");
			} else {
				var oEDateCheck = oEDate.substring(0, 2) + "/" + oEDate.substring(3, 5) + "/" + oEDate.substring(6, 10);
				var pattern =
					/^((0[1-9]|[12][0-9]|3[01])(\/)(0[13578]|1[02]))|((0[1-9]|[12][0-9])(\/)(02))|((0[1-9]|[12][0-9]|3[0])(\/)(0[469]|11))(\/)\d{4}$/;

				if (pattern.test(oEDateCheck) === true) {
					oEDate = oEDate.substring(6, 10) + " " + oEDate.substring(3, 5) + " " + oEDate.substring(0, 2);
					oEDate = new Date(oEDate);
					var getStartdate = sap.ui.getCore().byId("selectedDateFrom").getValue();
					getStartdate = new Date(getStartdate.substring(6, 10), getStartdate.substring(3, 5) - 1, getStartdate.substring(0, 2));
					var resourceModel = this.getView().getModel("i18n").getResourceBundle();
					//oneyear date validation -- 11 jan
					var sdiff = Math.abs(getStartdate.getTime() - oEDate.getTime());
					var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));
					if (oEDate < getStartdate) {
						sap.ui.getCore().byId("selectedDateTo").setValueState("Error");

						sap.ui.getCore().byId("selectedDateTo").setValueStateText(resourceModel.getText("datecheckVal"));

						this.getView().byId("selectedDateFrom").setValueState("None");
						var oCalendar = sap.ui.getCore().byId("calendar1");
						oCalendar.removeAllSelectedDates();
						oCalendar.addSelectedDate(new DateRange({
							startDate: oEDate
						}));

					} else if (sdiffD > 365) {

						sap.ui.getCore().byId("selectedDateTo").setValueState("Error");
						//sap.ui.getCore().byId("selectedDateTo").setValueState("Error");
						sap.ui.getCore().byId("selectedDateTo").setValueStateText(resourceModel.getText("selectionError2"));
						showerrormsgFlag = true;
						//end
					} else {

						sap.ui.getCore().byId("selectedDateTo").setValueState("None");
						sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
						var oCalendar = sap.ui.getCore().byId("calendar1");
						oCalendar.removeAllSelectedDates();
						oCalendar.addSelectedDate(new DateRange({
							startDate: oEDate
						}));
					}
					oCalendar.focusDate(oEDate);
				} else {
					sap.ui.getCore().byId("selectedDateTo").setValueState("Error");

				}
			}
		},
		handleCalendarSelect: function (oEvent) {

			var oCalendar = oEvent.getSource();
			this._updateTextClickTo(oCalendar.getSelectedDates()[0]);
		},
		handleCalendarSelectTo: function (oEvent) {
			var oCalendar = oEvent.getSource();
			this._updateTextClickFrom(oCalendar.getSelectedDates()[0]);
		},
		_updateTextClickTo: function (oCalendar) {
			var oSelectedDateFrom = sap.ui.getCore().byId("selectedDateFrom");
			var oEDate = sap.ui.getCore().byId("selectedDateTo").getValue();
			oEDate = oEDate.substring(6, 10) + " " + oEDate.substring(3, 5) + " " + oEDate.substring(0, 2);
			var oEnddate = new Date(oEDate);
			var oSDate = oCalendar.getProperty("startDate");
			var sdiff = Math.abs(oSDate.getTime() - oEnddate.getTime());
			var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			showerrormsgFlag = "";
			if (oCalendar !== undefined) {
				this.oStartdate = oCalendar.getStartDate();

				oSelectedDateFrom.setValue(this.oFormatYyyymmdd.format(this.oStartdate));
				vFlagTo = true;

				//	this.fnSetDate(vFlagTo, vFlagFrom);
			}
			if (oSDate > oEnddate) {
				sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");

				sap.m.MessageToast.show(resourceModel.getText("datecheckVal"));
			} else if (sdiffD > 365) {
				sap.ui.getCore().byId("selectedDateFrom").setValueState("Error");

				sap.m.MessageToast.show(resourceModel.getText("selectionError2"));
				showerrormsgFlag = true;

			} else {

				sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
				sap.ui.getCore().byId("selectedDateTo").setValueState("None");
			}
		},
		_updateTextClickFrom: function (oCalendar) {
			var oSelectedDateTo = sap.ui.getCore().byId("selectedDateTo");
			var oSDate = sap.ui.getCore().byId("selectedDateFrom").getValue();
			oSDate = oSDate.substring(6, 10) + " " + oSDate.substring(3, 5) + " " + oSDate.substring(0, 2);
			var oSDate = new Date(oSDate);
			var oEDate = oCalendar.getProperty("startDate");
			var sdiff = Math.abs(oSDate.getTime() - oEDate.getTime());
			var sdiffD = Math.ceil(sdiff / (1000 * 60 * 60 * 24));
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();
			showerrormsgFlag = "";

			if (oCalendar !== undefined) {
				this.oEnddate = oCalendar.getStartDate();
				oSelectedDateTo.setValue(this.oFormatYyyymmdd.format(this.oEnddate));
				vFlagFrom = true;
				//	this.fnSetDate(vFlagTo, vFlagFrom);
			}
			if (oEDate < oSDate) {
				sap.ui.getCore().byId("selectedDateTo").setValueState("Error");

				sap.m.MessageToast.show(resourceModel.getText("datecheckVal"));
			} else if (sdiffD > 365) {
				sap.ui.getCore().byId("selectedDateTo").setValueState("Error");

				sap.m.MessageToast.show(resourceModel.getText("selectionError2"));
				showerrormsgFlag = true;

			} else {

				sap.ui.getCore().byId("selectedDateTo").setValueState("None");
				sap.ui.getCore().byId("selectedDateFrom").setValueState("None");
			}
		},
		_updateText: function (oCalendar, oCalendar1) {
			var oSelectedDateFrom = sap.ui.getCore().byId("selectedDateFrom"),
				oSelectedDateTo = sap.ui.getCore().byId("selectedDateTo");
			// var oSelectedDateFrom1 = this.getView().byId("selectedDateFrom1"),
			// 	oSelectedDateTo1 = this.getView().byId("selectedDateTo1");
			var ValueHelpDate = this.getView().byId("idValueHelpDateRange");

			var aSelectedDates = oCalendar.getSelectedDates();
			var aSelectedDatesEnd = oCalendar1.getSelectedDates();

			this.oStartdate = aSelectedDates[0].getStartDate();
			this.oEnddate = aSelectedDatesEnd[0].getStartDate();
			// oSelectedDateFrom.setValue(this.oStartdate);
			// oSelectedDateTo.setValue(this.oEnddate);
			oSelectedDateFrom.setValue(this.oFormatYyyymmdd.format(this.oStartdate));
			oSelectedDateTo.setValue(this.oFormatYyyymmdd.format(this.oEnddate));
			// oSelectedDateFrom1.setValue(this.oFormatYyyymmdd.format(this.oStartdate));
			// oSelectedDateTo1.setValue(this.oFormatYyyymmdd.format(this.oEnddate));

			var vMargedDate = this.oStartdate + " - " + this.oEnddate;
			// var vMargedDate = this.oFormatYyyymmdd.format(this.oStartdate) + " - " + this.oFormatYyyymmdd.format(this.oEnddate);
			ValueHelpDate.setValue(vMargedDate);
		},
		//Deselect All option changes
		onFnDeselectAll: function (oEvent) {
			this.getView().byId("idListPopover").removeSelections(true);

			var oControl = this.byId('idSmartFilterBar').getControlByKey("CustomerNumber");
			var vLen = oControl.getTokens().length;
			var aTokens = oControl.getTokens();
			for (var i = 0; i < vLen; i++) {

				aTokens.splice(0, 1);
			}
			oControl.setTokens(aTokens);

		},

		onExit: function () {
			flagCustomerDrop1 = false;
		},
		onSelectionChangePopupListLocation: function (oEvent) {
			var resourceModel = this.getView().getModel("i18n").getResourceBundle();

			var aSelectedPaths = oEvent.getSource().getSelectedContextPaths();
			if (aSelectedPaths.length > 3) {
				MessageBox.alert(resourceModel.getText("LocationSelection"));
				return oEvent.getParameters().listItem.setSelected(false);
			}
			var oModel = this.getView().getModel();
			var oControl = this.byId('idSmartFilterBar').getControlByKey("Location");
			var aTokens = oControl.getTokens();
			var deSelected = oEvent.getParameter("listItem").getTitle();
			if (!oEvent.getParameter('selected')) {
				if (aTokens.some(function (ele, index) {
						if (deSelected === ele.getKey()) {

							aTokens.splice(index, 1);
						}
						return deSelected === ele.getKey();
					})) {
					oControl.setTokens(aTokens);
				}
			}

			aSelectedPaths.forEach(function (item) {
				var oo = oModel.getProperty(item);
				var nToken = new sap.m.Token({
					key: oo.BpNumber,
					text: oo.Name
				});
				aTokens = oControl.getTokens();
				if (aTokens.some(function (ele) {
						return oo.BpNumber === ele.getKey();
					})) {

				} else {
					//oControl.addToken(nToken);
					aTokens.push(nToken);
					oControl.setTokens(aTokens);
				}
			});
		},
		onBeforeOpenLocation: function (oEvent) {
			var aFilter = [];
			var oControl = this.byId('idSmartFilterBar').getControlByKey("ShipTo");

			var oList = this.byId("idListPopoverLocation");
			oList.removeSelections(true);
			var oBinding = oList.getBinding("items");
			aFilter.push(new Filter("IntUser", FilterOperator.EQ, internalGroup));
			// add flag  -- NameAddressOnly -- SG 31 jan
			aFilter.push(new Filter("NameAddressOnly", FilterOperator.EQ, true));
			//end
			oBinding.filter(aFilter);

		},
		onUpdateFinishedLocation: function (oEvent) {
			var oControl = this.byId('idSmartFilterBar').getControlByKey("Location");
			var aTokens = oControl.getTokens();
			var oList = this.byId("idListPopoverLocation");

			aTokens.forEach(function (item) {
				//setSelectedItemById(sId, bSelect?) 
				var oSelected = '';
				var bSelect = oList.getItems().some(function (element) {
					if (element.getTitle() === item.getKey()) {
						oSelected = element;
					}
					return element.getTitle() === item.getKey();
				});
				if (bSelect) {
					oList.setSelectedItem(oSelected);
				}

			});
		},
		onValueHelpRequestedLoc1: function (oLocationControl) {
			var oView = this.getView();
			if (oLocationControl instanceof sap.m.MultiInput) {

				if (!this._pDialogDuplicate1) {
					this._pDialogDuplicate1 = Fragment.load({
						id: oView.getId(),
						name: "com.bp.fuels-invoicesearch-ui5.view.fragment.PopoverLocation",
						controller: this
					}).then(function (oDialog) {
						oView.addDependent(oDialog);
						return oDialog;
					});
				}
				this._pDialogDuplicate1.then(function (oDialog) {
					oDialog.openBy(oLocationControl);
				}.bind(this));
			}
		},
		//Deselect All option changes Locations
		onFnDeselectAllLOc: function (oEvent) {
			this.getView().byId("idListPopoverLocation").removeSelections(true);

			var oControl = this.byId('idSmartFilterBar').getControlByKey("Location");
			var vLen = oControl.getTokens().length;
			var aTokens = oControl.getTokens();
			for (var i = 0; i < vLen; i++) {

				aTokens.splice(0, 1);
			}
			oControl.setTokens(aTokens);

		},
		onSearchLocation: function (oEvent) {
			var oList = this.byId("idListPopoverLocation");
			if (oList) {

				var aFilter = [];
				var sQuery = oEvent.getParameter("newValue");
				if (sQuery) {
					aFilter.push(new Filter("Search", FilterOperator.Contains, sQuery));
					aFilter.push(new Filter("IntUser", FilterOperator.EQ, internalGroup));
					//	aFilter.push(new Filter("BpNumber", FilterOperator.EQ, sQuery));
				}

				// filter binding

				var oBinding = oList.getBinding("items");
				oBinding.filter(aFilter);
			}
		},
		// date custom field save to variant
		onBeforeVariantFetch: function (oevt) {
			var customFiltersObject = this.getView().byId("idValueHelpDateRange").getValue();
			this.byId("idSmartFilterBar").setFilterData({
				_CUSTOM: customFiltersObject
			});
		},
		onAfterVariantLoad: function () {
			var filterData = this.byId("idSmartFilterBar").getFilterData();
			this.getView().byId("idValueHelpDateRange").setValue(filterData._CUSTOM);
			//this.getModel("customFilterModel").setData(filterData._CUSTOM);	
		}
	});
});
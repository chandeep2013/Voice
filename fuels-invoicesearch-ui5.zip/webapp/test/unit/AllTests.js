sap.ui.define([
	"com/bp/fuels-invoicesearch-ui5/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
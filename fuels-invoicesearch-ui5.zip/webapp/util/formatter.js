sap.ui.define([], function () {
	"use strict";

	return {
		
	
		dateFormatCountryCode:function(value){
			var oDate;
			var localLang = sap.ui.getCore().getConfiguration().getLanguage();
			if (value && localLang) {
					var oDateFormat;
						value = value.substring(0, 4) + "/" + value.substring(4, 6) + "/" + value.substr(6, 8);
						if(localLang === "en-US"){
							
							 oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							style: "medium",
							pattern: 'MM/dd/yyyy'
							}) ;
						}
							if(localLang === "es-MX" || localLang === "pt-PT"){
							
							 oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							style: "medium",
							pattern: 'dd/mm/yyyy'
							}) ;
						}
							if(localLang === "fr-FR" || localLang === "nl-NL"){
							
							 oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							style: "medium",
							pattern: 'dd-mm-yyyy'
							}) ;
						}
							if(localLang === "de-DE" || localLang === "pl-PL" ){
							
							 oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							style: "medium",
							pattern: 'dd.mm.yyyy'
							}) ;
						}
							
				oDate = oDateFormat.format(new Date(value), false);
			}
			return oDate;
			
			//var local1 = sap.ui.core.Locale.getLanguage();
			//return sap.ui.core.format.DateFormat.getDateInstance(new Date(dat), "es_ES");
		},
		dateFormatterMedium: function (value) {
			var oDate;
			if (value) {
				value = value.substring(0, 4) + "/" + value.substring(4, 6) + "/" + value.substr(6, 8);
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					style: "medium"
				});
				oDate = oDateFormat.format(new Date(value), false);
			}
			return oDate;
		},
		TimeFormat:function(iTime){
			if(iTime !== "00:00:00"){
				var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "HH:mm aa"
				});
				iTime = oTimeFormat.format(new Date(1970, 0, 1, iTime.substring(0, 2), iTime.substring(3, 5), iTime.substr(6, 8)), false);
			return iTime;
			} else {
				iTime ="";
			return iTime;
			}
		},
		/** 
		 * Format the Currency values by applying $/,/. charecters. 
		 * @param {String} amount for Gross Amount, Net Amount & Fee columns
		 */
		formatCurrencyString: function (sValue) {
			return sValue;
		},
		/** 
		 * Format the Amount values by applying $/,/. charecters. 
		 * @param {String} amount for Gross Amount, Net Amount & Fee columns
		 */
		numberFormatter: function (amount) {
			amount += '';
			var x = amount.split('.');
			var x1 = x[0];
			var x2 = x[1].length > 1 ? '.' + x[1] : '.' + x[1] + '0';
			var rgx = /(\d+)(\d{3})/;
			while (rgx.test(x1)) {
				x1 = x1.replace(rgx, '$1' + ',' + '$2');
			}
			return x1 + x2;
		},

		encode64: function (input) {
			var keyStr = "ABCDEFGHIJKLMNOP" +
				"QRSTUVWXYZabcdef" +
				"ghijklmnopqrstuv" +
				"wxyz0123456789+/" +
				"=";
			input = escape(input);
			var output = "";
			var chr1, chr2, chr3 = "";
			var enc1, enc2, enc3, enc4 = "";
			var i = 0;
			do {
				chr1 = input.charCodeAt(i++);
				chr2 = input.charCodeAt(i++);
				chr3 = input.charCodeAt(i++);
				enc1 = chr1 >> 2;
				enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
				enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
				enc4 = chr3 & 63;
				if (isNaN(chr2)) {
					enc3 = enc4 = 64;
				} else if (isNaN(chr3)) {
					enc4 = 64;
				}
				output = output +
					keyStr.charAt(enc1) +
					keyStr.charAt(enc2) +
					keyStr.charAt(enc3) +
					keyStr.charAt(enc4);
				chr1 = chr2 = chr3 = "";
				enc1 = enc2 = enc3 = enc4 = "";
			} while (i < input.length);
			return output;
		}
	};

});
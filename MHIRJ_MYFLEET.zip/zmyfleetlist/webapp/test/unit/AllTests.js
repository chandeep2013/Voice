sap.ui.define([
	"commhirj.portal.cpo./zmyfleetlist/test/unit/controller/List.controller"
], function () {
	"use strict";
});

sap.ui.define([
		"sap/ui/core/mvc/Controller",
        "sap/ui/core/UIComponent",
        "sap/m/BusyDialog",
        "com/mhirj/portal/cpo/zmyfleetlist/util/OdataCall",
        "com/mhirj/portal/cpo/zmyfleetlist/util/AppUtil",
        "com/mhirj/portal/cpo/zmyfleetlist/util/formatter",
        "jquery.sap.global"
	],
	function (Controller, UIComponent, BusyDialog, oDataCall, AppUtil, formatter, jquery) {
        "use strict";
        var busyMessageDialog = new BusyDialog();
		return Controller.extend("com.mhirj.portal.cpo.zmyfleetlist.controller.BaseController", {
			_oTPC: null,
			_oResourceBundle: null,
            formatter: formatter,

			onInit: function () {
				oDataCall.setService(this.getModel());
				this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);
			},
			getRouter: function () {
				return UIComponent.getRouterFor(this);
			},
			getModel: function (sName, iView) {
				if (iView) {
					return this.getView().getModel(sName);
				} else {
					if (sName) {
						return this.getOwnerComponent().getModel(sName);
					} else {
						return this.getOwnerComponent().getModel();
					}
				}
			},
			getResourceBundle: function () {
				if ($.isEmptyObject(this._oResourceBundle)) {
					this._oResourceBundle = this.getOwnerComponent().getModel("i18n")._oResourceBundle;
				}
				return this._oResourceBundle;
			},
			getTextFromBundle: function (key) {
				return this.getResourceBundle().getText(key);
			},
			onRouteMatched: function () {
				//abstract method, child will implement it.
			},
			showBusyDialog: function () {
               	busyMessageDialog.open();
			},
			hideBusyDialog: function () {
                busyMessageDialog.close();
			},

			showMessageToast: function (text, options) {
				if ($.isEmptyObject(text)) {
					text = this.getTextFromBundle("MESSAGE_GEN_EXCEPTION");
				}
				AppUtil.showMessageToast(text, options);
            },
            getApplicationID: function () {
                return this.getOwnerComponent().getManifestEntry("/sap.app").id.replaceAll(".", "");
            },
            getApplicationVersion: function () {
                return this.getOwnerComponent().getManifestEntry("/sap.app").applicationVersion.version;
            },
            getApplicationRouter: function () {
                return "/" + this.getOwnerComponent().getManifestEntry("/sap.cloud").service;
            },
            getCompleteURL: function () {
                return this.getApplicationRouter() + "." + this.getApplicationID() + "-" + this.getApplicationVersion();
            },
            // getUserInfo: function () {
              
            //     $.ajax({
            //       // "url": this.getCompleteURL() + "/user-info/UserInfoEntity",
            //         "url": "/user-info/UserInfoEntity",
            //         "method": "GET",
            //         "async": false,
            //         "xhrFields": {
            //             "withCredentials": true
            //         },
            //         "headers": {
            //             "Content-Type": "application/json"
            //         },
            //         success: function (result, xhr, successData) {
            //             this._sPartner = result.value[0];
            //         }.bind(this),
            //         error: function (errorData) {
            //           //  this.userInfoDeferred.reject();
            //         }.bind(this)
            //     });
            // },
            getUserInfo: function () {
                var successCallBack = function (result, xhr, successData) {
                    $.ajax({
                       "url": this.getCompleteURL() + "/user-info/UserInfoEntity",
                     //  "url": "/user-info/UserInfoEntity",
                        "method": "GET",
                        "async": false,
                        "headers": {
                          "Authorization": 'Bearer ' + result.oauthToken.access_token
                        //  "Content-Type": "application/json"
                        },
                        "success": function (result, xhr, successData) {

                         this._sPartner = result.value[0];
                            
                        }.bind(this),
                        "error": function (errorData) {

                        }.bind(this)
                    });
               }.bind(this);
               var errorCallBack = function (errorData) {
               }.bind(this);
               this.getoAuthToken(successCallBack, errorCallBack);
            },
            getoAuthToken: function (successCallBack, errorCallBack) {
                $.ajax({
                    "url": this.getCompleteURL() + "/getOAuthToken",
                   // "url": "/getOAuthToken",
                    "method": "GET",
                    "async": false,
                    "success": function (result, xhr, successData) {
                        successCallBack(result, xhr, successData)
                    }.bind(this),
                    "error": function (errorData) {
                        errorCallBack(errorData);
                    }.bind(this)
                });
            }
		});
	});
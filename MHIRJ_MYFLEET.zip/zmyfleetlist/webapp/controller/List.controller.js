sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "./BaseController",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "com/mhirj/portal/cpo/zmyfleetlist/util/OdataCall"

],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (Controller, BaseController, Filter, FilterOperator, JSONModel, oDataCall) {
        "use strict";

        return BaseController.extend("com.mhirj.portal.cpo.zmyfleetlist.controller.List", {
            onInit: function () {
                BaseController.prototype.onInit.call(this);
                this.getUserInfo();
                var vars = window.location.href.split("&");
                for (var i = 0; i < vars.length; i++) {
                    var pair = vars[i].split("=");
                    if (pair[1] == "UI5#CustomApp-myFlletList?aircraft-model") {
                        this._sModel = pair[2].replace(/['"]+/g, '');
                        this._sModel =  this._sModel.replace(/%20+/g, " ");
                    }
                }

            },
            onRouteMatched: function (oEvent) {
                if (this._sPartner) {
                    this._sPartner.CostCenter = this._sPartner.CostCenter.replace(/^0+/, '');
                    this._userType = this._sPartner.UserType.toUpperCase();
                    this._selBp = this._sPartner.CostCenter;
                    while (this._selBp.length < 10) this._selBp = "0" + this._selBp;

                    this.showBusyDialog();
                    var fnSuccess = jQuery.proxy(function (oData, oResponse) {
                        this.hideBusyDialog();
                        this._FleetData = oData;
                        var aFleet = {};
                        var aUniqFleet = oData.filter(function (entry) {
                            if (aFleet[entry.BuSort2]) {
                                return false;
                            }
                            aFleet[entry.BuSort2] = true;

                            return true;
                        });

                        var total_cnt = 0;
                        for (var i = 0; i < aUniqFleet.length; i++) {
                            total_cnt = total_cnt + parseInt(aUniqFleet[i].Cnt);
                            if (parseInt(aUniqFleet[i].Cnt) == "0") {
                                aUniqFleet[i].Expandable = false;
                            } else {
                                aUniqFleet[i].Expandable = true;
                            }
                            // aUniqFleet[i].Expandable = true;
                            if (this._sModel) {
                                if (this._sModel == aUniqFleet[i].BuSort2) {
                                    aUniqFleet[i].Expand = true;
                                } else {
                                    aUniqFleet[i].Expand = false;

                                }
                                // } else if (i == 0) {
                                //     aUniqFleet[i].Expand = true;
                            } else {
                                aUniqFleet[i].Expand = false;
                            }
                            if (aUniqFleet[i].BuSort2 === 'CRJ100, CRJ200, CRJ440') {
                                aUniqFleet[i]["idx"] = 1;
                            } else if (aUniqFleet[i].BuSort2 === 'CRJ550, CRJ700') {
                                aUniqFleet[i]["idx"] = 2;
                            } else if (aUniqFleet[i].BuSort2 === 'CRJ705, CRJ900') {
                                aUniqFleet[i]["idx"] = 3;
                            } else if (aUniqFleet[i].BuSort2 === 'CRJ1000') {
                                aUniqFleet[i]["idx"] = 4;
                            }
                        }
                        // if (total_cnt > 1) {
                        //     var sAirText = this.getTextFromBundle("aircrafts");
                        //     this.getView().byId("idListTitle").setText(sAirText + " (" + total_cnt + ")");
                        // } else {
                        var sAirText = this.getTextFromBundle("aircrafts");
                        this.getView().byId("idListTitle").setText(sAirText + " (" + total_cnt + ")");
                        // }
                        aUniqFleet.sort(function (a, b) {
                            if (a["idx"] && b["idx"]) {
                                if (a["idx"] > b["idx"]) {
                                    return 1;
                                } else if (a["idx"] < b["idx"]) {
                                    return -1;
                                }
                            }
                            return 0;
                        }
                        );
                         //enter code by Prerna
                        if(this._userType == 'EMPLOYEE'){
                            for (var j = 0; j < aUniqFleet.length; j++) {
                                aUniqFleet[j].Expandable = false;
                                aUniqFleet[j].Cnt = "0";
                            }
                            this.getView().byId("idListTitle").setText(sAirText + " (" + "All fleets" + ")");
                        }
                        //end Code
                        this.getView().setModel(new JSONModel(aUniqFleet), "listFleetModel");
                    }, this);
                    var fnFailure = jQuery.proxy(function () {
                        this.hideBusyDialog();
                    }, this);
                    var aFilters = [];
                    if (this._userType != 'EMPLOYEE') {
                        aFilters.push(new Filter("Partner1", FilterOperator.EQ, this._selBp));
                    }
                    var mParameters = {
                        filters: aFilters
                    };
                    oDataCall.read("/FLEET_INFOSet", mParameters, fnSuccess, fnFailure);
                } else {
                    var sErrMsg = this.getTextFromBundle("noOrg");
                    this.showMessageToast(sErrMsg);
                }
            },
            onExpand: function (oEvent) {
                if (oEvent.getSource().getProperty("expanded") === true) {
                    var oSelObj = oEvent.getSource().getBindingContext("listFleetModel").getObject();
                    var sCurrentSelectedPath = oEvent.getSource().getParent().getBindingContextPath();
                    if (sCurrentSelectedPath && this._selPath && this._selPath !== sCurrentSelectedPath) {
                        this.getView().getModel("listFleetModel").getProperty(this._selPath).Expand = false;
                    }

                    this._selPath = oEvent.getSource().getParent().getBindingContextPath();
                    var aFilters = [];

                    var aMsnData = this._FleetData.filter(function (entry) {
                        // return entry.Partner1 == this._sPartner.CostCenter && entry.BuSort2 == oSelObj.BuSort2;
                        return entry.BuSort2 == oSelObj.BuSort2 & entry.Partner != "" & entry.Partner !="20001" & entry.Partner !="20002" & entry.Partner !="20003" & entry.Partner !="20004";
                    }, this);
                   
                    aMsnData.sort(function(a, b){return a.Partner - b.Partner});
                    this.getView().setModel(new JSONModel(aMsnData), "listMsnModel");

                }

            },
            onSearch: function (oEvent) {
                var searchTerm = oEvent.getParameter("query");
                var aFilters = [];
                if (searchTerm) {
                    aFilters.push(new Filter("BuSort2", FilterOperator.Contains, searchTerm));
                }

                this.showBusyDialog();
                var fnSuccess = jQuery.proxy(function (oData, oResponse) {
                    this.hideBusyDialog();
                     //enter code by Prerna
                    //  for (var x = 0; x < oData.length; x++) {
                    //     var sBusort1 = oData[x].BuSort1,
                    //         sBusort2 = oData[x].BuSort2;
                    //     if (sBusort1 == "G1" || sBusort1 == "G2" || sBusort1 == "G3" || sBusort1 == "G4") {
                    //         sBusort2 = sBusort2 + "-Generic";
                    //         oData[x].BuSort2 = sBusort2;
                    //         oData[x].Cnt = 0;
                    //     }

                    //  }
                    //end of code by Prerna
                    this._FleetData = oData;
                    var aFleet = {};
                    var aUniqFleet = oData.filter(function (entry) {
                        if (aFleet[entry.BuSort2]) {
                            return false;
                        }
                        aFleet[entry.BuSort2] = true;
                        return true;
                    });

                    var total_cnt = 0;
                    for (var i = 0; i < aUniqFleet.length; i++) {
                        total_cnt = total_cnt + parseInt(aUniqFleet[i].Cnt);
                        if (parseInt(aUniqFleet[i].Cnt) == "0") {
                            aUniqFleet[i].Expandable = false;
                        } else {
                            aUniqFleet[i].Expandable = true;
                        }
                        // aUniqFleet[i].Expandable = true;
                        // if (i === 0) {
                        //     aUniqFleet[i].Expand = true;

                        // } else {
                        aUniqFleet[i].Expand = false;

                        // }
                    }
                    // if (total_cnt > 1) {
                    //     var sAirText = this.getTextFromBundle("aircrafts");
                    //     this.getView().byId("idListTitle").setText(sAirText + " (" + total_cnt + ")");
                    // } else {
                    var sAirText = this.getTextFromBundle("aircrafts");
                    this.getView().byId("idListTitle").setText(sAirText + " (" + total_cnt + ")");
                     //enter code by Prerna
                     if(this._userType == 'EMPLOYEE'){
                        for (var j = 0; j < aUniqFleet.length; j++) {
                            aUniqFleet[j].Expandable = false;
                            aUniqFleet[j].Cnt = "0";
                        }
                        this.getView().byId("idListTitle").setText(sAirText + " (" + "All fleets" + ")");
                    }
                    //end Code
                    var oFleetModel = this.getView().getModel("listFleetModel");
                    oFleetModel.setData(aUniqFleet);
                }, this);
                var fnFailure = jQuery.proxy(function () {
                    this.hideBusyDialog();
                }, this);
                if (this._userType != 'EMPLOYEE') {
                    aFilters.push(new Filter("Partner1", FilterOperator.EQ, this._selBp));
                }
                // aFilters.push(new Filter("Partner1", FilterOperator.EQ, this._selBp));

                var mParameters = {
                    filters: aFilters
                };
                oDataCall.read("/FLEET_INFOSet", mParameters, fnSuccess, fnFailure);
            }
        });
    });

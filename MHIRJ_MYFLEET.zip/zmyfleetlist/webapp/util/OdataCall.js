sap.ui.define([
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Filter, FilterOperator) {
	"use strict";
	var oDataCall = {

		_filter: Filter,
		_filterOperator: FilterOperator,
		
		_service: null,
		_sDeferredGroupId: "sDeferredGroup",
		
		READ_REQUEST_TYPE: "read",
		UPDATE_REQUEST_TYPE: "update",
		CREATE_REQUEST_TYPE: "create",
		REMOVE_REQUEST_TYPE: "remove",
		CALLFUNCTION_REQUEST_TYPE: "callFunction",

		
		getService: function(){
			return this._service;
		},
		
		setService: function(oDataModel){
			this._service = oDataModel;
			this._service.sDefaultUpdateMethod = "PUT";
			this._service.setDeferredGroups([this._sDeferredGroupId]);
		},

		reset: function() {
			this._service = null;
		},

		read: function(sPath, mParameters, fnSuccess, fnFailure) {
			this.sendRequest(this.READ_REQUEST_TYPE, sPath, null, mParameters, fnSuccess, fnFailure);
		},
		
		update: function(sPath, oPayload, mParameters, fnSuccess, fnFailure) {
			this.sendRequest(this.UPDATE_REQUEST_TYPE, sPath, oPayload, mParameters, fnSuccess, fnFailure);
		},
		
		create: function(sPath, oPayload, mParameters, fnSuccess, fnFailure) {
			this.sendRequest(this.CREATE_REQUEST_TYPE, sPath, oPayload, mParameters, fnSuccess, fnFailure);                                                                               
		},
		
		remove: function(sPath, mParameters, fnSuccess, fnFailure) {
			this.sendRequest(this.REMOVE_REQUEST_TYPE, sPath, null, mParameters, fnSuccess, fnFailure);
		},
		
		callFunction: function(sPath, mParameters, fnSuccess, fnFailure){
			this.sendRequest(this.CALLFUNCTION_REQUEST_TYPE, sPath, null, mParameters, fnSuccess, fnFailure);
		},
		
		sendRequest: function (sRequestType, sPath, oPayload, mParameters, fnSuccess, fnFailure){
			var fnServiceCall = this.getService()[sRequestType];
			mParameters = mParameters? mParameters:{};
			if (sRequestType === this.CALLFUNCTION_REQUEST_TYPE) {
				mParameters.method = typeof (mParameters.method) === "string" ? mParameters.method : "GET";
			}
			var aServiceCallParameters = [sPath, jQuery.extend(mParameters, {
				success: jQuery.proxy(function(oData, oResponse) {
					if (typeof fnSuccess === "function") {
						var oResult = oData && oData.results ? oData.results : oData;
						fnSuccess(oResult, oResponse);
					}
				}, this),
				error: jQuery.proxy(function(oError) {
					if (typeof fnFailure === "function") {
						this.raiseErrors([oError], fnFailure);
					}
				}, this)
			})];
			// only certain request types require a payload
			if (oPayload) {
				aServiceCallParameters.splice(1, 0, oPayload);
			}
			fnServiceCall.apply(this.getService(), aServiceCallParameters);
		},
		
		// {string} sRequestType								READ	UPDATE	CREATE	REMOVE
		// {string}	sPath										Req.	Req.	Req.	Req.
		// {object}	oPayload											Req.	Req.
		// {object} mParameters?
		//		{string}	mParameters.groupId?
		//		{object}	mParameters.context?
		//		{map}	mParameters.urlParameters?
		//		{array}	mParameters.filters?					Opt.
		//		{array}	mParameters.sorters?					Opt.
		//		{string}	mParameters.changeSetId?					Opt.
		//		{map}	mParameters.headers?							Opt.	Opt.
		//		{string}	mParameters.eTag?							Opt.			Opt.
		//		{string}	mParameters.changeSetId?							Opt.	Opt.
		
		createBatchRequest: function(sRequestType, sPath, oPayload, mParameters){
			var service = this.getService();
			var fnServiceCall = service[sRequestType];
			mParameters = mParameters? mParameters:{};
			mParameters.groupId = typeof mParameters.groupId === "string" ? mParameters.groupId : this._sDeferredGroupId;
			if (sRequestType === this.CALLFUNCTION_REQUEST_TYPE) {
				mParameters.method = typeof (mParameters.method) === "string" ? mParameters.method : "GET";
			}
			var fnCreateServiceCallParameters = function(fnResolve){
				var aServiceCallParams = [sPath, jQuery.extend(mParameters, {
					success: function(oData, oResponse) {
						fnResolve({
							// the response data format depends on the type of request (single entity or entity set)
							data: oData && oData.results ? oData.results : oData,
							response: oResponse
						});
					},
					error: function(oError) {
						fnResolve({
							error: oError
						});
					}
				})];
				// only certain request types require a payload
				if (oPayload) {
					aServiceCallParams.splice(1, 0, oPayload);
				}
				return aServiceCallParams;
			};
			
			return new Promise(function(fnResolve) {
				fnServiceCall.apply(service, fnCreateServiceCallParameters(fnResolve));
			});
		},
		
		sendBatchRequests: function(aBatchRequests, sRequestGroupId, fnBatchSuccess, fnBatchFailure){
			Promise.all(aBatchRequests).then(function(aResolvedResponses) {
				var aErrorResponses = this._getErrorResponsesFromBatch(aResolvedResponses);
				if(aErrorResponses.length>0){
					// there are some errors in the batch
					this.raiseErrors(aErrorResponses, fnBatchFailure);
				}
				else{
					// all requests are successful
					var aBatchResponseData = aResolvedResponses.map(function(oBatchResponse){
						return oBatchResponse.data;
					});
					fnBatchSuccess(aBatchResponseData);
				}
			}.bind(this));
			this.getService().submitChanges({
				groupId: typeof sRequestGroupId === "string" ? sRequestGroupId : this._sDeferredGroupId,
				success: function() {}.bind(this),
				error: function(oError) {
					this.raiseErrors([oError], fnBatchFailure);
				}.bind(this)
			});
		},
		
		raiseErrors: function(aErrorResponses, fnErrorCallback) {
			
            // var sGenericErrorMessage = this._utilities.getText("GENERIC_ERROR_MESSAGE"); 
            var sGenericErrorMessage = "Error";
			var oGenericErrorMessage = new this._errorMessage(sGenericErrorMessage, "");
			var aErrorMessages = [ oGenericErrorMessage ];
			
			if (aErrorResponses.constructor === Array) {
				
				if ( aErrorResponses.length > 0 ) {

					aErrorMessages = aErrorResponses.map(function(oErrorResponse) {

						// Set default values
						var sBackendErrorMessage = sGenericErrorMessage; 
						var sBackendErrorCode = "";
						var oErrorMessage = oGenericErrorMessage;
					
						// Parse actual error message and error code returned by the backend
						var oJSONErrorResponse = null;  
						if ( oErrorResponse.responseText ) { // Get the backend error message
					
							// jQuery.parseJSON does not accept "" nor HTML  Valid json string example would be: jQuery.parseJSON('{"a":"1"}')
							// Consequently, we catch parse error in case responseText is not on in JSON format. That happens when
							// there is an http error such as http error 503 (service unavailable) or http error 504 (timeout) where 
							// the response text is in HTML format.
							try {
								oJSONErrorResponse = jQuery.parseJSON(oErrorResponse.responseText);
								}
							catch(e) {
								oJSONErrorResponse = null; 
							
								// Whatever text returned by backend may convey additional information. This enriched generic error message
								// might be replaced with HTTP request error message later on if HTTP request error message is available.
								// If not, at least we have this minimal information about the error.
								sBackendErrorMessage = sBackendErrorMessage.concat(" ").concat(oErrorResponse.responseText); 
							}
						
							// If error response exists in JSON format, try to extract the backend error text and code 
							var bBackendErrorAvailable = false;
							if ( oJSONErrorResponse ) {
								// Get actual error message and error code returned by the backend
								if ( oJSONErrorResponse.error ) {
									if ( oJSONErrorResponse.error.message ) {
										if ( oJSONErrorResponse.error.message.value ) {
											// Get actual backend error message text
											sBackendErrorMessage = oJSONErrorResponse.error.message.value;
											bBackendErrorAvailable = true;
										}
										if ( oJSONErrorResponse.error.code ) {
											// Get actual backend error code
											sBackendErrorCode = oJSONErrorResponse.error.code;
										}
									}
								}
							}
						
							// If backend error text and code not found, get HTTP level error message
							if ( bBackendErrorAvailable === false ) {
								if ( oErrorResponse.message || oErrorResponse.statusCode || oErrorResponse.statusText) {  // Get the http request error message if any
									// E.g.  oErrorResponse.message = "HTTP request failed",  oErrorResponse.statusCode = 503 and oErrorResponse.statusText = "Service Unaivailable"
									sBackendErrorMessage = oErrorResponse.message.concat(": ").concat(oErrorResponse.statusCode.toString()).concat(" ").concat(oErrorResponse.statusText);
								}
							}
						
							oErrorMessage = new this._errorMessage(sBackendErrorMessage.trim(), sBackendErrorCode);
						}
						return oErrorMessage;
					}, this);
				}
			}

			// If the error callback is undefined, the facade will handle it
			if (typeof fnErrorCallback !== "function") {
				// this._utilities.displayErrorMessages(aErrorMessages);
			} else {
				fnErrorCallback(aErrorMessages);
			}
		},
		
		_getErrorResponsesFromBatch: function(aBatchResponses){
			// extract the responses with errors
			var aErrorResponses = aBatchResponses.filter(function(oBatchResponse){
				return oBatchResponse.error !== undefined;
			}).map(function(oBatchResponseWithError){
				return oBatchResponseWithError.error;
			});
			return aErrorResponses;
		},
		
		
		_createSearchFilterObject: function(aFilterIds, aFilterValues) {
			var aFilters = [];

			if (aFilterIds.length > 0 && aFilterIds.length === aFilterValues.length) {
				aFilters = aFilterIds.map(function(sFilterId, index) {
					return new Filter(sFilterId, FilterOperator.EQ, aFilterValues[index]);
				});
			}
			return aFilters;
		}

	
	};
	return oDataCall;
});
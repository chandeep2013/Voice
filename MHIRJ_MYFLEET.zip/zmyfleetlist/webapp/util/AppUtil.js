/* global Storage */

sap.ui.define([
	"sap/m/MessageBox",
	"sap/ui/core/Element",
	"sap/m/MessageToast",
	"sap/m/BusyDialog",
	"sap/ui/export/library"
], function (MessageBox, Element, MessageToast, BusyDialog, exportLibrary) {
	"use strict";
	var busyDialog = new BusyDialog();
	var busyMessageDialog = new BusyDialog();
	var AppUtil = Element.extend("com.mhirj.portal.cpo.zmyfleetlist.util.AppUtil");
	/**
	 *
	 * @param {text} i18n Text
	 * @param {type} type:(error/information/alert/success/warning)
	 * @returns {undefined}
	 */
	AppUtil.showMessage = function (text, type, e, fnSuccess) {
		if ($.isEmptyObject(type)) {
			type = 'error';
		}
		if ($.isEmptyObject(e)) {
			switch (type) {
			case "error":
				MessageBox.error(text);
				break;
			case "information":
				MessageBox.information(text);
				break;
			case "alert":
				MessageBox.alert(text);
				break;
			case "confirm":
				MessageBox.confirm(text);
				break;
			case "warning":
				MessageBox.warning(text);
				break;
			case "success":
				MessageBox.success(text);
				break;
			case "Information":
				MessageBox.show(text, {
					icon: MessageBox.Icon.Information,
					title: "Information",
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					defaultAction: MessageBox.Action.OK,
					onClose: jQuery.proxy(function (oAction) {
						if (typeof fnSuccess === "function") {
							fnSuccess(oAction);
						}
					}, this)
				});
			}
		} else {
			MessageBox.show(text, {
				icon: MessageBox.Icon.Error,
				title: "Error",
				actions: [MessageBox.Action.OK],
				defaultAction: MessageBox.Action.OK,
				details: JSON.stringify(e)
			});
		}
	};

	/**
	 *
	 * @returns {undefined}
	 */
	AppUtil.setTitle = function (title) {
		busyDialog.setTitle(title);
	};
	AppUtil.showBusyDialog = function () {

		busyDialog.open();
	};
	/**
	 *
	 * @returns {undefined}
	 */
	AppUtil.hideBusyDialog = function () {
		busyDialog.close();
	};

	AppUtil.showBusyMessageDialog = function (msg) {
		busyMessageDialog.setText(msg);
		busyMessageDialog.open();
	};
	/**
	 *
	 * @returns {undefined}
	 */
	AppUtil.hideBusyMessageDialog = function () {
		busyMessageDialog.close();
	};

	AppUtil.showMessageToast = function (text, options) {
		if (options) {
			MessageToast.show(text, options);
		} else {
			MessageToast.show(text, {
				duration: 10000
			});
		}
	};
	AppUtil.setInterval = function (oInstance, iInterval) {
		return setInterval(function () {
			oInstance.refreshTable();
		}.bind(this), iInterval);
	};
	AppUtil.clearInterval = function (x) {
		clearInterval(x);
	};
	return AppUtil;
});
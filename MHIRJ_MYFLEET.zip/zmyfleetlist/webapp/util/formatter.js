sap.ui.define([] ,
function() {
	return {
        getValue: function(sValue){
			return  sValue.replace(/,(?=[^\s])/gs, ", ");
            
		},
		imageSrc:function(sPath,sVal){
			if(sVal =="CRJ100, CRJ200, CRJ440"){
				return sPath+"CRJ100,CRJ200,CRJ440.jpg";
			}
			else if(sVal == "CRJ550, CRJ700"){
				return sPath+"CRJ550,CRJ700.jpg";
			}
			else if(sVal == "CRJ705, CRJ900"){
				return sPath+"CRJ705,CRJ900.jpg";
			}
			else if(sVal == "CRJ1000"){
				return sPath+"CRJ1000.jpg";
			}
		}
	};
}
);
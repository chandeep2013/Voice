sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"IT_SPM_DM/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("IT_SPM_DM.Component", {

		metadata: {
			manifest: "json",
			config: {
		        sapFiori2Adaptation: true,
		        reportingId: "xyz" 
		    }
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			var that = this;
			// call the base component's init function
			UIComponent.prototype.init.apply(that, arguments);

			// set the device model
			that.setModel(models.createDeviceModel(), "device");
			
			var url = "/services/userapi/currentUser";
			var loggedInUserData = ajaxCall(url, "GET", false);
			
			function ajaxCall(url, method, sync, oParam) {
			
				var data;
				$.ajax( {
					method : method,
					url : url,
					data : JSON.stringify(oParam),
					dataType : "application/json",
					cache : false,
					async : sync,
					beforeSend : function() {
						$("#preloader").show();
					},
					complete : function(arg) {
						$("#preloader").hide();
						data = JSON.parse(arg.responseText);
						var ologinUserModel = new sap.ui.model.json.JSONModel();
						ologinUserModel.loadData("/itspm_dm/user/" +  data.name, null, false);
						if(ologinUserModel.getData().userDetail){
							that.setModel(ologinUserModel, "userLoginModel");
						}
				},
				error : function() {
					$("#preloader").hide();
				}
				});
				return data;
	}
	
		/*	this.ofilesToUploadJson = new sap.ui.model.json.JSONModel({files : []});
				sap.ui.getCore().setModel(this.ofilesToUploadJson);
	
			*/
			// initialize Router
			that.getRouter().initialize();
			
		}
	});
});
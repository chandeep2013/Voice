sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("IT_SPM_DM.controller.Dashboard", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf IT_SPM_DM.view.Dashboard
		 */
			onInit: function() {
				var oController = this;
				/*setTimeout(function(){*/
				/*	
				var loginUser = sap.ui.getCore().getModel("userapi").getData().name;
				var ologinUserModel = new sap.ui.model.json.JSONModel();
				ologinUserModel.loadData("/itspm_dm/user/" + loginUser, null, false);
				sap.ui.getCore().setModel(ologinUserModel, "userLoginModel");
				*/
				
				sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function(oEvent){
			if(oEvent.getParameter("name") === "Dashboard"){
							if(!oController.getOwnerComponent().getModel("userLoginModel")){
					setTimeout(function(){
						var router = sap.ui.core.UIComponent.getRouterFor(oController);
						router.navTo("RequestUser");	
					}, 100);
					
				}
				else{
					oController.setInitialFocus();
					var userGroup = oController.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup;
				if(userGroup === "admin"){
					oController.getView().byId("createReqTileId").setVisible(true);
					oController.getView().byId("reportingTileId").setVisible(true);
					oController.getView().byId("masterDataTileId").setVisible(true);
				}else if(userGroup === "Vendor"){
					oController.getView().byId("createReqTileId").setVisible(true);
					oController.getView().byId("reportingTileId").setVisible(true);
					oController.getView().byId("masterDataTileId").setVisible(false);
				}else if(userGroup === "SPM"){
					oController.getView().byId("createReqTileId").setVisible(true);
					oController.getView().byId("reportingTileId").setVisible(true);
					oController.getView().byId("masterDataTileId").setVisible(false);
				}else if(userGroup === "PA"){
					oController.getView().byId("createReqTileId").setVisible(true);
					oController.getView().byId("reportingTileId").setVisible(true);
					oController.getView().byId("masterDataTileId").setVisible(false);
				}else if(userGroup === "Display"){
					oController.getView().byId("createReqTileId").setVisible(false);
					oController.getView().byId("reportingTileId").setVisible(true);
					oController.getView().byId("masterDataTileId").setVisible(false);
				}
					var oReportCountModel = new sap.ui.model.json.JSONModel();
				if(oController.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup === "Vendor"){
					oReportCountModel.loadData("/itspm_dm/changerequest/count/" + oController.getOwnerComponent().getModel("userLoginModel").getData().userDetail.vendorCode, null, false);		
				}
				else{
					oReportCountModel.loadData("/itspm_dm/changerequest/count/status", null, false);
				}
				if(oReportCountModel.getData()){
				var oReportingTile = oController.getView().byId("reportingTileId");
				oReportingTile.getTileContent()[0].getContent().setValue(oReportCountModel.getData().count);
				}
				var oMessageModel = new sap.ui.model.json.JSONModel();
				oMessageModel.loadData("/itspm_dm/notification", null, false);
				oController.getView().setModel(oMessageModel, "oMessageModel");
				}
					}
						
				
					});
				
			
					
					
			/*	}, 1000);*/
				
				
			
			
			},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf IT_SPM_DM.view.Dashboard
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf IT_SPM_DM.view.Dashboard
		 */
		onAfterRendering: function() {
			jQuery.sap.delayedCall(500, this, function() {
				    this.getView().getContent()[0].getContent()[0].getContent()[0].getContent()[0].focus();
				 });
		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf IT_SPM_DM.view.Dashboard
		 */
		//	onExit: function() {
		//
		//	}
	setInitialFocus: function(control) { 
	  this.getView().addEventDelegate({
	    onAfterShow: function() {
	      setTimeout(function() {
	        this.getView().byId("createReqTileId").focus();
	      }.bind(this), 0);
	    }
	  }, this);
	},
	
	pressCreateRequest:function(){
		var router = sap.ui.core.UIComponent.getRouterFor(this);
		router.navTo("CreateCR");
	},
	pressReporting:function(){
		var router = sap.ui.core.UIComponent.getRouterFor(this);
		router.navTo("Reporting");
	},
	pressMasterData:function(){
		var router = sap.ui.core.UIComponent.getRouterFor(this);
		router.navTo("DataManagement");
	},
	
	onPressDownload:function(){/*
		var url = "https://itspmdm-wfd7746b4.dispatcher.int.sap.hana.ondemand.com/doccuments/IT_SPM_DM_End_User_Document_Updated.pdf";
		window.open(url);
		//window.location.href = url;
	*/}
	});
	

});
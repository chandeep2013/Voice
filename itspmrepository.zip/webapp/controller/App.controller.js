sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("IT_SPM_DM.controller.App", {
		
		onInit : function(){
	/*	var a = this;*/	
			
	// 		var url = "/services/userapi/currentUser";
	// 		var loggedInUserData = ajaxCall(url, "GET", false);
			
	// 		function ajaxCall(url, method, sync, oParam) {
			
	// 			var data;
	// 			$.ajax( {
	// 				method : method,
	// 				url : url,
	// 				data : JSON.stringify(oParam),
	// 				dataType : "application/json",
	// 				cache : false,
	// 				async : sync,
	// 				beforeSend : function() {
	// 					$("#preloader").show();
	// 				},
	// 				complete : function(arg) {
	// 					$("#preloader").hide();
	// 					data = JSON.parse(arg.responseText);
	// 					var ologinUserModel = new sap.ui.model.json.JSONModel();
	// 					ologinUserModel.loadData("/itspm_dm/user/" +  data.name, null, false);
	// 					if(ologinUserModel.getData().userDetail){
	// 						sap.ui.getCore().setModel(ologinUserModel, "userLoginModel");
	// 					}
					
	// 			},
	// 			error : function() {
	// 				$("#preloader").hide();
	// 			}
	// 			});
	// 			return data;
	// }

			
		/*var oController = this;
			var userModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser", null, false);
				sap.ui.getCore().setModel(userModel, "userapi");*/
				
		/*	setTimeout(function(){*/
		/*var loggedInUserData = loggedInUserData;*/
			/*	var loginUser = loggedInUserData.name;
				var ologinUserModel = new sap.ui.model.json.JSONModel();
				ologinUserModel.loadData("/itspm_dm/user/" + loginUser, null, false);
				*/
				/*else{
					var router = sap.ui.core.UIComponent.getRouterFor(this);
					router.navTo("RequestUser");
				}*/
		/*	}, 1000);*/
		}

	});
});
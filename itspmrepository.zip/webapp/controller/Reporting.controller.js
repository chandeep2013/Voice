sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("IT_SPM_DM.controller.Reporting", {

		onInit: function () {
			var oController = this;
			oController.filtered = false;
			var vrMasterModel = new sap.ui.model.json.JSONModel();
			if (oController.getOwnerComponent().getModel("userLoginModel")) {
				if (oController.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup === "Vendor") {
					vrMasterModel.loadData("/itspm_dm/changerequest/vendor/" + oController.getOwnerComponent().getModel("userLoginModel").getData().userDetail
						.vendorCode, null, false);
					vrMasterModel = oController._sortDescendingList(vrMasterModel);
				} else {
					vrMasterModel.loadData("/itspm_dm/changerequest", null, false);
					vrMasterModel = oController._sortDescendingList(vrMasterModel);
				}
				oController.getView().setModel(vrMasterModel, "vrMasterModelId");
			}
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function (oEvent) {
				oController.getView().byId("serchInMasterId").setValue();

				if (!oController.getOwnerComponent().getModel("userLoginModel")) {
					setTimeout(function () {
						var router = sap.ui.core.UIComponent.getRouterFor(oController);
						router.navTo("RequestUser");
					}, 100);

				} else {
					oController.setInitialFocus();                                               
					if (oEvent.getParameter("config").target === "Reporting" && oEvent.getParameter("arguments").id) {
						var sIndex;
						if (oController.filtered !== true) {
							var sIndex = oController.getView().getModel("vrMasterModelId").getProperty("/result").map(function (obj, index) {
								if (obj.crSlNo == oEvent.getParameter("arguments").id) {
									return index;
								}
							}).filter(isFinite);
							oController.getView().byId("vrMasterListId").setSelectedItem(oController.getView().byId("vrMasterListId").getItems()[sIndex[0]],
								true);
						}

						oController._masterServiceIntegration("/itspm_dm/team", "vrTeamModelId");
						oController._masterServiceIntegration("/itspm_dm/product", "vrProductModelId");
						oController._masterServiceIntegration("/itspm_dm/placeholder", "vrPlaceholderModelId");
						oController._masterServiceIntegration("/itspm_dm/dateref", "vrDateModelId");
						oController._masterServiceIntegration("/itspm_dm/organization", "organizationModelId");
						oController._masterServiceIntegration("/itspm_dm/crtype", "vrTypeModelId");
						oController._masterServiceIntegration("/itspm_dm/user", "oUserModelId");
						oController.pressDiscard();
					} else if (oEvent.getParameter("config").target === "Reporting" && !oEvent.getParameter("arguments").id) {
						var vrMasterModel = new sap.ui.model.json.JSONModel();
						if (oController.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup === "Vendor") {
							vrMasterModel.loadData("/itspm_dm/changerequest/vendor/" + oController.getOwnerComponent().getModel("userLoginModel").getData()
								.userDetail.vendorCode, null, false);
							vrMasterModel = oController._sortDescendingList(vrMasterModel);
						} else {
							vrMasterModel.loadData("/itspm_dm/changerequest", null, false);
							vrMasterModel = oController._sortDescendingList(vrMasterModel);
						}
						oController.getView().setModel(vrMasterModel, "vrMasterModelId");
						if (vrMasterModel.getData().result && vrMasterModel.getData().result.length) {
							oController.getView().byId("vrMasterListId").setSelectedItem(oController.getView().byId("vrMasterListId").getItems()[0], true);

							oController._masterServiceIntegration("/itspm_dm/team", "vrTeamModelId");
							oController._masterServiceIntegration("/itspm_dm/product", "vrProductModelId");
							oController._masterServiceIntegration("/itspm_dm/placeholder", "vrPlaceholderModelId");
							oController._masterServiceIntegration("/itspm_dm/dateref", "vrDateModelId");
							oController._masterServiceIntegration("/itspm_dm/organization", "organizationModelId");
							oController._masterServiceIntegration("/itspm_dm/crtype", "vrTypeModelId");
							oController._masterServiceIntegration("/itspm_dm/user", "oUserModelId");
							oController.pressDiscard();
						}

					}

				}
			});
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf IT_SPM_DM.view.Reporting
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf IT_SPM_DM.view.Reporting
		 */
		onAfterRendering: function () {
			this.ofilesToUploadJson = new sap.ui.model.json.JSONModel({
				files: []
			});
			jQuery.sap.delayedCall(500, this, function () {
				this.getView().getContent()[0].getContent()[2].focus();
			});
		},
		
		/**
		 * Event handler to set the initial focus of the page to the title
		 * @param  {Object} control title of the page
		 */
		setInitialFocus: function(control) { 
		  this.getView().addEventDelegate({
		    onAfterShow: function() {
		      setTimeout(function() {
		        this.getView().byId("titleTextId").focus();
		      }.bind(this), 0);
		    }
		  }, this);
		},
		
		/**
		 * Event handler to sort the create request list according to serial number
		 * @param  {Object} vrMasterModel for sorting
		 * @return {Object} vrMasterModel after sorting
		 */
		_sortDescendingList: function (vrMasterModel) {
			if (vrMasterModel.getData().result && vrMasterModel.getData().result.length) {
				vrMasterModel.getData().result.sort(function (a, b) {
					return b.crSlNo - a.crSlNo;
				});
			}
			return vrMasterModel;
		},
		
		/**
		 * Event handler when list item of master page is selected
		 * @param  {Object} oEvent List item
		 */
		selectList: function (oEvent) {
			var contexts = this.getView().byId("vrMasterListId").getSelectedContexts();
			var items = contexts.map(function (c) {
				return c.getObject();
			});

			if (items.length) {
				var router = sap.ui.core.UIComponent.getRouterFor(this);
				router.navTo("Reporting", {
					from: "Reporting",
					id: items[0].crSlNo
				});
			}

			var userGroup = this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup;
			if (userGroup === "Vendor") {
				this.getView().byId("spmDetailPanelId").setVisible(false);
				this.getView().byId("vendorDetailPanelId").setVisible(true);
				this.getView().byId("paDetailPanelId").setVisible(false);
				this.getView().byId("vrAcceptId").setVisible(true);
				this.getView().byId("vrRejectId").setVisible(true);
				this.getView().byId("vrCloseId").setVisible(false);
				this.getView().byId("vrSteadyStateId").setVisible(false);
				this.getView().byId("vrCancelId").setVisible(false);

			}
			else {
				this.getView().byId("spmDetailPanelId").setVisible(true);
				this.getView().byId("vendorDetailPanelId").setVisible(true);
				this.getView().byId("paDetailPanelId").setVisible(true);
				this.getView().byId("vrCloseId").setVisible(true);
				this.getView().byId("vrAcceptId").setVisible(false);
				this.getView().byId("vrRejectId").setVisible(false);
				this.getView().byId("vrSteadyStateId").setVisible(true);
				this.getView().byId("vrCancelId").setVisible(true);
			}

			var vrDetailModel = new sap.ui.model.json.JSONModel();
			if (items.length) {

				if (items[0].status === "Accepted") {
					this.getView().byId("vrAcceptId").setEnabled(false);
					this.getView().byId("vrRejectId").setEnabled(false);
					this.getView().byId("vrEditId").setEnabled(true);
					this.getView().byId("vrCloseId").setEnabled(true);
					this.getView().byId("vrSteadyStateId").setEnabled(false);
					this.getView().byId("vrCancelId").setEnabled(true);
				} else if (items[0].status === "Rejected") {
					this.getView().byId("vrAcceptId").setEnabled(false);
					this.getView().byId("vrRejectId").setEnabled(false);
					this.getView().byId("vrEditId").setEnabled(true);
					this.getView().byId("vrCloseId").setEnabled(false);
					this.getView().byId("vrSteadyStateId").setEnabled(false);
					this.getView().byId("vrCancelId").setEnabled(false);
				} else if (items[0].status === "Draft") {
					this.getView().byId("vrAcceptId").setEnabled(false);
					this.getView().byId("vrRejectId").setEnabled(false);
					this.getView().byId("vrEditId").setEnabled(true);
					this.getView().byId("vrCloseId").setEnabled(false);
					this.getView().byId("vrSteadyStateId").setEnabled(false);
					this.getView().byId("vrCancelId").setEnabled(true);
				} else if (items[0].status === "Released") {
					this.getView().byId("vrAcceptId").setEnabled(false);
					this.getView().byId("vrRejectId").setEnabled(false);
					this.getView().byId("vrEditId").setEnabled(true);
					this.getView().byId("vrCloseId").setEnabled(false);
					this.getView().byId("vrSteadyStateId").setEnabled(true);
					this.getView().byId("vrCancelId").setEnabled(false);
				} else if (items[0].status === "Steady State") {
					this.getView().byId("vrAcceptId").setEnabled(false);
					this.getView().byId("vrRejectId").setEnabled(false);
					this.getView().byId("vrEditId").setEnabled(false);
					this.getView().byId("vrCloseId").setEnabled(false);
					this.getView().byId("vrSteadyStateId").setEnabled(false);
					this.getView().byId("vrCancelId").setEnabled(false);
				} else if (items[0].status === "Cancelled") {
					this.getView().byId("vrAcceptId").setEnabled(false);
					this.getView().byId("vrRejectId").setEnabled(false);
					this.getView().byId("vrEditId").setEnabled(false);
					this.getView().byId("vrCloseId").setEnabled(false);
					this.getView().byId("vrSteadyStateId").setEnabled(false);
					this.getView().byId("vrCancelId").setEnabled(false);
				} else {
					this.getView().byId("vrAcceptId").setEnabled(true);
					this.getView().byId("vrRejectId").setEnabled(true);
					this.getView().byId("vrEditId").setEnabled(true);
					this.getView().byId("vrCloseId").setEnabled(false);
					this.getView().byId("vrSteadyStateId").setEnabled(false);
					this.getView().byId("vrCancelId").setEnabled(true);
				}
				vrDetailModel.loadData("/itspm_dm/changerequest/" + items[0].crSlNo, null, false);
				if (userGroup === "Display") {
					this.getView().byId("vrEditId").setEnabled(false);
				}
			} else {
				vrDetailModel.setData({
					crDateTransactionDo: [],
					crTransactionDo: {},
					files: []
				});
				this.getView().byId("vrAcceptId").setEnabled(false);
				this.getView().byId("vrRejectId").setEnabled(false);
				this.getView().byId("vrEditId").setEnabled(false);
				this.getView().byId("vrCloseId").setEnabled(false);
				this.getView().byId("vrCommentId").setEnabled(false);
				this.getView().byId("vrSteadyStateId").setEnabled(false);
				this.getView().byId("vrCancelId").setEnabled(false);
			}
			this.getView().setModel(vrDetailModel, "vrDetailModelId");
			var oFileModel = vrDetailModel.getData().files;
			for (i = 0; i < oFileModel.length; i++) {
				oFileModel[i].name = oFileModel[i]['fileName'];
				delete oFileModel[i].fileName;
			}
			var dateMdl = vrDetailModel.getData().crDateTransactionDo;
			var oGridCreate = this.getView().byId("vrDateGridId");
			oGridCreate.removeAllContent();
			var oSelectedDate = [];
			for (var i = 0; i < dateMdl.length; i++) {
				this.getView().byId("vrDatePanelId").setVisible(true);

				var oDateVLayout = new sap.ui.layout.VerticalLayout({
					layoutData: new sap.ui.layout.GridData({
						span: "L3 M3 S12"
					}),
					content: [
						new sap.m.Label({
							text: dateMdl[i].dateName
						}).addStyleClass("labelColor"),
						new sap.m.DatePicker({
							enabled: false,
							displayFormat: "dd-MMM-YY",
							name: dateMdl[i].dateId
						})
					]
				});
				oDateVLayout.getContent()[1].setValue(dateMdl[i].dateVal);
				oGridCreate.addContent(oDateVLayout);
				oSelectedDate.push(dateMdl[i].dateName.slice(0, -2));

			}
			this.getView().byId("vrDateId").setSelectedKeys(oSelectedDate);
			if (vrDetailModel.getData().files.length > 0) {
				this.getView().byId("vrAttachmentId").setVisible(true);
			}
			if (vrDetailModel.getData().crTransactionDo.crTypeName === "Enhance existing scope" || vrDetailModel.getData().crTransactionDo.crTypeName ===
				"Discontinue existing scope") {
				this.getView().byId("vrRefVboxId").setVisible(true);
				this.getView().byId("vrCostObjectVboxId").setVisible(false);
			} else if (vrDetailModel.getData().crTransactionDo.crTypeName === "Project request") {
				this.getView().byId("vrCostObjectVboxId").setVisible(true);
				this.getView().byId("vrRefVboxId").setVisible(false);
			} else {
				this.getView().byId("vrRefVboxId").setVisible(false);
				this.getView().byId("vrCostObjectVboxId").setVisible(false);
			}
			if (items[0].status !== "Draft") {
				var sIndex = this.getView().getModel("organizationModelId").getProperty("/organization").map(function (obj, index) {
					if (obj.orgCode === vrDetailModel.getProperty("/crTransactionDo/vendorCode")) {
						return index;
					}
				}).filter(isFinite);

				this.getView().byId("vrSelectVendorId").setSelectedItem(this.getView().byId("vrSelectVendorId").getItems()[sIndex[0]], true);
			} else {
				this.getView().byId("vrSelectVendorId").setSelectedItem(null);
			}
			if (sap.ui.Device.system.phone) {
				var oSplitObject = this.byId("splitAppId");
				oSplitObject.toDetail(this.createId("detailPgageId"));
				this.byId("navBackDetailPageId").setVisible(true);
			}

		},
		
		/**
		 * Event handler when back button in detail page is clicked.This button is visible only in mobile view
		 */
		onPressNavBack: function () {
			var oSplitObject = this.byId("splitAppId");
			oSplitObject.toMaster(this.createId("masterPageId"));
		},
		
		/**
		 * Event handler when dates from dropdown is selected in combobox
		 */
		pressAddDate: function () {
			var oComboBoxelectedItem = this.getView().byId("vrDateId").getSelectedItems();
			var oComboBoxelectedItemKey = this.getView().byId("vrDateId").getSelectedKeys();
			var oGridCreate = this.getView().byId("vrDateGridId");
			this.getView().byId("vrDatePanelId").setVisible(true);
			if (oComboBoxelectedItem.length) {
				if (!oGridCreate.getContent().length) {

					for (var i = 0; i < oComboBoxelectedItem.length; i++) {
						var sText = oComboBoxelectedItem[i].getText();
						var sDateId = this.getView().getModel("vrDateModelId").getData().dateRef.filter(function (obj) {
							return obj.dateRefName == oComboBoxelectedItemKey[i];
						}).dateRefId;

						var oDateVLayout = new sap.ui.layout.VerticalLayout({
							layoutData: new sap.ui.layout.GridData({
								span: "L3 M3 S12"
							}),
							content: [
								new sap.m.Label({
									text: sText
								}).addStyleClass("labelColor"),
								new sap.m.DatePicker({
									displayFormat: "dd-MMM-YY",
									name: sDateId
								})
							]
						});
						oGridCreate.addContent(oDateVLayout);
					}
				} else {
					for (var i = 0; i < oComboBoxelectedItem.length; i++) {

						for (var j = 0; j < oGridCreate.getContent().length; j++) {
							if (oComboBoxelectedItem[i].getText() === oGridCreate.getContent()[j].getContent()[0].getText().slice(0, -2)) {
								break;
							} else if (oComboBoxelectedItem[i].getText() !== oGridCreate.getContent()[j].getContent()[0].getText().slice(0, -2) && j ===
								oGridCreate.getContent().length - 1) {
								var sText = oComboBoxelectedItem[i].getText();
								var sDateId = this.getView().getModel("vrDateModelId").getData().dateRef.filter(function (obj) {
									return obj.dateRefName == oComboBoxelectedItemKey[i];
								}).dateRefId;
								var oDateVLayout = new sap.ui.layout.VerticalLayout({
									layoutData: new sap.ui.layout.GridData({
										span: "L3 M3 S12"
									}),
									content: [
										new sap.m.Label({
											text: sText + " :"
										}).addStyleClass("labelColor"),
										new sap.m.DatePicker({
											displayFormat: "dd-MMM-YY",
											name: sDateId
										})
									]
								});
								oGridCreate.addContent(oDateVLayout);
							}
						}
					}
					for (var i = 0; i < oGridCreate.getContent().length; i++) {
						for (var j = 0; j < oComboBoxelectedItem.length; j++) {
							if (oGridCreate.getContent()[i].getContent()[0].getText().slice(0, -2) === oComboBoxelectedItem[j].getText()) {
								break;
							} else if (j === oComboBoxelectedItem.length - 1) {
								oGridCreate.removeContent(oGridCreate.getContent()[i]);
								i--;
							}
						}
					}
				}
			} else {
				oGridCreate.removeAllContent();
				this.getView().byId("vrDatePanelId").setVisible(false);
			}
		},
		
		/**
		 * Event handler when file uploader button is clicked
		 * @param {Object} oEvent File uploader button
		 */
		selectFileUploader: function (oEvent) {
			var that = this;
			var oFilesToAdd = oEvent.getParameter("files");
			var oFilesArray = $.map(oFilesToAdd, function (value, index) {
				return [value];
			});
			var nNewFileCount = this.getView().getModel("vrDetailModelId").getData().files.length + oFilesArray.length;
			if (nNewFileCount > 9) {
				this._statusDialog("Warning", "Warning", "Maximum 9 files can be uploaded");
			} else {
				var oNewData = this.getView().getModel("vrDetailModelId").getData().files.concat(oFilesArray);
				this.getView().getModel("vrDetailModelId").getData().files = oNewData;
				this.ofilesToUploadJson.setData({
					files: this.ofilesToUploadJson.getData().files.concat(oFilesArray)
				});
				this.getView().byId("vrAttachmentId").setVisible(true);
			}
		},
		
		/**
		 * Event handler when view attachment link is clicked
		 * @param {Object} events View attachment link
		 */
		pressAttachment: function (events) {
			var oPopover = new sap.m.ResponsivePopover({
				showHeader: false
			});
			var tokenMdl = this.getView().getModel("vrDetailModelId").getData().files;
			for (var i = 0; i < tokenMdl.length; i++) {

				oPopover.addContent(new sap.m.Tokenizer({
					tokens: [new sap.m.Token({
						text: tokenMdl[i].name,
						editable: false,
						press: function (oevt) {
							var fileName = oevt.getSource().getProperty("text");
							var fileObj = tokenMdl.find(function (obj) {
								return obj.name === fileName;
							});
							window.open("/itspm_dm/fileupload/" + fileObj.id);

							/*	var fileName = oevt.getSource().getProperty("text");
								for(var j = 0; j < tokenMdl.length; j++){
									if(fileName === tokenMdl[j].fileName){
										var sBase64 = tokenMdl[j].data;
									}
								}
								var u8_2 = new Uint8Array(atob(sBase64).split("").map(function(c) {
											return c.charCodeAt(0);
										}));
								var apptype = "text/html";
								var blob = new Blob( [ u8_2 ], {type : apptype});
								var url = URL.createObjectURL(blob);
									
										if ("download" in document
										.createElement("a")) {
									var a = document.createElement("a");
									a.setAttribute("href", url);
									a.setAttribute("download", fileName);

									// Create Click event
									var clickEvent = document.createEvent("MouseEvent");
									clickEvent.initMouseEvent("click",
											true, true, window, 0,
											event.screenX, event.screenY,
											event.clientX, event.clientY,
											event.ctrlKey, event.altKey,
											event.shiftKey, event.metaKey,
											0, null);

									// dispatch click event to simulate
									// download
									a.dispatchEvent(clickEvent);
								} else {
									// fallover, open resource in new tab.
									window.open(url, "_blank", "");
								}
							*/
						}
					})]
				}));
			}
			oPopover.openBy(events.getSource());
		},
		
		/**
		 * Event handler when back button of page is clicked
		 */
		pressBackButton: function () {
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("Dashboard");
		},
		
		/**
		 * Event handler when filter button is clicked
		 */
		pressFilter: function () {
			var oFilterDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.FilterDialog", this);
			this.getView().addDependent(oFilterDialog);
			var firstItem = new sap.ui.core.Item({
				text: "Select",
				key: "select"
			});
			oFilterDialog.getCustomTabs()[0].getContent()[0].getContent()[1].getItems()[0].getContent()[0].getItems()[0].insertItem(firstItem,
				0);
			if (this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup === "Vendor") {
				oFilterDialog.getCustomTabs()[0].getContent()[0].getContent()[1].getItems()[1].getItems()[5].setVisible(false);
				oFilterDialog.getCustomTabs()[0].getContent()[0].getContent()[0].setVisible(false);
			}
			oFilterDialog.open();
		},
		
		/**
		 * Event handler when filter option is clicked (filter by detail/date)
		 * @param {Object} oEvent radio button
		 */
		selectCheckBoxId: function (oEvent) {
			if (oEvent.getSource().getText() === "Filter by date") {
				oEvent.getSource().getParent().getParent().getContent()[1].getItems()[0].setVisible(true);
				oEvent.getSource().getParent().getParent().getContent()[1].getItems()[1].setVisible(false);
			} else {
				oEvent.getSource().getParent().getParent().getContent()[1].getItems()[0].setVisible(false);
				oEvent.getSource().getParent().getParent().getContent()[1].getItems()[1].setVisible(true);
			}
		},
		
		/**
		 * Event handler when search criteria for CreatedBy in filter dialog is changed
		 * @param {Object} oEvent search field
		 */
		searchCreatedBy: function (oEvent) {
			var sQuery = oEvent.getParameter("newValue");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("userName", sap.ui.model.FilterOperator.Contains, sQuery));
			var oFilter = new sap.ui.model.Filter(aFilter, false);
			var oList = oEvent.getSource().getParent().getContent()[1];
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},
		
		pressFilterByDate: function (oEvent) {
			var oFilterDialogDate = sap.ui.xmlfragment("IT_SPM_DM.fragment.FilterDialogByDate", this);
			this.getView().addDependent(oFilterDialogDate);
			var firstItem = new sap.ui.core.Item({
				text: "Select date",
				key: "select"
			});
			oFilterDialogDate.getCustomTabs()[0].getContent()[0].getContent()[0].getItems()[0].insertItem(
				firstItem, 0);
			oFilterDialogDate.open();
		},
		
		/**
		 * Event handler when download button in master page is clicked
		 */
		pressDownload: function () {
			var oDownloadDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.DownloadDialog", this);
			this.getView().addDependent(oDownloadDialog);
			oDownloadDialog.open();
		},
		
		/**
		 * Event handler when OK button of download dialog is clicked
		 * @param {Object} oEvent search field
		 */
		confirmDownload: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts");
			var oSelectedItem = aContexts.map(function (oContext) {
				return oContext.getObject();
			});

			if (oSelectedItem.length) {
				for (var i = 0; i < oSelectedItem.length; i++) {
					oSelectedItem[i]["CR ID"] = oSelectedItem[i].crRefId;
					oSelectedItem[i]["Created Date"] = oSelectedItem[i].createdDate;
					oSelectedItem[i]["CR Type"] = oSelectedItem[i].crTypeName;
					oSelectedItem[i]["CR Status"] = oSelectedItem[i].status;
					oSelectedItem[i]["Team"] = oSelectedItem[i].teamName;
					oSelectedItem[i]["Product"] = oSelectedItem[i].productName;
					delete oSelectedItem[i].status;
					delete oSelectedItem[i].crTypeName;
					delete oSelectedItem[i].createdDate;
					delete oSelectedItem[i].crRefId;
					delete oSelectedItem[i].crSlNo;
					delete oSelectedItem[i].teamName;
					delete oSelectedItem[i].productName;
				}
				var CSV = '';
				CSV += '\r\n';
				var row = "";
				for (var index in oSelectedItem[0]) {
					row += index + ',';
				}
				row = row.slice(0, -1);
				CSV += row + '\r\n';
				for (var i = 0; i < oSelectedItem.length; i++) {
					var row = "";
					for (var index in oSelectedItem[i]) {
						row += '"' + oSelectedItem[i][index] + '",';
					}
					row.slice(0, row.length - 1);
					CSV += row + '\r\n';
				}
				var fileName = "CR-Request";
				var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
				var link = document.createElement("a");
				link.href = uri;
				link.style = "visibility:hidden";
				link.download = fileName + ".csv";
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}
		},
		
		/**
		 * Event handler when Edit button of detail page is clicked
		 */
		pressEdit: function () {
			this.sMode = "Edit";
			this.getView().getContent()[1].getMasterPages()[0].setBusy(true);
			var oControlId = ["vrNameId", "vrTeamId", "vrProductId", "vrDateId", "vrPurposeId", "vrTransitionId", "vrExpectationId",
				"vrVolumeId", "vrMilestoneId", "vrUploadId", "vrCategoryId", "vrInvolvedId", "vrRemarksId", "vrSPMEmailId", "vrSPMRemarksId",
				"vrPAEmailId", "vrPARemarksId", "vrSelectVendorId", "vrVendorEmailId", "vrVendorRemarksId"
			];
			for (var i = 0; i < 17; i++) {
				this.getView().byId(oControlId[i]).setEnabled(true);
			}
			var dateArray = this.getView().byId("vrDateGridId").getContent();
			for (var j = 0; j < dateArray.length; j++) {
				dateArray[j].getContent()[1].setEnabled(true);
			}

			var contexts = this.getView().byId("vrMasterListId").getSelectedContexts();
			var items = contexts.map(function (c) {
				return c.getObject();
			});
			if (items[0].status === "Draft") {
				for (var j = 17; j < oControlId.length; j++) {
					this.getView().byId(oControlId[j]).setEnabled(true);
				}
			}
			this.getView().byId("vrEditId").setVisible(false);
			this.getView().byId("vrSubmitId").setVisible(true);
			this.getView().byId("vrCancleEditId").setVisible(true);
			this.getView().byId("vrPrintBtn").setEnabled(false);

			this._masterServiceIntegration("/itspm_dm/team", "vrTeamModelId");
			this._masterServiceIntegration("/itspm_dm/product", "vrProductModelId");
			this._masterServiceIntegration("/itspm_dm/placeholder", "vrPlaceholderModelId");
			this._masterServiceIntegration("/itspm_dm/dateref", "vrDateModelId");
			this._masterServiceIntegration("/itspm_dm/organization", "organizationModelId");
		},
		
		/**
		 * Event handler when a vendor is selected from select vendor combobox
		 * @param {Object} oEvent combobox
		 */
		selectVendor: function (oEvent) {
			var vendorModel = this.getView().getModel("organizationModelId");
			var sSelectedKey = oEvent.getSource().getSelectedKey();
			var oOrganization = vendorModel.getData().organization.find(function (obj) {
				return obj.orgCode === sSelectedKey;
			});
			this.getView().byId("vrVendorEmailId").setValue(oOrganization.orgEmail);
		},
		
		/**
		 * To get all the master data and save in a model
		 * @param {String} sServiceURL service url
		 * @param {Object} sModel model id
		 */
		_masterServiceIntegration: function (sServiceURL, sModel) {
			var oServiceModel = new sap.ui.model.json.JSONModel();
			oServiceModel.loadData(sServiceURL, null, false);
			if (sModel === "vrPlaceholderModelId") {
				var placeholder = oServiceModel.getData().placeHolderToolTip;
				var oData = [{}];
				for (var i = 0; i < placeholder.length; i++) {
					oData[0][placeholder[i].plttId] = placeholder[i];
				}
				oServiceModel.getData().placeHolderToolTip = oData;
			}
			this.getView().setModel(oServiceModel, sModel);
		},
		
		/**
		 * Event handler when discard button is clicked
		 */
		pressDiscard: function () {
			var oControlId = ["vrNameId", "vrTeamId", "vrProductId", "vrDateId", "vrPurposeId", "vrTransitionId", "vrExpectationId",
				"vrVolumeId", "vrMilestoneId", "vrUploadId", "vrCategoryId", "vrInvolvedId", "vrRemarksId", "vrSPMEmailId", "vrSPMRemarksId",
				"vrPAEmailId", "vrPARemarksId", "vrSelectVendorId", "vrVendorEmailId", "vrVendorRemarksId"
			];
			for (var i = 0; i < oControlId.length; i++) {
				this.getView().byId(oControlId[i]).setEnabled(false);
			}
			this.selectList();
			this.getView().byId("vrCancleEditId").setVisible(false);
			this.getView().byId("vrSubmitId").setVisible(false);
			this.getView().byId("vrEditId").setVisible(true);
			this.getView().byId("vrCommentId").setVisible(true);
			this.getView().getContent()[1].getMasterPages()[0].setBusy(false);
			this.getView().byId("vrPrintBtn").setEnabled(true);
		},
		
		/**
		 * Event handler when ok button of status dialog is clicked 
		 * @param {Object} oEvent OK Button
		 */
		pressSubmit: function (oEvent) {
			var status;
			var contexts = this.getView().byId("vrMasterListId").getSelectedContexts();
			var items = contexts.map(function (c) {
				return c.getObject();
			});
			if (this.getView().byId("vrVendorEmailId").getValue() === "") {
				if(this.sMode === "Cancel"){
					status = "Cancelled";
				}else{
					status = "Draft";
				}
			} else if (this.sMode === "Accept" || this.sMode === "Reject" || this.sMode === "Releas") {
				status = this.sMode + "ed";
			} else if (this.sMode === "Cancel") {
				status = this.sMode + "led";
			} else if (this.sMode === "Steady") {
				status = "Steady State";
			} else if (items[0].status === "Accepted" || items[0].status === "Rejected" || items[0].status === "Released" || this.sMode === "Cancelled") {
				status = items[0].status;
				this.sMode = items[0].status;
			} else {
				this.sMode = "Creat";
				status = "Created";
			}

			var newDate = new Date();
			var todaysDate = newDate.getDate() + "/" + (newDate.getMonth() + 1) + "/" + newDate.getFullYear();
			var Time = newDate.getHours() + ":" + newDate.getMinutes();
			var dateGrid = this.getView().byId("vrDateGridId");
			var dateArr = [];
			for (var i = 0; i < dateGrid.getContent().length; i++) {
				var dateValue = dateGrid.getContent()[i].getContent()[1].getValue();
				var dateId = dateGrid.getContent()[i].getContent()[1].getName();
				var dateName = dateGrid.getContent()[i].getContent()[0].getText();
				var date = {
					"crSlNo": items[0].crSlNo,
					"dateName": dateName,
					"dateVal": dateValue,
					"dateId": dateId
				};
				dateArr.push(date);
			}
			var finalJson = {
				"crTransactionDo": {
					"crReqId": "",
					"crRefId": items[0].crRefId,
					"crSlNo": items[0].crSlNo,
					"reqRefId": this.getView().byId("vrReferenceId").getValue(),
					"costObjt": this.getView().byId("vrCostObjectId").getValue(),
					"crTypeId": this.getView().byId("vrTypeId").getSelectedKey(),
					"crTypeName": this.getView().byId("vrTypeId").getValue(),
					"crName": this.getView().byId("vrNameId").getValue(),
					"flag": false,
					"productSlNo": Number(this.getView().byId("vrProductId").getSelectedKey()),
					"productName": this.getView().byId("vrProductId").getValue(),
					"teamSlNo": Number(this.getView().byId("vrTeamId").getSelectedKey()),
					"teamName": this.getView().byId("vrTeamId").getValue(),
					"categoryId": this.getView().byId("vrCategoryId").getValue(),
					"purpose": this.getView().byId("vrPurposeId").getValue(),
					"transition": this.getView().byId("vrTransitionId").getValue(),
					"volume": this.getView().byId("vrVolumeId").getValue(),
					"status": status,
					"vUserId": this.getView().byId("vrSelectVendorId").getSelectedKey(),
					"vendorCode": this.getView().byId("vrSelectVendorId").getSelectedKey(),
					"vEmail": this.getView().byId("vrVendorEmailId").getValue(),
					"vName": this.getView().byId("vrSelectVendorId").getValue(),
					"spmUserId": "",
					"spmEmail": this.getView().byId("vrSPMEmailId").getValue(),
					"paUserId": "",
					"paEmail": this.getView().byId("vrPAEmailId").getValue(),
					"rmrkCreateCR": this.getView().byId("vrRemarksId").getValue(),
					"rmkrForVendor": this.getView().byId("vrVendorRemarksId").getValue(),
					"rmkrForSPM": this.getView().byId("vrSPMRemarksId").getValue(),
					"rmkrForPA": this.getView().byId("vrPARemarksId").getValue(),
					"expectation": this.getView().byId("vrExpectationId").getValue(),
					"milestone": this.getView().byId("vrMilestoneId").getValue(),
					"involvedSys": this.getView().byId("vrInvolvedId").getValue(),
					"createdBy": this.getView().getModel("vrDetailModelId").getData().crTransactionDo.createdBy,
					"createdDate": items[0].createdDate,
					"lastModfBy": this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userEmail,
					"lastModfDate": todaysDate
				},
				"crDateTransactionDo": dateArr

			};

			var mdlObj = new sap.ui.model.json.JSONModel();
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			mdlObj.loadData("/itspm_dm/changerequest/" + items[0].crSlNo,
				JSON.stringify(finalJson), false, "PUT", false, false, oHeader);

			if (mdlObj.getData() && mdlObj.getData().status === 204) {

				var oFileUploader = this.getView().byId("vrUploadId");
				var oFormData = new FormData();
				oFormData.append("vEmail", this.getView().byId("vrVendorEmailId").getValue());
				oFormData.append("paEmail", this.getView().byId("vrPAEmailId").getValue());
				oFormData.append("spmEmail", this.getView().byId("vrSPMEmailId").getValue());
				oFormData.append("createdBy", this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userId);
				oFormData.append("crRefId", mdlObj.getData().createRequest);
				oFormData.append("crSlNo", items[0].crSlNo);
				for (var i = 0; i < this.ofilesToUploadJson.getData().files.length; i++) {
					oFormData.append("data", this.ofilesToUploadJson.getData().files[i]);
				}
				var data = jQuery.ajax({
					url: "/itspm_dm/fileupload",
					data: oFormData,
					cache: false,
					contentType: false,
					processData: false,
					async: false,
					type: 'POST',
					success: function (oData) {
						return oData;
					}
				});
				var idCreatedMsg;
				if (this.sMode === "Accept" || this.sMode === "Reject" || this.sMode === "Releas" || this.sMode === "Cancel" || this.sMode === "Steady") {

					var toEmailId = sap.ui.getCore().byId("statusToEmailId").getSelectedKeys();
					var sDefaultComment;
					if (this.sMode === "Steady") {
						sDefaultComment = "Steady :-";
					} else if(this.sMode === "Cancel"){
						sDefaultComment = this.sMode + "led :-";
					} else {
						sDefaultComment = this.sMode + "ed :-";
					}

					var commentJson = {
						"crRefId": items[0].crRefId,
						"crRefSlNo": items[0].crSlNo,
						"comment": sDefaultComment + sap.ui.getCore().byId("commentStatusId").getValue().replace(/(?:\r\n|\r|\n)/g, '<br/>'),
						"commentedUser": this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userName,
						"commentedUserId": this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userId,
						"createdOn": todaysDate + "," + Time,
						"receiverEmailId": toEmailId
					};
					var commentMdlObj = new sap.ui.model.json.JSONModel();
					var oCommentHeader = {
						"Content-Type": "application/json;charset=utf-8"
					};
					commentMdlObj.loadData("/itspm_dm/usercomments",
						JSON.stringify(commentJson), false, "POST", false, false, oCommentHeader);

					idCreatedMsg = mdlObj.getData().createRequest + " " + status + " successfully";
					oEvent.getSource().getParent().close();
					oEvent.getSource().getParent().destroy();

				} else {
					idCreatedMsg = mdlObj.getData().createRequest + " " + "updated successfully.";
				}
				this.getView().byId("vrMasterListId").getSelectedItem().setInfo(status);

				if (data.responseJSON && data.responseJSON.status !== 200) {
					idCreatedMsg = idCreatedMsg + " Error in file uploading, try to upload it again";
				}
				this.ofilesToUploadJson.setData({
					files: []
				});
				this._statusDialog("Success", "Success", idCreatedMsg);
			} else {
				this._statusDialog("Error", "Error", "Technical error. Please try again later");
			}
			this.pressDiscard();
		},
		
		/**
		 * Event handler when Decline button of comment, create request and status dialog is clicked 
		 * @param {Object} oEvent Decline Button
		 */
		pressDecline: function (oEvent) {
			oEvent.getSource().getParent().getParent().close();
			oEvent.getSource().getParent().getParent().destroy();
		},
		
		/**
		 * Event handler when Comment button of detail page is clicked 
		 */
		pressComment: function () {
			var contexts = this.getView().byId("vrMasterListId").getSelectedContexts();
			var items = contexts.map(function (c) {
				return c.getObject();
			});
			var oCommentModel = new sap.ui.model.json.JSONModel();
			oCommentModel.loadData("/itspm_dm/usercomments/" + items[0].crSlNo, null, false);
			this.getView().setModel(oCommentModel, "oCommentModelId");
			var oCommentDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.CommentDialog", this);
			this.getView().addDependent(oCommentDialog);
			oCommentDialog.open();
		},
		
		/**
		 * Event handler when post button of feed input on comment dialog is clicked 
		 * @param {Object} oEvent post Button of feed input
		 */
		postComment: function (oEvent) {
			var newDate = new Date();
			var todaysDate = newDate.getDate() + "/" + (newDate.getMonth() + 1) + "/" + newDate.getFullYear();
			var Time = newDate.getHours() + ":" + newDate.getMinutes();

			var contexts = this.getView().byId("vrMasterListId").getSelectedContexts();
			var items = contexts.map(function (c) {
				return c.getObject();
			});
			var toEmailId = sap.ui.getCore().byId("commentToEmailId").getSelectedKeys();
			var commentJson = {
				"crRefId": items[0].crRefId,
				"crRefSlNo": items[0].crSlNo,
				"comment": oEvent.getParameter("value").replace(/(?:\r\n|\r|\n)/g, '<br/>'),
				"commentedUser": this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userName,
				"commentedUserId": this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userId,
				"createdOn": todaysDate + "," + Time,
				"receiverEmailId": toEmailId
			};
			var mdlObj = new sap.ui.model.json.JSONModel();
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			mdlObj.loadData("/itspm_dm/usercomments",
				JSON.stringify(commentJson), false, "POST", false, false, oHeader);

			sap.ui.getCore().byId("commentToEmailId").clearSelection();
			var oCommentModel = new sap.ui.model.json.JSONModel();
			oCommentModel.loadData("/itspm_dm/usercomments/" + items[0].crSlNo, null, false);
			this.getView().setModel(oCommentModel, "oCommentModelId");
		},
		
		/**
		 * Event handler when Cancel button is clicked 
		 */
		pressCancel: function () {
			this.sMode = "Cancel";
			var oRejectDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.StatusDialog", this);
			this.getView().addDependent(oRejectDialog);
			oRejectDialog.getSubHeader().getContent()[1].setText("Cancel");
			oRejectDialog.open();
		},
		
		/**
		 * Event handler when Accept button is clicked 
		 */
		pressAccept: function () {
			this.sMode = "Accept";
			var oAcceptDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.StatusDialog", this);
			this.getView().addDependent(oAcceptDialog);
			oAcceptDialog.getSubHeader().getContent()[1].setText("Accept");
			oAcceptDialog.open();
		},
		
		/**
		 * Event handler when Reject button is clicked 
		 */
		pressReject: function () {
			this.sMode = "Reject";
			var oRejectDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.StatusDialog", this);
			this.getView().addDependent(oRejectDialog);
			oRejectDialog.getSubHeader().getContent()[1].setText("Reject");
			oRejectDialog.open();
		},
		
		/**
		 * Event handler when Steady state button is clicked 
		 */
		pressSteady: function () {
			this.sMode = "Steady";
			var oRejectDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.StatusDialog", this);
			this.getView().addDependent(oRejectDialog);
			oRejectDialog.getSubHeader().getContent()[1].setText("Steady State");
			oRejectDialog.open();
		},
		
		/**
		 * Event handler when Close button is clicked 
		 */
		pressClose: function () {
			this.sMode = "Releas";
			var oRejectDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.StatusDialog", this);
			this.getView().addDependent(oRejectDialog);
			oRejectDialog.getSubHeader().getContent()[1].setText("Release");
			oRejectDialog.open();
		},

		pressOkStatusChange: function (oEvent) {
		},
		
		/**
		 * Event handler when slider in filter dialog is changed 
		 * @param {Object} oEvent slider
		 */
		filterSliderChange: function (oEvent) {
			var oRange = oEvent.getParameter("range");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("crSlNo", sap.ui.model.FilterOperator.BT, oRange[0], oRange[1]));
			var oList = oEvent.getSource().getParent().getContent()[1];
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},
		
		/**
		 * Event handler when search criteria in master page is changed 
		 * @param {Object} oEvent search bar
		 */
		searchInMaster: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("crRefId", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("crTypeName", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.Contains, sQuery));
			var oFilter = new sap.ui.model.Filter(aFilter, false);
			var oList = this.getView().byId("vrMasterListId");
			var oBinding = oList.getBinding("items");
			oBinding.filter(oFilter);
		},
		
		/**
		 * Event handler when search criteria in download dialog is changed 
		 * @param {Object} oEvent search bar
		 */
		downloadDialogSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("crRefId", sap.ui.model.FilterOperator.Contains, sValue));
			aFilter.push(new sap.ui.model.Filter("crTypeName", sap.ui.model.FilterOperator.Contains, sValue));
			aFilter.push(new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.Contains, sValue));
			aFilter.push(new sap.ui.model.Filter("teamName", sap.ui.model.FilterOperator.Contains, sValue));
			aFilter.push(new sap.ui.model.Filter("productName", sap.ui.model.FilterOperator.Contains, sValue));
			var oFilter = new sap.ui.model.Filter(aFilter, false);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(oFilter);
		},
		
		/**
		 * Event handler when date is selcted from dropdown in filter dialog 
		 * @param {Object} oEvent select input field
		 */
		dateFilterSelectionChange: function (oEvent) {
			oEvent.getSource().getParent().getItems()[2].setValue();
			var selectedKey = oEvent.getParameter("selectedItem").getKey();
			if (selectedKey !== "select") {
				oEvent.getSource().getParent().getItems()[2].setEnabled(true);
			} else {
				oEvent.getSource().getParent().getItems()[2].setEnabled(false);
			}
		},
		
		/**
		 * Event handler when Ok button of filter dialog is clicked 
		 * @param {Object} oEvent ok button
		 */
		handleConfirm: function (oEvent) {
			var oDialogContent = oEvent.getSource().getDependents()[0].getContent()[0].getPages()[1].getContent();
			if (oDialogContent[0].getContent()[0].getItems()[1].getSelected() === true) {
				var oDate = [];
				if (oDialogContent[0].getContent()[1].getItems()[0].getContent()[0].getItems()[0].getSelectedKey() !== "select") {
					oDate.push(oDialogContent[0].getContent()[1].getItems()[0].getContent()[0].getItems()[0].getSelectedKey());
					var oFromDate = oDialogContent[0].getContent()[1].getItems()[0].getContent()[0].getItems()[2].getDateValue();
					var oToDate = oDialogContent[0].getContent()[1].getItems()[0].getContent()[0].getItems()[2].getSecondDateValue();
					oDate.push((oFromDate.getMonth() + 1) + "/" + oFromDate.getDate() + "/" + oFromDate.getFullYear().toString().slice(-2));
					oDate.push((oToDate.getMonth() + 1) + "/" + oToDate.getDate() + "/" + oToDate.getFullYear().toString().slice(-2));
					var oData = {
						"dateId": oDate[0],
						"startDate": oDate[1],
						"endDate": oDate[2]
					};
					var mdlObj = new sap.ui.model.json.JSONModel();
					var oHeader = {
						"Content-Type": "application/json;charset=utf-8"
					};
					mdlObj.loadData("/itspm_dm/changerequest/filter/date",
						JSON.stringify(oData), false, "POST", false, false, oHeader);
					var vrMasterModel = this._sortDescendingList(mdlObj);
					this.getView().setModel(vrMasterModel, "vrMasterModelId");
					this.getView().getModel("vrMasterModelId").refresh();

					if (oDate.length) {
						this.filtered = true;
					} else {
						this.filtered = false;
					}
				}
			} else {
				oDialogContent = oDialogContent[0].getContent()[1].getItems()[1].getItems();
				var oRequestRange = oDialogContent[0].getContent()[0].getRange();
				var oRequestNum = [];
				var oStatus = [];
				var oType = [];
				var oTeam = [];
				var oProduct = [];
				var oVendor = [];
				var oCreatedBy = [];

				for (var i = 0; i < oDialogContent[0].getContent()[1].getSelectedItems().length; i++) {
					oRequestNum.push(oDialogContent[0].getContent()[1].getSelectedItems()[i].getCells()[0].getText());
				}
				for (var i = 0; i < oDialogContent[1].getContent()[0].getItems()[0].getSelectedItems().length; i++) {
					oType.push(oDialogContent[1].getContent()[0].getItems()[0].getSelectedItems()[i].getTitle());
				}
				for (var i = 0; i < oDialogContent[2].getContent()[0].getItems()[0].getSelectedItems().length; i++) {
					oStatus.push(oDialogContent[2].getContent()[0].getItems()[0].getSelectedItems()[i].getTitle());
				}
				for (var i = 0; i < oDialogContent[3].getContent()[0].getItems()[0].getSelectedItems().length; i++) {
					oTeam.push(oDialogContent[3].getContent()[0].getItems()[0].getSelectedItems()[i].getTitle());
				}
				for (var i = 0; i < oDialogContent[4].getContent()[0].getItems()[0].getSelectedItems().length; i++) {
					oProduct.push(oDialogContent[4].getContent()[0].getItems()[0].getSelectedItems()[i].getTitle());
				}
				for (var i = 0; i < oDialogContent[5].getContent()[0].getItems()[0].getSelectedItems().length; i++) {
					oVendor.push(oDialogContent[5].getContent()[0].getItems()[0].getSelectedItems()[i].getInfo());
				}
				for (var i = 0; i < oDialogContent[6].getContent()[1].getSelectedItems().length; i++) {
					oCreatedBy.push(oDialogContent[6].getContent()[1].getSelectedItems()[i].getInfo());
				}
				var aFilter = [];

				if (oRequestNum.length) {
					for (var i = 0; i < oRequestNum.length; i++) {
						aFilter.push(new sap.ui.model.Filter("crRefId", sap.ui.model.FilterOperator.EQ, oRequestNum[i]));
					}
				}

				if (oStatus.length) {
					for (var i = 0; i < oStatus.length; i++) {
						aFilter.push(new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, oStatus[i]));
					}
				}

				if (oType.length) {
					for (var i = 0; i < oType.length; i++) {
						aFilter.push(new sap.ui.model.Filter("crTypeName", sap.ui.model.FilterOperator.EQ, oType[i]));
					}
				}
				if (oTeam.length) {
					for (var i = 0; i < oTeam.length; i++) {
						aFilter.push(new sap.ui.model.Filter("teamName", sap.ui.model.FilterOperator.EQ, oTeam[i]));
					}
				}
				if (oProduct.length) {
					for (var i = 0; i < oProduct.length; i++) {
						aFilter.push(new sap.ui.model.Filter("productName", sap.ui.model.FilterOperator.EQ, oProduct[i]));
					}
				}
				if (oVendor.length) {
					for (var i = 0; i < oVendor.length; i++) {
						aFilter.push(new sap.ui.model.Filter("vendorCode", sap.ui.model.FilterOperator.EQ, oVendor[i]));
					}
				}
				if (oCreatedBy.length) {
					for (var i = 0; i < oCreatedBy.length; i++) {
						aFilter.push(new sap.ui.model.Filter("createdBy", sap.ui.model.FilterOperator.EQ, oCreatedBy[i]));
					}
				}
				var vrMasterModel = new sap.ui.model.json.JSONModel();
				if (this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup === "Vendor") {
					vrMasterModel.loadData("/itspm_dm/changerequest/vendor/" + this.getOwnerComponent().getModel("userLoginModel").getData().userDetail
						.vendorCode, null, false);
					vrMasterModel = this._sortDescendingList(vrMasterModel);
				} else {
					vrMasterModel.loadData("/itspm_dm/changerequest", null, false);
					vrMasterModel = this._sortDescendingList(vrMasterModel);
				}
				this.getView().setModel(vrMasterModel, "vrMasterModelId");
				this.getView().getModel("vrMasterModelId").refresh();

				// filter binding
				var oList = this.getView().byId("vrMasterListId");
				var oBinding = oList.getBinding("items");
				oBinding.filter(aFilter);

				if (aFilter.length) {
					this.filtered = true;
				} else {
					this.filtered = false;
				}
			}
			this.getView().byId("vrMasterListId").setSelectedItem(this.getView().byId("vrMasterListId").getItems()[0], true);
			this.selectList();
			oEvent.getSource().destroy();
		},
		
		/**
		 * Event handler when Cancel button of filter dialog is clicked 
		 * @param {Object} oEvent Cancel button
		 */
		handleCancel:function(oEvent){
			oEvent.getSource().destroy();
		},
		
		/**
		 * To open success, error and warning message dialog 
		 * @param {String} title of dialog
		 * @param {String} status to update
		 * @param {String} text to display in content
		 */
		_statusDialog: function (title, status, text) {
			var oDialog = new sap.m.Dialog({
				title: title,
				type: "Message",
				state: status,
				content: new sap.m.Text({
					text: text
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function (oEvnt) {
						oDialog.close();
						oEvnt.getSource().getParent().close();
						oEvnt.getSource().getParent().destroy();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});
			oDialog.open();
		},
		
		/**
		 * Event handler when Print button is clicked 
		 */
		pressPrintCRDetails:function(){
			var contexts = this.getView().byId("vrMasterListId").getSelectedContexts();
			var oItem = contexts.map(function (c) {
				return c.getObject();
			});
			var crName = this.getView().byId("vrNameId").getValue();
			var crType = this.getView().byId("vrTypeId").getValue();
			var crTeam = this.getView().byId("vrTeamId").getValue();
			var crProduct = this.getView().byId("vrProductId").getValue();
			var crPurpose = this.getView().byId("vrPurposeId").getValue();
			var crTransition = this.getView().byId("vrTransitionId").getValue();
			var crExpectation = this.getView().byId("vrExpectationId").getValue();
			var crMilestone = this.getView().byId("vrMilestoneId").getValue();
			var crCategoryId = this.getView().byId("vrCategoryId").getValue();
			var crInvolvedSystem = this.getView().byId("vrInvolvedId").getValue();
			var crRemark = this.getView().byId("vrRemarksId").getValue();
			var part1PDF = "<html>" +
							"<head>" +
							"</head>" +
							"<body>" +
							
							"<h1 style='text-align:center;'>SPM PROGRAM</h1>" +
							"<h2 style='text-align:center;'>Demand fulfilment Project Request form</h2>" +
							
							"<ul style='list-style-type:none;'>" +
							  "<li style='padding-bottom:1%;'>Project Request Number : " + oItem[0].crRefId + "</li>" +
							  "<li style='padding-bottom:1%;'>CR Name : " + crName + "</li>" +
							  "<li style='padding-bottom:1%;'>Type : " + crType + "</li>" +
							  "<li style='padding-bottom:1%;'>Team : " + crTeam + "</li>" +
							  "<li style='padding-bottom:1%;'>Product : " + crProduct + "</li>";
			 				  
			var dateGrid = this.getView().byId("vrDateGridId");
			var subdate = "";
			var dateList;
			var crDateName = "";
			var crDateValue = "";
			for (var i = 0; i < dateGrid.getContent().length; i++) {
				crDateName = dateGrid.getContent()[i].getContent()[0].getText();
				crDateValue = dateGrid.getContent()[i].getContent()[1].getValue();
				dateList = "<li style='padding-bottom:1%;padding-left:5%;'>" + crDateName + " " + crDateValue + "</li>";
				subdate += dateList;
			}
			var part2PDF =	  "<li style='padding-bottom:1%;'>Date Fields : </li>";
							  
			var part3PDF = 	  "<li style='padding-bottom:1%;'>Purpose :" + crPurpose + "</li>" +
							  "<li style='padding-bottom:1%;'>Transition :" + crTransition + "</li>" +
							  "<li style='padding-bottom:1%;'>Expectation :" + crExpectation + "</li>" +
							  "<li style='padding-bottom:1%;'>Milestone :" + crMilestone + "</li>";
			var crAttachment = "";
			var fileModel = this.getView().getModel("vrDetailModelId").getData().files;
			for (var j = 0; j < fileModel.length; j++) {
				crAttachment += fileModel[j].name + " , ";
			}
			crAttachment = crAttachment.slice(0,crAttachment.length - 1);
			var part4PDF = 	  "<li style='padding-bottom:1%;'>Attachment : " + crAttachment + "</li>";
			
			var part5PDF = 	  "<li style='padding-bottom:1%;'>Category ID : " + crCategoryId + "</li>" +
							  "<li style='padding-bottom:1%;'>Involved system : " + crInvolvedSystem + "</li>" +
							  "<li style='padding-bottom:1%;'>Remarks : " + crRemark + "</li>" +
							"</ul>" +
							
							"</body>" +
							"</html>";
			var ctrlString = "width=1000,height=1000";
			var wind = window.open("", "PrintWindow", ctrlString);     
			wind.document.write(part1PDF + part2PDF + subdate + part3PDF + part4PDF + part5PDF);
			wind.print();
			wind.close();
		}
	});

});
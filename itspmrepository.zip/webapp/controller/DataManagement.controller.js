sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("IT_SPM_DM.controller.DataManagement", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf IT_SPM_DM.view.DataManagement
		 */
			onInit: function() {
				var oController = this;
					sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function(oEvent){
						if(!oController.getOwnerComponent().getModel("userLoginModel")){
					setTimeout(function(){
						var router = sap.ui.core.UIComponent.getRouterFor(oController);
						router.navTo("RequestUser");	
					}, 100);
					
				}
					});
			
			},
			
		/**
		 * To refresh the master data page and set it to initial condition
		 */
		_refreshData : function(){
			var refreshModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(refreshModel,"refreshDataModel");
			this.getView().getModel("refreshDataModel").setData(null);
			this.getView().getModel("refreshDataModel").refresh();
			
			this.getView().getModel("refreshDataModel").destroy();
		},
		
		/**
		 * Event handler when a description is selected from dropdown (Help Text View) 
		 * @param {Object} oEvent search bar
		 */
		onselectdesc : function(oEvent){
			var sSelectedKey = oEvent.getParameter("selectedItem").getKey();
			var oServiceModel = new sap.ui.model.json.JSONModel();
				oServiceModel.loadData("/itspm_dm/placeholder",null,false);
				this.getView().setModel(oServiceModel,"oServiceModelId");
				var result;
				if(oServiceModel.getData().placeHolderToolTip){
					 result = oServiceModel.getData().placeHolderToolTip.filter(function( obj ) {
						return obj.plttId === sSelectedKey;	
					});
				}
			if(result.length === 0){
				this.getView().byId("htPlaceholderId").setValue("");
				this.getView().byId("htTooltipId").setValue("");
			}else if(sSelectedKey === result[0].plttId){
				this.getView().byId("htPlaceholderId").setValue(result[0].placeHolderVal);
				this.getView().byId("htTooltipId").setValue(result[0].toolTipVal);
			}
		},
		
		/**
		 * Event handler when edit button is clicked (Help Text View) 
		 */
		OnPressEditHelpText : function(){
			var inputs = [
				this.getView().byId("htSelectId")
				];
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
					if (input.getSelectedItem().getText() === "Select"){
						input.setValueState("Error");
						canContinue = false;
					}else{
						input.setValueState("None");
					}
			});
			if(!canContinue){
				this._statusDialog("Error","Error","Please select a description to edit");
			}else{
			this.getView().byId("htPlaceholderId").setEnabled(true);
			this.getView().byId("htTooltipId").setEnabled(true);
			this.getView().byId("ApplyChangesId").setVisible(true);
			this.getView().byId("EditHelpTextId").setVisible(false);
			}
		},
		
		/**
		 * Event handler when appy changes is clicked (Help Text View) 
		 */
		pressApplyChanges: function(){
			var selectedItem = this.getView().byId("htSelectId").getSelectedItem();
			var selectedItemText = this.getView().byId("htSelectId").getSelectedItem().getText();
			var oData = {};
				oData.plttId = selectedItem.getKey();
				oData.plttName = selectedItem.getText();
				oData.placeHolderVal = 	this.getView().byId("htPlaceholderId").getValue();
				oData.toolTipVal =	this.getView().byId("htTooltipId").getValue();
				
			var result = this.getView().getModel("oServiceModelId").getData().placeHolderToolTip.filter(function( obj ) {
				return obj.plttId === selectedItem.getKey();
			});
			if(result.length === 0){
				var oplaceholderModel = new sap.ui.model.json.JSONModel();
				var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
				oplaceholderModel.loadData("/itspm_dm/placeholder",JSON.stringify(oData),false, "POST",false,false,oHeader);
				if(oplaceholderModel.getData().status === 201){
					var helpTextMsg = "Help text for" + " " + selectedItemText + " " + "created successfully";
					this._statusDialog("Success","Success",helpTextMsg);
				}else {
					this._statusDialog("Error","Error","Technical error. Please try again later");
				}
			}else if(selectedItem.getKey() === result[0].plttId){
				oData.plttSlNo = result[0].plttSlNo;
				var oplaceholderModelPut = new sap.ui.model.json.JSONModel();
				var oHeaderPut = {"Content-Type" : "application/json;charset=utf-8"};
				oplaceholderModelPut.loadData("/itspm_dm/placeholder/" + result[0].plttSlNo ,JSON.stringify(oData),false, "PUT",false,false,oHeaderPut);
				if(oplaceholderModelPut.getData().status === 204){
					var helpTextMsg = "Help text for" + " " + selectedItemText + " " + "edited successfully";
					this._statusDialog("Success","Success",helpTextMsg);
				}else {
					this._statusDialog("Error","Error","Technical error. Please try again later");
				}
			}
			
			this.getView().byId("htPlaceholderId").setEnabled(false);
			this.getView().byId("htTooltipId").setEnabled(false);
			this.getView().byId("EditHelpTextId").setVisible(true);
			this.getView().byId("ApplyChangesId").setVisible(false);
		},
		
		/**
		 * Event handler when back button is clicked 
		 */
		pressBackButton:function(){
			var cUserId = this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userId;
			if(this.getView().getModel("oUserModelId") && this.getView().getModel("oUserModelId").getData().user){
				var result = this.getView().getModel("oUserModelId").getData().user.filter(function( obj ) {
				  return obj.userId === cUserId;
				});
				if(!result.length){
					this.getOwnerComponent().getModel("userLoginModel").destroy();
					var router = sap.ui.core.UIComponent.getRouterFor(this);
				router.navTo("RequestUser");
			
				}
				else{
					var router = sap.ui.core.UIComponent.getRouterFor(this);
				router.navTo("Dashboard");
				}
			}
			else{
				var router = sap.ui.core.UIComponent.getRouterFor(this);
				router.navTo("Dashboard");
			}
		},
		
		/**
		 * Event handler when master data maintainance list item is clicked 
		 */
		onPressMasterDataMaintain : function() {
			this.getSplitAppObj().toMaster(this.createId("adminMasterPage2Id"));
		},
		
		/**
		 * Event handler when back button in detail page is clicked.(create message page)
		 * this button is only visible in mobile view
		 */
		onPressNavBack:function(){
			this.getSplitAppObj().toMaster(this.createId("adminMasterPageId"));
		},
		
		/**
		 * Event handler when master list item is clicked 
		 * @param {Object} oEvent list item
		 */
		onPressActiveMasterListItem: function(oEvent){
			var sToPageId = oEvent.getSource().getCustomData()[0].getValue();
			this.getSplitAppObj().toDetail(this.createId(sToPageId));
			if(sap.ui.Device.system.phone){
				this.byId(sToPageId).setShowNavButton(true);
			}
		},
		
		/**
		 * Event handler when back button in detail page is clicked.(Team detail page)
		 * this button is only visible in mobile view
		 */
		onPressNavBackMasterData:function(){
			this.getSplitAppObj().backDetail();
		},
		
		/**
		 * Event handler when master data maintainance item is clicked 
		 * @param {Object} oEvent list item
		 */
		pressListUser: function(oEvent){
			var sToPageId;
			if(typeof(oEvent) === "object"){
				sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();
				if(sap.ui.Device.system.phone){
					this.byId(sToPageId).setShowNavButton(true);
				}
			}
			else{
				sToPageId = oEvent;	
			}
			this.getSplitAppObj().toDetail(this.createId(sToPageId));
			if(sToPageId === "teamDetailId"){
				this.itemPressed = "teamDetailId";
				var oTeamModel = new sap.ui.model.json.JSONModel();
				oTeamModel.loadData("/itspm_dm/team",null,false); 
				this.getView().setModel(oTeamModel,"oTeamModelId");
				this.getView().byId("removeTeamButtonId").setEnabled(false);
				this.getView().byId("addTeamPanelId").setVisible(false);
				this.getView().byId("searchTeamId").setValue();
			}else if(sToPageId === "productDetailId"){
				this.itemPressed = "productDetailId";
				var oProductModel = new sap.ui.model.json.JSONModel();
				oProductModel.loadData("/itspm_dm/product",null,false); 
				this.getView().setModel(oProductModel,"oProductModelId");
				this.getView().byId("addProductPanelId").setVisible(false);
				this.getView().byId("removeProdButtonId").setEnabled(false);
				this.getView().byId("searchProdId").setValue();
			}else if(sToPageId === "dateDetailId"){
				this.itemPressed = "dateDetailId";
				var oDateModel = new sap.ui.model.json.JSONModel();
				oDateModel.loadData("/itspm_dm/dateref",null,false); 
				this.getView().setModel(oDateModel,"oDateModelId");
				this.getView().byId("addDatePanelId").setVisible(false);
				this.getView().byId("removeDateButtonId").setEnabled(false);
				this.getView().byId("searchDateId").setValue();
			}else if(sToPageId === "userDataDetailId"){
				this.itemPressed = "userDataDetailId";
				var oUserModel = new sap.ui.model.json.JSONModel();
				oUserModel.loadData("/itspm_dm/user",null,false); 
				this.getView().setModel(oUserModel,"oUserModelId");
				this.getView().byId("addUserpanelId").setVisible(false);
				this.getView().byId("removeUserButtonId").setEnabled(false);
				this.getView().byId("activateUserId").setEnabled(false);
				this.getView().byId("inactivateUserId").setEnabled(false);
				this.getView().byId("searchUserId").setValue();
			}else if(sToPageId === "organizationDetailId"){
				this.itemPressed = "organizationDetailId";
				var oOrgModel = new sap.ui.model.json.JSONModel();
				oOrgModel.loadData("/itspm_dm/organization",null,false); 
				this.getView().setModel(oOrgModel,"oOrgModelId");
				this.getView().byId("addOrgpanelId").setVisible(false);
				this.getView().byId("removeOrgButtonId").setEnabled(false);
				this.getView().byId("searchOrgId").setValue();
			}
		},
		searchTeam:function(oEvent){
			var sQuery = oEvent.getParameter("query");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("teamId", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("teamName", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("spmName", sap.ui.model.FilterOperator.Contains, sQuery));
			var oFilter = new sap.ui.model.Filter( aFilter, false );
			var oList = this.getView().byId("teamTableId");
				var oBinding = oList.getBinding("items");
				oBinding.filter(oFilter);
		},
		pressAddTeam:function(){
			var inputs = ["teamIdId","teamNameId","teamSPMId","teamSPMIdId","teamPAId","teamPAIdId"];
			for(var i = 0; i < inputs.length; i++){
				this.getView().byId(inputs[i]).setValueState("None");
			}
			this._refreshData();
			this.getView().byId("addTeamPanelId").setVisible(true);
		},
		pressRemoveTeam : function(){
			var contexts =  this.getView().byId("teamTableId").getSelectedContexts();
			 var items = contexts.map(function (c) {
				return c.getObject();
			}); 
				var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
				var oTeamDeleteModel = new sap.ui.model.json.JSONModel();
			oTeamDeleteModel.loadData("/itspm_dm/team/" + items[0].teamSlNo,null,false, "DELETE",false,false,oHeader);
		
				if(oTeamDeleteModel.getData().status === 200){
					this._refreshData();
					this._statusDialog("Success","Success","Team deleted successfully");
				}else {
					this._statusDialog("Error","Error","Technical error. Please try again later");
				}
				this.pressListUser("teamDetailId");
		},
		teamTableSelect : function(oEvent){
			this.getView().byId("removeTeamButtonId").setEnabled(true);
		},
		pressAddNewTeam:function(){
			var view = this.getView();
			var inputs = [
				view.byId("teamIdId"),
				view.byId("teamNameId"),
				view.byId("teamDescId")
				];
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
					if(!input.getValue()){
						input.setValueState("Error");
						canContinue = false;
					}else{
						input.setValueState("None");
					}
			});
			if(!canContinue){
				this._statusDialog("Error","Error","Please complete the input first");
			}else{
			var oData = {
				"teamId": this.getView().byId("teamIdId").getValue(),
				"teamName" : this.getView().byId("teamNameId").getValue(),
				"teamDes" : this.getView().byId("teamDescId").getValue(),
				"spmId" : this.getView().byId("teamSPMIdId").getValue(),
				"spmName" : this.getView().byId("teamSPMId").getValue(),
				"paId" : this.getView().byId("teamPAIdId").getValue(),
				"paName" : this.getView().byId("teamPAId").getValue()
			};
			
			var oTeamAddModel = new sap.ui.model.json.JSONModel();
			var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
			oTeamAddModel.loadData("/itspm_dm/team",JSON.stringify(oData),false, "POST",false,false,oHeader);
			if(oTeamAddModel.getData().status === 201){
				this._refreshData();
				this._statusDialog("Success","Success","Team created successfully");
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again later");
			}
			this.pressListUser("teamDetailId");
			}
		},
		searchProduct:function(oEvent){
			var sQuery = oEvent.getParameter("query");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("productId", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("productName", sap.ui.model.FilterOperator.Contains, sQuery));
	
			var oFilter = new sap.ui.model.Filter( aFilter, false );
			
			var oList = this.getView().byId("productTableId");
				var oBinding = oList.getBinding("items");
				oBinding.filter(oFilter);
		},
		pressAddProduct:function(){
			var inputs = ["productIdId","productNameId"];
			for(var i = 0; i < inputs.length; i++){
				this.getView().byId(inputs[i]).setValueState("None");
			}
			this._refreshData();
			this.getView().byId("addProductPanelId").setVisible(true);
		},
		pressRemoveProd : function(){
			var contexts =  this.getView().byId("productTableId").getSelectedContexts();
			 var items = contexts.map(function (c) {
				return c.getObject();
			}); 
				var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
				var oProdDeleteModel = new sap.ui.model.json.JSONModel();
			oProdDeleteModel.loadData("/itspm_dm/product/" + items[0].productSlNo,null,false, "DELETE",false,false,oHeader);
		
				if(oProdDeleteModel.getData().status === 200){
					this._refreshData();
					this._statusDialog("Success","Success","Product deleted successfully");
				}else {
					this._statusDialog("Error","Error","Technical error. Please try again later");
				}
				this.pressListUser("productDetailId");
		},
		productTableSelect : function(oEvent){
			this.getView().byId("removeProdButtonId").setEnabled(true);
		},
		pressAddNewProduct:function(){
			var view = this.getView();
			var inputs = [
				view.byId("productIdId"),
				view.byId("productNameId")
				];
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
					if(!input.getValue()){
						input.setValueState("Error");
						canContinue = false;
					}else{
						input.setValueState("None");
					}
			});
			if(!canContinue){
				this._statusDialog("Error","Error","Please complete the input first");
			}else{
			var oData = {
				"productId": this.getView().byId("productIdId").getValue(),
				"productName" : this.getView().byId("productNameId").getValue(),
				"productDes" : this.getView().byId("productDescId").getValue()
			};
			
			var oUserAddModel = new sap.ui.model.json.JSONModel();
			var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
			oUserAddModel.loadData("/itspm_dm/product",JSON.stringify(oData),false, "POST",false,false,oHeader);
			if(oUserAddModel.getData().status === 201){
				this._refreshData();
				this._statusDialog("Success","Success","Product created successfully");
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again later");
			}
			this.pressListUser("productDetailId");
			}
		},
		searchDate:function(oEvent){
			var sQuery = oEvent.getParameter("query");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("dateRefId", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("dateRefName", sap.ui.model.FilterOperator.Contains, sQuery));
	
			var oFilter = new sap.ui.model.Filter( aFilter, false );
			
			var oList = this.getView().byId("dateTableId");
				var oBinding = oList.getBinding("items");
				oBinding.filter(oFilter);
		},
		pressAddDate:function(){
			var inputs = ["DatetIdId","DatetNameId"];
			for(var i = 0; i < inputs.length; i++){
				this.getView().byId(inputs[i]).setValueState("None");
			}
			this._refreshData();
			this.getView().byId("addDatePanelId").setVisible(true);
		},
		
		pressRemoveDate : function(){
			var contexts =  this.getView().byId("dateTableId").getSelectedContexts();
			 var items = contexts.map(function (c) {
				return c.getObject();
			}); 
				var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
				var oEmailDeleteModel = new sap.ui.model.json.JSONModel();
			oEmailDeleteModel.loadData("/itspm_dm/dateref/" + items[0].dateRefSlNo,null,false, "DELETE",false,false,oHeader);
		
				if(oEmailDeleteModel.getData().status === 200){
					this._refreshData();
					this._statusDialog("Success","Success","Date deleted successfully");
				}else {
					this._statusDialog("Error","Error","Technical error. Please try again later");
				}
				this.pressListUser("dateDetailId");
		},
		dateTableSelect : function(oEvent){
			this.getView().byId("removeDateButtonId").setEnabled(true);
		},
		pressAddNewDate:function(){
			var view = this.getView();
			var inputs = [
				view.byId("DatetIdId"),
				view.byId("DatetNameId")
				];
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
					if(!input.getValue()){
						input.setValueState("Error");
						canContinue = false;
					}else{
						input.setValueState("None");
					}
			});
			if(!canContinue){
				this._statusDialog("Error","Error","Please complete the input first");
			}else{
			var oData = {
				"dateRefId" : this.getView().byId("DatetIdId").getValue(),
				"dateRefName": this.getView().byId("DatetNameId").getValue()
			};
			var oUserAddModel = new sap.ui.model.json.JSONModel();
			var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
			oUserAddModel.loadData("/itspm_dm/dateref",JSON.stringify(oData),false, "POST",false,false,oHeader);
			if(oUserAddModel.getData().status === 201){
				this._refreshData();
				this._statusDialog("Success","Success","Date created successfully");
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again later");
			}
			this.pressListUser("dateDetailId");
			}
		},
		searchUser:function(oEvent){
			if(typeof(oEvent) === "object"){
				var sQuery = oEvent.getParameter("query");
			}else{
			sQuery = this.getView().byId("searchUserId").getValue();
			}
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("userId", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("userGroup", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("orgCode", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("userName", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("validFrom", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("validTo", sap.ui.model.FilterOperator.Contains, sQuery));
	
			var oFilter = new sap.ui.model.Filter( aFilter, false );
			
			var oList = this.getView().byId("userTableId");
				var oBinding = oList.getBinding("items");
				oBinding.filter(oFilter);
		},
		
		pressUserStatus:function(){
			var contexts =  this.getView().byId("userTableId").getSelectedContexts();
			 var items = contexts.map(function (c) {
				return c.getObject();
			}); 
			if(items[0].status === "Active"){
				items[0].status = "Inactive";
				var userStatus = "Deactivated";
			}else{
				items[0].status = "Active";
				 userStatus = "Activated";
			}
			var oEditUserMdl = new sap.ui.model.json.JSONModel();
			var oHeaderPut = {"Content-Type" : "application/json;charset=utf-8"};
			oEditUserMdl.loadData("/itspm_dm/user/" + items[0].userSlNo ,JSON.stringify(items[0]),false, "PUT",false,false,oHeaderPut);
			
			if(oEditUserMdl.getData().status === 201){
				this._refreshData();
				this._statusDialog("Success","Success","User" + " " + userStatus + " " + " successfully");
				this.getView().byId("inactivateUserId").setEnabled(false);
				this.getView().byId("activateUserId").setEnabled(false);
				this.getView().byId("removeUserButtonId").setEnabled(false);
				this.getView().byId("editUserButtonId").setEnabled(false);
				
				var oUserModel = new sap.ui.model.json.JSONModel();
				oUserModel.loadData("/itspm_dm/user",null,false); 
				this.getView().setModel(oUserModel,"oUserModelId");
				this.searchUser();
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again later");
			}
		},
		
		pressAddUser:function(oEvent){
			var inputs = ["userEmpId","userEmailId","userNameId","userValidFromId","userValidToId","userOrgId","userRoleId"];
			for(var i = 0; i < inputs.length; i++){
				this.getView().byId(inputs[i]).setValueState("None");
			}
			var oOrgModel = new sap.ui.model.json.JSONModel();
			oOrgModel.loadData("/itspm_dm/organization",null,false); 
			this.getView().setModel(oOrgModel,"oOrgModelId");
			this.getView().byId("addUserpanelId").setVisible(true);
			this._refreshData();
			if(oEvent.getSource().getText() === "Add"){
				this.statusUser = "add";
				this.getView().byId("addNewUserId").setText("Add User");
				this.getView().byId("userRoleId").setSelectedItem(this.getView().byId("userRoleId").getSelectableItems()[0]);
	            this.getView().byId("userOrgId").insertItem(new sap.ui.core.Item({text : "Select"}),0);
	            this.getView().byId("userOrgId").setSelectedItem(this.getView().byId("userOrgId").getSelectableItems()[0]);	
			} else{
				this.statusUser = "edit";
				this.getView().byId("addNewUserId").setText("Update User");
				var contexts =  this.getView().byId("userTableId").getSelectedContexts();
				var items = contexts.map(function (c) {
					return c.getObject();
				});
				this.getView().byId("userEmpId").setValue(items[0].userId);
				this.getView().byId("userEmailId").setValue(items[0].userEmail);
				this.getView().byId("userNameId").setValue(items[0].userName);
				this.getView().byId("userOrgId").setSelectedKey(items[0].vendorCode);
				this.getView().byId("userRoleId").setSelectedKey(items[0].userGroup);
				var sValidFrom = items[0].validFrom.split("/");
				var sValidTo = items[0].validTo.split("/");
				this.getView().byId("userValidFromId").setDateValue(new Date(sValidFrom[2], Number(sValidFrom[1]-1), sValidFrom[0]));
				this.getView().byId("userValidToId").setDateValue(new Date(sValidTo[2], Number(sValidTo[1]-1), sValidTo[0]));
			}
            
		},
		pressRemoveUser : function(){
			var contexts =  this.getView().byId("userTableId").getSelectedContexts();
			 var items = contexts.map(function (c) {
				return c.getObject();
			}); 
				var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
				var oProdDeleteModel = new sap.ui.model.json.JSONModel();
			oProdDeleteModel.loadData("/itspm_dm/user/" + items[0].userSlNo,null,false, "DELETE",false,false,oHeader);
		
			if(oProdDeleteModel.getData().status === 200){
				this._refreshData();
				this.getView().byId("inactivateUserId").setEnabled(false);
				this.getView().byId("activateUserId").setEnabled(false);
				this.getView().byId("editUserButtonId").setEnabled(false);
				this._statusDialog("Success","Success","User deleted successfully");
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again later");
			}
			this.pressListUser("userDataDetailId");
		},
		userTableSelect : function(oEvent){
			this.getView().byId("removeUserButtonId").setEnabled(true);
			this.getView().byId("editUserButtonId").setEnabled(true);
			var contexts =  this.getView().byId("userTableId").getSelectedContexts();
			 var items = contexts.map(function (c) {
				return c.getObject();
			});
			if(items[0].status === "Active"){
				this.getView().byId("inactivateUserId").setEnabled(true);
				this.getView().byId("activateUserId").setEnabled(false);
			}else{
				this.getView().byId("activateUserId").setEnabled(true);
				this.getView().byId("inactivateUserId").setEnabled(false);
			}
		},
		
		dateChangeUser: function(oEvent){
			var sControlId = oEvent.getParameter("id").split("--")[1];
			var oFromDateValue = this.getView().byId("userValidFromId").getDateValue();
			var oToDateValue = this.getView().byId("userValidToId").getDateValue();
			if(oToDateValue && oToDateValue < oFromDateValue){
				this.getView().byId("userValidToId").setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId("userValidToId").setValueStateText("To Date must be greater than From Date");
				this.getView().byId("userValidToId").setValue();
			}
			else{
				this.getView().byId("userValidToId").setValueState(sap.ui.core.ValueState.None);
				
			}
		},
		pressAddNewUser:function(){
			var view = this.getView();
			var inputs = [
				view.byId("userEmpId"),
				view.byId("userEmailId"),
				view.byId("userNameId"),
				view.byId("userValidFromId"),
				view.byId("userValidToId"),
				view.byId("userOrgId"),
				view.byId("userRoleId")
				];
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
				if(i < 5){
					if(!input.getValue()){
						input.setValueState("Error");
						canContinue = false;
					}else{
						input.setValueState("None");
					}
				}else{
					if (input.getSelectedItem().getText() === "Select"){
						input.setValueState("Error");
						canContinue = false;
					}else{
						input.setValueState("None");
					}
				}
			});
			if(!canContinue){
				this._statusDialog("Error","Error","Please complete the input first");
			}else{
				var sValidFrom = this.getView().byId("userValidFromId").getDateValue();
					var validFrom = sValidFrom.getDate() + "/" + (sValidFrom.getMonth() + 1) + "/" + sValidFrom.getFullYear();
					var sValidTo = this.getView().byId("userValidToId").getDateValue();
					var validTo = sValidTo.getDate() + "/" + (sValidTo.getMonth() + 1) + "/" + sValidTo.getFullYear();
					
				if(this.statusUser === "add"){
					var oData = {
						"userId" : this.getView().byId("userEmpId").getValue().toUpperCase(), 
						"userName" : this.getView().byId("userNameId").getValue(),
						"userTelNo" : "",
						"userEmail" : this.getView().byId("userEmailId").getValue(),
						"userGroup" : this.getView().byId("userRoleId").getSelectedKey(),
						"vendorCode" : this.getView().byId("userOrgId").getSelectedKey(),
						"orgName" : this.getView().byId("userOrgId").getSelectedItem().getText(),
						"status" : "Active",
						"validTo" : validTo,
		                "validFrom" : validFrom
					};
					var oUserAddModel = new sap.ui.model.json.JSONModel();
					var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
					oUserAddModel.loadData("/itspm_dm/user",JSON.stringify(oData),false, "POST",false,false,oHeader);
					if(oUserAddModel.getData().status === 201){
						this._statusDialog("Success","Success","User created successfully");
					}else if(oUserAddModel.getData().status === 204){
						this._statusDialog("Warning","Warning","User already exists.");
					}else {
						this._statusDialog("Error","Error","Technical error. Please try again later");
					}
					this.pressListUser("userDataDetailId");
				}
				else if(this.statusUser === "edit"){
					
					var contexts =  this.getView().byId("userTableId").getSelectedContexts();
					var items = contexts.map(function (c) {
						return c.getObject();
					});
					var oData = {
						"userId" : this.getView().byId("userEmpId").getValue().toUpperCase(), 
						"userName" : this.getView().byId("userNameId").getValue(),
						"userTelNo" : "",
						"userEmail" : this.getView().byId("userEmailId").getValue(),
						"userGroup" : this.getView().byId("userRoleId").getSelectedKey(),
						"vendorCode" : this.getView().byId("userOrgId").getSelectedKey(),
						"orgName" : this.getView().byId("userOrgId").getSelectedItem().getText(),
						"status" : items[0].status,
						"userSlNo" : items[0].userSlNo,
						"validTo" : validTo,
		                "validFrom" : validFrom
					};
					var oEditUserMdl = new sap.ui.model.json.JSONModel();
					var oHeaderPut = {"Content-Type" : "application/json;charset=utf-8"};
					oEditUserMdl.loadData("/itspm_dm/user/" + items[0].userSlNo ,JSON.stringify(oData),false, "PUT",false,false,oHeaderPut);
					
					if(oEditUserMdl.getData().status === 201){
						this._statusDialog("Success","Success","User updated successfully");
						this.getView().byId("editUserButtonId").setEnabled(false);
					}else {
						this._statusDialog("Error","Error","Technical error. Please try again later");
					}
					this.pressListUser("userDataDetailId");
				}	
			}
		},
		seacrhOrg:function(oEvent){
			var sQuery = oEvent.getParameter("query");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("orgCode", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("orgName", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("orgCPerson", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("orgAddress", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilter.push(new sap.ui.model.Filter("orgEmail", sap.ui.model.FilterOperator.Contains, sQuery));
	
			var oFilter = new sap.ui.model.Filter( aFilter, false );
			
			var oList = this.getView().byId("orgTableId");
				var oBinding = oList.getBinding("items");
				oBinding.filter(oFilter);
		},
		pressAddOrg:function(){
			var inputs = ["orgId","orgNameId","orgEmailId","contactId","orgAddressId"];
			for(var i = 0; i < inputs.length; i++){
				this.getView().byId(inputs[i]).setValueState("None");
			}
			this._refreshData();
			this.getView().byId("addOrgpanelId").setVisible(true);
		},
		pressRemoveOrg : function(){
			var contexts =  this.getView().byId("orgTableId").getSelectedContexts();
			 var items = contexts.map(function (c) {
				return c.getObject();
			}); 
				var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
				var oProdDeleteModel = new sap.ui.model.json.JSONModel();
			oProdDeleteModel.loadData("/itspm_dm/organization/" + items[0].orgSlNo,null,false, "DELETE",false,false,oHeader);
		
				if(oProdDeleteModel.getData().status === 200){
				this._refreshData();
				this._statusDialog("Success","Success","Organization deleted successfully");
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again late");
			}
			this.pressListUser("organizationDetailId");
		},
		orgTableSelect : function(oEvent){
			this.getView().byId("removeOrgButtonId").setEnabled(true);
		},
		pressAddNewOrg:function(){
			var view = this.getView();
			var inputs = [
				view.byId("orgId"),
				view.byId("orgNameId"),
				view.byId("orgEmailId"),
				view.byId("contactId"),
				view.byId("orgAddressId")
				];
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
			if(!input.getValue()){
				input.setValueState("Error");
				canContinue = false;
			}else {
				input.setValueState("None");
			}
			});
			if(!canContinue){
				this._statusDialog("Error","Error","Please complete the input first");
			}else{
			var oData = {
				"orgCode" : this.getView().byId("orgId").getValue(),
				"orgName" : this.getView().byId("orgNameId").getValue(),
				"orgEmail" : this.getView().byId("orgEmailId").getValue(),
				"orgTelNo" : "",
				"orgCPerson" : this.getView().byId("contactId").getValue(),
				"orgAddress" : this.getView().byId("orgAddressId").getValue()
			};
			
			var oUserAddModel = new sap.ui.model.json.JSONModel();
			var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
			oUserAddModel.loadData("/itspm_dm/organization",JSON.stringify(oData),false, "POST",false,false,oHeader);
			if(oUserAddModel.getData().status === 201){
				this._refreshData();
				this._statusDialog("Success","Success","Organization created successfully");
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again later");
			}
			this.pressListUser("organizationDetailId");
			}
		},
		
		onPressCreateNotification : function(oEvent){
			var inputs = [
				this.getView().byId("idNotificationMessage"),
				this.getView().byId("idStartDateTime"),
				this.getView().byId("idEndDateTime")
				];
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
					if (!input.getValue()){
						input.setValueState("Error");
						canContinue = false;
					}else{
						input.setValueState("None");
					}
			});
			if(!canContinue){
				this._statusDialog("Error","Error","Please complete the input");
			}else{
			var sTextNotification = this.getView().byId("idNotificationMessage").getValue();
			var oNotificationStartTime = this.getView().byId("idStartDateTime").getValue().split("-");
			var oNotificationEndTime = this.getView().byId("idEndDateTime").getValue().split("-");
			var oTodayDate = new Date();
			var oData = {
			"createdBy": "Admin",
            "validFrom": oNotificationStartTime[2] + "/" + oNotificationStartTime[1] + "/" + oNotificationStartTime[0] + " " + oNotificationStartTime[3] + ":" + oNotificationStartTime[4] + ":" + oNotificationStartTime[5],
            "message": sTextNotification,
            "createdOn": oTodayDate.getDate() + "/" +(oTodayDate.getMonth() + 1) + "/" + oTodayDate.getFullYear() + " " + oTodayDate.getHours() + ":" + oTodayDate.getMinutes() + ":00",
            "validTo": oNotificationEndTime[2] + "/" + oNotificationEndTime[1] + "/" + oNotificationEndTime[0] + " " + oNotificationEndTime[3] + ":" + oNotificationEndTime[4] + ":" + oNotificationEndTime[5]
			}; 

			var oNotificationAddModel = new sap.ui.model.json.JSONModel();
			var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
			oNotificationAddModel.loadData("/itspm_dm/notification",JSON.stringify(oData),false, "POST",false,false,oHeader);
		
			if(oNotificationAddModel.getData().status === 201){
				this._refreshData();
				this._statusDialog("Success","Success","Notification created successfully");
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again later");
			}	
		}
		},
		
		onPressCreateEmailMsg : function(){
			var sEmailMessage = this.getView().byId("idEmailMessage").getValue();
			var oSelectedItem = this.getView().byId("idSelectEmailFor").getSelectedKey();
			var oData = {
				"serviceType": oSelectedItem,
	            "emailContent": sEmailMessage
				};
				
			var oEmailContentModel = new sap.ui.model.json.JSONModel();
			oEmailContentModel.loadData("/itspm_dm/emailcontent",null,false);
			
				var result = oEmailContentModel.getData().emailContentList.filter(function( obj ) {
				return obj.serviceType === oSelectedItem;
			});
				var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
			if(result.length){
				var oEmailDeleteModel = new sap.ui.model.json.JSONModel();
			oEmailDeleteModel.loadData("/itspm_dm/emailcontent/" + result[0].emailSlNo,JSON.stringify(oData),false, "DELETE",false,false,oHeader);
			}
			var oEmailMessageModel = new sap.ui.model.json.JSONModel();
		
			oEmailMessageModel.loadData("/itspm_dm/emailcontent",JSON.stringify(oData),false, "POST",false,false,oHeader);
		
				if(oEmailMessageModel.getData().status === 201){
					this._refreshData();
					this._statusDialog("Success","Success","Email content created successfully");
				}else {
					this._statusDialog("Error","Error","Technical error. Please try again later");
				}
		},
		selectEmailForCahange : function(oEvent){
			var sKey = oEvent.getParameter("selectedItem").getKey();
			
			var oEmailContentModel = new sap.ui.model.json.JSONModel();
			oEmailContentModel.loadData("/itspm_dm/emailcontent",null,false);
			
				var result = oEmailContentModel.getData().emailContentList.filter(function( obj ) {
				return obj.serviceType === sKey;
			});
			
			if(sKey === "select"){
				this.getView().byId("idEmailMessage").setEditable(false);
					this.getView().byId("idEmailMessage").setValue("");
				this.getView().byId("submitEmailBtn").setEnabled(false);
			}
			else /*if(sKey === "edit")*/{
				this.getView().byId("idEmailMessage").setEditable(true);
				if(result.length){
					this.getView().byId("idEmailMessage").setValue(result[0].emailContent);
				}
				this.getView().byId("submitEmailBtn").setEnabled(true);
			}
		},
		onPressMasterBack : function() {
			this.getSplitAppObj().backMaster();
		},
		getSplitAppObj : function() {
			var result = this.byId("adminAppId");
			if (!result) {
				jQuery.sap.log.info("SplitApp object can't be found");
			}
			return result;
		},
		
		/**
		 * To open success, error and warning message dialog 
		 * @param {String} title of dialog
		 * @param {String} status to update
		 * @param {String} text to display in content
		 */
		_statusDialog:function(title,status,text){
			var oDialog = new sap.m.Dialog({
				title: title,
				type: "Message",
				state: status,
				content: new sap.m.Text({
					text: text
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function (oEvnt) {
						oDialog.close();
						oEvnt.getSource().getParent().close();
	        			oEvnt.getSource().getParent().destroy();
					} 
				}),
				afterClose: function() {
					oDialog.destroy();
				}	
			});
	    	oDialog.open();
		}

	});

});
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("IT_SPM_DM.controller.CreateCR", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf IT_SPM_DM.view.CreateCR
		 */
		onInit: function () {

			var oControllerOnInIt = this;
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function (oEvent) {
				oControllerOnInIt.setInitialFocus();
				if (!oControllerOnInIt.getOwnerComponent().getModel("userLoginModel")) {
					setTimeout(function () {
						var router = sap.ui.core.UIComponent.getRouterFor(oControllerOnInIt);
						router.navTo("RequestUser");
					}, 100);

				} else {
					if (oEvent.getParameter("name") === "CreateCR") {
						oControllerOnInIt._masterServiceIntegration("/itspm_dm/crtype", "crTypeModelId");
						oControllerOnInIt._masterServiceIntegration("/itspm_dm/team", "teamModelId");
						oControllerOnInIt._masterServiceIntegration("/itspm_dm/product", "productModelId");
						oControllerOnInIt._masterServiceIntegration("/itspm_dm/placeholder", "placeholderModelId");
						oControllerOnInIt._masterServiceIntegration("/itspm_dm/dateref", "dateModelId");
						oControllerOnInIt._masterServiceIntegration("/itspm_dm/organization", "organizationModelId");
						oControllerOnInIt._masterServiceIntegration("/itspm_dm/user", "userModelId");
						oControllerOnInIt._refreshCR();
					}
					if (oControllerOnInIt.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup === "Vendor") {
						oControllerOnInIt.getView().byId("crDraftBtnId").setEnabled(false);
					}

				}
			});
		},
		
		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf IT_SPM_DM.view.CreateCR
		 */
		onAfterRendering: function () {
			this.ofilesToUploadJson = new sap.ui.model.json.JSONModel({
				files: []
			});
			this.getView().setModel(this.ofilesToUploadJson);
			jQuery.sap.delayedCall(500, this, function () {
				this.getView().byId("crTypeId").focus();
			});
		},
		
		/**
		 * Event handler to set the initial focus of the page to the cr type input field
		 * @param  {Object} control cr type input field
		 */
		setInitialFocus: function(control) { 
		  this.getView().addEventDelegate({
		    onAfterShow: function() {
		      setTimeout(function() {
		        this.getView().byId("crTypeId").focus();
		      }.bind(this), 0);
		    }
		  }, this);
		},
		
		/**
		 * To refresh the create request page and set it to initial condition
		 */
		_refreshCR: function () {
			var refreshModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(refreshModel, "refreshJsonModel");
			this.getView().getModel("refreshJsonModel").setData(null);
			this.getView().getModel("refreshJsonModel").refresh();
			this.getView().getModel("refreshJsonModel").destroy();
			var oGridCreate = this.getView().byId("dateGridId");
			oGridCreate.removeAllContent();
			this.getView().byId("dateId").clearSelection();
			this.getView().byId("datePanelId").setVisible(false);
			this.getView().byId("crTypeId").setSelectedKey(null);
			this.getView().byId("crReferenceId").setSelectedKey(null);
			this.getView().byId("crCostObjectVboxId").setVisible(false);
			this.getView().byId("crRefVboxId").setVisible(false);
			this.getView().byId("crTeamId").setSelectedKey(null);
			this.getView().byId("crProductId").setSelectedKey(null);
		},
		
		/**
		 * To get all the master data and save in a model
		 * @param {String} sServiceURL service url
		 * @param {Object} sModel model id
		 */
		_masterServiceIntegration: function (sServiceURL, sModel) {
			var oServiceModel = new sap.ui.model.json.JSONModel();
			oServiceModel.loadData(sServiceURL, null, false);
			if (sModel === "placeholderModelId") {
				var placeholder = oServiceModel.getData().placeHolderToolTip;
				var oData = [{}];
				for (var i = 0; i < placeholder.length; i++) {
					oData[0][placeholder[i].plttId] = placeholder[i];
				}
				oServiceModel.getData().placeHolderToolTip = oData;
			}
			this.getView().setModel(oServiceModel, sModel);
		},
		
		/**
		 * Event handler when back button of page is clicked
		 */
		pressBackButton: function () {
			var router = sap.ui.core.UIComponent.getRouterFor(this);
			router.navTo("Dashboard");
		},
		
		/**
		 * Event handler when cr type is selected from dropdown
		 * @param {Object} oEvent combobox
		 */
		changeCRType: function (oEvent) {
			if (oEvent.getParameter("value") === "Enhance existing scope" || oEvent.getParameter("value") === "Discontinue existing scope") {
				this.getView().byId("crRefVboxId").setVisible(true);
				this.getView().byId("crCostObjectVboxId").setVisible(false);
				this._masterServiceIntegration("/itspm_dm/changerequest", "refModelId");
			} else if (oEvent.getParameter("value") === "Project request") {
				this.getView().byId("crCostObjectVboxId").setVisible(true);
				this.getView().byId("crRefVboxId").setVisible(false);
			} else {
				this.getView().byId("crRefVboxId").setVisible(false);
				this.getView().byId("crCostObjectVboxId").setVisible(false);
			}
		},
		
		/**
		 * Event handler when dates from dropdown is selected in combobox
		 */
		pressAddDate: function () {
			var oComboBoxelectedItem = this.getView().byId("dateId").getSelectedItems();
			var oComboBoxelectedItemKey = this.getView().byId("dateId").getSelectedKeys();
			var oGridCreate = this.getView().byId("dateGridId");
			this.getView().byId("datePanelId").setVisible(true);
			if (oComboBoxelectedItem.length) {
				if (!oGridCreate.getContent().length) {
					for (var i = 0; i < oComboBoxelectedItem.length; i++) {
						var sText = oComboBoxelectedItem[i].getText();
						var sDateId = oComboBoxelectedItemKey[i];
						var oDateVLayout = new sap.ui.layout.VerticalLayout({
							layoutData: new sap.ui.layout.GridData({
								span: "L3 M3 S12"
							}),
							content: [
								new sap.m.Label({
									text: sText + " :"
								}).addStyleClass("labelColor"),
								new sap.m.DatePicker({
									displayFormat: "dd-MMM-YY",
									name: sDateId
								})
							]
						});
						oGridCreate.addContent(oDateVLayout);
					}
				} else {
					for (var i = 0; i < oComboBoxelectedItem.length; i++) {

						for (var j = 0; j < oGridCreate.getContent().length; j++) {
							if (oComboBoxelectedItem[i].getText() === oGridCreate.getContent()[j].getContent()[0].getText().slice(0, -2)) {
								break;
							} else if (oComboBoxelectedItem[i].getText() !== oGridCreate.getContent()[j].getContent()[0].getText().slice(0, -2) && j ===
								oGridCreate.getContent().length - 1) {
								var sText = oComboBoxelectedItem[i].getText();
								var oDateVLayout = new sap.ui.layout.VerticalLayout({
									layoutData: new sap.ui.layout.GridData({
										span: "L3 M3 S12"
									}),
									content: [
										new sap.m.Label({
											text: sText + " :"
										}).addStyleClass("labelColor"),
										new sap.m.DatePicker({
											displayFormat: "dd-MMM-YY"
										})
									]
								});
								oGridCreate.addContent(oDateVLayout);
							}
						}
					}
					for (var i = 0; i < oGridCreate.getContent().length; i++) {
						for (var j = 0; j < oComboBoxelectedItem.length; j++) {
							if (oGridCreate.getContent()[i].getContent()[0].getText().slice(0, -2) === oComboBoxelectedItem[j].getText()) {
								break;
							} else if (j === oComboBoxelectedItem.length - 1) {
								oGridCreate.removeContent(oGridCreate.getContent()[i]);
								i--;
							}
						}
					}
				}
			} else {
				oGridCreate.removeAllContent();
				this.getView().byId("datePanelId").setVisible(false);
			}

		},
		
		/**
		 * Event handler when view attachment link is clicked
		 * @param {Object} events View attachment link
		 */
		pressAttachment: function (events) {
			var that = this;
			var oFileUploader = that.getView().byId("crFileUploaderId");
			var oPopover = new sap.m.ResponsivePopover({
				showHeader: false
			});
			var tokenMdl = that.ofilesToUploadJson.getData().files;
			for (var i = 0; i < tokenMdl.length; i++) {

				oPopover.addContent(new sap.m.Tokenizer({
					tokens: [
						new sap.m.Token({
							text: tokenMdl[i].name,
							delete: function (oEvnt) {
								var sIndex = that.getView().getModel(this.ofilesToUploadJson).getProperty("/files").map(function (obj, index) {
									if (obj.name === oEvnt.getParameter("token").getText()) {
										return index;
									}
								}).filter(isFinite);
								that.getView().getModel(this.ofilesToUploadJson).getData().files.splice(sIndex[0], 1);
							}
						})
					]
				}));
			}
			oPopover.openBy(events.getSource());
		},
		
		/**
		 * Event handler when file uploader button is clicked
		 * @param {Object} oEvent File uploader button
		 */
		selectFileUploader: function (oEvent) {
			var that = this;
			var oFilesToAdd = oEvent.getParameter("files");
			var oFilesArray = $.map(oFilesToAdd, function (value, index) {
				return [value];
			});
			var nNewFileCount = this.ofilesToUploadJson.getData().files.length + oFilesArray.length;
			if (nNewFileCount > 9) {
				this._statusDialog("Warning", "Warning", "Maximum 9 files can be uploaded");
			} else {
				var oNewData = this.ofilesToUploadJson.getData().files.concat(oFilesArray);
				this.ofilesToUploadJson.setData({
					files: oNewData
				});
				this.getView().byId("viewAttachmentId").setVisible(true);
			}
			/*that.oBase64 = [];
			for(var i = 0; i < this.ofilesToUploadJson.getData().files.length; i++){
				var fileName = oEvent.getParameter("files")[0].name;
					var reader = new FileReader();
					reader.readAsDataURL(this.ofilesToUploadJson.getData().files[i]);
			reader.onload = function(
				event) {
				var sResult = event.target.result;
				var base64 = sResult.substr(sResult.lastIndexOf(","));
				var base62Data =  base64.split(",")[1];
		/*	that.fileData = base64.split(",")[1];
			
			var oBase64Initial = {
				                "fileName":fileName,
                				"data":base62Data
								};
			that.oBase64.push(oBase64Initial);
			};
			}*/
		},
		
		/**
		 * Event handler when Save as draft button is clicked
		 * @param {Object} oEvent save as draft button
		 */
		pressSaveAsDraft: function (oEvent) {
			this.createMode = "Draft";
			this.pressCreateCRDialog();
		},
		
		/**
		 * Event handler when create requestr button is clicked
		 * @param {Object} oEvent create request button
		 */
		pressCreateRequest: function () {
			this.createMode = "Created";
			var oCreateRequestDialog = sap.ui.xmlfragment("IT_SPM_DM.fragment.CreateRequestDialog", this);
			this.getView().addDependent(oCreateRequestDialog);
			oCreateRequestDialog.open();
		},
		
		/**
		 * Event handler before opening the cr dialog
		 * @param {Object} oEvent dialog
		 */
		beforeOpenCRDialog: function (oEvent) {
			sap.ui.getCore().byId("hBox2Id").setVisible(false);
			sap.ui.getCore().byId("vBox1Id").setVisible(false);
			sap.ui.getCore().byId("vBox3Id").setVisible(false);
			sap.ui.getCore().byId("vBox2Id").setVisible(false);
			var userGroup = this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup;
			if (userGroup === "admin") {
				sap.ui.getCore().byId("spmCheckBoxId").setVisible(true);
				sap.ui.getCore().byId("paCheckBoxId").setVisible(true);
				sap.ui.getCore().byId("vendorCheckBoxId").setVisible(true);
			} else if (userGroup === "Vendor") {
				sap.ui.getCore().byId("spmCheckBoxId").setVisible(true);
				sap.ui.getCore().byId("paCheckBoxId").setVisible(true);
				sap.ui.getCore().byId("vendorCheckBoxId").setVisible(false);
			} else if (userGroup === "SPM") {
				sap.ui.getCore().byId("spmCheckBoxId").setVisible(false);
				sap.ui.getCore().byId("paCheckBoxId").setVisible(true);
				sap.ui.getCore().byId("vendorCheckBoxId").setVisible(true);
			} else if (userGroup === "PA") {
				sap.ui.getCore().byId("spmCheckBoxId").setVisible(true);
				sap.ui.getCore().byId("paCheckBoxId").setVisible(false);
				sap.ui.getCore().byId("vendorCheckBoxId").setVisible(true);
			}
			if (sap.ui.Device.system.phone) {
				oEvent.getSource().setStretch(true);
			} else {
				oEvent.getSource().setStretch(false);
			}
		},
		
		/**
		 * Event handler when notify spm checkbox is selected
		 * @param {Object} oEvent checkbox
		 */
		selectNotifySPM: function (oEvent) {
			if (oEvent.getSource().getSelected() === true) {
				sap.ui.getCore().byId("hBox2Id").setVisible(true);
				sap.ui.getCore().byId("vBox1Id").setVisible(true);
			} else {
				sap.ui.getCore().byId("vBox1Id").setVisible(false);
			}
		},
		
		/**
		 * Event handler when Assign Vendor checkbox is selected
		 * @param {Object} oEvent checkbox
		 */
		selectAssignVendor: function (oEvent) {
			if (oEvent.getSource().getSelected() === true) {
				sap.ui.getCore().byId("hBox2Id").setVisible(true);
				sap.ui.getCore().byId("vBox2Id").setVisible(true);
			} else {
				sap.ui.getCore().byId("vBox2Id").setVisible(false);
			}
		},
		
		/**
		 * Event handler when Assign PA checkbox is selected
		 * @param {Object} oEvent checkbox
		 */
		selectAssignPA: function (oEvent) {
			if (oEvent.getSource().getSelected() === true) {
				sap.ui.getCore().byId("hBox2Id").setVisible(true);
				sap.ui.getCore().byId("vBox3Id").setVisible(true);
			} else {
				sap.ui.getCore().byId("vBox3Id").setVisible(false);
			}
		},
		
		/**
		 * Event handler after cr dialog is opened
		 * @param {Object} oEvent cr dialog
		 */
		afterOpenDialog: function (oEvent) {
			oEvent.getSource().focus();
		},
		
		/**
		 * Event handler when Decline button is clicked
		 * @param {Object} oEvent checkbox
		 */
		pressDecline: function (oEvent) {
			oEvent.getSource().getParent().getParent().close();
			oEvent.getSource().getParent().getParent().destroy();
		},
		
		/**
		 * Event handler when user from select user combobox is selected
		 * @param {Object} oEvent combobox
		 */
		selectUser: function (oEvent) {
			var sNotifyToId = oEvent.getParameter("id");
			var sSelectedKey = oEvent.getSource().getSelectedKey();
			var oUserModel = this.getView().getModel("userModelId");
			var oUser;
			if (sNotifyToId === "crVendorId") {
				var vendorModel = this.getView().getModel("organizationModelId");
				var oOrganization = vendorModel.getData().organization.find(function (obj) {
					return obj.orgCode === sSelectedKey;
				});
				sap.ui.getCore().byId("crVendorEmailID").setValue(oOrganization.orgEmail);
			} else if (sNotifyToId === "crPAId") {
				oUser = oUserModel.getData().user.find(function (obj) {
					return obj.userId === sSelectedKey;
				});
				sap.ui.getCore().byId("crPAEmailID").setValue(oUser.userEmail);
			} else if (sNotifyToId === "crSPMId") {
				oUser = oUserModel.getData().user.find(function (obj) {
					return obj.userId === sSelectedKey;
				});
				sap.ui.getCore().byId("crSpmEmailId").setValue(oUser.userEmail);
			}
		},
		
		/**
		 * Event handler when create cr button in cr dialog is clicked
		 * @param {Object} oEvent  create cr button
		 */
		pressCreateCRDialog: function (oEvent) {
			var oController = this;
			if (oEvent) {
				oEvent.getSource().getParent().setBusy(true);
				oController.getView().getContent()[0].setBusy(true);
			} else {
				oController.getView().getContent()[0].setBusy(true);
			}
			var oCRType = this.getView().getModel("crTypeModelId").getData().crTypeCollection.find(function (obj) {
				return obj.crTypeId === oController.getView().byId("crTypeId").getSelectedKey();
			});
			var newDate = new Date();
			var todaysDate = newDate.getDate() + "/" + (newDate.getMonth() + 1) + "/" + newDate.getFullYear();
			var dateGrid = this.getView().byId("dateGridId");
			var dateArr = [];
			for (var i = 0; i < dateGrid.getContent().length; i++) {
				var dateValue = dateGrid.getContent()[i].getContent()[1].getValue();
				var dateId = dateGrid.getContent()[i].getContent()[1].getName();
				var dateName = dateGrid.getContent()[i].getContent()[0].getText();
				var date = {
					"dateName": dateName,
					"dateVal": dateValue,
					"dateId": dateId
				};
				dateArr.push(date);
			}

			var finalJson = {
				"crTransactionDo": {
					"crReqId": "",
					"crTypeId": this.getView().byId("crTypeId").getSelectedKey(),
					"crTypeName": this.getView().byId("crTypeId").getValue(),
					"reqRefId": this.getView().byId("crReferenceId").getValue(),
					"costObjt": this.getView().byId("crCostObjectId").getValue(),
					"crName": this.getView().byId("crNameId").getValue(),
					"flag": false,
					"orgSlNo": 20,
					"productSlNo": Number(this.getView().byId("crProductId").getSelectedKey()),
					"productName": this.getView().byId("crProductId").getValue(),
					"teamSlNo": Number(this.getView().byId("crTeamId").getSelectedKey()),
					"teamName": this.getView().byId("crTeamId").getValue(),
					"categoryId": this.getView().byId("crCategoryId").getValue(),
					"purpose": this.getView().byId("crPurposeId").getValue(),
					"transition": this.getView().byId("crTransitionId").getValue(),
					"volume": this.getView().byId("crVolumeId").getValue(),
					"rmrkCreateCR": this.getView().byId("crRemarksId").getValue(),
					"expectation": this.getView().byId("crExpectationId").getValue(),
					"milestone": this.getView().byId("crMilestoneId").getValue(),
					"involvedSys": this.getView().byId("crInvolvedId").getValue(),
					"createdBy": this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userId,
					"createdDate": todaysDate,
					"lastModfBy": this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userId,
					"lastModfDate": todaysDate
				},
				"crDateTransactionDo": dateArr
			};
			var sMsgStatus;
			if (this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userGroup === "Vendor") {
				sMsgStatus = "Created";
				finalJson.crTransactionDo.status = "Created";
				finalJson.crTransactionDo.vendorCode = this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.vendorCode;
				finalJson.crTransactionDo.vEmail = this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userEmail;
				finalJson.crTransactionDo.vUserId = this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.vendorCode;
				finalJson.crTransactionDo.spmUserId = sap.ui.getCore().byId("crSPMId").getSelectedKey();
				finalJson.crTransactionDo.spmEmail = sap.ui.getCore().byId("crSpmEmailId").getValue();
				finalJson.crTransactionDo.paUserId = sap.ui.getCore().byId("crPAId").getSelectedKey();
				finalJson.crTransactionDo.paEmail = sap.ui.getCore().byId("crPAEmailID").getValue();
				finalJson.crTransactionDo.rmkrForVendor = "";
				finalJson.crTransactionDo.rmkrForSPM = sap.ui.getCore().byId("crSpmRemarksId").getValue();
				finalJson.crTransactionDo.rmkrForPA = sap.ui.getCore().byId("crPARemarksId").getValue();

			} else {
				if (this.createMode === "Draft") {
					sMsgStatus = "saved";
					finalJson.crTransactionDo.status = "Draft";
					finalJson.crTransactionDo.vUserId = "";
					finalJson.crTransactionDo.vendorCode = "";
					finalJson.crTransactionDo.vEmail = "";
					finalJson.crTransactionDo.vName = "";
					finalJson.crTransactionDo.spmUserId = "";
					finalJson.crTransactionDo.spmEmail = "";
					finalJson.crTransactionDo.paUserId = "";
					finalJson.crTransactionDo.paEmail = "";
					finalJson.crTransactionDo.rmkrForVendor = "";
					finalJson.crTransactionDo.rmkrForSPM = "";
					finalJson.crTransactionDo.rmkrForPA = "";
				} else {
					if (this.createMode === "Created" && sap.ui.getCore().byId("crVendorEmailID").getValue() !== "") {
						finalJson.crTransactionDo.status = "Created";
						sMsgStatus = "created";
					} else {
						finalJson.crTransactionDo.status = "Draft";
						sMsgStatus = "saved";
					}
					finalJson.crTransactionDo.vUserId = sap.ui.getCore().byId("crVendorId").getSelectedKey();
					finalJson.crTransactionDo.vendorCode = sap.ui.getCore().byId("crVendorId").getSelectedKey();
					finalJson.crTransactionDo.vEmail = sap.ui.getCore().byId("crVendorEmailID").getValue();
					finalJson.crTransactionDo.vName = sap.ui.getCore().byId("crVendorId").getValue();
					finalJson.crTransactionDo.spmUserId = sap.ui.getCore().byId("crSPMId").getSelectedKey();
					finalJson.crTransactionDo.spmEmail = sap.ui.getCore().byId("crSpmEmailId").getValue();
					finalJson.crTransactionDo.paUserId = sap.ui.getCore().byId("crPAId").getSelectedKey();
					finalJson.crTransactionDo.paEmail = sap.ui.getCore().byId("crPAEmailID").getValue();
					finalJson.crTransactionDo.rmkrForVendor = sap.ui.getCore().byId("crVendorRemarksId").getValue();
					finalJson.crTransactionDo.rmkrForSPM = sap.ui.getCore().byId("crSpmRemarksId").getValue();
					finalJson.crTransactionDo.rmkrForPA = sap.ui.getCore().byId("crPARemarksId").getValue();
				}
			}

			var mdlObj = new sap.ui.model.json.JSONModel();
			var oHeader = {
				"Content-Type": "application/json;charset=utf-8"
			};
			mdlObj.loadData("/itspm_dm/changerequest",
				JSON.stringify(finalJson), false, "POST", false, false, oHeader);

			if (mdlObj.getData().status === 200) {
				var oFileUploader = this.getView().byId("crFileUploaderId");
				var oFormData = new FormData();
				if (this.createMode === "Created") {
					oFormData.append("vEmail", sap.ui.getCore().byId("crVendorEmailID").getValue());
					oFormData.append("paEmail", sap.ui.getCore().byId("crPAEmailID").getValue());
					oFormData.append("spmEmail", sap.ui.getCore().byId("crSpmEmailId").getValue());
				}
				oFormData.append("createdBy", this.getOwnerComponent().getModel("userLoginModel").getData().userDetail.userId);
				oFormData.append("crRefId", mdlObj.getData().createRequest);
				oFormData.append("crSlNo", mdlObj.getData().crSerialNumber);
				for (var i = 0; i < this.ofilesToUploadJson.getData().files.length; i++) {
					oFormData.append("data", this.ofilesToUploadJson.getData().files[i]);
				}
				var data = jQuery.ajax({
					url: "/itspm_dm/fileupload",
					data: oFormData,
					cache: false,
					contentType: false,
					processData: false,
					async: false,
					type: 'POST',
					success: function (oData) {
						return oData;
					}
				});

				if (oEvent) {
					oEvent.getSource().getParent().setBusy(false);
					oController.getView().getContent()[0].setBusy(false);
				} else {
					oController.getView().getContent()[0].setBusy(false);
				}

				var idCreatedMsg = mdlObj.getData().createRequest + " " + sMsgStatus + " successfully.";

				if (!data) {
					idCreatedMsg = idCreatedMsg + " Error in file uploading, try to upload fron Reporting";
				} else if (data.responseJSON.status !== 200) {
					idCreatedMsg = idCreatedMsg + " Error in file uploading, try to upload fron Reporting";
				}
				this._refreshCR();
				this.ofilesToUploadJson.setData({
					files: []
				});
				this.getView().byId("viewAttachmentId").setVisible(false);
				this._statusDialog("Success", "Success", idCreatedMsg);
			} else {
				if (oEvent) {
					oEvent.getSource().getParent().setBusy(false);
					oController.getView().getContent()[0].setBusy(false);
				} else {
					oController.getView().getContent()[0].setBusy(false);
				}
				this._statusDialog("Error", "Error", "Technical error. Please try again later");
			}
			if (oEvent) {
				oEvent.getSource().getParent().close();
				oEvent.getSource().getParent().destroy();
			}
		},
		
		/**
		 * To open success, error and warning message dialog 
		 * @param {String} title of dialog
		 * @param {String} status to update
		 * @param {String} text to display in content
		 */
		_statusDialog: function (title, status, text) {
			var oDialog = new sap.m.Dialog({
				title: title,
				type: "Message",
				state: status,
				content: new sap.m.Text({
					text: text
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function (oEvnt) {
						oDialog.close();
						oEvnt.getSource().getParent().close();
						oEvnt.getSource().getParent().destroy();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});
			oDialog.open();
		}
	});

});
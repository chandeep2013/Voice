sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("IT_SPM_DM.controller.RequestUser", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf IT_SPM_DM.view.RequestUser
		 */
			onInit: function() {
				var oController = this;
		if(oController.getOwnerComponent().getModel("userLoginModel") && oController.getOwnerComponent().getModel("userLoginModel").getData().userDetail){
					setTimeout(function(){
						var router = sap.ui.core.UIComponent.getRouterFor(oController);
						router.navTo("Dashboard");	
					}, 100);
					
				}
			},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf IT_SPM_DM.view.RequestUser
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf IT_SPM_DM.view.RequestUser
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf IT_SPM_DM.view.RequestUser
		 */
		//	onExit: function() {
		//
		//	}
		_refreshData : function(){
			var refreshModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(refreshModel,"refreshDataModel");
			this.getView().getModel("refreshDataModel").setData(null);
			this.getView().getModel("refreshDataModel").refresh();
			
			this.getView().getModel("refreshDataModel").destroy();
			this.getView().byId("requestUserpanelId").setVisible(false);
		},
			
		selectRequestUser : function(oEvent){
			var bCheckSelect = oEvent.getParameter("selected");
			if(bCheckSelect){
				var oOrgModel = new sap.ui.model.json.JSONModel();
				oOrgModel.loadData("/itspm_dm/organization",null,false); 
				this.getView().setModel(oOrgModel,"oOrgReqModelId");
				this._refreshData();
				this.getView().byId("requestUserpanelId").setVisible(true);
				this.getView().byId("reqUserOrgId").setEnabled(false);
            	this.getView().byId("reqUserRoleId").setSelectedItem(this.getView().byId("reqUserRoleId").getSelectableItems()[0]);
            	this.getView().byId("reqUserOrgId").insertItem(new sap.ui.core.Item({text : "--Select--"}),0);
            	this.getView().byId("reqUserOrgId").setSelectedItem(this.getView().byId("reqUserOrgId").getSelectableItems()[0]);
			}
			else{
				this.getView().byId("requestUserpanelId").setVisible(false);
			}
		},
		changeRole:function(){
			if(this.getView().byId("reqUserRoleId").getSelectedKey() === "Vendor"){
				this.getView().byId("reqUserOrgId").setEnabled(true);
			}else{
				this.getView().byId("reqUserOrgId").setEnabled(false);
			}
		},
		pressRequestNewUser : function(){
			var sValidFrom = new Date();
			var validFrom = sValidFrom.getDate() + "/" + (sValidFrom.getMonth() + 1) + "/" + sValidFrom.getFullYear();
			var sValidTo = new Date();
			var validTo = sValidTo.getDate() + "/" + (sValidTo.getMonth() + 1) + "/" + (sValidTo.getFullYear() + 3);
			
			if(this.getView().byId("reqUserRoleId").getSelectedKey() === "Vendor"){
				var vendorCode = this.getView().byId("reqUserOrgId").getSelectedKey();
				var orgName = this.getView().byId("reqUserOrgId").getSelectedItem().getText();
			}else{
				var vendorCode = "SAP";
				var orgName = "SAP";
			}
			var oData = {
				"userId" : this.getView().byId("reqUserEmpId").getValue(),
				"userName" : this.getView().byId("reqUserNameId").getValue(),
				"userTelNo" : "",
				"userEmail" : this.getView().byId("reqUserEmailId").getValue(),
				"userGroup" : this.getView().byId("reqUserRoleId").getSelectedKey(),
				"vendorCode" : vendorCode,
				"orgName" : orgName,
				"status" : "Inactive",
				"validTo" : validTo,
                "validFrom" : validFrom
			};
			
			var oUserAddModel = new sap.ui.model.json.JSONModel();
			var oHeader = {"Content-Type" : "application/json;charset=utf-8"};
			oUserAddModel.loadData("/itspm_dm/user",JSON.stringify(oData),false, "POST",false,false,oHeader);
			if(oUserAddModel.getData().status === 201){
				this._refreshData();
				this.getView().byId("reqUserCheckBox").setSelected(false);
				this._statusDialog("Success","Success","Request Sent successfully");
			}else if(oUserAddModel.getData().status === 204){
				this._statusDialog("Warning","Warning","User already exists.");
			}else {
				this._statusDialog("Error","Error","Technical error. Please try again later");
			}
		},
		_statusDialog:function(title,status,text){
			var oDialog = new sap.m.Dialog({
				title: title,
				type: "Message",
				state: status,
				content: new sap.m.Text({
					text: text
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function (oEvnt) {
						oDialog.close();
						oEvnt.getSource().getParent().close();
	        			oEvnt.getSource().getParent().destroy();
					}
				}),
				afterClose: function() {
					oDialog.destroy();
				}	
			});
	    	oDialog.open();
		}

	});

});
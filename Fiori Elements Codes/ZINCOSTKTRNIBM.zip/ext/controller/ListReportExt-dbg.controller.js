sap.ui.define([
	"sap/ui/model/odata/ODataUtils",
	"sap/ui/core/library",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (ODataUtils, coreLibrary, DateFormat, Filter, FilterOperator) {
	"use strict";
	var CalendarType = coreLibrary.CalendarType;
	return sap.ui.controller("com.ibm.zincostktrn.ext.controller.ListReportExt", {
		oFormatYyyymmdd: null,

		onBeforeRebindTableExtension: function (oEvent) {
			this.oFormatYyyymmdd = DateFormat.getInstance({
				pattern: "yyyy-MM-dd",
				calendarType: CalendarType.Gregorian
			});
			var oSmartTable = oEvent.getSource();
			var oSmartFilterBar = this.byId(oSmartTable.getSmartFilterId());
			oSmartTable.setUseExportToExcel(true);
			oSmartTable.setShowFullScreenButton(true);
			var aColumns = oSmartTable.getTable().getColumns();
			if (aColumns) {
				for (var i = 0; i < aColumns.length; i++) {
					//aColumns[i].setAutoResizable(true);
					aColumns[i].setWidth("10rem");
				}
			}

			var newFilters = [];
			var aFilters = oSmartFilterBar.getFilters();
			if (oSmartFilterBar instanceof sap.ui.comp.smartfilterbar.SmartFilterBar) {
				var oCustomControl = oSmartFilterBar.getControlByKey("P_keydate");
				if (oCustomControl instanceof sap.m.DatePicker) {
					var oDate = oCustomControl.getDateValue();
					var keyDate = this.oFormatYyyymmdd.format(oDate);
					keyDate = keyDate.replaceAll("-", "");
					oSmartTable.setTableBindingPath("/ZBW_CON_RTR_STOCKTRAN_002(P_keydate='" + keyDate + "')/Results");
					//oSmartTable.setTableBindingPath("/ZSTPCV_PRICE_BENCHMARK(p_waers='" + currency + "')/Results");
				}
				/*if (oSmartFilterBar.getFilterData()) {
					var oDate = oSmartFilterBar.getFilterData().PostingDate;
					if (oDate) {
						var sDate = new Date(oDate).getDay();
						var sMonth = new Date(oDate).getMonth() + 1;
						var sYear = new Date(oDate).getFullYear();
						//oDate = ODataUtils.formatValue(oDate.getTime(), "Edm.DateTime");
						//oSmartTable.setTableBindingPath("/ZBW_CON_RTR_STOCKTRAN_002(P_keydate=" + oDate + ")/Results");
						oSmartTable.setTableBindingPath("/ZBW_CON_RTR_STOCKTRAN_002(P_keydate='" + sYear + sMonth + sDate + "')/Results");
					}
				}*/
				/**Add custom filter for the 'Scope of List' check box values for the fields
				 *PurchasingDocumentType
				 *IsCompletelyDelivered
				 *DeletionIndicator
				 **/
				var oBindingParams = oEvent.getParameter("bindingParams"),
					oPurchasingDocumentType = oSmartFilterBar.getControlByKey("PurchasingDocumentType_key"),
					oFilter_PurchasingDocumentType = null;
				if (oPurchasingDocumentType.getSelected()) {
					//oFilter_PurchasingDocumentType = new Filter("PurchasingDocumentType", FilterOperator.EQ, "Z004");
					oFilter_PurchasingDocumentType = new Filter("SINTIndicator", FilterOperator.EQ, "X");
					
				} else {
					oFilter_PurchasingDocumentType = new Filter("SINTIndicator", FilterOperator.EQ, "");
				}

				if (aFilters && aFilters.length > 0 && aFilters[0].aFilters && aFilters[0].aFilters.length > 0) {
					$.each(aFilters[0].aFilters, function (i, oFilter) {
						if (oFilter.aFilters && oFilter.aFilters.length > 0) {
							newFilters.push(oFilter);
						} else {
							newFilters.push(oFilter);
						}
					});
					newFilters.push(oFilter_PurchasingDocumentType);
					oBindingParams.filters = newFilters;
					//}
				} else {
					newFilters.push(oFilter_PurchasingDocumentType);
					oBindingParams.filters = newFilters;
				}

			}
		},
		onInitSmartFilterBarExtension: function (oEvent) {
			// the custom field in the filter bar might have to be bound to a custom data model
			// if a value change in the field shall trigger a follow up action, this method is the 
			// place to define and bind an event handler to the field
			// Example:
			var oSmartFilterBar = oEvent.getSource();
			oSmartFilterBar.getControlByKey("P_keydate").setDateValue(new Date());
		},
		
		onDateChange: function (oEvent) {
			var oSource = oEvent.getSource();
			var bValid   = oEvent.getParameter("valid");
			if (!bValid) {
				oSource.setValueState("Error");
				var sErrorText = this.getView().getModel("i18n").getResourceBundle().getText("MESSAGE_KEYDATE_ERROR");
				oSource.setValueStateText(sErrorText);
			} else {
				oSource.setValueState("None");
				oSource.setValueStateText(null);
			}
		},
		
		//
		/*
		 * Content of the custom field shall be stored in the app state, so that it can be restored later again e.g. after a back navigation.
		 * @param oCustomData  : referance to the custome data.
		 */
		getCustomAppStateDataExtension: function (oCustomAppData) {
			/*
			var oCustomField1 = this.oView.byId("SampleFilterFieldID");
			if (oCustomField1) {
				oCustomAppData.SampleFilterFieldID = oCustomField1.getValue();
			}
			return oCustomAppData;
			*/
		},
		/*
		 * In order to restore content of the custom field in the filterbar e.g. after a back navigation.
		 * @param oCustomData  : referance to the custome data.
		 */
		restoreCustomAppStateDataExtension: function (oCustomAppData) {
			/*
			if (oCustomAppData.SampleFilterFieldID !== undefined) {
				if ( this.oView.byId("SampleFilterFieldID") ) {
					this.oView.byId("SampleFilterFieldID").setSelectedKey(oCustomAppData.SampleFilterFieldID);
				}
			}
			*/
		}

	});
});
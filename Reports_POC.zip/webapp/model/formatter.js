sap.ui.define([],function(){
	"use strict";
	return{
		StatusFormatter:function(sValue){
			
			if(sValue.indexOf("Approv") !== -1){
				return "Success";
			}
			else if(sValue.indexOf("Reject")  !== -1 || sValue.indexOf("Sent back")  !== -1){
				return "Error";
			}
			else if(sValue.indexOf("Saved")  !== -1 || sValue.indexOf("Submitted") !== -1){
				return "Warning";
			}
			
		},
		ButtonVisibilityFormatter:function(sValue){
			if(sValue === null){
				return true;
			}
			if(sValue.indexOf("Approv") !== -1 || sValue.indexOf("Reject")  !== -1 || sValue.indexOf("Submitted") !== -1){
				return false;
			}
			else if( sValue.indexOf("Sent back")  !== -1 || sValue.indexOf("Saved")  !== -1 ){
				return true;
			}
	},
		EditButtonVisibility:function(sValue,reqNo){
			if(reqNo === "--" || reqNo === ""){
				return false;
			}
			else{
			if(sValue === null){
				return true;
			}
			if(sValue.indexOf("Approv") !== -1 || sValue.indexOf("Reject")  !== -1 || sValue.indexOf("Submitted") !== -1){
				return false;
			}
			else if( sValue.indexOf("Sent back")  !== -1 || sValue.indexOf("Saved")  !== -1 ){
				return true;
			}
			}
		},
		ActionButtonVisibility:function(reqNo){
			if(reqNo === "--" || reqNo === ""){
				return false;
			}
			else{
				return true;
			}
		},
		deviceVisible:function(sValue){
			if(sValue === null || sValue === false){
				return false;
			}
			else{
				return true;
			}
		},
		onDateChange:function(dateChange,editable){
			if(editable === true || dateChange === true){
				return true;
			}
			else{
				return false;
			}
		},
		CostAssignmentRemove:function(editMode,Selected){
			
			if(editMode === true && Selected === true ){
				return true;
			}
			else {
				return false;
			}
			
		},
		TravelDetailRemove:function(editMode,Selected){
			
			if(editMode === true && Selected === true ){
				return true;
			}
			else {
				return false;
			}
			
		},
		AccomRemove:function(editMode,Selected){
			
			if(editMode === true && Selected === true ){
				return true;
			}
			else {
				return false;
			}
			
		},
		AdvRemove:function(editMode,Selected){
			
			if(editMode === true && Selected === true ){
				return true;
			}
			else {
				return false;
			}
		}
	};
});
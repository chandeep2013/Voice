sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"com/bosch/hr/swift_trv/model/formatter",
	"sap/m/ColumnListItem",
	"sap/m/Input",
	"sap/m/DatePicker",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function (Controller, MessageBox, JSONModel, Filter, MessageToast, formatter, ColumnListItem, Input, DatePicker, FilterOperator,
	Sorter) {
	"use strict";

	return Controller.extend("com.bosch.hr.swift_trv.controller.Detail", {
		formatter: formatter,
		onInit: function () {
			var that = this;
			this.oOwnerComponent = this.getOwnerComponent();

			this.oRouter = this.oOwnerComponent.getRouter();
			this.oModel = this.oOwnerComponent.getModel();

		//	this.oRouter.getRoute("master").attachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").attachPatternMatched(this._onProductMatched, this);

		
		

		},
		
		TemplateForTable:function(){
			var that = this;
				/************************* Cost Assignment Table********************************/

			this.CostAssigmenTable = this.byId("idCostAssigmenTable");
			this.oReadOnlyTemplate_C = this.byId("idCostAssigmenTable").removeItem(0);
			this.rebindTable_C(this.oReadOnlyTemplate_C, "Navigation");
			this.oEditableTemplate_C = new ColumnListItem({
				cells: [
					new Input({
						value: "",
						visible: false
					}),
					new Input({
						value: "{detail>percent}"
					}), new Input({
						value: "{detail>fund}",
						valueHelpRequest: function (oEvent) {
							if (!that._oDialogFund) {
								that._oDialogFund = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_Fund", that);
								that.getView().addDependent(that._oDialogFund);
							}
							that._oDialogFund.open();
							that.selectedPath = oEvent.getSource().getParent().getBindingContextPath();
						},
						textFormatMode: "KeyValue",
						showValueHelp: true,
						placeholder: "Fund",
						showSuggestion: true
					}), new Input({
						value: "{detail>budget}",
						textFormatMode: "KeyValue",
						showValueHelp: true,
						placeholder: "Budget",
						showSuggestion: true,
						valueHelpRequest: function (oEvent) {
							if (!that._oDialogBudget) {
								that._oDialogBudget = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_Budget", that);
								that.getView().addDependent(that._oDialogBudget);
							}
							that._oDialogBudget.open();
							that.selectedPath_budget = oEvent.getSource().getParent().getBindingContextPath();
						}
					}), new Input({
						value: "{detail>wbs}",
						textFormatMode: "KeyValue",
						showValueHelp: true,
						placeholder: "WBS",
						showSuggestion: true,
						valueHelpRequest: function (oEvent) {
							if (!that._oDialogWBS) {
								that._oDialogWBS = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_WBS", that);
								that.getView().addDependent(that._oDialogWBS);
							}
							that._oDialogWBS.open();
							that.selectedPath_WBS = oEvent.getSource().getParent().getBindingContextPath();
						}
					}),
					new Input({
						value: "{detail>cost}",
						textFormatMode: "KeyValue",
						showValueHelp: true,
						placeholder: "Cost Center",
						showSuggestion: true,
						valueHelpRequest: function (oEvent) {
							if (!that._oDialogCost) {
								that._oDialogCost = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_CostCenter", that);
								that.getView().addDependent(that._oDialogCost);
							}
							that._oDialogCost.open();
							that.selectedPath_cost = oEvent.getSource().getParent().getBindingContextPath();
						}
					}),
					new Input({
						value: "{detail>code}",
						textFormatMode: "KeyValue",
						showValueHelp: true,
						placeholder: "Code",
						showSuggestion: true,
						valueHelpRequest: function (oEvent) {
							if (!that._oDialogBudgetCode) {
								that._oDialogBudgetCode = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_BudgetCode", that);
								that.getView().addDependent(that._oDialogBudgetCode);
							}
							that._oDialogBudgetCode.open();
							that.selectedPath_BudgetCode = oEvent.getSource().getParent().getBindingContextPath();

						}
					})

				]
			});

			/*******************************************************************************/

			/************************* Travel Details Table********************************/
			this.TravelDetailTable = this.byId("idTravelDetailTable");
			this.oReadOnlyTemplate_T = this.byId("idTravelDetailTable").removeItem(0);
			this.rebindTable_T(this.oReadOnlyTemplate_T, "Navigation");
			this.oEditableTemplate_T = new ColumnListItem({
				cells: [
					new Input({
						value: "",
						visible: false
					}), new Input({
						value: "{detail>Traveller}"
					}), new sap.m.Input({
						value: "{detail>From}"
					}), new sap.m.Input({
						value: "{detail>To}"
					}), new sap.m.HBox({
						items: [new DatePicker({
							value: "{detail>Depdate}"
						}), new sap.m.TimePicker({
							value: "{detail>DeptTime}"
						})]
					}),

					new sap.m.HBox({
						items: [new DatePicker({
							value: "{detail>ArrDate}"
						}), new sap.m.TimePicker({
							value: "{detail>ArrTime}"
						})]
					}),
					new sap.m.Select({
						selectedKey: "{detail>Mode}",
						width: "100%",
						items: {
							path: 'detail>/TravelMode',
							templateShareable: false,
							template: new sap.ui.core.Item({
								key: "{detail>key}",
								text: "{detail>title}"
							})

						}
					})

				]
			});

			/**********************************************************/

			/************************* Accomdation Table********************************/

			this.AccomdationTable = this.byId("idAccomdationTable");
			this.oReadOnlyTemplate_ACC = this.byId("idAccomdationTable").removeItem(0);
			this.rebindTable_ACC(this.oReadOnlyTemplate_ACC, "Navigation");
			this.oEditableTemplate_ACC = new ColumnListItem({
				cells: [
					new Input({
						value: "",
						visible: false
					}),
					new Input({
						value: "{detail>place}"
					}), new DatePicker({
						value: "{detail>fromDate}"
					}), new DatePicker({
						value: "{detail>toDate}"
					}), new Input({
						value: "{detail>contact}"
					})
				]
			});

			/**********************************************************/

			/************************* Advance Table********************************/

			this.AdvanceTable = this.byId("idAdvanceTable");
			this.oReadOnlyTemplate_ADV = this.byId("idAdvanceTable").removeItem(0);
			this.rebindTable_ADV(this.oReadOnlyTemplate_ADV, "Navigation");
			this.oEditableTemplate_ADV = new ColumnListItem({
				cells: [
					new Input({
						value: "",
						visible: false
					}),
					new sap.m.Select({
						selectedKey: "{detail>Currency}",
						width: "100%",
						items: {
							path: 'detail>/Currency',
							templateShareable: false,
							template: new sap.ui.core.Item({
								key: "{detail>key}",
								text: "{detail>title}"
							})

						}
					}),
					new Input({
						value: "{detail>Boarding}"
					}),
					new Input({
						value: "{detail>Lodging}"
					}), new Input({
						value: "{detail>Others}"
					}),
					new Input({
						value: "{detail>Total}"
					})
				]
			});

			/**********************************************************/
		},
		rebindTable_C: function (oTemplate, sKeyboardMode) {
			this.CostAssigmenTable.bindItems({
				path: "detail>/CostAssignment",
				template: oTemplate,
				templateShareable: true,
				key: "fund"
			}).setKeyboardMode(sKeyboardMode);
		},
		rebindTable_T: function (oTemplate, sKeyboardMode) {
			this.TravelDetailTable.bindItems({
				path: "detail>/Travel",
				template: oTemplate,
				templateShareable: true,
				key: "Traveller"
			}).setKeyboardMode(sKeyboardMode);
		},

		rebindTable_ACC: function (oTemplate, sKeyboardMode) {
			this.AccomdationTable.bindItems({
				path: "detail>/Accomdation",
				template: oTemplate,
				templateShareable: true,
				key: "place"
			}).setKeyboardMode(sKeyboardMode);
		},
		rebindTable_ADV: function (oTemplate, sKeyboardMode) {
			this.AdvanceTable.bindItems({
				path: "detail>/Advance",
				template: oTemplate,
				templateShareable: true,
				key: "Currency"
			}).setKeyboardMode(sKeyboardMode);
		},
		onAfterRendering: function () {

			var Device = sap.ui.Device.system.desktop;
			if (Device === true || sap.ui.Device.system.tablet) {
				this.getView().byId("idCostAssigmenTable").getInfoToolbar().setVisible(true);
				this.getView().byId("idTravelDetailTable").getInfoToolbar().setVisible(true);
				this.getView().byId("idAccomdationTable").getInfoToolbar().setVisible(true);
				this.getView().byId("idAdvanceTable").getInfoToolbar().setVisible(true);

			} else {
				this.getView().byId("idCostAssigmenTable").getInfoToolbar().setVisible(false);
				this.getView().byId("idTravelDetailTable").getInfoToolbar().setVisible(false);
				this.getView().byId("idAccomdationTable").getInfoToolbar().setVisible(false);
				this.getView().byId("idAdvanceTable").getInfoToolbar().setVisible(false);

			}
			this.getView().byId("idTravelHideColumn").setWidth("1px");
			this.getView().byId("idCostAssingmentColumn").setWidth("1px");
			this.getView().byId("idAccommodationColumn").setWidth("1px");
			this.getView().byId("idAdvanceColumn").setWidth("1px");

		},

		edit_Elements: function () {

			var objPage = this.byId("idObjPage");
			objPage.removeAllBlocks();
			objPage.addBlock(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.General.ChangeForm", this));

			this.rebindTable_C(this.oEditableTemplate_C, "Edit");
			this.rebindTable_T(this.oEditableTemplate_T, "Edit");
			this.rebindTable_ACC(this.oEditableTemplate_ACC, "Edit");
			this.rebindTable_ADV(this.oEditableTemplate_ADV, "Edit");

			this.getView().byId("idCostAssigmenTable").setMode("MultiSelect");
			this.getView().byId("idTravelDetailTable").setMode("MultiSelect");
			this.getView().byId("idAccomdationTable").setMode("MultiSelect");
			this.getView().byId("idAdvanceTable").setMode("MultiSelect");

			this.getView().byId("idCostAssigmenTable").getHeaderToolbar().setVisible(true);
			this.getView().byId("idTravelDetailTable").getHeaderToolbar().setVisible(true);
			this.getView().byId("idAccomdationTable").getHeaderToolbar().setVisible(true);

			setTimeout(function () {
				$(".sapMListTblSubCntRow").css("cssText", "display: block !important;");
				$(".sapMListTbl .sapMLabel").css("cssText", "width: auto !important;");
				$(".sapMListTblSubCntSpr").css("cssText", "display: None !important;");
			}, 100);

		},
		nonedit_Elements: function () {

			var objPage = this.byId("idObjPage");
			objPage.removeAllBlocks();
			objPage.addBlock(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.General.DisplayForm", this));

			this.rebindTable_C(this.oReadOnlyTemplate_C, "Navigation");
			this.rebindTable_T(this.oReadOnlyTemplate_T, "Navigation");
			this.rebindTable_ACC(this.oReadOnlyTemplate_ACC, "Navigation");
			this.rebindTable_ADV(this.oReadOnlyTemplate_ADV, "Navigation");

			this.getView().byId("idCostAssigmenTable").setMode("None");
			this.getView().byId("idTravelDetailTable").setMode("None");
			this.getView().byId("idAccomdationTable").setMode("None");
			this.getView().byId("idAdvanceTable").setMode("None");

			this.getView().byId("idCostAssigmenTable").getHeaderToolbar().setVisible(false);
			this.getView().byId("idTravelDetailTable").getHeaderToolbar().setVisible(false);
			this.getView().byId("idAccomdationTable").getHeaderToolbar().setVisible(false);

			setTimeout(function () {
				$(".sapMListTblSubCntRow").css("cssText", "display: -webkit-box !important;");
				$(".sapMListTbl .sapMLabel").css("cssText", "width: 7.8rem !important;");
				$(".sapMListTblSubCntSpr").css("cssText", "display: .5rem !important;");
			}, 100);
		},
		onPressAdvance: function () {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.General.Common.AdvancesAsPerPolicy", this);
				//	this._oDialog = sap.ui.xmlfragment("com.Tricon.Learn.FragmentsForViews.Test", this);
				this.getView().addDependent(this._oDialog);
			}
			this._oDialog.open();
		},
		onClosePopup: function () {
			this._oDialog.close();
			//this._oDialog.destroy();
		},

		_onProductMatched: function (oEvent) {
			var that= this;
				var detailModel = new JSONModel();
			var get = $.ajax({
				cache: false,
				url: "model/data.json",
				type: "GET",
				async: false
			});
			get.done(function (result) {
				detailModel.setData(result);
				that.getView().setModel(detailModel, "detail");
				that.TemplateForTable();
			});
			get.fail(function (err) {
				/*	console.log(err);*/
			});
			
			this._product = oEvent.getParameter("arguments").product || this._product || "0";
			this.getView().bindElement({
				path: "/ProductCollection/" + this._product,
				model: "products"
			});

			if (parseInt(this._product) >= 10) {
				var model = this.getView().getModel("detail").getData();
				model.CostAssignment = [];
				model.CostAssignment.push({
					"percent": "",
					"fund": "",
					"budget": "",
					"wbs": "",
					"cost": "",
					"code": ""
				});

				model.Travel = [];
				model.Travel.push({
					"type": "BUSR",
					"Traveller": "Chandeep",
					"From": "India",
					"To": "Germany",
					"Depdate": "",
					"DeptTime": "",
					"ArrDate": "",
					"ArrTime": "",
					"Mode": ""
				});

				model.Accomdation = [];
				model.Accomdation.push({
					"place": "",
					"fromDate": "",
					"toDate": "",
					"contact": ""
				});
				this.edit_Elements();
				this.getView().getModel("detail").refresh();
				this.getView().getModel("products").getData().editable = true;
				this.getView().getModel("products").refresh();
				var oObjectPage = this.getView().byId("ObjectPageLayout");
				oObjectPage.setShowFooter(true);
			} else {
				this.nonedit_Elements();
			    oObjectPage = this.getView().byId("ObjectPageLayout");
				oObjectPage.setShowFooter(false);
				this.getView().getModel("products").getData().editable = false;
				this.getView().getModel("products").refresh();
			}
		},
		onPressSave: function (val) {
			if (val == "Submit") {
				var Msg = "TR Submitted";
			} else {
				var Msg = "TR Saved";
			}
			this.getView().getModel("products").getData().editable = false;
			this.getView().getModel("products").refresh();

			var oObjectPage = this.getView().byId("ObjectPageLayout");
			oObjectPage.setShowFooter(false);
			sap.ui.getCore().getModel("products").getData().butonVisible = true;
			sap.ui.getCore().getModel("products").getData().busy = false;
			sap.ui.getCore().getModel('products').refresh();
			var data = this.getView().getModel("products").getData().ProductCollection[this._product];
			if (data.RequestNo == "--") {
				var req = this.getView().getModel("products").getData().ProductCollection[this._product - 1].RequestNo;
				var updated = parseInt(req) + 1;
				data.RequestNo = updated;
				data.Status = Msg;
				this.getView().getModel("products").refresh();
			}
			sap.m.MessageBox.confirm(data.RequestNo + "-" + Msg + "Successfully..!!!", {
				icon: MessageBox.Icon.INFORMATION,
				title: "Success",
				actions: [MessageBox.Action.OK],
				onClose: function (oAction) {}
			});
			this.nonedit_Elements();
		},
		onPressSubmit: function () {
			var val = "Submit";
			this.onPressSave(val);
		},
		onPressCancel: function () {
			this.getView().getModel("products").getData().editable = false;
			this.getView().getModel("products").refresh();
			/*this.getView().byId("idTripEndDate").setEditable(false);*/
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			oObjectPage.setShowFooter(false);
		},
		onSelectSimCard: function (evt) {
			//	var val = parseInt(this._product);
			//	var selected = this.getView().getModel("products").getData().ProductCollection[val].Sim;
			if (evt.getSource().getSelectedItem().getText() == "No") {
				this.getView().getModel("products").getData().simVisible = false;
			} else {
				this.getView().getModel("products").getData().simVisible = true;
			}
			this.getView().getModel("products").refresh();
		},

		onEditToggleButtonPress: function () {
			var oObjectPage = this.getView().byId("ObjectPageLayout"),
				bCurrentShowFooterState = oObjectPage.getShowFooter();
			oObjectPage.setShowFooter(!bCurrentShowFooterState);

			if (!bCurrentShowFooterState == true) {
				this.getView().getModel("products").getData().editable = true;
				this.getView().getModel("products").getData().busy = true;
				this.getView().getModel("products").refresh();
				sap.ui.getCore().getModel("products").getData().butonVisible = false;
				sap.ui.getCore().getModel("products").getData().busy = true;
				sap.ui.getCore().getModel('products').refresh();
				this.edit_Elements();
			} else {
				this.getView().getModel("products").getData().editable = false;
				this.getView().getModel("products").getData().busy = false;
				this.getView().getModel("products").refresh();
				sap.ui.getCore().getModel("products").getData().butonVisible = true;
				sap.ui.getCore().getModel("products").getData().busy = false;
				sap.ui.getCore().getModel('products').refresh();
				this.nonedit_Elements();

			}
		},

		handleFullScreen: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.oRouter.navTo("detail", {
				layout: sNextLayout,
				product: this._product
			});
		},

		handleExitFullScreen: function () {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
			this.oRouter.navTo("detail", {
				layout: sNextLayout,
				product: this._product
			});
		},

		handleClose: function () {
			this.nonedit_Elements();
			this.rebindTable_C(this.oReadOnlyTemplate_C, "Navigation");
			this.rebindTable_T(this.oReadOnlyTemplate_T, "Navigation");
			this.rebindTable_ACC(this.oReadOnlyTemplate_ACC, "Navigation");
			this.rebindTable_ADV(this.oReadOnlyTemplate_ADV, "Navigation");
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			oObjectPage.setShowFooter(false);
			sap.ui.getCore().getModel("products").getData().busy = false;
			sap.ui.getCore().getModel('products').refresh();
			this.getView().getModel("products").getData().editable = false;
			sap.ui.getCore().getModel("products").getData().butonVisible = true;
			this.getView().getModel("products").refresh();
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
			this.oRouter.navTo("master", {
				layout: sNextLayout
			});
		},

		onExit: function () {
		//	this.oRouter.getRoute("master").detachPatternMatched(this._onProductMatched, this);
		//	this.oRouter.getRoute("detail").detachPatternMatched(this._onProductMatched, this);
		},
		onActionSheet: function (oEvent) {
			var oButton = oEvent.getSource();

			// create action sheet only once
			if (!this._actionSheet) {
				this._actionSheet = sap.ui.xmlfragment(
					"com.bosch.hr.swift_trv.Fragments.Common.ActionSheet",
					this
				);
				this.getView().addDependent(this._actionSheet);
			}

			this._actionSheet.openBy(oButton);
		},
		onUserInfo: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Reports", {
					layout: "MidColumnFullScreen"
				});
		},
		onTicketing: function (oEvent) {
			var that = this;
			var productPath = oEvent.getSource().getBindingContext("products").getPath(),
				product = productPath.split("/").slice(-1).pop(),
				oNextUIState;
			this.getOwnerComponent().getHelper().then(function (oHelper) {
				oNextUIState = oHelper.getNextUIState(1);
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Ticketing", {
					layout: "MidColumnFullScreen",
					product: product
				});
			}.bind(this));

		},
		onCreateInsurance: function (oEvent) {
			var that = this;
			var productPath = oEvent.getSource().getBindingContext("products").getPath(),
				product = productPath.split("/").slice(-1).pop(),
				oNextUIState;
			this.getOwnerComponent().getHelper().then(function (oHelper) {
				oNextUIState = oHelper.getNextUIState(1);
				that.oRouter.navTo("Insurance", {
					layout: "MidColumnFullScreen",
					product: product
				});
			}.bind(that));
		},
		onDateChange: function () {
			//this.edit_Elements();
			var objPage = this.byId("idObjPage");
			objPage.removeAllBlocks();
			objPage.addBlock(sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.General.ChangeForm", this));
			this.getView().getModel("products").getData().dateChange = true;
			this.getView().getModel("products").getData().editable = false;
			this.getView().getModel("products").refresh();
			var oObjectPage = this.getView().byId("ObjectPageLayout");
			oObjectPage.setShowFooter(true);

		},
		onCancelRequest: function () {
			sap.m.MessageBox.information("Confirm your Cancellation", {
				actions: ["Submit Request", MessageBox.Action.CLOSE],
				emphasizedAction: "Submit Request",
				onClose: function (sAction) {
					MessageToast.show("Action selected: " + sAction);
				}
			});
		},

		onValueHelpRequest_Fund: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			if (!this._oDialogFund) {
				this._oDialogFund = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_Fund", this);
				this.getView().addDependent(this._oDialogFund);
			}
			this._oDialogFund.open();
			this.selectedPath = oEvent.getSource().getParent().getBindingContextPath();
		},
		_handleValueHelpClose_fund: function (evt) {
			/*var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				this.getView().getModel("detail").getProperty(this.selectedPath).fund = oSelectedItem.getTitle();
				this.getView().getModel("detail").refresh();
			}
			this._oDialogFund.getBinding("items").filter([]);*/
			var selectedItem = evt.getSource().getTitle();
			this.getView().getModel("detail").getProperty(this.selectedPath).fund = selectedItem;
			this.getView().getModel("detail").refresh();
			this._oDialogFund.close();

		},
		onFundCancel: function () {
			this._oDialogFund.close();
		},

		onValueHelpRequest_Budget: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			if (!this._oDialogBudget) {
				this._oDialogBudget = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_Budget", this);
				this.getView().addDependent(this._oDialogBudget);
			}
			this._oDialogBudget.open();
			this.selectedPath_budget = oEvent.getSource().getParent().getBindingContextPath();
		},
		_handleValueHelpClose_budget: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				this.getView().getModel("detail").getProperty(this.selectedPath_budget).budget = oSelectedItem.getTitle();
				this.getView().getModel("detail").refresh();
			}
			this._oDialogBudget.getBinding("items").filter([]);
		},
		onValueHelpRequest_BudgetCode: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			if (!this._oDialogBudgetCode) {
				this._oDialogBudgetCode = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_BudgetCode", this);
				this.getView().addDependent(this._oDialogBudgetCode);
			}
			this._oDialogBudgetCode.open();
			this.selectedPath_BudgetCode = oEvent.getSource().getParent().getBindingContextPath();
		},
		_handleValueHelpClose_budgetCode: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				this.getView().getModel("detail").getProperty(this.selectedPath_BudgetCode).code = oSelectedItem.getTitle();
				this.getView().getModel("detail").refresh();
			}
			this._oDialogBudgetCode.getBinding("items").filter([]);
		},
		onValueHelpRequest_WBS: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			if (!this._oDialogWBS) {
				this._oDialogWBS = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_WBS", this);
				this.getView().addDependent(this._oDialogWBS);
			}
			this._oDialogWBS.open();
			this.selectedPath_WBS = oEvent.getSource().getParent().getBindingContextPath();
		},
		_handleValueHelpClose_wbs: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				this.getView().getModel("detail").getProperty(this.selectedPath_WBS).wbs = oSelectedItem.getTitle();
				this.getView().getModel("detail").refresh();
			}
			this._oDialogWBS.getBinding("items").filter([]);
		},

		onValueHelpRequest_Cost: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue();
			if (!this._oDialogCost) {
				this._oDialogCost = sap.ui.xmlfragment("com.bosch.hr.swift_trv.Fragments.F4Help.SuggestionItems_CostCenter", this);
				this.getView().addDependent(this._oDialogCost);
			}
			this._oDialogCost.open();
			this.selectedPath_cost = oEvent.getSource().getParent().getBindingContextPath();
		},
		_handleValueHelpClose_cost: function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				this.getView().getModel("detail").getProperty(this.selectedPath_cost).cost = oSelectedItem.getTitle();
				this.getView().getModel("detail").refresh();
			}
			this._oDialogCost.getBinding("items").filter([]);
		},

		onAddCostAssignment: function () {
			var model = this.getView().getModel("detail").getData();
			model.CostAssignment.push({
				"percent": "",
				"fund": "",
				"budget": "",
				"wbs": "",
				"cost": "",
				"code": ""
			});
			this.getView().getModel("detail").refresh();
		},
		onDeleteRow: function (oEvent) {
			var model = this.getView().getModel("detail").getData();
			if (oEvent.getSource().getParent().getParent().getId().indexOf("idCostAssigmenTable") != -1) {
				var aTable = this.getView().byId("idCostAssigmenTable");
				var DataArray = model.CostAssignment;
			} else if (oEvent.getSource().getParent().getParent().getId().indexOf("idTravelDetailTable") != -1) {
				var aTable = this.getView().byId("idTravelDetailTable");
				var DataArray = model.Travel;
			} else if (oEvent.getSource().getParent().getParent().getId().indexOf("idAccomdationTable") != -1) {
				var aTable = this.getView().byId("idAccomdationTable");
				var DataArray = model.Accomdation;
			} else if (oEvent.getSource().getParent().getParent().getId().indexOf("idAdvanceTable") != -1) {
				var aTable = this.getView().byId("idAdvanceTable");
				var DataArray = model.Advance;
			}
			var sItems = aTable.getSelectedItems();
			if (sItems.length == 0) {
				sap.m.MessageBox.show(
					"Please select a row", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {}
					}
				);
			} else {
				for (var i = sItems.length - 1; i >= 0; i--) {
					var path = sItems[i].getBindingContextPath();
					var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));
					DataArray.splice(idx, 1);
					this.getView().getModel("detail").refresh();
					sap.m.MessageToast.show("Deleted Suessfully");
				}
			}
		},
		onAddTravelDetail: function () {
			var model = this.getView().getModel("detail").getData();
			model.Travel.push({
				"type": "BUSR",
				"Traveller": "Chandeep",
				"From": "",
				"To": "",
				"Depdate": "",
				"DeptTime": "",
				"ArrDate": "",
				"ArrTime": "",
				"Mode": ""
			});
			this.getView().getModel("detail").refresh();
		},
		onAddAccomdation: function () {
			var model = this.getView().getModel("detail").getData();
			model.Accomdation.push({
				"place": "",
				"fromDate": "",
				"toDate": "",
				"contact": ""
			});
			this.getView().getModel("detail").refresh();
		},
		onAddAdvance: function () {
			var model = this.getView().getModel("detail").getData();
			if (model.Advance.length > 2) {
				sap.m.MessageToast.show("You can add 3 rows only");
			} else {
				model.Advance.push({
					"Currency": "",
					"Boarding": "",
					"Lodging": "",
					"Others": "",
					"Total": ""
				});
				this.getView().getModel("detail").refresh();
			}
		},
		onSelectCostAssignemnt: function () {
			var table = this.getView().byId("idCostAssigmenTable").getSelectedItems();
			if (table.length >= 1) {
				this.getView().getModel("products").getData().Costeditable = true;
			} else {
				this.getView().getModel("products").getData().Costeditable = false;
			}
			this.getView().getModel("products").refresh();
		},
		onSelectTravelDetail: function () {

			var table = this.getView().byId("idTravelDetailTable").getSelectedItems();
			if (table.length >= 1) {
				this.getView().getModel("products").getData().Traveleditable = true;
			} else {
				this.getView().getModel("products").getData().Traveleditable = false;
			}
			this.getView().getModel("products").refresh();

		},
		onSelectAccom: function () {

			var table = this.getView().byId("idAccomdationTable").getSelectedItems();
			if (table.length >= 1) {
				this.getView().getModel("products").getData().AccomEditable = true;
			} else {
				this.getView().getModel("products").getData().AccomEditable = false;
			}
			this.getView().getModel("products").refresh();

		},
		onSelectAdv: function () {
			var table = this.getView().byId("idAdvanceTable").getSelectedItems();
			if (table.length >= 1) {
				this.getView().getModel("products").getData().AdvEditable = true;
			} else {
				this.getView().getModel("products").getData().AdvEditable = false;
			}
			this.getView().getModel("products").refresh();
		},

		_handleValueHelpSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("title", FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		OnSearchFund: function () {
			//var sQuery = oEvent.getParameter("query");
			var sQuery = sap.ui.getCore().byId("idSearchFund").getValue();
			var Fund = new sap.ui.model.Filter("title", sap.ui.model.FilterOperator.Contains, sQuery);
			var Desc = new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sQuery);

			var filters = new sap.ui.model.Filter([Fund, Desc]);
			var listassign = sap.ui.getCore().byId("idList");
			listassign.getBinding("items").filter(filters, "Appliation");
		},
		onSortFund: function (oEvent) {
			var selectedButton = oEvent.getSource().getText();
			var value = "";
			if (selectedButton == "Ascending") {
				value = "title";
				var oBinding = sap.ui.getCore().byId("idList").getBinding("items"),
					oSorter = new Sorter(value, false);
			} else {
				value = "title";
				var oBinding = sap.ui.getCore().byId("idList").getBinding("items"),
					oSorter = new Sorter(value, true);
			}
			oBinding.sort(oSorter);
		},
		ShowEndColumn:function(){
			var product = this.getView().getModel("products").getData().ProductCollection.length - 1;
				var oNextUIState;
			this.getOwnerComponent().getHelper().then(function (oHelper) {
				oNextUIState = oHelper.getNextUIState(1);
				this.oRouter.navTo("detailDetail", {
					layout: "ThreeColumnsEndExpanded",
					product: product
				});
			}.bind(this));
		}
	});

});
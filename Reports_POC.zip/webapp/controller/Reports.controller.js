sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/suite/ui/commons/ChartContainer",
	"sap/suite/ui/commons/ChartContainerContent"
], function (Controller, ChartContainer, ChartContainerContent) {
	"use strict";

	return Controller.extend("com.bosch.hr.swift_trv.controller.Reports", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.bosch.hr.swift_trv.view.Reports
		 */
		onInit: function () {
			this.oOwnerComponent = this.getOwnerComponent();
			this.oRouter = this.oOwnerComponent.getRouter();
			this.oRouter.getRoute("Reports").attachPatternMatched(this._onvizCharts, this);
		},
		_onvizCharts: function () {
			var that = this;
			var vizModel = new sap.ui.model.json.JSONModel();
			//	Model.loadData("model/expense.json");
			var data = "";
			var that = this;
			//	vizModel.setData("");
			//	sap.ui.getCore().setModel(vizModel, "data");
			$.ajax({
				url: "model/reports.json",
				dataType: "json",
				async: false,
				type: "GET",
				complete: function (xhr, status) {},
				success: function (response) {
					data = response;
					vizModel.setData(response);
					sap.ui.getCore().setModel(vizModel, "data");
					that.getView().setModel(vizModel, "data");
				},
				error: function (textStatus, errorThrown) {
					data = textStatus.responseText;
				}
			});

			var oView = this.getView();
			this.expandmyChart(oView, "idVizFrame1", "Cell1");
			this.expandmyChart(oView, "idVizFrame2", "Cell2");
			this.expandmyChart(oView, "idVizFrame3", "Cell3");
			this.expandmyChart(oView, "idVizFrame4", "Cell4");
			this.expandmyChart(oView, "idVizFrame5", "Cell5");
			this.expandmyChart(oView, "idVizFrame6", "Cell6");
			this.expandmyChart(oView, "idVizFrame7", "Cell7");
			this.expandmyChart(oView, "idVizFrame8", "Cell8");
			this.expandmyChart(oView, "idVizFrame9", "Cell10");
			this.expandmyChart(oView, "idVizFrame9", "Cell10");

			this.popOverChart(oView, "idVizFrame1", "idPopOver1");
			this.popOverChart(oView, "idVizFrame2", "idPopOver2");
			this.popOverChart(oView, "idVizFrame3", "idPopOver3");
			this.popOverChart(oView, "idVizFrame4", "idPopOver4");
			this.popOverChart(oView, "idVizFrame5", "idPopOver5");
			this.popOverChart(oView, "idVizFrame6", "idPopOver6");
			this.popOverChart(oView, "idVizFrame7", "idPopOver7");
			this.popOverChart(oView, "idVizFrame8", "idPopOver8");
			this.popOverChart(oView, "idVizFrame9", "idPopOver10");
			this.popOverChart(oView, "idVizFrame9", "idPopOver10");

			this.twoSeriesChart(oView, "idVizFrame1", "valueAxisFeed1");
			this.twoSeriesChart(oView, "idVizFrame2", "valueAxisFeed2");
			this.twoSeriesChart(oView, "idVizFrame3", "valueAxisFeed3");
			this.Combination(oView, "idVizFrame10", "valueAxisFeed10");
		},
		twoSeriesChart:function(oView,sChart,seriesId){
			var value = ["Milk", "Tea","Sugar"];
			var oVizFrame = oView.byId(sChart);
			var feedValueAxis1 = this.getView().byId(seriesId);
			oVizFrame.removeFeed(feedValueAxis1);
			feedValueAxis1.setValues(value);
			oVizFrame.addFeed(feedValueAxis1);
		},
		popOverChart: function (oView, sChart, sPopOverId) {
			var oVizFrame = oView.byId(sChart);
			var oPopOver = this.getView().byId(sPopOverId);
			oPopOver.connect(oVizFrame.getVizUid());
		},
		expandmyChart: function (oView, sChart, sBlockId) {
			var vizFrame = oView.byId(sChart);
			var oChartContainerContent = new ChartContainerContent({
				content: [vizFrame]
			});
			var oChartContainer = new ChartContainer({
				content: [oChartContainerContent]
			});
			oChartContainer.setShowFullScreen(true);
			oChartContainer.setAutoAdjustHeight(true);
			oView.byId(sBlockId).addContent(oChartContainer);
		},
		navButtonPress: function () {
			//window.history.go(-1);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1", {
				layout: "OneColumn"
			});
		},
		onPressColumn:function(){
			var chart = this.getView().byId("idVizFrame8");
			chart.setVizType("column");
		},
		Combination:function(oView, sChart, seriesId){
			var value = ["DEPU", "BUSR", "INFO", "SECO", "DEPUAvgDuration", "BUSRAvgDuration","INFOAvgDuration","HOMEAvgDuration"];
			var oVizFrame = oView.byId(sChart);
			var feedValueAxis1 = this.getView().byId(seriesId);
			oVizFrame.removeFeed(feedValueAxis1);
			feedValueAxis1.setValues(value);
			oVizFrame.addFeed(feedValueAxis1);
			oVizFrame.setVizProperties({
				plotArea: {
					dataShape: {
						primaryAxis: ['bar', 'bar', 'bar', 'bar', 'line','line','line'],
						secondaryAxis: ['line', 'line', 'line']
					}
				}
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.bosch.hr.swift_trv.view.Reports
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.bosch.hr.swift_trv.view.Reports
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.bosch.hr.swift_trv.view.Reports
		 */
		//	onExit: function() {
		//
		//	}

	});

});